gdjs.C9Code = {};
gdjs.C9Code.GDcaseObjects1= [];
gdjs.C9Code.GDcaseObjects2= [];
gdjs.C9Code.GDimageObjects1= [];
gdjs.C9Code.GDimageObjects2= [];
gdjs.C9Code.GDoffObjects1= [];
gdjs.C9Code.GDoffObjects2= [];
gdjs.C9Code.GDonObjects1= [];
gdjs.C9Code.GDonObjects2= [];
gdjs.C9Code.GDstartObjects1= [];
gdjs.C9Code.GDstartObjects2= [];
gdjs.C9Code.GDBObjects1= [];
gdjs.C9Code.GDBObjects2= [];
gdjs.C9Code.GDblackObjects1= [];
gdjs.C9Code.GDblackObjects2= [];
gdjs.C9Code.GDAObjects1= [];
gdjs.C9Code.GDAObjects2= [];
gdjs.C9Code.GDbuttonObjects1= [];
gdjs.C9Code.GDbuttonObjects2= [];

gdjs.C9Code.conditionTrue_0 = {val:false};
gdjs.C9Code.condition0IsTrue_0 = {val:false};
gdjs.C9Code.condition1IsTrue_0 = {val:false};
gdjs.C9Code.conditionTrue_1 = {val:false};
gdjs.C9Code.condition0IsTrue_1 = {val:false};
gdjs.C9Code.condition1IsTrue_1 = {val:false};


gdjs.C9Code.mapOfGDgdjs_46C9Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.C9Code.GDbuttonObjects1});gdjs.C9Code.mapOfGDgdjs_46C9Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.C9Code.GDoffObjects1});gdjs.C9Code.mapOfGDgdjs_46C9Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.C9Code.GDonObjects1});gdjs.C9Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.C9Code.condition0IsTrue_0.val = false;
{
{gdjs.C9Code.conditionTrue_1 = gdjs.C9Code.condition0IsTrue_0;
gdjs.C9Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(94036564);
}
}if (gdjs.C9Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter5_v6.mp3", true, 80, 1);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.C9Code.GDbuttonObjects1);

gdjs.C9Code.condition0IsTrue_0.val = false;
{
gdjs.C9Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C9Code.mapOfGDgdjs_46C9Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.C9Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s333", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.C9Code.GDoffObjects1);

gdjs.C9Code.condition0IsTrue_0.val = false;
{
gdjs.C9Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C9Code.mapOfGDgdjs_46C9Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.C9Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.C9Code.GDonObjects1);

gdjs.C9Code.condition0IsTrue_0.val = false;
{
gdjs.C9Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C9Code.mapOfGDgdjs_46C9Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.C9Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.C9Code.condition0IsTrue_0.val = false;
{
gdjs.C9Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.C9Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s333", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.C9Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.C9Code.GDcaseObjects1.length = 0;
gdjs.C9Code.GDcaseObjects2.length = 0;
gdjs.C9Code.GDimageObjects1.length = 0;
gdjs.C9Code.GDimageObjects2.length = 0;
gdjs.C9Code.GDoffObjects1.length = 0;
gdjs.C9Code.GDoffObjects2.length = 0;
gdjs.C9Code.GDonObjects1.length = 0;
gdjs.C9Code.GDonObjects2.length = 0;
gdjs.C9Code.GDstartObjects1.length = 0;
gdjs.C9Code.GDstartObjects2.length = 0;
gdjs.C9Code.GDBObjects1.length = 0;
gdjs.C9Code.GDBObjects2.length = 0;
gdjs.C9Code.GDblackObjects1.length = 0;
gdjs.C9Code.GDblackObjects2.length = 0;
gdjs.C9Code.GDAObjects1.length = 0;
gdjs.C9Code.GDAObjects2.length = 0;
gdjs.C9Code.GDbuttonObjects1.length = 0;
gdjs.C9Code.GDbuttonObjects2.length = 0;

gdjs.C9Code.eventsList0(runtimeScene);
return;

}

gdjs['C9Code'] = gdjs.C9Code;
