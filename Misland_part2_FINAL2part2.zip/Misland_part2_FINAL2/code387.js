gdjs.s344Code = {};
gdjs.s344Code.GDcaseObjects1= [];
gdjs.s344Code.GDcaseObjects2= [];
gdjs.s344Code.GDimageObjects1= [];
gdjs.s344Code.GDimageObjects2= [];
gdjs.s344Code.GDoffObjects1= [];
gdjs.s344Code.GDoffObjects2= [];
gdjs.s344Code.GDonObjects1= [];
gdjs.s344Code.GDonObjects2= [];
gdjs.s344Code.GDstartObjects1= [];
gdjs.s344Code.GDstartObjects2= [];
gdjs.s344Code.GDBObjects1= [];
gdjs.s344Code.GDBObjects2= [];
gdjs.s344Code.GDAObjects1= [];
gdjs.s344Code.GDAObjects2= [];
gdjs.s344Code.GDcrosshairsObjects1= [];
gdjs.s344Code.GDcrosshairsObjects2= [];
gdjs.s344Code.GDDOWNbuttonObjects1= [];
gdjs.s344Code.GDDOWNbuttonObjects2= [];
gdjs.s344Code.GDDOWNcolObjects1= [];
gdjs.s344Code.GDDOWNcolObjects2= [];
gdjs.s344Code.GDUPbuttonObjects1= [];
gdjs.s344Code.GDUPbuttonObjects2= [];
gdjs.s344Code.GDUPcolObjects1= [];
gdjs.s344Code.GDUPcolObjects2= [];
gdjs.s344Code.GDLbuttonObjects1= [];
gdjs.s344Code.GDLbuttonObjects2= [];
gdjs.s344Code.GDLcolObjects1= [];
gdjs.s344Code.GDLcolObjects2= [];
gdjs.s344Code.GDRbuttonObjects1= [];
gdjs.s344Code.GDRbuttonObjects2= [];
gdjs.s344Code.GDRcolObjects1= [];
gdjs.s344Code.GDRcolObjects2= [];
gdjs.s344Code.GDchapter4Objects1= [];
gdjs.s344Code.GDchapter4Objects2= [];
gdjs.s344Code.GDchapter3Objects1= [];
gdjs.s344Code.GDchapter3Objects2= [];
gdjs.s344Code.GDchapter2Objects1= [];
gdjs.s344Code.GDchapter2Objects2= [];
gdjs.s344Code.GDblackObjects1= [];
gdjs.s344Code.GDblackObjects2= [];
gdjs.s344Code.GDchapter1Objects1= [];
gdjs.s344Code.GDchapter1Objects2= [];

gdjs.s344Code.conditionTrue_0 = {val:false};
gdjs.s344Code.condition0IsTrue_0 = {val:false};
gdjs.s344Code.condition1IsTrue_0 = {val:false};
gdjs.s344Code.condition2IsTrue_0 = {val:false};


gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s344Code.GDDOWNbuttonObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s344Code.GDUPbuttonObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s344Code.GDRbuttonObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s344Code.GDLbuttonObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s344Code.GDcrosshairsObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s344Code.GDRcolObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s344Code.GDcrosshairsObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s344Code.GDLcolObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s344Code.GDcrosshairsObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s344Code.GDUPcolObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s344Code.GDcrosshairsObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s344Code.GDDOWNcolObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s344Code.GDcrosshairsObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s344Code.GDDOWNcolObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s344Code.GDoffObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s344Code.GDonObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s344Code.GDcrosshairsObjects1});gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s344Code.GDchapter1Objects1});gdjs.s344Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s344Code.GDDOWNbuttonObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
gdjs.s344Code.condition1IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s344Code.condition0IsTrue_0.val ) {
{
gdjs.s344Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s344Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s344Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s344Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s344Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s344Code.GDUPbuttonObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
gdjs.s344Code.condition1IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s344Code.condition0IsTrue_0.val ) {
{
gdjs.s344Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s344Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s344Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s344Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s344Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s344Code.GDRbuttonObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
gdjs.s344Code.condition1IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s344Code.condition0IsTrue_0.val ) {
{
gdjs.s344Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s344Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s344Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s344Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s344Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s344Code.GDLbuttonObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
gdjs.s344Code.condition1IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s344Code.condition0IsTrue_0.val ) {
{
gdjs.s344Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s344Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s344Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s344Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s344Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s344Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s344Code.GDcrosshairsObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects, gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s344Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s344Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s344Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s344Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s344Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s344Code.GDcrosshairsObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects, gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s344Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s344Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s344Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s344Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s344Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s344Code.GDcrosshairsObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects, gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s344Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s344Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s344Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s344Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s344Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s344Code.GDcrosshairsObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects, gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s344Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s344Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s344Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s344Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s344Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s344Code.GDcrosshairsObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects, gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s344Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s344Code.GDoffObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s344Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s344Code.GDonObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s344Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s344Code.GDstartObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s344Code.GDstartObjects1.length;i<l;++i) {
    if ( gdjs.s344Code.GDstartObjects1[i].timerElapsedTime("", 4) ) {
        gdjs.s344Code.condition0IsTrue_0.val = true;
        gdjs.s344Code.GDstartObjects1[k] = gdjs.s344Code.GDstartObjects1[i];
        ++k;
    }
}
gdjs.s344Code.GDstartObjects1.length = k;}if (gdjs.s344Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s343", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s344Code.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s344Code.GDcrosshairsObjects1);

gdjs.s344Code.condition0IsTrue_0.val = false;
gdjs.s344Code.condition1IsTrue_0.val = false;
{
gdjs.s344Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDcrosshairsObjects1Objects, gdjs.s344Code.mapOfGDgdjs_46s344Code_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s344Code.condition0IsTrue_0.val ) {
{
gdjs.s344Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s344Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s345", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s344Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s344Code.GDcaseObjects1.length = 0;
gdjs.s344Code.GDcaseObjects2.length = 0;
gdjs.s344Code.GDimageObjects1.length = 0;
gdjs.s344Code.GDimageObjects2.length = 0;
gdjs.s344Code.GDoffObjects1.length = 0;
gdjs.s344Code.GDoffObjects2.length = 0;
gdjs.s344Code.GDonObjects1.length = 0;
gdjs.s344Code.GDonObjects2.length = 0;
gdjs.s344Code.GDstartObjects1.length = 0;
gdjs.s344Code.GDstartObjects2.length = 0;
gdjs.s344Code.GDBObjects1.length = 0;
gdjs.s344Code.GDBObjects2.length = 0;
gdjs.s344Code.GDAObjects1.length = 0;
gdjs.s344Code.GDAObjects2.length = 0;
gdjs.s344Code.GDcrosshairsObjects1.length = 0;
gdjs.s344Code.GDcrosshairsObjects2.length = 0;
gdjs.s344Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s344Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s344Code.GDDOWNcolObjects1.length = 0;
gdjs.s344Code.GDDOWNcolObjects2.length = 0;
gdjs.s344Code.GDUPbuttonObjects1.length = 0;
gdjs.s344Code.GDUPbuttonObjects2.length = 0;
gdjs.s344Code.GDUPcolObjects1.length = 0;
gdjs.s344Code.GDUPcolObjects2.length = 0;
gdjs.s344Code.GDLbuttonObjects1.length = 0;
gdjs.s344Code.GDLbuttonObjects2.length = 0;
gdjs.s344Code.GDLcolObjects1.length = 0;
gdjs.s344Code.GDLcolObjects2.length = 0;
gdjs.s344Code.GDRbuttonObjects1.length = 0;
gdjs.s344Code.GDRbuttonObjects2.length = 0;
gdjs.s344Code.GDRcolObjects1.length = 0;
gdjs.s344Code.GDRcolObjects2.length = 0;
gdjs.s344Code.GDchapter4Objects1.length = 0;
gdjs.s344Code.GDchapter4Objects2.length = 0;
gdjs.s344Code.GDchapter3Objects1.length = 0;
gdjs.s344Code.GDchapter3Objects2.length = 0;
gdjs.s344Code.GDchapter2Objects1.length = 0;
gdjs.s344Code.GDchapter2Objects2.length = 0;
gdjs.s344Code.GDblackObjects1.length = 0;
gdjs.s344Code.GDblackObjects2.length = 0;
gdjs.s344Code.GDchapter1Objects1.length = 0;
gdjs.s344Code.GDchapter1Objects2.length = 0;

gdjs.s344Code.eventsList0(runtimeScene);
return;

}

gdjs['s344Code'] = gdjs.s344Code;
