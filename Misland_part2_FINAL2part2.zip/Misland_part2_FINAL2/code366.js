gdjs.s324Code = {};
gdjs.s324Code.GDcaseObjects1= [];
gdjs.s324Code.GDcaseObjects2= [];
gdjs.s324Code.GDimageObjects1= [];
gdjs.s324Code.GDimageObjects2= [];
gdjs.s324Code.GDoffObjects1= [];
gdjs.s324Code.GDoffObjects2= [];
gdjs.s324Code.GDonObjects1= [];
gdjs.s324Code.GDonObjects2= [];
gdjs.s324Code.GDstartObjects1= [];
gdjs.s324Code.GDstartObjects2= [];
gdjs.s324Code.GDBObjects1= [];
gdjs.s324Code.GDBObjects2= [];
gdjs.s324Code.GDblackObjects1= [];
gdjs.s324Code.GDblackObjects2= [];
gdjs.s324Code.GDAObjects1= [];
gdjs.s324Code.GDAObjects2= [];

gdjs.s324Code.conditionTrue_0 = {val:false};
gdjs.s324Code.condition0IsTrue_0 = {val:false};
gdjs.s324Code.condition1IsTrue_0 = {val:false};
gdjs.s324Code.conditionTrue_1 = {val:false};
gdjs.s324Code.condition0IsTrue_1 = {val:false};
gdjs.s324Code.condition1IsTrue_1 = {val:false};


gdjs.s324Code.mapOfGDgdjs_46s324Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s324Code.GDoffObjects1});gdjs.s324Code.mapOfGDgdjs_46s324Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s324Code.GDonObjects1});gdjs.s324Code.mapOfGDgdjs_46s324Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s324Code.GDAObjects1});gdjs.s324Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s324Code.condition0IsTrue_0.val = false;
{
{gdjs.s324Code.conditionTrue_1 = gdjs.s324Code.condition0IsTrue_0;
gdjs.s324Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(93887092);
}
}if (gdjs.s324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\oldlib_v4.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s324Code.GDoffObjects1);

gdjs.s324Code.condition0IsTrue_0.val = false;
{
gdjs.s324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s324Code.mapOfGDgdjs_46s324Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s324Code.GDonObjects1);

gdjs.s324Code.condition0IsTrue_0.val = false;
{
gdjs.s324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s324Code.mapOfGDgdjs_46s324Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s324Code.condition0IsTrue_0.val = false;
{
gdjs.s324Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s325", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s324Code.GDAObjects1);

gdjs.s324Code.condition0IsTrue_0.val = false;
{
gdjs.s324Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s324Code.mapOfGDgdjs_46s324Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s324Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s325", false);
}}

}


{


{
}

}


};

gdjs.s324Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s324Code.GDcaseObjects1.length = 0;
gdjs.s324Code.GDcaseObjects2.length = 0;
gdjs.s324Code.GDimageObjects1.length = 0;
gdjs.s324Code.GDimageObjects2.length = 0;
gdjs.s324Code.GDoffObjects1.length = 0;
gdjs.s324Code.GDoffObjects2.length = 0;
gdjs.s324Code.GDonObjects1.length = 0;
gdjs.s324Code.GDonObjects2.length = 0;
gdjs.s324Code.GDstartObjects1.length = 0;
gdjs.s324Code.GDstartObjects2.length = 0;
gdjs.s324Code.GDBObjects1.length = 0;
gdjs.s324Code.GDBObjects2.length = 0;
gdjs.s324Code.GDblackObjects1.length = 0;
gdjs.s324Code.GDblackObjects2.length = 0;
gdjs.s324Code.GDAObjects1.length = 0;
gdjs.s324Code.GDAObjects2.length = 0;

gdjs.s324Code.eventsList0(runtimeScene);
return;

}

gdjs['s324Code'] = gdjs.s324Code;
