gdjs.s335Code = {};
gdjs.s335Code.GDcaseObjects1= [];
gdjs.s335Code.GDcaseObjects2= [];
gdjs.s335Code.GDimageObjects1= [];
gdjs.s335Code.GDimageObjects2= [];
gdjs.s335Code.GDoffObjects1= [];
gdjs.s335Code.GDoffObjects2= [];
gdjs.s335Code.GDonObjects1= [];
gdjs.s335Code.GDonObjects2= [];
gdjs.s335Code.GDstartObjects1= [];
gdjs.s335Code.GDstartObjects2= [];
gdjs.s335Code.GDBObjects1= [];
gdjs.s335Code.GDBObjects2= [];
gdjs.s335Code.GDblackObjects1= [];
gdjs.s335Code.GDblackObjects2= [];
gdjs.s335Code.GDAObjects1= [];
gdjs.s335Code.GDAObjects2= [];

gdjs.s335Code.conditionTrue_0 = {val:false};
gdjs.s335Code.condition0IsTrue_0 = {val:false};
gdjs.s335Code.condition1IsTrue_0 = {val:false};


gdjs.s335Code.mapOfGDgdjs_46s335Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s335Code.GDoffObjects1});gdjs.s335Code.mapOfGDgdjs_46s335Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s335Code.GDonObjects1});gdjs.s335Code.mapOfGDgdjs_46s335Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s335Code.GDBObjects1});gdjs.s335Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s335Code.GDoffObjects1);

gdjs.s335Code.condition0IsTrue_0.val = false;
{
gdjs.s335Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s335Code.mapOfGDgdjs_46s335Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s335Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s335Code.GDonObjects1);

gdjs.s335Code.condition0IsTrue_0.val = false;
{
gdjs.s335Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s335Code.mapOfGDgdjs_46s335Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s335Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s335Code.condition0IsTrue_0.val = false;
{
gdjs.s335Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s335Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s336", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s335Code.GDBObjects1);

gdjs.s335Code.condition0IsTrue_0.val = false;
{
gdjs.s335Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s335Code.mapOfGDgdjs_46s335Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s335Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s336", false);
}}

}


{


{
}

}


};

gdjs.s335Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s335Code.GDcaseObjects1.length = 0;
gdjs.s335Code.GDcaseObjects2.length = 0;
gdjs.s335Code.GDimageObjects1.length = 0;
gdjs.s335Code.GDimageObjects2.length = 0;
gdjs.s335Code.GDoffObjects1.length = 0;
gdjs.s335Code.GDoffObjects2.length = 0;
gdjs.s335Code.GDonObjects1.length = 0;
gdjs.s335Code.GDonObjects2.length = 0;
gdjs.s335Code.GDstartObjects1.length = 0;
gdjs.s335Code.GDstartObjects2.length = 0;
gdjs.s335Code.GDBObjects1.length = 0;
gdjs.s335Code.GDBObjects2.length = 0;
gdjs.s335Code.GDblackObjects1.length = 0;
gdjs.s335Code.GDblackObjects2.length = 0;
gdjs.s335Code.GDAObjects1.length = 0;
gdjs.s335Code.GDAObjects2.length = 0;

gdjs.s335Code.eventsList0(runtimeScene);
return;

}

gdjs['s335Code'] = gdjs.s335Code;
