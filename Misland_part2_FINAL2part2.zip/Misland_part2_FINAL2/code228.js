gdjs.s2102Code = {};
gdjs.s2102Code.GDcaseObjects1= [];
gdjs.s2102Code.GDcaseObjects2= [];
gdjs.s2102Code.GDimageObjects1= [];
gdjs.s2102Code.GDimageObjects2= [];
gdjs.s2102Code.GDoffObjects1= [];
gdjs.s2102Code.GDoffObjects2= [];
gdjs.s2102Code.GDonObjects1= [];
gdjs.s2102Code.GDonObjects2= [];
gdjs.s2102Code.GDstartObjects1= [];
gdjs.s2102Code.GDstartObjects2= [];
gdjs.s2102Code.GDBObjects1= [];
gdjs.s2102Code.GDBObjects2= [];
gdjs.s2102Code.GDblackObjects1= [];
gdjs.s2102Code.GDblackObjects2= [];
gdjs.s2102Code.GDAObjects1= [];
gdjs.s2102Code.GDAObjects2= [];
gdjs.s2102Code.GDbuttonObjects1= [];
gdjs.s2102Code.GDbuttonObjects2= [];

gdjs.s2102Code.conditionTrue_0 = {val:false};
gdjs.s2102Code.condition0IsTrue_0 = {val:false};
gdjs.s2102Code.condition1IsTrue_0 = {val:false};


gdjs.s2102Code.mapOfGDgdjs_46s2102Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s2102Code.GDoffObjects1});gdjs.s2102Code.mapOfGDgdjs_46s2102Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s2102Code.GDonObjects1});gdjs.s2102Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s2102Code.GDcaseObjects1);

gdjs.s2102Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s2102Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s2102Code.GDcaseObjects1[i].timerElapsedTime("", 0.8) ) {
        gdjs.s2102Code.condition0IsTrue_0.val = true;
        gdjs.s2102Code.GDcaseObjects1[k] = gdjs.s2102Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s2102Code.GDcaseObjects1.length = k;}if (gdjs.s2102Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s2112", false);
}}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s2102Code.GDoffObjects1);

gdjs.s2102Code.condition0IsTrue_0.val = false;
{
gdjs.s2102Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s2102Code.mapOfGDgdjs_46s2102Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s2102Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s2102Code.GDonObjects1);

gdjs.s2102Code.condition0IsTrue_0.val = false;
{
gdjs.s2102Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s2102Code.mapOfGDgdjs_46s2102Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s2102Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s2102Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s2102Code.GDcaseObjects1.length = 0;
gdjs.s2102Code.GDcaseObjects2.length = 0;
gdjs.s2102Code.GDimageObjects1.length = 0;
gdjs.s2102Code.GDimageObjects2.length = 0;
gdjs.s2102Code.GDoffObjects1.length = 0;
gdjs.s2102Code.GDoffObjects2.length = 0;
gdjs.s2102Code.GDonObjects1.length = 0;
gdjs.s2102Code.GDonObjects2.length = 0;
gdjs.s2102Code.GDstartObjects1.length = 0;
gdjs.s2102Code.GDstartObjects2.length = 0;
gdjs.s2102Code.GDBObjects1.length = 0;
gdjs.s2102Code.GDBObjects2.length = 0;
gdjs.s2102Code.GDblackObjects1.length = 0;
gdjs.s2102Code.GDblackObjects2.length = 0;
gdjs.s2102Code.GDAObjects1.length = 0;
gdjs.s2102Code.GDAObjects2.length = 0;
gdjs.s2102Code.GDbuttonObjects1.length = 0;
gdjs.s2102Code.GDbuttonObjects2.length = 0;

gdjs.s2102Code.eventsList0(runtimeScene);
return;

}

gdjs['s2102Code'] = gdjs.s2102Code;
