gdjs.mainmenuCode = {};
gdjs.mainmenuCode.GDcaseObjects1= [];
gdjs.mainmenuCode.GDcaseObjects2= [];
gdjs.mainmenuCode.GDimageObjects1= [];
gdjs.mainmenuCode.GDimageObjects2= [];
gdjs.mainmenuCode.GDoffObjects1= [];
gdjs.mainmenuCode.GDoffObjects2= [];
gdjs.mainmenuCode.GDonObjects1= [];
gdjs.mainmenuCode.GDonObjects2= [];
gdjs.mainmenuCode.GDstartObjects1= [];
gdjs.mainmenuCode.GDstartObjects2= [];
gdjs.mainmenuCode.GDBObjects1= [];
gdjs.mainmenuCode.GDBObjects2= [];
gdjs.mainmenuCode.GDAObjects1= [];
gdjs.mainmenuCode.GDAObjects2= [];

gdjs.mainmenuCode.conditionTrue_0 = {val:false};
gdjs.mainmenuCode.condition0IsTrue_0 = {val:false};
gdjs.mainmenuCode.condition1IsTrue_0 = {val:false};
gdjs.mainmenuCode.conditionTrue_1 = {val:false};
gdjs.mainmenuCode.condition0IsTrue_1 = {val:false};
gdjs.mainmenuCode.condition1IsTrue_1 = {val:false};


gdjs.mainmenuCode.mapOfGDgdjs_46mainmenuCode_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.mainmenuCode.GDBObjects1});gdjs.mainmenuCode.mapOfGDgdjs_46mainmenuCode_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.mainmenuCode.GDAObjects1});gdjs.mainmenuCode.mapOfGDgdjs_46mainmenuCode_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.mainmenuCode.GDoffObjects1});gdjs.mainmenuCode.mapOfGDgdjs_46mainmenuCode_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.mainmenuCode.GDonObjects1});gdjs.mainmenuCode.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.mainmenuCode.condition0IsTrue_0.val = false;
{
{gdjs.mainmenuCode.conditionTrue_1 = gdjs.mainmenuCode.condition0IsTrue_0;
gdjs.mainmenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(86170356);
}
}if (gdjs.mainmenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter5_v6.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.mainmenuCode.GDBObjects1);

gdjs.mainmenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainmenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.mainmenuCode.mapOfGDgdjs_46mainmenuCode_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.mainmenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "chapselect", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.mainmenuCode.GDAObjects1);

gdjs.mainmenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainmenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.mainmenuCode.mapOfGDgdjs_46mainmenuCode_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.mainmenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "intro", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.mainmenuCode.GDoffObjects1);

gdjs.mainmenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainmenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.mainmenuCode.mapOfGDgdjs_46mainmenuCode_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.mainmenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.mainmenuCode.GDonObjects1);

gdjs.mainmenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainmenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.mainmenuCode.mapOfGDgdjs_46mainmenuCode_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.mainmenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.mainmenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainmenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.mainmenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "intro", false);
}}

}


{


gdjs.mainmenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainmenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.mainmenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "chapselect", false);
}}

}


};

gdjs.mainmenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.mainmenuCode.GDcaseObjects1.length = 0;
gdjs.mainmenuCode.GDcaseObjects2.length = 0;
gdjs.mainmenuCode.GDimageObjects1.length = 0;
gdjs.mainmenuCode.GDimageObjects2.length = 0;
gdjs.mainmenuCode.GDoffObjects1.length = 0;
gdjs.mainmenuCode.GDoffObjects2.length = 0;
gdjs.mainmenuCode.GDonObjects1.length = 0;
gdjs.mainmenuCode.GDonObjects2.length = 0;
gdjs.mainmenuCode.GDstartObjects1.length = 0;
gdjs.mainmenuCode.GDstartObjects2.length = 0;
gdjs.mainmenuCode.GDBObjects1.length = 0;
gdjs.mainmenuCode.GDBObjects2.length = 0;
gdjs.mainmenuCode.GDAObjects1.length = 0;
gdjs.mainmenuCode.GDAObjects2.length = 0;

gdjs.mainmenuCode.eventsList0(runtimeScene);
return;

}

gdjs['mainmenuCode'] = gdjs.mainmenuCode;
