gdjs.START_95SCREENCode = {};
gdjs.START_95SCREENCode.GDcaseObjects1= [];
gdjs.START_95SCREENCode.GDcaseObjects2= [];
gdjs.START_95SCREENCode.GDimageObjects1= [];
gdjs.START_95SCREENCode.GDimageObjects2= [];
gdjs.START_95SCREENCode.GDoffObjects1= [];
gdjs.START_95SCREENCode.GDoffObjects2= [];
gdjs.START_95SCREENCode.GDonObjects1= [];
gdjs.START_95SCREENCode.GDonObjects2= [];
gdjs.START_95SCREENCode.GDstartObjects1= [];
gdjs.START_95SCREENCode.GDstartObjects2= [];
gdjs.START_95SCREENCode.GDBObjects1= [];
gdjs.START_95SCREENCode.GDBObjects2= [];
gdjs.START_95SCREENCode.GDAObjects1= [];
gdjs.START_95SCREENCode.GDAObjects2= [];
gdjs.START_95SCREENCode.GDblackObjects1= [];
gdjs.START_95SCREENCode.GDblackObjects2= [];

gdjs.START_95SCREENCode.conditionTrue_0 = {val:false};
gdjs.START_95SCREENCode.condition0IsTrue_0 = {val:false};
gdjs.START_95SCREENCode.condition1IsTrue_0 = {val:false};
gdjs.START_95SCREENCode.conditionTrue_1 = {val:false};
gdjs.START_95SCREENCode.condition0IsTrue_1 = {val:false};
gdjs.START_95SCREENCode.condition1IsTrue_1 = {val:false};


gdjs.START_95SCREENCode.mapOfGDgdjs_46START_9595SCREENCode_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.START_95SCREENCode.GDoffObjects1});gdjs.START_95SCREENCode.mapOfGDgdjs_46START_9595SCREENCode_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.START_95SCREENCode.GDonObjects1});gdjs.START_95SCREENCode.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.START_95SCREENCode.condition0IsTrue_0.val = false;
{
{gdjs.START_95SCREENCode.conditionTrue_1 = gdjs.START_95SCREENCode.condition0IsTrue_0;
gdjs.START_95SCREENCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(86158780);
}
}if (gdjs.START_95SCREENCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\dead.mp3", true, 100, 1);
}}

}


{


{
}

}


{


gdjs.START_95SCREENCode.condition0IsTrue_0.val = false;
{
gdjs.START_95SCREENCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 6, "");
}if (gdjs.START_95SCREENCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mainmenu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.START_95SCREENCode.GDoffObjects1);

gdjs.START_95SCREENCode.condition0IsTrue_0.val = false;
{
gdjs.START_95SCREENCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.START_95SCREENCode.mapOfGDgdjs_46START_9595SCREENCode_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.START_95SCREENCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.START_95SCREENCode.GDonObjects1);

gdjs.START_95SCREENCode.condition0IsTrue_0.val = false;
{
gdjs.START_95SCREENCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.START_95SCREENCode.mapOfGDgdjs_46START_9595SCREENCode_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.START_95SCREENCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.START_95SCREENCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.START_95SCREENCode.GDcaseObjects1.length = 0;
gdjs.START_95SCREENCode.GDcaseObjects2.length = 0;
gdjs.START_95SCREENCode.GDimageObjects1.length = 0;
gdjs.START_95SCREENCode.GDimageObjects2.length = 0;
gdjs.START_95SCREENCode.GDoffObjects1.length = 0;
gdjs.START_95SCREENCode.GDoffObjects2.length = 0;
gdjs.START_95SCREENCode.GDonObjects1.length = 0;
gdjs.START_95SCREENCode.GDonObjects2.length = 0;
gdjs.START_95SCREENCode.GDstartObjects1.length = 0;
gdjs.START_95SCREENCode.GDstartObjects2.length = 0;
gdjs.START_95SCREENCode.GDBObjects1.length = 0;
gdjs.START_95SCREENCode.GDBObjects2.length = 0;
gdjs.START_95SCREENCode.GDAObjects1.length = 0;
gdjs.START_95SCREENCode.GDAObjects2.length = 0;
gdjs.START_95SCREENCode.GDblackObjects1.length = 0;
gdjs.START_95SCREENCode.GDblackObjects2.length = 0;

gdjs.START_95SCREENCode.eventsList0(runtimeScene);
return;

}

gdjs['START_95SCREENCode'] = gdjs.START_95SCREENCode;
