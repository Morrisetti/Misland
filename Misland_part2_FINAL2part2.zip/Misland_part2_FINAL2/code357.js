gdjs.s315Code = {};
gdjs.s315Code.GDcaseObjects1= [];
gdjs.s315Code.GDcaseObjects2= [];
gdjs.s315Code.GDimageObjects1= [];
gdjs.s315Code.GDimageObjects2= [];
gdjs.s315Code.GDoffObjects1= [];
gdjs.s315Code.GDoffObjects2= [];
gdjs.s315Code.GDonObjects1= [];
gdjs.s315Code.GDonObjects2= [];
gdjs.s315Code.GDstartObjects1= [];
gdjs.s315Code.GDstartObjects2= [];
gdjs.s315Code.GDBObjects1= [];
gdjs.s315Code.GDBObjects2= [];
gdjs.s315Code.GDAObjects1= [];
gdjs.s315Code.GDAObjects2= [];
gdjs.s315Code.GDcrosshairsObjects1= [];
gdjs.s315Code.GDcrosshairsObjects2= [];
gdjs.s315Code.GDDOWNbuttonObjects1= [];
gdjs.s315Code.GDDOWNbuttonObjects2= [];
gdjs.s315Code.GDDOWNcolObjects1= [];
gdjs.s315Code.GDDOWNcolObjects2= [];
gdjs.s315Code.GDUPbuttonObjects1= [];
gdjs.s315Code.GDUPbuttonObjects2= [];
gdjs.s315Code.GDUPcolObjects1= [];
gdjs.s315Code.GDUPcolObjects2= [];
gdjs.s315Code.GDLbuttonObjects1= [];
gdjs.s315Code.GDLbuttonObjects2= [];
gdjs.s315Code.GDLcolObjects1= [];
gdjs.s315Code.GDLcolObjects2= [];
gdjs.s315Code.GDRbuttonObjects1= [];
gdjs.s315Code.GDRbuttonObjects2= [];
gdjs.s315Code.GDRcolObjects1= [];
gdjs.s315Code.GDRcolObjects2= [];
gdjs.s315Code.GDchapter4Objects1= [];
gdjs.s315Code.GDchapter4Objects2= [];
gdjs.s315Code.GDchapter3Objects1= [];
gdjs.s315Code.GDchapter3Objects2= [];
gdjs.s315Code.GDchapter2Objects1= [];
gdjs.s315Code.GDchapter2Objects2= [];
gdjs.s315Code.GDblackObjects1= [];
gdjs.s315Code.GDblackObjects2= [];
gdjs.s315Code.GDchapter1Objects1= [];
gdjs.s315Code.GDchapter1Objects2= [];

gdjs.s315Code.conditionTrue_0 = {val:false};
gdjs.s315Code.condition0IsTrue_0 = {val:false};
gdjs.s315Code.condition1IsTrue_0 = {val:false};
gdjs.s315Code.condition2IsTrue_0 = {val:false};


gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s315Code.GDDOWNbuttonObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s315Code.GDUPbuttonObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s315Code.GDRbuttonObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s315Code.GDLbuttonObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s315Code.GDcrosshairsObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s315Code.GDRcolObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s315Code.GDcrosshairsObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s315Code.GDLcolObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s315Code.GDcrosshairsObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s315Code.GDUPcolObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s315Code.GDcrosshairsObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s315Code.GDDOWNcolObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s315Code.GDcrosshairsObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s315Code.GDDOWNcolObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s315Code.GDoffObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s315Code.GDonObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s315Code.GDcrosshairsObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s315Code.GDchapter1Objects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s315Code.GDAObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s315Code.GDcrosshairsObjects1});gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s315Code.GDchapter1Objects1});gdjs.s315Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s315Code.GDDOWNbuttonObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
gdjs.s315Code.condition1IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s315Code.condition0IsTrue_0.val ) {
{
gdjs.s315Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s315Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s315Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s315Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s315Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s315Code.GDUPbuttonObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
gdjs.s315Code.condition1IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s315Code.condition0IsTrue_0.val ) {
{
gdjs.s315Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s315Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s315Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s315Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s315Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s315Code.GDRbuttonObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
gdjs.s315Code.condition1IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s315Code.condition0IsTrue_0.val ) {
{
gdjs.s315Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s315Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s315Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s315Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s315Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s315Code.GDLbuttonObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
gdjs.s315Code.condition1IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s315Code.condition0IsTrue_0.val ) {
{
gdjs.s315Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s315Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s315Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s315Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s315Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s315Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s315Code.GDcrosshairsObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects, gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s315Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s315Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s315Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s315Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s315Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s315Code.GDcrosshairsObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects, gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s315Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s315Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s315Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s315Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s315Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s315Code.GDcrosshairsObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects, gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s315Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s315Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s315Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s315Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s315Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s315Code.GDcrosshairsObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects, gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s315Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s315Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s315Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s315Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s315Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s315Code.GDcrosshairsObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects, gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s315Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s315Code.GDoffObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s315Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s315Code.GDonObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s315Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s315Code.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s315Code.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s315Code.GDcrosshairsObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
gdjs.s315Code.condition1IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects, gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s315Code.condition0IsTrue_0.val ) {
{
gdjs.s315Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.s315Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s316", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s315Code.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s315Code.GDcrosshairsObjects1);

gdjs.s315Code.condition0IsTrue_0.val = false;
gdjs.s315Code.condition1IsTrue_0.val = false;
{
gdjs.s315Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDcrosshairsObjects1Objects, gdjs.s315Code.mapOfGDgdjs_46s315Code_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s315Code.condition0IsTrue_0.val ) {
{
gdjs.s315Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s315Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s316", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s315Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s315Code.GDcaseObjects1.length = 0;
gdjs.s315Code.GDcaseObjects2.length = 0;
gdjs.s315Code.GDimageObjects1.length = 0;
gdjs.s315Code.GDimageObjects2.length = 0;
gdjs.s315Code.GDoffObjects1.length = 0;
gdjs.s315Code.GDoffObjects2.length = 0;
gdjs.s315Code.GDonObjects1.length = 0;
gdjs.s315Code.GDonObjects2.length = 0;
gdjs.s315Code.GDstartObjects1.length = 0;
gdjs.s315Code.GDstartObjects2.length = 0;
gdjs.s315Code.GDBObjects1.length = 0;
gdjs.s315Code.GDBObjects2.length = 0;
gdjs.s315Code.GDAObjects1.length = 0;
gdjs.s315Code.GDAObjects2.length = 0;
gdjs.s315Code.GDcrosshairsObjects1.length = 0;
gdjs.s315Code.GDcrosshairsObjects2.length = 0;
gdjs.s315Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s315Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s315Code.GDDOWNcolObjects1.length = 0;
gdjs.s315Code.GDDOWNcolObjects2.length = 0;
gdjs.s315Code.GDUPbuttonObjects1.length = 0;
gdjs.s315Code.GDUPbuttonObjects2.length = 0;
gdjs.s315Code.GDUPcolObjects1.length = 0;
gdjs.s315Code.GDUPcolObjects2.length = 0;
gdjs.s315Code.GDLbuttonObjects1.length = 0;
gdjs.s315Code.GDLbuttonObjects2.length = 0;
gdjs.s315Code.GDLcolObjects1.length = 0;
gdjs.s315Code.GDLcolObjects2.length = 0;
gdjs.s315Code.GDRbuttonObjects1.length = 0;
gdjs.s315Code.GDRbuttonObjects2.length = 0;
gdjs.s315Code.GDRcolObjects1.length = 0;
gdjs.s315Code.GDRcolObjects2.length = 0;
gdjs.s315Code.GDchapter4Objects1.length = 0;
gdjs.s315Code.GDchapter4Objects2.length = 0;
gdjs.s315Code.GDchapter3Objects1.length = 0;
gdjs.s315Code.GDchapter3Objects2.length = 0;
gdjs.s315Code.GDchapter2Objects1.length = 0;
gdjs.s315Code.GDchapter2Objects2.length = 0;
gdjs.s315Code.GDblackObjects1.length = 0;
gdjs.s315Code.GDblackObjects2.length = 0;
gdjs.s315Code.GDchapter1Objects1.length = 0;
gdjs.s315Code.GDchapter1Objects2.length = 0;

gdjs.s315Code.eventsList0(runtimeScene);
return;

}

gdjs['s315Code'] = gdjs.s315Code;
