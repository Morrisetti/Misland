gdjs.s305Code = {};
gdjs.s305Code.GDcaseObjects1= [];
gdjs.s305Code.GDcaseObjects2= [];
gdjs.s305Code.GDimageObjects1= [];
gdjs.s305Code.GDimageObjects2= [];
gdjs.s305Code.GDoffObjects1= [];
gdjs.s305Code.GDoffObjects2= [];
gdjs.s305Code.GDonObjects1= [];
gdjs.s305Code.GDonObjects2= [];
gdjs.s305Code.GDstartObjects1= [];
gdjs.s305Code.GDstartObjects2= [];
gdjs.s305Code.GDBObjects1= [];
gdjs.s305Code.GDBObjects2= [];
gdjs.s305Code.GDblackObjects1= [];
gdjs.s305Code.GDblackObjects2= [];
gdjs.s305Code.GDAObjects1= [];
gdjs.s305Code.GDAObjects2= [];

gdjs.s305Code.conditionTrue_0 = {val:false};
gdjs.s305Code.condition0IsTrue_0 = {val:false};
gdjs.s305Code.condition1IsTrue_0 = {val:false};


gdjs.s305Code.mapOfGDgdjs_46s305Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s305Code.GDoffObjects1});gdjs.s305Code.mapOfGDgdjs_46s305Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s305Code.GDonObjects1});gdjs.s305Code.mapOfGDgdjs_46s305Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s305Code.GDBObjects1});gdjs.s305Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s305Code.GDoffObjects1);

gdjs.s305Code.condition0IsTrue_0.val = false;
{
gdjs.s305Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s305Code.mapOfGDgdjs_46s305Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s305Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s305Code.GDonObjects1);

gdjs.s305Code.condition0IsTrue_0.val = false;
{
gdjs.s305Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s305Code.mapOfGDgdjs_46s305Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s305Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s305Code.condition0IsTrue_0.val = false;
{
gdjs.s305Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s305Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s306", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s305Code.GDBObjects1);

gdjs.s305Code.condition0IsTrue_0.val = false;
{
gdjs.s305Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s305Code.mapOfGDgdjs_46s305Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s305Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s306", false);
}}

}


{


{
}

}


};

gdjs.s305Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s305Code.GDcaseObjects1.length = 0;
gdjs.s305Code.GDcaseObjects2.length = 0;
gdjs.s305Code.GDimageObjects1.length = 0;
gdjs.s305Code.GDimageObjects2.length = 0;
gdjs.s305Code.GDoffObjects1.length = 0;
gdjs.s305Code.GDoffObjects2.length = 0;
gdjs.s305Code.GDonObjects1.length = 0;
gdjs.s305Code.GDonObjects2.length = 0;
gdjs.s305Code.GDstartObjects1.length = 0;
gdjs.s305Code.GDstartObjects2.length = 0;
gdjs.s305Code.GDBObjects1.length = 0;
gdjs.s305Code.GDBObjects2.length = 0;
gdjs.s305Code.GDblackObjects1.length = 0;
gdjs.s305Code.GDblackObjects2.length = 0;
gdjs.s305Code.GDAObjects1.length = 0;
gdjs.s305Code.GDAObjects2.length = 0;

gdjs.s305Code.eventsList0(runtimeScene);
return;

}

gdjs['s305Code'] = gdjs.s305Code;
