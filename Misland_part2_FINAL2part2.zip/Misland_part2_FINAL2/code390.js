gdjs.s347Code = {};
gdjs.s347Code.GDcaseObjects1= [];
gdjs.s347Code.GDcaseObjects2= [];
gdjs.s347Code.GDimageObjects1= [];
gdjs.s347Code.GDimageObjects2= [];
gdjs.s347Code.GDoffObjects1= [];
gdjs.s347Code.GDoffObjects2= [];
gdjs.s347Code.GDonObjects1= [];
gdjs.s347Code.GDonObjects2= [];
gdjs.s347Code.GDstartObjects1= [];
gdjs.s347Code.GDstartObjects2= [];
gdjs.s347Code.GDBObjects1= [];
gdjs.s347Code.GDBObjects2= [];
gdjs.s347Code.GDAObjects1= [];
gdjs.s347Code.GDAObjects2= [];
gdjs.s347Code.GDcrosshairsObjects1= [];
gdjs.s347Code.GDcrosshairsObjects2= [];
gdjs.s347Code.GDDOWNbuttonObjects1= [];
gdjs.s347Code.GDDOWNbuttonObjects2= [];
gdjs.s347Code.GDDOWNcolObjects1= [];
gdjs.s347Code.GDDOWNcolObjects2= [];
gdjs.s347Code.GDUPbuttonObjects1= [];
gdjs.s347Code.GDUPbuttonObjects2= [];
gdjs.s347Code.GDUPcolObjects1= [];
gdjs.s347Code.GDUPcolObjects2= [];
gdjs.s347Code.GDLbuttonObjects1= [];
gdjs.s347Code.GDLbuttonObjects2= [];
gdjs.s347Code.GDLcolObjects1= [];
gdjs.s347Code.GDLcolObjects2= [];
gdjs.s347Code.GDRbuttonObjects1= [];
gdjs.s347Code.GDRbuttonObjects2= [];
gdjs.s347Code.GDRcolObjects1= [];
gdjs.s347Code.GDRcolObjects2= [];
gdjs.s347Code.GDchapter4Objects1= [];
gdjs.s347Code.GDchapter4Objects2= [];
gdjs.s347Code.GDchapter3Objects1= [];
gdjs.s347Code.GDchapter3Objects2= [];
gdjs.s347Code.GDchapter2Objects1= [];
gdjs.s347Code.GDchapter2Objects2= [];
gdjs.s347Code.GDblackObjects1= [];
gdjs.s347Code.GDblackObjects2= [];
gdjs.s347Code.GDchapter1Objects1= [];
gdjs.s347Code.GDchapter1Objects2= [];

gdjs.s347Code.conditionTrue_0 = {val:false};
gdjs.s347Code.condition0IsTrue_0 = {val:false};
gdjs.s347Code.condition1IsTrue_0 = {val:false};
gdjs.s347Code.condition2IsTrue_0 = {val:false};


gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s347Code.GDDOWNbuttonObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s347Code.GDUPbuttonObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s347Code.GDRbuttonObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s347Code.GDLbuttonObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s347Code.GDcrosshairsObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s347Code.GDRcolObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s347Code.GDcrosshairsObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s347Code.GDLcolObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s347Code.GDcrosshairsObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s347Code.GDUPcolObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s347Code.GDcrosshairsObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s347Code.GDDOWNcolObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s347Code.GDcrosshairsObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s347Code.GDDOWNcolObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s347Code.GDoffObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s347Code.GDonObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s347Code.GDcrosshairsObjects1});gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s347Code.GDchapter1Objects1});gdjs.s347Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s347Code.GDDOWNbuttonObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
gdjs.s347Code.condition1IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s347Code.condition0IsTrue_0.val ) {
{
gdjs.s347Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s347Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s347Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s347Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s347Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s347Code.GDUPbuttonObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
gdjs.s347Code.condition1IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s347Code.condition0IsTrue_0.val ) {
{
gdjs.s347Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s347Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s347Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s347Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s347Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s347Code.GDRbuttonObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
gdjs.s347Code.condition1IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s347Code.condition0IsTrue_0.val ) {
{
gdjs.s347Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s347Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s347Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s347Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s347Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s347Code.GDLbuttonObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
gdjs.s347Code.condition1IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s347Code.condition0IsTrue_0.val ) {
{
gdjs.s347Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s347Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s347Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s347Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s347Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s347Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s347Code.GDcrosshairsObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects, gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s347Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s347Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s347Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s347Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s347Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s347Code.GDcrosshairsObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects, gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s347Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s347Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s347Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s347Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s347Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s347Code.GDcrosshairsObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects, gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s347Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s347Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s347Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s347Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s347Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s347Code.GDcrosshairsObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects, gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s347Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s347Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s347Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s347Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s347Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s347Code.GDcrosshairsObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects, gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s347Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s347Code.GDoffObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s347Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s347Code.GDonObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s347Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s347Code.GDstartObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s347Code.GDstartObjects1.length;i<l;++i) {
    if ( gdjs.s347Code.GDstartObjects1[i].timerElapsedTime("", 4) ) {
        gdjs.s347Code.condition0IsTrue_0.val = true;
        gdjs.s347Code.GDstartObjects1[k] = gdjs.s347Code.GDstartObjects1[i];
        ++k;
    }
}
gdjs.s347Code.GDstartObjects1.length = k;}if (gdjs.s347Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s343", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s347Code.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s347Code.GDcrosshairsObjects1);

gdjs.s347Code.condition0IsTrue_0.val = false;
gdjs.s347Code.condition1IsTrue_0.val = false;
{
gdjs.s347Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDcrosshairsObjects1Objects, gdjs.s347Code.mapOfGDgdjs_46s347Code_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s347Code.condition0IsTrue_0.val ) {
{
gdjs.s347Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s347Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s348", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s347Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s347Code.GDcaseObjects1.length = 0;
gdjs.s347Code.GDcaseObjects2.length = 0;
gdjs.s347Code.GDimageObjects1.length = 0;
gdjs.s347Code.GDimageObjects2.length = 0;
gdjs.s347Code.GDoffObjects1.length = 0;
gdjs.s347Code.GDoffObjects2.length = 0;
gdjs.s347Code.GDonObjects1.length = 0;
gdjs.s347Code.GDonObjects2.length = 0;
gdjs.s347Code.GDstartObjects1.length = 0;
gdjs.s347Code.GDstartObjects2.length = 0;
gdjs.s347Code.GDBObjects1.length = 0;
gdjs.s347Code.GDBObjects2.length = 0;
gdjs.s347Code.GDAObjects1.length = 0;
gdjs.s347Code.GDAObjects2.length = 0;
gdjs.s347Code.GDcrosshairsObjects1.length = 0;
gdjs.s347Code.GDcrosshairsObjects2.length = 0;
gdjs.s347Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s347Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s347Code.GDDOWNcolObjects1.length = 0;
gdjs.s347Code.GDDOWNcolObjects2.length = 0;
gdjs.s347Code.GDUPbuttonObjects1.length = 0;
gdjs.s347Code.GDUPbuttonObjects2.length = 0;
gdjs.s347Code.GDUPcolObjects1.length = 0;
gdjs.s347Code.GDUPcolObjects2.length = 0;
gdjs.s347Code.GDLbuttonObjects1.length = 0;
gdjs.s347Code.GDLbuttonObjects2.length = 0;
gdjs.s347Code.GDLcolObjects1.length = 0;
gdjs.s347Code.GDLcolObjects2.length = 0;
gdjs.s347Code.GDRbuttonObjects1.length = 0;
gdjs.s347Code.GDRbuttonObjects2.length = 0;
gdjs.s347Code.GDRcolObjects1.length = 0;
gdjs.s347Code.GDRcolObjects2.length = 0;
gdjs.s347Code.GDchapter4Objects1.length = 0;
gdjs.s347Code.GDchapter4Objects2.length = 0;
gdjs.s347Code.GDchapter3Objects1.length = 0;
gdjs.s347Code.GDchapter3Objects2.length = 0;
gdjs.s347Code.GDchapter2Objects1.length = 0;
gdjs.s347Code.GDchapter2Objects2.length = 0;
gdjs.s347Code.GDblackObjects1.length = 0;
gdjs.s347Code.GDblackObjects2.length = 0;
gdjs.s347Code.GDchapter1Objects1.length = 0;
gdjs.s347Code.GDchapter1Objects2.length = 0;

gdjs.s347Code.eventsList0(runtimeScene);
return;

}

gdjs['s347Code'] = gdjs.s347Code;
