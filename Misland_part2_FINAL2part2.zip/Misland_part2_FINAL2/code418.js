gdjs.s375Code = {};
gdjs.s375Code.GDcaseObjects1= [];
gdjs.s375Code.GDcaseObjects2= [];
gdjs.s375Code.GDimageObjects1= [];
gdjs.s375Code.GDimageObjects2= [];
gdjs.s375Code.GDoffObjects1= [];
gdjs.s375Code.GDoffObjects2= [];
gdjs.s375Code.GDonObjects1= [];
gdjs.s375Code.GDonObjects2= [];
gdjs.s375Code.GDstartObjects1= [];
gdjs.s375Code.GDstartObjects2= [];
gdjs.s375Code.GDBObjects1= [];
gdjs.s375Code.GDBObjects2= [];
gdjs.s375Code.GDblackObjects1= [];
gdjs.s375Code.GDblackObjects2= [];
gdjs.s375Code.GDAObjects1= [];
gdjs.s375Code.GDAObjects2= [];

gdjs.s375Code.conditionTrue_0 = {val:false};
gdjs.s375Code.condition0IsTrue_0 = {val:false};
gdjs.s375Code.condition1IsTrue_0 = {val:false};


gdjs.s375Code.mapOfGDgdjs_46s375Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s375Code.GDoffObjects1});gdjs.s375Code.mapOfGDgdjs_46s375Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s375Code.GDonObjects1});gdjs.s375Code.mapOfGDgdjs_46s375Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s375Code.GDBObjects1});gdjs.s375Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s375Code.GDoffObjects1);

gdjs.s375Code.condition0IsTrue_0.val = false;
{
gdjs.s375Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s375Code.mapOfGDgdjs_46s375Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s375Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s375Code.GDonObjects1);

gdjs.s375Code.condition0IsTrue_0.val = false;
{
gdjs.s375Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s375Code.mapOfGDgdjs_46s375Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s375Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s375Code.condition0IsTrue_0.val = false;
{
gdjs.s375Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s375Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s376", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s375Code.GDBObjects1);

gdjs.s375Code.condition0IsTrue_0.val = false;
{
gdjs.s375Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s375Code.mapOfGDgdjs_46s375Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s375Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s376", false);
}}

}


{


{
}

}


};

gdjs.s375Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s375Code.GDcaseObjects1.length = 0;
gdjs.s375Code.GDcaseObjects2.length = 0;
gdjs.s375Code.GDimageObjects1.length = 0;
gdjs.s375Code.GDimageObjects2.length = 0;
gdjs.s375Code.GDoffObjects1.length = 0;
gdjs.s375Code.GDoffObjects2.length = 0;
gdjs.s375Code.GDonObjects1.length = 0;
gdjs.s375Code.GDonObjects2.length = 0;
gdjs.s375Code.GDstartObjects1.length = 0;
gdjs.s375Code.GDstartObjects2.length = 0;
gdjs.s375Code.GDBObjects1.length = 0;
gdjs.s375Code.GDBObjects2.length = 0;
gdjs.s375Code.GDblackObjects1.length = 0;
gdjs.s375Code.GDblackObjects2.length = 0;
gdjs.s375Code.GDAObjects1.length = 0;
gdjs.s375Code.GDAObjects2.length = 0;

gdjs.s375Code.eventsList0(runtimeScene);
return;

}

gdjs['s375Code'] = gdjs.s375Code;
