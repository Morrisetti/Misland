gdjs.s311Code = {};
gdjs.s311Code.GDcaseObjects1= [];
gdjs.s311Code.GDcaseObjects2= [];
gdjs.s311Code.GDoffObjects1= [];
gdjs.s311Code.GDoffObjects2= [];
gdjs.s311Code.GDonObjects1= [];
gdjs.s311Code.GDonObjects2= [];
gdjs.s311Code.GDstartObjects1= [];
gdjs.s311Code.GDstartObjects2= [];
gdjs.s311Code.GDBObjects1= [];
gdjs.s311Code.GDBObjects2= [];
gdjs.s311Code.GDAObjects1= [];
gdjs.s311Code.GDAObjects2= [];
gdjs.s311Code.GDbugzObjects1= [];
gdjs.s311Code.GDbugzObjects2= [];
gdjs.s311Code.GDDOWNbuttonObjects1= [];
gdjs.s311Code.GDDOWNbuttonObjects2= [];
gdjs.s311Code.GDblackObjects1= [];
gdjs.s311Code.GDblackObjects2= [];
gdjs.s311Code.GDDOWNcolObjects1= [];
gdjs.s311Code.GDDOWNcolObjects2= [];
gdjs.s311Code.GDUPbuttonObjects1= [];
gdjs.s311Code.GDUPbuttonObjects2= [];
gdjs.s311Code.GDUPcolObjects1= [];
gdjs.s311Code.GDUPcolObjects2= [];
gdjs.s311Code.GDLbuttonObjects1= [];
gdjs.s311Code.GDLbuttonObjects2= [];
gdjs.s311Code.GDLcolObjects1= [];
gdjs.s311Code.GDLcolObjects2= [];
gdjs.s311Code.GDRbuttonObjects1= [];
gdjs.s311Code.GDRbuttonObjects2= [];
gdjs.s311Code.GDexitObjects1= [];
gdjs.s311Code.GDexitObjects2= [];
gdjs.s311Code.GDDeathObjects1= [];
gdjs.s311Code.GDDeathObjects2= [];
gdjs.s311Code.GDRcolObjects1= [];
gdjs.s311Code.GDRcolObjects2= [];
gdjs.s311Code.GDchapter4Objects1= [];
gdjs.s311Code.GDchapter4Objects2= [];
gdjs.s311Code.GDchapter3Objects1= [];
gdjs.s311Code.GDchapter3Objects2= [];
gdjs.s311Code.GDchapter2Objects1= [];
gdjs.s311Code.GDchapter2Objects2= [];
gdjs.s311Code.GDchapter1Objects1= [];
gdjs.s311Code.GDchapter1Objects2= [];
gdjs.s311Code.GDBGObjects1= [];
gdjs.s311Code.GDBGObjects2= [];
gdjs.s311Code.GDshadowObjects1= [];
gdjs.s311Code.GDshadowObjects2= [];

gdjs.s311Code.conditionTrue_0 = {val:false};
gdjs.s311Code.condition0IsTrue_0 = {val:false};
gdjs.s311Code.condition1IsTrue_0 = {val:false};
gdjs.s311Code.condition2IsTrue_0 = {val:false};
gdjs.s311Code.conditionTrue_1 = {val:false};
gdjs.s311Code.condition0IsTrue_1 = {val:false};
gdjs.s311Code.condition1IsTrue_1 = {val:false};
gdjs.s311Code.condition2IsTrue_1 = {val:false};


gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s311Code.GDDOWNbuttonObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s311Code.GDUPbuttonObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s311Code.GDRbuttonObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s311Code.GDLbuttonObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s311Code.GDbugzObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s311Code.GDRcolObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s311Code.GDbugzObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s311Code.GDLcolObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s311Code.GDbugzObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s311Code.GDUPcolObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s311Code.GDbugzObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s311Code.GDDOWNcolObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s311Code.GDbugzObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s311Code.GDDOWNcolObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s311Code.GDBObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s311Code.GDAObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s311Code.GDoffObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s311Code.GDonObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s311Code.GDbugzObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs.s311Code.GDDeathObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s311Code.GDbugzObjects1});gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.s311Code.GDexitObjects1});gdjs.s311Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s311Code.GDDOWNbuttonObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
gdjs.s311Code.condition1IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s311Code.condition0IsTrue_0.val ) {
{
gdjs.s311Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s311Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s311Code.GDUPbuttonObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
gdjs.s311Code.condition1IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s311Code.condition0IsTrue_0.val ) {
{
gdjs.s311Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s311Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s311Code.GDRbuttonObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
gdjs.s311Code.condition1IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s311Code.condition0IsTrue_0.val ) {
{
gdjs.s311Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s311Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s311Code.GDLbuttonObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
gdjs.s311Code.condition1IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s311Code.condition0IsTrue_0.val ) {
{
gdjs.s311Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s311Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


gdjs.s311Code.condition0IsTrue_0.val = false;
{
{gdjs.s311Code.conditionTrue_1 = gdjs.s311Code.condition0IsTrue_0;
gdjs.s311Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(93448076);
}
}if (gdjs.s311Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter7_v1.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s311Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects, gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s311Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s311Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s311Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects, gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s311Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s311Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s311Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects, gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s311Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s311Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s311Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects, gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s311Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s311Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s311Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects, gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s311Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s311Code.GDBObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s311Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s311Code.GDAObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s311Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s311Code.GDoffObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s311Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s311Code.GDonObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s311Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s311Code.condition0IsTrue_0.val = false;
gdjs.s311Code.condition1IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s311Code.condition0IsTrue_0.val ) {
{
gdjs.s311Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s311Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s311Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s311Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s311Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s311Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s311Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s311Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.s311Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects, gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDDeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s311Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s281", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.s311Code.GDexitObjects1);

gdjs.s311Code.condition0IsTrue_0.val = false;
{
gdjs.s311Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDbugzObjects1Objects, gdjs.s311Code.mapOfGDgdjs_46s311Code_46GDexitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s311Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s312", false);
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s311Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s311Code.GDbugzObjects1.length !== 0 ? gdjs.s311Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s311Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s311Code.GDcaseObjects1.length = 0;
gdjs.s311Code.GDcaseObjects2.length = 0;
gdjs.s311Code.GDoffObjects1.length = 0;
gdjs.s311Code.GDoffObjects2.length = 0;
gdjs.s311Code.GDonObjects1.length = 0;
gdjs.s311Code.GDonObjects2.length = 0;
gdjs.s311Code.GDstartObjects1.length = 0;
gdjs.s311Code.GDstartObjects2.length = 0;
gdjs.s311Code.GDBObjects1.length = 0;
gdjs.s311Code.GDBObjects2.length = 0;
gdjs.s311Code.GDAObjects1.length = 0;
gdjs.s311Code.GDAObjects2.length = 0;
gdjs.s311Code.GDbugzObjects1.length = 0;
gdjs.s311Code.GDbugzObjects2.length = 0;
gdjs.s311Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s311Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s311Code.GDblackObjects1.length = 0;
gdjs.s311Code.GDblackObjects2.length = 0;
gdjs.s311Code.GDDOWNcolObjects1.length = 0;
gdjs.s311Code.GDDOWNcolObjects2.length = 0;
gdjs.s311Code.GDUPbuttonObjects1.length = 0;
gdjs.s311Code.GDUPbuttonObjects2.length = 0;
gdjs.s311Code.GDUPcolObjects1.length = 0;
gdjs.s311Code.GDUPcolObjects2.length = 0;
gdjs.s311Code.GDLbuttonObjects1.length = 0;
gdjs.s311Code.GDLbuttonObjects2.length = 0;
gdjs.s311Code.GDLcolObjects1.length = 0;
gdjs.s311Code.GDLcolObjects2.length = 0;
gdjs.s311Code.GDRbuttonObjects1.length = 0;
gdjs.s311Code.GDRbuttonObjects2.length = 0;
gdjs.s311Code.GDexitObjects1.length = 0;
gdjs.s311Code.GDexitObjects2.length = 0;
gdjs.s311Code.GDDeathObjects1.length = 0;
gdjs.s311Code.GDDeathObjects2.length = 0;
gdjs.s311Code.GDRcolObjects1.length = 0;
gdjs.s311Code.GDRcolObjects2.length = 0;
gdjs.s311Code.GDchapter4Objects1.length = 0;
gdjs.s311Code.GDchapter4Objects2.length = 0;
gdjs.s311Code.GDchapter3Objects1.length = 0;
gdjs.s311Code.GDchapter3Objects2.length = 0;
gdjs.s311Code.GDchapter2Objects1.length = 0;
gdjs.s311Code.GDchapter2Objects2.length = 0;
gdjs.s311Code.GDchapter1Objects1.length = 0;
gdjs.s311Code.GDchapter1Objects2.length = 0;
gdjs.s311Code.GDBGObjects1.length = 0;
gdjs.s311Code.GDBGObjects2.length = 0;
gdjs.s311Code.GDshadowObjects1.length = 0;
gdjs.s311Code.GDshadowObjects2.length = 0;

gdjs.s311Code.eventsList0(runtimeScene);
return;

}

gdjs['s311Code'] = gdjs.s311Code;
