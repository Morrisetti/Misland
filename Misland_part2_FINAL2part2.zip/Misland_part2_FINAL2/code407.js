gdjs.s363Code = {};
gdjs.s363Code.GDcaseObjects1= [];
gdjs.s363Code.GDcaseObjects2= [];
gdjs.s363Code.GDimageObjects1= [];
gdjs.s363Code.GDimageObjects2= [];
gdjs.s363Code.GDoffObjects1= [];
gdjs.s363Code.GDoffObjects2= [];
gdjs.s363Code.GDonObjects1= [];
gdjs.s363Code.GDonObjects2= [];
gdjs.s363Code.GDstartObjects1= [];
gdjs.s363Code.GDstartObjects2= [];
gdjs.s363Code.GDBObjects1= [];
gdjs.s363Code.GDBObjects2= [];
gdjs.s363Code.GDAObjects1= [];
gdjs.s363Code.GDAObjects2= [];
gdjs.s363Code.GDcrosshairsObjects1= [];
gdjs.s363Code.GDcrosshairsObjects2= [];
gdjs.s363Code.GDDOWNbuttonObjects1= [];
gdjs.s363Code.GDDOWNbuttonObjects2= [];
gdjs.s363Code.GDDOWNcolObjects1= [];
gdjs.s363Code.GDDOWNcolObjects2= [];
gdjs.s363Code.GDUPbuttonObjects1= [];
gdjs.s363Code.GDUPbuttonObjects2= [];
gdjs.s363Code.GDUPcolObjects1= [];
gdjs.s363Code.GDUPcolObjects2= [];
gdjs.s363Code.GDLbuttonObjects1= [];
gdjs.s363Code.GDLbuttonObjects2= [];
gdjs.s363Code.GDLcolObjects1= [];
gdjs.s363Code.GDLcolObjects2= [];
gdjs.s363Code.GDRbuttonObjects1= [];
gdjs.s363Code.GDRbuttonObjects2= [];
gdjs.s363Code.GDRcolObjects1= [];
gdjs.s363Code.GDRcolObjects2= [];
gdjs.s363Code.GDchapter4Objects1= [];
gdjs.s363Code.GDchapter4Objects2= [];
gdjs.s363Code.GDchapter3Objects1= [];
gdjs.s363Code.GDchapter3Objects2= [];
gdjs.s363Code.GDchapter2Objects1= [];
gdjs.s363Code.GDchapter2Objects2= [];
gdjs.s363Code.GDblackObjects1= [];
gdjs.s363Code.GDblackObjects2= [];
gdjs.s363Code.GDchapter1Objects1= [];
gdjs.s363Code.GDchapter1Objects2= [];

gdjs.s363Code.conditionTrue_0 = {val:false};
gdjs.s363Code.condition0IsTrue_0 = {val:false};
gdjs.s363Code.condition1IsTrue_0 = {val:false};
gdjs.s363Code.condition2IsTrue_0 = {val:false};


gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s363Code.GDDOWNbuttonObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s363Code.GDUPbuttonObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s363Code.GDRbuttonObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s363Code.GDLbuttonObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s363Code.GDcrosshairsObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s363Code.GDRcolObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s363Code.GDcrosshairsObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s363Code.GDLcolObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s363Code.GDcrosshairsObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s363Code.GDUPcolObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s363Code.GDcrosshairsObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s363Code.GDDOWNcolObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s363Code.GDcrosshairsObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s363Code.GDDOWNcolObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s363Code.GDoffObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s363Code.GDonObjects1});gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s363Code.GDBObjects1});gdjs.s363Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s363Code.GDDOWNbuttonObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
gdjs.s363Code.condition1IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s363Code.condition0IsTrue_0.val ) {
{
gdjs.s363Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s363Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s363Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s363Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s363Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s363Code.GDUPbuttonObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
gdjs.s363Code.condition1IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s363Code.condition0IsTrue_0.val ) {
{
gdjs.s363Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s363Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s363Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s363Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s363Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s363Code.GDRbuttonObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
gdjs.s363Code.condition1IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s363Code.condition0IsTrue_0.val ) {
{
gdjs.s363Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s363Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s363Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s363Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s363Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s363Code.GDLbuttonObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
gdjs.s363Code.condition1IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s363Code.condition0IsTrue_0.val ) {
{
gdjs.s363Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s363Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s363Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s363Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s363Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s363Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s363Code.GDcrosshairsObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDcrosshairsObjects1Objects, gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s363Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s363Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s363Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s363Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s363Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s363Code.GDcrosshairsObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDcrosshairsObjects1Objects, gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s363Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s363Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s363Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s363Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s363Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s363Code.GDcrosshairsObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDcrosshairsObjects1Objects, gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s363Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s363Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s363Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s363Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s363Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s363Code.GDcrosshairsObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDcrosshairsObjects1Objects, gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s363Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s363Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s363Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s363Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s363Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s363Code.GDcrosshairsObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDcrosshairsObjects1Objects, gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s363Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s363Code.GDoffObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s363Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s363Code.GDonObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s363Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s363Code.GDstartObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s363Code.GDstartObjects1.length;i<l;++i) {
    if ( gdjs.s363Code.GDstartObjects1[i].timerElapsedTime("", 3) ) {
        gdjs.s363Code.condition0IsTrue_0.val = true;
        gdjs.s363Code.GDstartObjects1[k] = gdjs.s363Code.GDstartObjects1[i];
        ++k;
    }
}
gdjs.s363Code.GDstartObjects1.length = k;}if (gdjs.s363Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s359.1", false);
}}

}


{


gdjs.s363Code.condition0IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s363Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s364", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s363Code.GDBObjects1);

gdjs.s363Code.condition0IsTrue_0.val = false;
{
gdjs.s363Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s363Code.mapOfGDgdjs_46s363Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s363Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s364", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s363Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s363Code.GDcaseObjects1.length = 0;
gdjs.s363Code.GDcaseObjects2.length = 0;
gdjs.s363Code.GDimageObjects1.length = 0;
gdjs.s363Code.GDimageObjects2.length = 0;
gdjs.s363Code.GDoffObjects1.length = 0;
gdjs.s363Code.GDoffObjects2.length = 0;
gdjs.s363Code.GDonObjects1.length = 0;
gdjs.s363Code.GDonObjects2.length = 0;
gdjs.s363Code.GDstartObjects1.length = 0;
gdjs.s363Code.GDstartObjects2.length = 0;
gdjs.s363Code.GDBObjects1.length = 0;
gdjs.s363Code.GDBObjects2.length = 0;
gdjs.s363Code.GDAObjects1.length = 0;
gdjs.s363Code.GDAObjects2.length = 0;
gdjs.s363Code.GDcrosshairsObjects1.length = 0;
gdjs.s363Code.GDcrosshairsObjects2.length = 0;
gdjs.s363Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s363Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s363Code.GDDOWNcolObjects1.length = 0;
gdjs.s363Code.GDDOWNcolObjects2.length = 0;
gdjs.s363Code.GDUPbuttonObjects1.length = 0;
gdjs.s363Code.GDUPbuttonObjects2.length = 0;
gdjs.s363Code.GDUPcolObjects1.length = 0;
gdjs.s363Code.GDUPcolObjects2.length = 0;
gdjs.s363Code.GDLbuttonObjects1.length = 0;
gdjs.s363Code.GDLbuttonObjects2.length = 0;
gdjs.s363Code.GDLcolObjects1.length = 0;
gdjs.s363Code.GDLcolObjects2.length = 0;
gdjs.s363Code.GDRbuttonObjects1.length = 0;
gdjs.s363Code.GDRbuttonObjects2.length = 0;
gdjs.s363Code.GDRcolObjects1.length = 0;
gdjs.s363Code.GDRcolObjects2.length = 0;
gdjs.s363Code.GDchapter4Objects1.length = 0;
gdjs.s363Code.GDchapter4Objects2.length = 0;
gdjs.s363Code.GDchapter3Objects1.length = 0;
gdjs.s363Code.GDchapter3Objects2.length = 0;
gdjs.s363Code.GDchapter2Objects1.length = 0;
gdjs.s363Code.GDchapter2Objects2.length = 0;
gdjs.s363Code.GDblackObjects1.length = 0;
gdjs.s363Code.GDblackObjects2.length = 0;
gdjs.s363Code.GDchapter1Objects1.length = 0;
gdjs.s363Code.GDchapter1Objects2.length = 0;

gdjs.s363Code.eventsList0(runtimeScene);
return;

}

gdjs['s363Code'] = gdjs.s363Code;
