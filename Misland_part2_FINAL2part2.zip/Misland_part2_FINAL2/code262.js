gdjs.s231Code = {};
gdjs.s231Code.GDcaseObjects1= [];
gdjs.s231Code.GDcaseObjects2= [];
gdjs.s231Code.GDoffObjects1= [];
gdjs.s231Code.GDoffObjects2= [];
gdjs.s231Code.GDonObjects1= [];
gdjs.s231Code.GDonObjects2= [];
gdjs.s231Code.GDstartObjects1= [];
gdjs.s231Code.GDstartObjects2= [];
gdjs.s231Code.GDBObjects1= [];
gdjs.s231Code.GDBObjects2= [];
gdjs.s231Code.GDAObjects1= [];
gdjs.s231Code.GDAObjects2= [];
gdjs.s231Code.GDbugzObjects1= [];
gdjs.s231Code.GDbugzObjects2= [];
gdjs.s231Code.GDDOWNbuttonObjects1= [];
gdjs.s231Code.GDDOWNbuttonObjects2= [];
gdjs.s231Code.GDblockObjects1= [];
gdjs.s231Code.GDblockObjects2= [];
gdjs.s231Code.GDblackObjects1= [];
gdjs.s231Code.GDblackObjects2= [];
gdjs.s231Code.GDdeathObjects1= [];
gdjs.s231Code.GDdeathObjects2= [];
gdjs.s231Code.GDUPbuttonObjects1= [];
gdjs.s231Code.GDUPbuttonObjects2= [];
gdjs.s231Code.GDplatformObjects1= [];
gdjs.s231Code.GDplatformObjects2= [];
gdjs.s231Code.GDLbuttonObjects1= [];
gdjs.s231Code.GDLbuttonObjects2= [];
gdjs.s231Code.GDLcolObjects1= [];
gdjs.s231Code.GDLcolObjects2= [];
gdjs.s231Code.GDRbuttonObjects1= [];
gdjs.s231Code.GDRbuttonObjects2= [];
gdjs.s231Code.GDladObjects1= [];
gdjs.s231Code.GDladObjects2= [];
gdjs.s231Code.GDExitObjects1= [];
gdjs.s231Code.GDExitObjects2= [];
gdjs.s231Code.GDRcolObjects1= [];
gdjs.s231Code.GDRcolObjects2= [];
gdjs.s231Code.GDtargetObjects1= [];
gdjs.s231Code.GDtargetObjects2= [];
gdjs.s231Code.GDchapter3Objects1= [];
gdjs.s231Code.GDchapter3Objects2= [];
gdjs.s231Code.GDchapter2Objects1= [];
gdjs.s231Code.GDchapter2Objects2= [];
gdjs.s231Code.GDchapter1Objects1= [];
gdjs.s231Code.GDchapter1Objects2= [];
gdjs.s231Code.GDBGObjects1= [];
gdjs.s231Code.GDBGObjects2= [];

gdjs.s231Code.conditionTrue_0 = {val:false};
gdjs.s231Code.condition0IsTrue_0 = {val:false};
gdjs.s231Code.condition1IsTrue_0 = {val:false};
gdjs.s231Code.condition2IsTrue_0 = {val:false};
gdjs.s231Code.conditionTrue_1 = {val:false};
gdjs.s231Code.condition0IsTrue_1 = {val:false};
gdjs.s231Code.condition1IsTrue_1 = {val:false};
gdjs.s231Code.condition2IsTrue_1 = {val:false};


gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s231Code.GDDOWNbuttonObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s231Code.GDUPbuttonObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s231Code.GDRbuttonObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s231Code.GDLbuttonObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s231Code.GDbugzObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s231Code.GDRcolObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s231Code.GDbugzObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s231Code.GDLcolObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s231Code.GDbugzObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDplatformObjects1Objects = Hashtable.newFrom({"platform": gdjs.s231Code.GDplatformObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s231Code.GDbugzObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDdeathObjects1Objects = Hashtable.newFrom({"death": gdjs.s231Code.GDdeathObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s231Code.GDBObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s231Code.GDAObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s231Code.GDoffObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s231Code.GDonObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s231Code.GDbugzObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s231Code.GDExitObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s231Code.GDbugzObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDdeathObjects1Objects = Hashtable.newFrom({"death": gdjs.s231Code.GDdeathObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s231Code.GDbugzObjects1});gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDladObjects1Objects = Hashtable.newFrom({"lad": gdjs.s231Code.GDladObjects1});gdjs.s231Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s231Code.GDDOWNbuttonObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
gdjs.s231Code.condition1IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s231Code.condition0IsTrue_0.val ) {
{
gdjs.s231Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s231Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s231Code.GDUPbuttonObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
gdjs.s231Code.condition1IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s231Code.condition0IsTrue_0.val ) {
{
gdjs.s231Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s231Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s231Code.GDRbuttonObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
gdjs.s231Code.condition1IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s231Code.condition0IsTrue_0.val ) {
{
gdjs.s231Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s231Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s231Code.GDLbuttonObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
gdjs.s231Code.condition1IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s231Code.condition0IsTrue_0.val ) {
{
gdjs.s231Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s231Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].flipX(true);
}
}{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}}

}


{


gdjs.s231Code.condition0IsTrue_0.val = false;
{
{gdjs.s231Code.conditionTrue_1 = gdjs.s231Code.condition0IsTrue_0;
gdjs.s231Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(91774732);
}
}if (gdjs.s231Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "crazychaseV2.mp3", true, 100, 1.1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s231Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects, gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s231Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s231Code.GDbugzObjects1 */
{}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s231Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects, gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s231Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s231Code.GDbugzObjects1 */
{}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("platform"), gdjs.s231Code.GDplatformObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects, gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDplatformObjects1Objects, false, runtimeScene, false);
}if (gdjs.s231Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s231Code.GDbugzObjects1 */
{}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s231Code.GDdeathObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects, gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDdeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s231Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s231Code.GDbugzObjects1 */
{}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s231Code.GDBObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s231Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s231Code.GDAObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
gdjs.s231Code.condition1IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDAObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s231Code.condition0IsTrue_0.val ) {
{
{gdjs.s231Code.conditionTrue_1 = gdjs.s231Code.condition1IsTrue_0;
gdjs.s231Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(91779420);
}
}}
if (gdjs.s231Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s231Code.GDoffObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s231Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s231Code.GDonObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s231Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s231Code.condition0IsTrue_0.val = false;
gdjs.s231Code.condition1IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s231Code.condition0IsTrue_0.val ) {
{
gdjs.s231Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s231Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s231Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s231Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects, gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s231Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s232", false);
}}

}


{


gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s231Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s231Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s231Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s231Code.GDdeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("target"), gdjs.s231Code.GDtargetObjects1);
{for(var i = 0, len = gdjs.s231Code.GDdeathObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDdeathObjects1[i].addForceTowardObject((gdjs.s231Code.GDtargetObjects1.length !== 0 ? gdjs.s231Code.GDtargetObjects1[0] : null), 25, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s231Code.GDdeathObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects, gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDdeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s231Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s2302", false);
}}

}


{


gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s231Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s231Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("lad"), gdjs.s231Code.GDladObjects1);

gdjs.s231Code.condition0IsTrue_0.val = false;
{
gdjs.s231Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDbugzObjects1Objects, gdjs.s231Code.mapOfGDgdjs_46s231Code_46GDladObjects1Objects, false, runtimeScene, false);
}if (gdjs.s231Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s231Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Ladder");
}
}{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateUpKey();
}
}{for(var i = 0, len = gdjs.s231Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s231Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


};

gdjs.s231Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s231Code.GDcaseObjects1.length = 0;
gdjs.s231Code.GDcaseObjects2.length = 0;
gdjs.s231Code.GDoffObjects1.length = 0;
gdjs.s231Code.GDoffObjects2.length = 0;
gdjs.s231Code.GDonObjects1.length = 0;
gdjs.s231Code.GDonObjects2.length = 0;
gdjs.s231Code.GDstartObjects1.length = 0;
gdjs.s231Code.GDstartObjects2.length = 0;
gdjs.s231Code.GDBObjects1.length = 0;
gdjs.s231Code.GDBObjects2.length = 0;
gdjs.s231Code.GDAObjects1.length = 0;
gdjs.s231Code.GDAObjects2.length = 0;
gdjs.s231Code.GDbugzObjects1.length = 0;
gdjs.s231Code.GDbugzObjects2.length = 0;
gdjs.s231Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s231Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s231Code.GDblockObjects1.length = 0;
gdjs.s231Code.GDblockObjects2.length = 0;
gdjs.s231Code.GDblackObjects1.length = 0;
gdjs.s231Code.GDblackObjects2.length = 0;
gdjs.s231Code.GDdeathObjects1.length = 0;
gdjs.s231Code.GDdeathObjects2.length = 0;
gdjs.s231Code.GDUPbuttonObjects1.length = 0;
gdjs.s231Code.GDUPbuttonObjects2.length = 0;
gdjs.s231Code.GDplatformObjects1.length = 0;
gdjs.s231Code.GDplatformObjects2.length = 0;
gdjs.s231Code.GDLbuttonObjects1.length = 0;
gdjs.s231Code.GDLbuttonObjects2.length = 0;
gdjs.s231Code.GDLcolObjects1.length = 0;
gdjs.s231Code.GDLcolObjects2.length = 0;
gdjs.s231Code.GDRbuttonObjects1.length = 0;
gdjs.s231Code.GDRbuttonObjects2.length = 0;
gdjs.s231Code.GDladObjects1.length = 0;
gdjs.s231Code.GDladObjects2.length = 0;
gdjs.s231Code.GDExitObjects1.length = 0;
gdjs.s231Code.GDExitObjects2.length = 0;
gdjs.s231Code.GDRcolObjects1.length = 0;
gdjs.s231Code.GDRcolObjects2.length = 0;
gdjs.s231Code.GDtargetObjects1.length = 0;
gdjs.s231Code.GDtargetObjects2.length = 0;
gdjs.s231Code.GDchapter3Objects1.length = 0;
gdjs.s231Code.GDchapter3Objects2.length = 0;
gdjs.s231Code.GDchapter2Objects1.length = 0;
gdjs.s231Code.GDchapter2Objects2.length = 0;
gdjs.s231Code.GDchapter1Objects1.length = 0;
gdjs.s231Code.GDchapter1Objects2.length = 0;
gdjs.s231Code.GDBGObjects1.length = 0;
gdjs.s231Code.GDBGObjects2.length = 0;

gdjs.s231Code.eventsList0(runtimeScene);
return;

}

gdjs['s231Code'] = gdjs.s231Code;
