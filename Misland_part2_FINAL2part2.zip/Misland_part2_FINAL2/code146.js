gdjs.s128Code = {};
gdjs.s128Code.GDcaseObjects1= [];
gdjs.s128Code.GDcaseObjects2= [];
gdjs.s128Code.GDoffObjects1= [];
gdjs.s128Code.GDoffObjects2= [];
gdjs.s128Code.GDonObjects1= [];
gdjs.s128Code.GDonObjects2= [];
gdjs.s128Code.GDstartObjects1= [];
gdjs.s128Code.GDstartObjects2= [];
gdjs.s128Code.GDBObjects1= [];
gdjs.s128Code.GDBObjects2= [];
gdjs.s128Code.GDAObjects1= [];
gdjs.s128Code.GDAObjects2= [];
gdjs.s128Code.GDbugzObjects1= [];
gdjs.s128Code.GDbugzObjects2= [];
gdjs.s128Code.GDDOWNbuttonObjects1= [];
gdjs.s128Code.GDDOWNbuttonObjects2= [];
gdjs.s128Code.GDblackObjects1= [];
gdjs.s128Code.GDblackObjects2= [];
gdjs.s128Code.GDDOWNcol2Objects1= [];
gdjs.s128Code.GDDOWNcol2Objects2= [];
gdjs.s128Code.GDDOWNcolObjects1= [];
gdjs.s128Code.GDDOWNcolObjects2= [];
gdjs.s128Code.GDUPbuttonObjects1= [];
gdjs.s128Code.GDUPbuttonObjects2= [];
gdjs.s128Code.GDUPcolObjects1= [];
gdjs.s128Code.GDUPcolObjects2= [];
gdjs.s128Code.GDLbuttonObjects1= [];
gdjs.s128Code.GDLbuttonObjects2= [];
gdjs.s128Code.GDLcolObjects1= [];
gdjs.s128Code.GDLcolObjects2= [];
gdjs.s128Code.GDRbuttonObjects1= [];
gdjs.s128Code.GDRbuttonObjects2= [];
gdjs.s128Code.GDTALK3Objects1= [];
gdjs.s128Code.GDTALK3Objects2= [];
gdjs.s128Code.GDdeathObjects1= [];
gdjs.s128Code.GDdeathObjects2= [];
gdjs.s128Code.GDExitObjects1= [];
gdjs.s128Code.GDExitObjects2= [];
gdjs.s128Code.GDRcolObjects1= [];
gdjs.s128Code.GDRcolObjects2= [];
gdjs.s128Code.GDchapter4Objects1= [];
gdjs.s128Code.GDchapter4Objects2= [];
gdjs.s128Code.GDchapter3Objects1= [];
gdjs.s128Code.GDchapter3Objects2= [];
gdjs.s128Code.GDchapter2Objects1= [];
gdjs.s128Code.GDchapter2Objects2= [];
gdjs.s128Code.GDchapter1Objects1= [];
gdjs.s128Code.GDchapter1Objects2= [];
gdjs.s128Code.GDBGObjects1= [];
gdjs.s128Code.GDBGObjects2= [];

gdjs.s128Code.conditionTrue_0 = {val:false};
gdjs.s128Code.condition0IsTrue_0 = {val:false};
gdjs.s128Code.condition1IsTrue_0 = {val:false};
gdjs.s128Code.condition2IsTrue_0 = {val:false};


gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s128Code.GDDOWNbuttonObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s128Code.GDUPbuttonObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s128Code.GDRbuttonObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s128Code.GDLbuttonObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s128Code.GDbugzObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s128Code.GDRcolObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s128Code.GDbugzObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s128Code.GDLcolObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s128Code.GDbugzObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s128Code.GDUPcolObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s128Code.GDbugzObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s128Code.GDDOWNcolObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s128Code.GDbugzObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s128Code.GDDOWNcolObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s128Code.GDbugzObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDDOWNcol2Objects1Objects = Hashtable.newFrom({"DOWNcol2": gdjs.s128Code.GDDOWNcol2Objects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s128Code.GDBObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s128Code.GDAObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s128Code.GDoffObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s128Code.GDonObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s128Code.GDbugzObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s128Code.GDExitObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s128Code.GDbugzObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDdeathObjects1Objects = Hashtable.newFrom({"death": gdjs.s128Code.GDdeathObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s128Code.GDbugzObjects1});gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDTALK3Objects1Objects = Hashtable.newFrom({"TALK3": gdjs.s128Code.GDTALK3Objects1});gdjs.s128Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s128Code.GDDOWNbuttonObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
gdjs.s128Code.condition1IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s128Code.condition0IsTrue_0.val ) {
{
gdjs.s128Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s128Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s128Code.GDUPbuttonObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
gdjs.s128Code.condition1IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s128Code.condition0IsTrue_0.val ) {
{
gdjs.s128Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s128Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s128Code.GDRbuttonObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
gdjs.s128Code.condition1IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s128Code.condition0IsTrue_0.val ) {
{
gdjs.s128Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s128Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s128Code.GDLbuttonObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
gdjs.s128Code.condition1IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s128Code.condition0IsTrue_0.val ) {
{
gdjs.s128Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s128Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s128Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects, gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s128Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s128Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects, gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s128Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s128Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects, gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s128Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s128Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects, gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s128Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s128Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects, gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol2"), gdjs.s128Code.GDDOWNcol2Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects, gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDDOWNcol2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s128Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].setDirectionOrAngle(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s128Code.GDBObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s128Code.GDAObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s128Code.GDoffObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s128Code.GDonObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s128Code.condition0IsTrue_0.val = false;
gdjs.s128Code.condition1IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s128Code.condition0IsTrue_0.val ) {
{
gdjs.s128Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s128Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s128Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s128Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s128Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s128Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s128Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s128Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s128Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects, gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s129", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s128Code.GDdeathObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects, gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDdeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s123", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK3"), gdjs.s128Code.GDTALK3Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);

gdjs.s128Code.condition0IsTrue_0.val = false;
{
gdjs.s128Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDbugzObjects1Objects, gdjs.s128Code.mapOfGDgdjs_46s128Code_46GDTALK3Objects1Objects, false, runtimeScene, false);
}if (gdjs.s128Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s95", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s128Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s128Code.GDbugzObjects1.length !== 0 ? gdjs.s128Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s128Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s128Code.GDcaseObjects1.length = 0;
gdjs.s128Code.GDcaseObjects2.length = 0;
gdjs.s128Code.GDoffObjects1.length = 0;
gdjs.s128Code.GDoffObjects2.length = 0;
gdjs.s128Code.GDonObjects1.length = 0;
gdjs.s128Code.GDonObjects2.length = 0;
gdjs.s128Code.GDstartObjects1.length = 0;
gdjs.s128Code.GDstartObjects2.length = 0;
gdjs.s128Code.GDBObjects1.length = 0;
gdjs.s128Code.GDBObjects2.length = 0;
gdjs.s128Code.GDAObjects1.length = 0;
gdjs.s128Code.GDAObjects2.length = 0;
gdjs.s128Code.GDbugzObjects1.length = 0;
gdjs.s128Code.GDbugzObjects2.length = 0;
gdjs.s128Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s128Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s128Code.GDblackObjects1.length = 0;
gdjs.s128Code.GDblackObjects2.length = 0;
gdjs.s128Code.GDDOWNcol2Objects1.length = 0;
gdjs.s128Code.GDDOWNcol2Objects2.length = 0;
gdjs.s128Code.GDDOWNcolObjects1.length = 0;
gdjs.s128Code.GDDOWNcolObjects2.length = 0;
gdjs.s128Code.GDUPbuttonObjects1.length = 0;
gdjs.s128Code.GDUPbuttonObjects2.length = 0;
gdjs.s128Code.GDUPcolObjects1.length = 0;
gdjs.s128Code.GDUPcolObjects2.length = 0;
gdjs.s128Code.GDLbuttonObjects1.length = 0;
gdjs.s128Code.GDLbuttonObjects2.length = 0;
gdjs.s128Code.GDLcolObjects1.length = 0;
gdjs.s128Code.GDLcolObjects2.length = 0;
gdjs.s128Code.GDRbuttonObjects1.length = 0;
gdjs.s128Code.GDRbuttonObjects2.length = 0;
gdjs.s128Code.GDTALK3Objects1.length = 0;
gdjs.s128Code.GDTALK3Objects2.length = 0;
gdjs.s128Code.GDdeathObjects1.length = 0;
gdjs.s128Code.GDdeathObjects2.length = 0;
gdjs.s128Code.GDExitObjects1.length = 0;
gdjs.s128Code.GDExitObjects2.length = 0;
gdjs.s128Code.GDRcolObjects1.length = 0;
gdjs.s128Code.GDRcolObjects2.length = 0;
gdjs.s128Code.GDchapter4Objects1.length = 0;
gdjs.s128Code.GDchapter4Objects2.length = 0;
gdjs.s128Code.GDchapter3Objects1.length = 0;
gdjs.s128Code.GDchapter3Objects2.length = 0;
gdjs.s128Code.GDchapter2Objects1.length = 0;
gdjs.s128Code.GDchapter2Objects2.length = 0;
gdjs.s128Code.GDchapter1Objects1.length = 0;
gdjs.s128Code.GDchapter1Objects2.length = 0;
gdjs.s128Code.GDBGObjects1.length = 0;
gdjs.s128Code.GDBGObjects2.length = 0;

gdjs.s128Code.eventsList0(runtimeScene);
return;

}

gdjs['s128Code'] = gdjs.s128Code;
