gdjs.s87CHCode = {};
gdjs.s87CHCode.GDcaseObjects1= [];
gdjs.s87CHCode.GDcaseObjects2= [];
gdjs.s87CHCode.GDimageObjects1= [];
gdjs.s87CHCode.GDimageObjects2= [];
gdjs.s87CHCode.GDoffObjects1= [];
gdjs.s87CHCode.GDoffObjects2= [];
gdjs.s87CHCode.GDonObjects1= [];
gdjs.s87CHCode.GDonObjects2= [];
gdjs.s87CHCode.GDstartObjects1= [];
gdjs.s87CHCode.GDstartObjects2= [];
gdjs.s87CHCode.GDBObjects1= [];
gdjs.s87CHCode.GDBObjects2= [];
gdjs.s87CHCode.GDAObjects1= [];
gdjs.s87CHCode.GDAObjects2= [];
gdjs.s87CHCode.GDcrosshairsObjects1= [];
gdjs.s87CHCode.GDcrosshairsObjects2= [];
gdjs.s87CHCode.GDDOWNbuttonObjects1= [];
gdjs.s87CHCode.GDDOWNbuttonObjects2= [];
gdjs.s87CHCode.GDDOWNcolObjects1= [];
gdjs.s87CHCode.GDDOWNcolObjects2= [];
gdjs.s87CHCode.GDUPbuttonObjects1= [];
gdjs.s87CHCode.GDUPbuttonObjects2= [];
gdjs.s87CHCode.GDUPcolObjects1= [];
gdjs.s87CHCode.GDUPcolObjects2= [];
gdjs.s87CHCode.GDLbuttonObjects1= [];
gdjs.s87CHCode.GDLbuttonObjects2= [];
gdjs.s87CHCode.GDLcolObjects1= [];
gdjs.s87CHCode.GDLcolObjects2= [];
gdjs.s87CHCode.GDRbuttonObjects1= [];
gdjs.s87CHCode.GDRbuttonObjects2= [];
gdjs.s87CHCode.GDRcolObjects1= [];
gdjs.s87CHCode.GDRcolObjects2= [];
gdjs.s87CHCode.GDchapter4Objects1= [];
gdjs.s87CHCode.GDchapter4Objects2= [];
gdjs.s87CHCode.GDchapter3Objects1= [];
gdjs.s87CHCode.GDchapter3Objects2= [];
gdjs.s87CHCode.GDchapter2Objects1= [];
gdjs.s87CHCode.GDchapter2Objects2= [];
gdjs.s87CHCode.GDblackObjects1= [];
gdjs.s87CHCode.GDblackObjects2= [];
gdjs.s87CHCode.GDchapter1Objects1= [];
gdjs.s87CHCode.GDchapter1Objects2= [];

gdjs.s87CHCode.conditionTrue_0 = {val:false};
gdjs.s87CHCode.condition0IsTrue_0 = {val:false};
gdjs.s87CHCode.condition1IsTrue_0 = {val:false};
gdjs.s87CHCode.condition2IsTrue_0 = {val:false};


gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s87CHCode.GDDOWNbuttonObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s87CHCode.GDUPbuttonObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s87CHCode.GDRbuttonObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s87CHCode.GDLbuttonObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s87CHCode.GDcrosshairsObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s87CHCode.GDRcolObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s87CHCode.GDcrosshairsObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s87CHCode.GDLcolObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s87CHCode.GDcrosshairsObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s87CHCode.GDUPcolObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s87CHCode.GDcrosshairsObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s87CHCode.GDDOWNcolObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s87CHCode.GDcrosshairsObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s87CHCode.GDDOWNcolObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s87CHCode.GDoffObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s87CHCode.GDonObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s87CHCode.GDcrosshairsObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDchapter2Objects1Objects = Hashtable.newFrom({"chapter2": gdjs.s87CHCode.GDchapter2Objects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s87CHCode.GDAObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s87CHCode.GDcrosshairsObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDchapter2Objects1Objects = Hashtable.newFrom({"chapter2": gdjs.s87CHCode.GDchapter2Objects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s87CHCode.GDcrosshairsObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s87CHCode.GDchapter1Objects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s87CHCode.GDAObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s87CHCode.GDcrosshairsObjects1});gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s87CHCode.GDchapter1Objects1});gdjs.s87CHCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s87CHCode.GDDOWNbuttonObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
gdjs.s87CHCode.condition1IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s87CHCode.condition0IsTrue_0.val ) {
{
gdjs.s87CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s87CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s87CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s87CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s87CHCode.GDUPbuttonObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
gdjs.s87CHCode.condition1IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s87CHCode.condition0IsTrue_0.val ) {
{
gdjs.s87CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s87CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s87CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s87CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s87CHCode.GDRbuttonObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
gdjs.s87CHCode.condition1IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s87CHCode.condition0IsTrue_0.val ) {
{
gdjs.s87CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s87CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s87CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s87CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s87CHCode.GDLbuttonObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
gdjs.s87CHCode.condition1IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s87CHCode.condition0IsTrue_0.val ) {
{
gdjs.s87CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s87CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s87CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s87CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s87CHCode.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects, gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s87CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s87CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s87CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s87CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s87CHCode.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects, gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s87CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s87CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s87CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s87CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s87CHCode.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects, gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s87CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s87CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s87CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s87CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s87CHCode.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects, gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s87CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s87CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s87CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s87CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s87CHCode.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects, gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s87CHCode.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s87CHCode.GDoffObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s87CHCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s87CHCode.GDonObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s87CHCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s87CHCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter2"), gdjs.s87CHCode.GDchapter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
gdjs.s87CHCode.condition1IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects, gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDchapter2Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s87CHCode.condition0IsTrue_0.val ) {
{
gdjs.s87CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.s87CHCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s81", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter2"), gdjs.s87CHCode.GDchapter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
gdjs.s87CHCode.condition1IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects, gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDchapter2Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s87CHCode.condition0IsTrue_0.val ) {
{
gdjs.s87CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s87CHCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s81", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s87CHCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s87CHCode.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
gdjs.s87CHCode.condition1IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects, gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s87CHCode.condition0IsTrue_0.val ) {
{
gdjs.s87CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.s87CHCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s88", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s87CHCode.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s87CHCode.GDcrosshairsObjects1);

gdjs.s87CHCode.condition0IsTrue_0.val = false;
gdjs.s87CHCode.condition1IsTrue_0.val = false;
{
gdjs.s87CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDcrosshairsObjects1Objects, gdjs.s87CHCode.mapOfGDgdjs_46s87CHCode_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s87CHCode.condition0IsTrue_0.val ) {
{
gdjs.s87CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s87CHCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s88", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s87CHCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s87CHCode.GDcaseObjects1.length = 0;
gdjs.s87CHCode.GDcaseObjects2.length = 0;
gdjs.s87CHCode.GDimageObjects1.length = 0;
gdjs.s87CHCode.GDimageObjects2.length = 0;
gdjs.s87CHCode.GDoffObjects1.length = 0;
gdjs.s87CHCode.GDoffObjects2.length = 0;
gdjs.s87CHCode.GDonObjects1.length = 0;
gdjs.s87CHCode.GDonObjects2.length = 0;
gdjs.s87CHCode.GDstartObjects1.length = 0;
gdjs.s87CHCode.GDstartObjects2.length = 0;
gdjs.s87CHCode.GDBObjects1.length = 0;
gdjs.s87CHCode.GDBObjects2.length = 0;
gdjs.s87CHCode.GDAObjects1.length = 0;
gdjs.s87CHCode.GDAObjects2.length = 0;
gdjs.s87CHCode.GDcrosshairsObjects1.length = 0;
gdjs.s87CHCode.GDcrosshairsObjects2.length = 0;
gdjs.s87CHCode.GDDOWNbuttonObjects1.length = 0;
gdjs.s87CHCode.GDDOWNbuttonObjects2.length = 0;
gdjs.s87CHCode.GDDOWNcolObjects1.length = 0;
gdjs.s87CHCode.GDDOWNcolObjects2.length = 0;
gdjs.s87CHCode.GDUPbuttonObjects1.length = 0;
gdjs.s87CHCode.GDUPbuttonObjects2.length = 0;
gdjs.s87CHCode.GDUPcolObjects1.length = 0;
gdjs.s87CHCode.GDUPcolObjects2.length = 0;
gdjs.s87CHCode.GDLbuttonObjects1.length = 0;
gdjs.s87CHCode.GDLbuttonObjects2.length = 0;
gdjs.s87CHCode.GDLcolObjects1.length = 0;
gdjs.s87CHCode.GDLcolObjects2.length = 0;
gdjs.s87CHCode.GDRbuttonObjects1.length = 0;
gdjs.s87CHCode.GDRbuttonObjects2.length = 0;
gdjs.s87CHCode.GDRcolObjects1.length = 0;
gdjs.s87CHCode.GDRcolObjects2.length = 0;
gdjs.s87CHCode.GDchapter4Objects1.length = 0;
gdjs.s87CHCode.GDchapter4Objects2.length = 0;
gdjs.s87CHCode.GDchapter3Objects1.length = 0;
gdjs.s87CHCode.GDchapter3Objects2.length = 0;
gdjs.s87CHCode.GDchapter2Objects1.length = 0;
gdjs.s87CHCode.GDchapter2Objects2.length = 0;
gdjs.s87CHCode.GDblackObjects1.length = 0;
gdjs.s87CHCode.GDblackObjects2.length = 0;
gdjs.s87CHCode.GDchapter1Objects1.length = 0;
gdjs.s87CHCode.GDchapter1Objects2.length = 0;

gdjs.s87CHCode.eventsList0(runtimeScene);
return;

}

gdjs['s87CHCode'] = gdjs.s87CHCode;
