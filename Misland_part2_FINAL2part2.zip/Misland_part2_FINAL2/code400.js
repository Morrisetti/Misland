gdjs.s357Code = {};
gdjs.s357Code.GDcaseObjects1= [];
gdjs.s357Code.GDcaseObjects2= [];
gdjs.s357Code.GDimageObjects1= [];
gdjs.s357Code.GDimageObjects2= [];
gdjs.s357Code.GDoffObjects1= [];
gdjs.s357Code.GDoffObjects2= [];
gdjs.s357Code.GDonObjects1= [];
gdjs.s357Code.GDonObjects2= [];
gdjs.s357Code.GDstartObjects1= [];
gdjs.s357Code.GDstartObjects2= [];
gdjs.s357Code.GDBObjects1= [];
gdjs.s357Code.GDBObjects2= [];
gdjs.s357Code.GDblackObjects1= [];
gdjs.s357Code.GDblackObjects2= [];
gdjs.s357Code.GDAObjects1= [];
gdjs.s357Code.GDAObjects2= [];

gdjs.s357Code.conditionTrue_0 = {val:false};
gdjs.s357Code.condition0IsTrue_0 = {val:false};
gdjs.s357Code.condition1IsTrue_0 = {val:false};
gdjs.s357Code.conditionTrue_1 = {val:false};
gdjs.s357Code.condition0IsTrue_1 = {val:false};
gdjs.s357Code.condition1IsTrue_1 = {val:false};


gdjs.s357Code.mapOfGDgdjs_46s357Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s357Code.GDoffObjects1});gdjs.s357Code.mapOfGDgdjs_46s357Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s357Code.GDonObjects1});gdjs.s357Code.mapOfGDgdjs_46s357Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s357Code.GDAObjects1});gdjs.s357Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s357Code.condition0IsTrue_0.val = false;
{
{gdjs.s357Code.conditionTrue_1 = gdjs.s357Code.condition0IsTrue_0;
gdjs.s357Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(94594908);
}
}if (gdjs.s357Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Part 2\\NEW ITEMSV3\\chapter9_v4.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s357Code.GDoffObjects1);

gdjs.s357Code.condition0IsTrue_0.val = false;
{
gdjs.s357Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s357Code.mapOfGDgdjs_46s357Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s357Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s357Code.GDonObjects1);

gdjs.s357Code.condition0IsTrue_0.val = false;
{
gdjs.s357Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s357Code.mapOfGDgdjs_46s357Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s357Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s357Code.condition0IsTrue_0.val = false;
{
gdjs.s357Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s357Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s358", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s357Code.GDAObjects1);

gdjs.s357Code.condition0IsTrue_0.val = false;
{
gdjs.s357Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s357Code.mapOfGDgdjs_46s357Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s357Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s358", false);
}}

}


{


{
}

}


};

gdjs.s357Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s357Code.GDcaseObjects1.length = 0;
gdjs.s357Code.GDcaseObjects2.length = 0;
gdjs.s357Code.GDimageObjects1.length = 0;
gdjs.s357Code.GDimageObjects2.length = 0;
gdjs.s357Code.GDoffObjects1.length = 0;
gdjs.s357Code.GDoffObjects2.length = 0;
gdjs.s357Code.GDonObjects1.length = 0;
gdjs.s357Code.GDonObjects2.length = 0;
gdjs.s357Code.GDstartObjects1.length = 0;
gdjs.s357Code.GDstartObjects2.length = 0;
gdjs.s357Code.GDBObjects1.length = 0;
gdjs.s357Code.GDBObjects2.length = 0;
gdjs.s357Code.GDblackObjects1.length = 0;
gdjs.s357Code.GDblackObjects2.length = 0;
gdjs.s357Code.GDAObjects1.length = 0;
gdjs.s357Code.GDAObjects2.length = 0;

gdjs.s357Code.eventsList0(runtimeScene);
return;

}

gdjs['s357Code'] = gdjs.s357Code;
