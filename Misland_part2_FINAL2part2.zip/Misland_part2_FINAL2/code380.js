gdjs.s337Code = {};
gdjs.s337Code.GDcaseObjects1= [];
gdjs.s337Code.GDcaseObjects2= [];
gdjs.s337Code.GDimageObjects1= [];
gdjs.s337Code.GDimageObjects2= [];
gdjs.s337Code.GDoffObjects1= [];
gdjs.s337Code.GDoffObjects2= [];
gdjs.s337Code.GDonObjects1= [];
gdjs.s337Code.GDonObjects2= [];
gdjs.s337Code.GDstartObjects1= [];
gdjs.s337Code.GDstartObjects2= [];
gdjs.s337Code.GDBObjects1= [];
gdjs.s337Code.GDBObjects2= [];
gdjs.s337Code.GDblackObjects1= [];
gdjs.s337Code.GDblackObjects2= [];
gdjs.s337Code.GDAObjects1= [];
gdjs.s337Code.GDAObjects2= [];

gdjs.s337Code.conditionTrue_0 = {val:false};
gdjs.s337Code.condition0IsTrue_0 = {val:false};
gdjs.s337Code.condition1IsTrue_0 = {val:false};


gdjs.s337Code.mapOfGDgdjs_46s337Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s337Code.GDoffObjects1});gdjs.s337Code.mapOfGDgdjs_46s337Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s337Code.GDonObjects1});gdjs.s337Code.mapOfGDgdjs_46s337Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s337Code.GDBObjects1});gdjs.s337Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s337Code.GDoffObjects1);

gdjs.s337Code.condition0IsTrue_0.val = false;
{
gdjs.s337Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s337Code.mapOfGDgdjs_46s337Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s337Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s337Code.GDonObjects1);

gdjs.s337Code.condition0IsTrue_0.val = false;
{
gdjs.s337Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s337Code.mapOfGDgdjs_46s337Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s337Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s337Code.condition0IsTrue_0.val = false;
{
gdjs.s337Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s337Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s338", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s337Code.GDBObjects1);

gdjs.s337Code.condition0IsTrue_0.val = false;
{
gdjs.s337Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s337Code.mapOfGDgdjs_46s337Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s337Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s338", false);
}}

}


{


{
}

}


};

gdjs.s337Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s337Code.GDcaseObjects1.length = 0;
gdjs.s337Code.GDcaseObjects2.length = 0;
gdjs.s337Code.GDimageObjects1.length = 0;
gdjs.s337Code.GDimageObjects2.length = 0;
gdjs.s337Code.GDoffObjects1.length = 0;
gdjs.s337Code.GDoffObjects2.length = 0;
gdjs.s337Code.GDonObjects1.length = 0;
gdjs.s337Code.GDonObjects2.length = 0;
gdjs.s337Code.GDstartObjects1.length = 0;
gdjs.s337Code.GDstartObjects2.length = 0;
gdjs.s337Code.GDBObjects1.length = 0;
gdjs.s337Code.GDBObjects2.length = 0;
gdjs.s337Code.GDblackObjects1.length = 0;
gdjs.s337Code.GDblackObjects2.length = 0;
gdjs.s337Code.GDAObjects1.length = 0;
gdjs.s337Code.GDAObjects2.length = 0;

gdjs.s337Code.eventsList0(runtimeScene);
return;

}

gdjs['s337Code'] = gdjs.s337Code;
