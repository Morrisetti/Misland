gdjs.s319Code = {};
gdjs.s319Code.GDcaseObjects1= [];
gdjs.s319Code.GDcaseObjects2= [];
gdjs.s319Code.GDoffObjects1= [];
gdjs.s319Code.GDoffObjects2= [];
gdjs.s319Code.GDonObjects1= [];
gdjs.s319Code.GDonObjects2= [];
gdjs.s319Code.GDstartObjects1= [];
gdjs.s319Code.GDstartObjects2= [];
gdjs.s319Code.GDBObjects1= [];
gdjs.s319Code.GDBObjects2= [];
gdjs.s319Code.GDAObjects1= [];
gdjs.s319Code.GDAObjects2= [];
gdjs.s319Code.GDbugzObjects1= [];
gdjs.s319Code.GDbugzObjects2= [];
gdjs.s319Code.GDDOWNbuttonObjects1= [];
gdjs.s319Code.GDDOWNbuttonObjects2= [];
gdjs.s319Code.GDblackObjects1= [];
gdjs.s319Code.GDblackObjects2= [];
gdjs.s319Code.GDDOWNcolObjects1= [];
gdjs.s319Code.GDDOWNcolObjects2= [];
gdjs.s319Code.GDUPbuttonObjects1= [];
gdjs.s319Code.GDUPbuttonObjects2= [];
gdjs.s319Code.GDUPcolObjects1= [];
gdjs.s319Code.GDUPcolObjects2= [];
gdjs.s319Code.GDLbuttonObjects1= [];
gdjs.s319Code.GDLbuttonObjects2= [];
gdjs.s319Code.GDLcolObjects1= [];
gdjs.s319Code.GDLcolObjects2= [];
gdjs.s319Code.GDRbuttonObjects1= [];
gdjs.s319Code.GDRbuttonObjects2= [];
gdjs.s319Code.GDexitObjects1= [];
gdjs.s319Code.GDexitObjects2= [];
gdjs.s319Code.GDDeathObjects1= [];
gdjs.s319Code.GDDeathObjects2= [];
gdjs.s319Code.GDRcolObjects1= [];
gdjs.s319Code.GDRcolObjects2= [];
gdjs.s319Code.GDchapter4Objects1= [];
gdjs.s319Code.GDchapter4Objects2= [];
gdjs.s319Code.GDchapter3Objects1= [];
gdjs.s319Code.GDchapter3Objects2= [];
gdjs.s319Code.GDchapter2Objects1= [];
gdjs.s319Code.GDchapter2Objects2= [];
gdjs.s319Code.GDchapter1Objects1= [];
gdjs.s319Code.GDchapter1Objects2= [];
gdjs.s319Code.GDBGObjects1= [];
gdjs.s319Code.GDBGObjects2= [];
gdjs.s319Code.GDshadowObjects1= [];
gdjs.s319Code.GDshadowObjects2= [];

gdjs.s319Code.conditionTrue_0 = {val:false};
gdjs.s319Code.condition0IsTrue_0 = {val:false};
gdjs.s319Code.condition1IsTrue_0 = {val:false};
gdjs.s319Code.condition2IsTrue_0 = {val:false};


gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s319Code.GDDOWNbuttonObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s319Code.GDUPbuttonObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s319Code.GDRbuttonObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s319Code.GDLbuttonObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s319Code.GDbugzObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s319Code.GDRcolObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s319Code.GDbugzObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s319Code.GDLcolObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s319Code.GDbugzObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s319Code.GDUPcolObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s319Code.GDbugzObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s319Code.GDDOWNcolObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s319Code.GDbugzObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s319Code.GDDOWNcolObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s319Code.GDBObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s319Code.GDAObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s319Code.GDoffObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s319Code.GDonObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s319Code.GDbugzObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.s319Code.GDexitObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s319Code.GDbugzObjects1});gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs.s319Code.GDDeathObjects1});gdjs.s319Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s319Code.GDDOWNbuttonObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
gdjs.s319Code.condition1IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s319Code.condition0IsTrue_0.val ) {
{
gdjs.s319Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s319Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s319Code.GDUPbuttonObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
gdjs.s319Code.condition1IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s319Code.condition0IsTrue_0.val ) {
{
gdjs.s319Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s319Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s319Code.GDRbuttonObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
gdjs.s319Code.condition1IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s319Code.condition0IsTrue_0.val ) {
{
gdjs.s319Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s319Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s319Code.GDLbuttonObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
gdjs.s319Code.condition1IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s319Code.condition0IsTrue_0.val ) {
{
gdjs.s319Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s319Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s319Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects, gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s319Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s319Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s319Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects, gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s319Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s319Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s319Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects, gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s319Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s319Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s319Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects, gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s319Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s319Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s319Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects, gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s319Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s319Code.GDBObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s319Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s319Code.GDAObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s319Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s319Code.GDoffObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s319Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s319Code.GDonObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s319Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s319Code.condition0IsTrue_0.val = false;
gdjs.s319Code.condition1IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s319Code.condition0IsTrue_0.val ) {
{
gdjs.s319Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s319Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s319Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s319Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s319Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s319Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s319Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s319Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.s319Code.GDexitObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects, gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDexitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s319Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s320", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.s319Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);

gdjs.s319Code.condition0IsTrue_0.val = false;
{
gdjs.s319Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDbugzObjects1Objects, gdjs.s319Code.mapOfGDgdjs_46s319Code_46GDDeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s319Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s314", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s319Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s319Code.GDbugzObjects1.length !== 0 ? gdjs.s319Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s319Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s319Code.GDcaseObjects1.length = 0;
gdjs.s319Code.GDcaseObjects2.length = 0;
gdjs.s319Code.GDoffObjects1.length = 0;
gdjs.s319Code.GDoffObjects2.length = 0;
gdjs.s319Code.GDonObjects1.length = 0;
gdjs.s319Code.GDonObjects2.length = 0;
gdjs.s319Code.GDstartObjects1.length = 0;
gdjs.s319Code.GDstartObjects2.length = 0;
gdjs.s319Code.GDBObjects1.length = 0;
gdjs.s319Code.GDBObjects2.length = 0;
gdjs.s319Code.GDAObjects1.length = 0;
gdjs.s319Code.GDAObjects2.length = 0;
gdjs.s319Code.GDbugzObjects1.length = 0;
gdjs.s319Code.GDbugzObjects2.length = 0;
gdjs.s319Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s319Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s319Code.GDblackObjects1.length = 0;
gdjs.s319Code.GDblackObjects2.length = 0;
gdjs.s319Code.GDDOWNcolObjects1.length = 0;
gdjs.s319Code.GDDOWNcolObjects2.length = 0;
gdjs.s319Code.GDUPbuttonObjects1.length = 0;
gdjs.s319Code.GDUPbuttonObjects2.length = 0;
gdjs.s319Code.GDUPcolObjects1.length = 0;
gdjs.s319Code.GDUPcolObjects2.length = 0;
gdjs.s319Code.GDLbuttonObjects1.length = 0;
gdjs.s319Code.GDLbuttonObjects2.length = 0;
gdjs.s319Code.GDLcolObjects1.length = 0;
gdjs.s319Code.GDLcolObjects2.length = 0;
gdjs.s319Code.GDRbuttonObjects1.length = 0;
gdjs.s319Code.GDRbuttonObjects2.length = 0;
gdjs.s319Code.GDexitObjects1.length = 0;
gdjs.s319Code.GDexitObjects2.length = 0;
gdjs.s319Code.GDDeathObjects1.length = 0;
gdjs.s319Code.GDDeathObjects2.length = 0;
gdjs.s319Code.GDRcolObjects1.length = 0;
gdjs.s319Code.GDRcolObjects2.length = 0;
gdjs.s319Code.GDchapter4Objects1.length = 0;
gdjs.s319Code.GDchapter4Objects2.length = 0;
gdjs.s319Code.GDchapter3Objects1.length = 0;
gdjs.s319Code.GDchapter3Objects2.length = 0;
gdjs.s319Code.GDchapter2Objects1.length = 0;
gdjs.s319Code.GDchapter2Objects2.length = 0;
gdjs.s319Code.GDchapter1Objects1.length = 0;
gdjs.s319Code.GDchapter1Objects2.length = 0;
gdjs.s319Code.GDBGObjects1.length = 0;
gdjs.s319Code.GDBGObjects2.length = 0;
gdjs.s319Code.GDshadowObjects1.length = 0;
gdjs.s319Code.GDshadowObjects2.length = 0;

gdjs.s319Code.eventsList0(runtimeScene);
return;

}

gdjs['s319Code'] = gdjs.s319Code;
