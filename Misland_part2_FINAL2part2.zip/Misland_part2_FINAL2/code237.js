gdjs.s214Code = {};
gdjs.s214Code.GDcaseObjects1= [];
gdjs.s214Code.GDcaseObjects2= [];
gdjs.s214Code.GDimageObjects1= [];
gdjs.s214Code.GDimageObjects2= [];
gdjs.s214Code.GDoffObjects1= [];
gdjs.s214Code.GDoffObjects2= [];
gdjs.s214Code.GDonObjects1= [];
gdjs.s214Code.GDonObjects2= [];
gdjs.s214Code.GDstartObjects1= [];
gdjs.s214Code.GDstartObjects2= [];
gdjs.s214Code.GDBObjects1= [];
gdjs.s214Code.GDBObjects2= [];
gdjs.s214Code.GDblackObjects1= [];
gdjs.s214Code.GDblackObjects2= [];
gdjs.s214Code.GDAObjects1= [];
gdjs.s214Code.GDAObjects2= [];
gdjs.s214Code.GDbuttonObjects1= [];
gdjs.s214Code.GDbuttonObjects2= [];

gdjs.s214Code.conditionTrue_0 = {val:false};
gdjs.s214Code.condition0IsTrue_0 = {val:false};
gdjs.s214Code.condition1IsTrue_0 = {val:false};


gdjs.s214Code.mapOfGDgdjs_46s214Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s214Code.GDoffObjects1});gdjs.s214Code.mapOfGDgdjs_46s214Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s214Code.GDonObjects1});gdjs.s214Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s214Code.GDcaseObjects1);

gdjs.s214Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s214Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s214Code.GDcaseObjects1[i].timerElapsedTime("", 0.8) ) {
        gdjs.s214Code.condition0IsTrue_0.val = true;
        gdjs.s214Code.GDcaseObjects1[k] = gdjs.s214Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s214Code.GDcaseObjects1.length = k;}if (gdjs.s214Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s215", false);
}}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s214Code.GDoffObjects1);

gdjs.s214Code.condition0IsTrue_0.val = false;
{
gdjs.s214Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s214Code.mapOfGDgdjs_46s214Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s214Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s214Code.GDonObjects1);

gdjs.s214Code.condition0IsTrue_0.val = false;
{
gdjs.s214Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s214Code.mapOfGDgdjs_46s214Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s214Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s214Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s214Code.GDcaseObjects1.length = 0;
gdjs.s214Code.GDcaseObjects2.length = 0;
gdjs.s214Code.GDimageObjects1.length = 0;
gdjs.s214Code.GDimageObjects2.length = 0;
gdjs.s214Code.GDoffObjects1.length = 0;
gdjs.s214Code.GDoffObjects2.length = 0;
gdjs.s214Code.GDonObjects1.length = 0;
gdjs.s214Code.GDonObjects2.length = 0;
gdjs.s214Code.GDstartObjects1.length = 0;
gdjs.s214Code.GDstartObjects2.length = 0;
gdjs.s214Code.GDBObjects1.length = 0;
gdjs.s214Code.GDBObjects2.length = 0;
gdjs.s214Code.GDblackObjects1.length = 0;
gdjs.s214Code.GDblackObjects2.length = 0;
gdjs.s214Code.GDAObjects1.length = 0;
gdjs.s214Code.GDAObjects2.length = 0;
gdjs.s214Code.GDbuttonObjects1.length = 0;
gdjs.s214Code.GDbuttonObjects2.length = 0;

gdjs.s214Code.eventsList0(runtimeScene);
return;

}

gdjs['s214Code'] = gdjs.s214Code;
