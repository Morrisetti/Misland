gdjs.s253Code = {};
gdjs.s253Code.GDcaseObjects1= [];
gdjs.s253Code.GDcaseObjects2= [];
gdjs.s253Code.GDimageObjects1= [];
gdjs.s253Code.GDimageObjects2= [];
gdjs.s253Code.GDoffObjects1= [];
gdjs.s253Code.GDoffObjects2= [];
gdjs.s253Code.GDonObjects1= [];
gdjs.s253Code.GDonObjects2= [];
gdjs.s253Code.GDstartObjects1= [];
gdjs.s253Code.GDstartObjects2= [];
gdjs.s253Code.GDBObjects1= [];
gdjs.s253Code.GDBObjects2= [];
gdjs.s253Code.GDblackObjects1= [];
gdjs.s253Code.GDblackObjects2= [];
gdjs.s253Code.GDAObjects1= [];
gdjs.s253Code.GDAObjects2= [];

gdjs.s253Code.conditionTrue_0 = {val:false};
gdjs.s253Code.condition0IsTrue_0 = {val:false};
gdjs.s253Code.condition1IsTrue_0 = {val:false};


gdjs.s253Code.mapOfGDgdjs_46s253Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s253Code.GDoffObjects1});gdjs.s253Code.mapOfGDgdjs_46s253Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s253Code.GDonObjects1});gdjs.s253Code.mapOfGDgdjs_46s253Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s253Code.GDBObjects1});gdjs.s253Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s253Code.GDoffObjects1);

gdjs.s253Code.condition0IsTrue_0.val = false;
{
gdjs.s253Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s253Code.mapOfGDgdjs_46s253Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s253Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s253Code.GDonObjects1);

gdjs.s253Code.condition0IsTrue_0.val = false;
{
gdjs.s253Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s253Code.mapOfGDgdjs_46s253Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s253Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s253Code.condition0IsTrue_0.val = false;
{
gdjs.s253Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s253Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s254", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s253Code.GDBObjects1);

gdjs.s253Code.condition0IsTrue_0.val = false;
{
gdjs.s253Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s253Code.mapOfGDgdjs_46s253Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s253Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s254", false);
}}

}


{


{
}

}


};

gdjs.s253Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s253Code.GDcaseObjects1.length = 0;
gdjs.s253Code.GDcaseObjects2.length = 0;
gdjs.s253Code.GDimageObjects1.length = 0;
gdjs.s253Code.GDimageObjects2.length = 0;
gdjs.s253Code.GDoffObjects1.length = 0;
gdjs.s253Code.GDoffObjects2.length = 0;
gdjs.s253Code.GDonObjects1.length = 0;
gdjs.s253Code.GDonObjects2.length = 0;
gdjs.s253Code.GDstartObjects1.length = 0;
gdjs.s253Code.GDstartObjects2.length = 0;
gdjs.s253Code.GDBObjects1.length = 0;
gdjs.s253Code.GDBObjects2.length = 0;
gdjs.s253Code.GDblackObjects1.length = 0;
gdjs.s253Code.GDblackObjects2.length = 0;
gdjs.s253Code.GDAObjects1.length = 0;
gdjs.s253Code.GDAObjects2.length = 0;

gdjs.s253Code.eventsList0(runtimeScene);
return;

}

gdjs['s253Code'] = gdjs.s253Code;
