gdjs.s331Code = {};
gdjs.s331Code.GDcaseObjects1= [];
gdjs.s331Code.GDcaseObjects2= [];
gdjs.s331Code.GDoffObjects1= [];
gdjs.s331Code.GDoffObjects2= [];
gdjs.s331Code.GDonObjects1= [];
gdjs.s331Code.GDonObjects2= [];
gdjs.s331Code.GDstartObjects1= [];
gdjs.s331Code.GDstartObjects2= [];
gdjs.s331Code.GDBObjects1= [];
gdjs.s331Code.GDBObjects2= [];
gdjs.s331Code.GDAObjects1= [];
gdjs.s331Code.GDAObjects2= [];
gdjs.s331Code.GDcarObjects1= [];
gdjs.s331Code.GDcarObjects2= [];
gdjs.s331Code.GDDOWNbuttonObjects1= [];
gdjs.s331Code.GDDOWNbuttonObjects2= [];
gdjs.s331Code.GDblackObjects1= [];
gdjs.s331Code.GDblackObjects2= [];
gdjs.s331Code.GDDOWNcol2Objects1= [];
gdjs.s331Code.GDDOWNcol2Objects2= [];
gdjs.s331Code.GDDOWNcolObjects1= [];
gdjs.s331Code.GDDOWNcolObjects2= [];
gdjs.s331Code.GDUPbuttonObjects1= [];
gdjs.s331Code.GDUPbuttonObjects2= [];
gdjs.s331Code.GDUPcolObjects1= [];
gdjs.s331Code.GDUPcolObjects2= [];
gdjs.s331Code.GDLbuttonObjects1= [];
gdjs.s331Code.GDLbuttonObjects2= [];
gdjs.s331Code.GDLcolObjects1= [];
gdjs.s331Code.GDLcolObjects2= [];
gdjs.s331Code.GDRbuttonObjects1= [];
gdjs.s331Code.GDRbuttonObjects2= [];
gdjs.s331Code.GDTALK3Objects1= [];
gdjs.s331Code.GDTALK3Objects2= [];
gdjs.s331Code.GDTALK2Objects1= [];
gdjs.s331Code.GDTALK2Objects2= [];
gdjs.s331Code.GDExitObjects1= [];
gdjs.s331Code.GDExitObjects2= [];
gdjs.s331Code.GDRcolObjects1= [];
gdjs.s331Code.GDRcolObjects2= [];
gdjs.s331Code.GDchapter4Objects1= [];
gdjs.s331Code.GDchapter4Objects2= [];
gdjs.s331Code.GDchapter3Objects1= [];
gdjs.s331Code.GDchapter3Objects2= [];
gdjs.s331Code.GDchapter2Objects1= [];
gdjs.s331Code.GDchapter2Objects2= [];
gdjs.s331Code.GDchapter1Objects1= [];
gdjs.s331Code.GDchapter1Objects2= [];
gdjs.s331Code.GDNewObjectObjects1= [];
gdjs.s331Code.GDNewObjectObjects2= [];
gdjs.s331Code.GDob7Objects1= [];
gdjs.s331Code.GDob7Objects2= [];
gdjs.s331Code.GDob6Objects1= [];
gdjs.s331Code.GDob6Objects2= [];
gdjs.s331Code.GDob5Objects1= [];
gdjs.s331Code.GDob5Objects2= [];
gdjs.s331Code.GDob4Objects1= [];
gdjs.s331Code.GDob4Objects2= [];
gdjs.s331Code.GDob3Objects1= [];
gdjs.s331Code.GDob3Objects2= [];
gdjs.s331Code.GDob2Objects1= [];
gdjs.s331Code.GDob2Objects2= [];
gdjs.s331Code.GDob1Objects1= [];
gdjs.s331Code.GDob1Objects2= [];
gdjs.s331Code.GDtargetObjects1= [];
gdjs.s331Code.GDtargetObjects2= [];

gdjs.s331Code.conditionTrue_0 = {val:false};
gdjs.s331Code.condition0IsTrue_0 = {val:false};
gdjs.s331Code.condition1IsTrue_0 = {val:false};
gdjs.s331Code.condition2IsTrue_0 = {val:false};


gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s331Code.GDDOWNbuttonObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s331Code.GDUPbuttonObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s331Code.GDRbuttonObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s331Code.GDLbuttonObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s331Code.GDRcolObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s331Code.GDLcolObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s331Code.GDUPcolObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s331Code.GDDOWNcolObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s331Code.GDDOWNcolObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s331Code.GDBObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s331Code.GDAObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s331Code.GDoffObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s331Code.GDonObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob1Objects1Objects = Hashtable.newFrom({"ob1": gdjs.s331Code.GDob1Objects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob2Objects1Objects = Hashtable.newFrom({"ob2": gdjs.s331Code.GDob2Objects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob3Objects1Objects = Hashtable.newFrom({"ob3": gdjs.s331Code.GDob3Objects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob4Objects1Objects = Hashtable.newFrom({"ob4": gdjs.s331Code.GDob4Objects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob5Objects1Objects = Hashtable.newFrom({"ob5": gdjs.s331Code.GDob5Objects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob6Objects1Objects = Hashtable.newFrom({"ob6": gdjs.s331Code.GDob6Objects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s331Code.GDcarObjects1});gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob7Objects1Objects = Hashtable.newFrom({"ob7": gdjs.s331Code.GDob7Objects1});gdjs.s331Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s331Code.GDDOWNbuttonObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
gdjs.s331Code.condition1IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s331Code.condition0IsTrue_0.val ) {
{
gdjs.s331Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s331Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s331Code.GDUPbuttonObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
gdjs.s331Code.condition1IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s331Code.condition0IsTrue_0.val ) {
{
gdjs.s331Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s331Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s331Code.GDRbuttonObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
gdjs.s331Code.condition1IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s331Code.condition0IsTrue_0.val ) {
{
gdjs.s331Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s331Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s331Code.GDLbuttonObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
gdjs.s331Code.condition1IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s331Code.condition0IsTrue_0.val ) {
{
gdjs.s331Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s331Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s331Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s331Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s331Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s331Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s331Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s331Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s331Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s331Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s331Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s331Code.GDBObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s331Code.GDAObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s331Code.GDoffObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s331Code.GDonObjects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s331Code.condition0IsTrue_0.val = false;
gdjs.s331Code.condition1IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s331Code.condition0IsTrue_0.val ) {
{
gdjs.s331Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s331Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s331Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s331Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].flipX(false);
}
}}

}


{


gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s331Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s331Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s331Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s331Code.GDcarObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob1"), gdjs.s331Code.GDob1Objects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob1Objects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s330", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob2"), gdjs.s331Code.GDob2Objects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s330", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob3"), gdjs.s331Code.GDob3Objects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob3Objects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s330", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob4"), gdjs.s331Code.GDob4Objects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob4Objects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s330", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob5"), gdjs.s331Code.GDob5Objects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob5Objects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s330", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob6"), gdjs.s331Code.GDob6Objects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob6Objects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s330", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s331Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob7"), gdjs.s331Code.GDob7Objects1);

gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDcarObjects1Objects, gdjs.s331Code.mapOfGDgdjs_46s331Code_46GDob7Objects1Objects, false, runtimeScene, false);
}if (gdjs.s331Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s330", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob1"), gdjs.s331Code.GDob1Objects1);
{for(var i = 0, len = gdjs.s331Code.GDob1Objects1.length ;i < len;++i) {
    gdjs.s331Code.GDob1Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob2"), gdjs.s331Code.GDob2Objects1);
{for(var i = 0, len = gdjs.s331Code.GDob2Objects1.length ;i < len;++i) {
    gdjs.s331Code.GDob2Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob3"), gdjs.s331Code.GDob3Objects1);
{for(var i = 0, len = gdjs.s331Code.GDob3Objects1.length ;i < len;++i) {
    gdjs.s331Code.GDob3Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob4"), gdjs.s331Code.GDob4Objects1);
{for(var i = 0, len = gdjs.s331Code.GDob4Objects1.length ;i < len;++i) {
    gdjs.s331Code.GDob4Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob5"), gdjs.s331Code.GDob5Objects1);
{for(var i = 0, len = gdjs.s331Code.GDob5Objects1.length ;i < len;++i) {
    gdjs.s331Code.GDob5Objects1[i].addForceTowardPosition(400, 1000, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob6"), gdjs.s331Code.GDob6Objects1);
{for(var i = 0, len = gdjs.s331Code.GDob6Objects1.length ;i < len;++i) {
    gdjs.s331Code.GDob6Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob7"), gdjs.s331Code.GDob7Objects1);
{for(var i = 0, len = gdjs.s331Code.GDob7Objects1.length ;i < len;++i) {
    gdjs.s331Code.GDob7Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


gdjs.s331Code.condition0IsTrue_0.val = false;
{
gdjs.s331Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 45, "");
}if (gdjs.s331Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s332", false);
}}

}


};

gdjs.s331Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s331Code.GDcaseObjects1.length = 0;
gdjs.s331Code.GDcaseObjects2.length = 0;
gdjs.s331Code.GDoffObjects1.length = 0;
gdjs.s331Code.GDoffObjects2.length = 0;
gdjs.s331Code.GDonObjects1.length = 0;
gdjs.s331Code.GDonObjects2.length = 0;
gdjs.s331Code.GDstartObjects1.length = 0;
gdjs.s331Code.GDstartObjects2.length = 0;
gdjs.s331Code.GDBObjects1.length = 0;
gdjs.s331Code.GDBObjects2.length = 0;
gdjs.s331Code.GDAObjects1.length = 0;
gdjs.s331Code.GDAObjects2.length = 0;
gdjs.s331Code.GDcarObjects1.length = 0;
gdjs.s331Code.GDcarObjects2.length = 0;
gdjs.s331Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s331Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s331Code.GDblackObjects1.length = 0;
gdjs.s331Code.GDblackObjects2.length = 0;
gdjs.s331Code.GDDOWNcol2Objects1.length = 0;
gdjs.s331Code.GDDOWNcol2Objects2.length = 0;
gdjs.s331Code.GDDOWNcolObjects1.length = 0;
gdjs.s331Code.GDDOWNcolObjects2.length = 0;
gdjs.s331Code.GDUPbuttonObjects1.length = 0;
gdjs.s331Code.GDUPbuttonObjects2.length = 0;
gdjs.s331Code.GDUPcolObjects1.length = 0;
gdjs.s331Code.GDUPcolObjects2.length = 0;
gdjs.s331Code.GDLbuttonObjects1.length = 0;
gdjs.s331Code.GDLbuttonObjects2.length = 0;
gdjs.s331Code.GDLcolObjects1.length = 0;
gdjs.s331Code.GDLcolObjects2.length = 0;
gdjs.s331Code.GDRbuttonObjects1.length = 0;
gdjs.s331Code.GDRbuttonObjects2.length = 0;
gdjs.s331Code.GDTALK3Objects1.length = 0;
gdjs.s331Code.GDTALK3Objects2.length = 0;
gdjs.s331Code.GDTALK2Objects1.length = 0;
gdjs.s331Code.GDTALK2Objects2.length = 0;
gdjs.s331Code.GDExitObjects1.length = 0;
gdjs.s331Code.GDExitObjects2.length = 0;
gdjs.s331Code.GDRcolObjects1.length = 0;
gdjs.s331Code.GDRcolObjects2.length = 0;
gdjs.s331Code.GDchapter4Objects1.length = 0;
gdjs.s331Code.GDchapter4Objects2.length = 0;
gdjs.s331Code.GDchapter3Objects1.length = 0;
gdjs.s331Code.GDchapter3Objects2.length = 0;
gdjs.s331Code.GDchapter2Objects1.length = 0;
gdjs.s331Code.GDchapter2Objects2.length = 0;
gdjs.s331Code.GDchapter1Objects1.length = 0;
gdjs.s331Code.GDchapter1Objects2.length = 0;
gdjs.s331Code.GDNewObjectObjects1.length = 0;
gdjs.s331Code.GDNewObjectObjects2.length = 0;
gdjs.s331Code.GDob7Objects1.length = 0;
gdjs.s331Code.GDob7Objects2.length = 0;
gdjs.s331Code.GDob6Objects1.length = 0;
gdjs.s331Code.GDob6Objects2.length = 0;
gdjs.s331Code.GDob5Objects1.length = 0;
gdjs.s331Code.GDob5Objects2.length = 0;
gdjs.s331Code.GDob4Objects1.length = 0;
gdjs.s331Code.GDob4Objects2.length = 0;
gdjs.s331Code.GDob3Objects1.length = 0;
gdjs.s331Code.GDob3Objects2.length = 0;
gdjs.s331Code.GDob2Objects1.length = 0;
gdjs.s331Code.GDob2Objects2.length = 0;
gdjs.s331Code.GDob1Objects1.length = 0;
gdjs.s331Code.GDob1Objects2.length = 0;
gdjs.s331Code.GDtargetObjects1.length = 0;
gdjs.s331Code.GDtargetObjects2.length = 0;

gdjs.s331Code.eventsList0(runtimeScene);
return;

}

gdjs['s331Code'] = gdjs.s331Code;
