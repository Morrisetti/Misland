gdjs.s284Code = {};
gdjs.s284Code.GDcaseObjects1= [];
gdjs.s284Code.GDcaseObjects2= [];
gdjs.s284Code.GDoffObjects1= [];
gdjs.s284Code.GDoffObjects2= [];
gdjs.s284Code.GDonObjects1= [];
gdjs.s284Code.GDonObjects2= [];
gdjs.s284Code.GDstartObjects1= [];
gdjs.s284Code.GDstartObjects2= [];
gdjs.s284Code.GDBObjects1= [];
gdjs.s284Code.GDBObjects2= [];
gdjs.s284Code.GDAObjects1= [];
gdjs.s284Code.GDAObjects2= [];
gdjs.s284Code.GDbugzObjects1= [];
gdjs.s284Code.GDbugzObjects2= [];
gdjs.s284Code.GDDOWNbuttonObjects1= [];
gdjs.s284Code.GDDOWNbuttonObjects2= [];
gdjs.s284Code.GDblackObjects1= [];
gdjs.s284Code.GDblackObjects2= [];
gdjs.s284Code.GDDOWNcolObjects1= [];
gdjs.s284Code.GDDOWNcolObjects2= [];
gdjs.s284Code.GDUPbuttonObjects1= [];
gdjs.s284Code.GDUPbuttonObjects2= [];
gdjs.s284Code.GDUPcolObjects1= [];
gdjs.s284Code.GDUPcolObjects2= [];
gdjs.s284Code.GDLbuttonObjects1= [];
gdjs.s284Code.GDLbuttonObjects2= [];
gdjs.s284Code.GDLcolObjects1= [];
gdjs.s284Code.GDLcolObjects2= [];
gdjs.s284Code.GDRbuttonObjects1= [];
gdjs.s284Code.GDRbuttonObjects2= [];
gdjs.s284Code.GDexitObjects1= [];
gdjs.s284Code.GDexitObjects2= [];
gdjs.s284Code.GDDeathObjects1= [];
gdjs.s284Code.GDDeathObjects2= [];
gdjs.s284Code.GDRcolObjects1= [];
gdjs.s284Code.GDRcolObjects2= [];
gdjs.s284Code.GDchapter4Objects1= [];
gdjs.s284Code.GDchapter4Objects2= [];
gdjs.s284Code.GDchapter3Objects1= [];
gdjs.s284Code.GDchapter3Objects2= [];
gdjs.s284Code.GDchapter2Objects1= [];
gdjs.s284Code.GDchapter2Objects2= [];
gdjs.s284Code.GDchapter1Objects1= [];
gdjs.s284Code.GDchapter1Objects2= [];
gdjs.s284Code.GDBGObjects1= [];
gdjs.s284Code.GDBGObjects2= [];
gdjs.s284Code.GDshadowObjects1= [];
gdjs.s284Code.GDshadowObjects2= [];

gdjs.s284Code.conditionTrue_0 = {val:false};
gdjs.s284Code.condition0IsTrue_0 = {val:false};
gdjs.s284Code.condition1IsTrue_0 = {val:false};
gdjs.s284Code.condition2IsTrue_0 = {val:false};
gdjs.s284Code.conditionTrue_1 = {val:false};
gdjs.s284Code.condition0IsTrue_1 = {val:false};
gdjs.s284Code.condition1IsTrue_1 = {val:false};
gdjs.s284Code.condition2IsTrue_1 = {val:false};


gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s284Code.GDDOWNbuttonObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s284Code.GDUPbuttonObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s284Code.GDRbuttonObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s284Code.GDLbuttonObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s284Code.GDbugzObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s284Code.GDRcolObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s284Code.GDbugzObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s284Code.GDLcolObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s284Code.GDbugzObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s284Code.GDUPcolObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s284Code.GDbugzObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s284Code.GDDOWNcolObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s284Code.GDbugzObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s284Code.GDDOWNcolObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s284Code.GDBObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s284Code.GDAObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s284Code.GDoffObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s284Code.GDonObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s284Code.GDbugzObjects1});gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.s284Code.GDexitObjects1});gdjs.s284Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s284Code.GDDOWNbuttonObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
gdjs.s284Code.condition1IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s284Code.condition0IsTrue_0.val ) {
{
gdjs.s284Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s284Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s284Code.GDUPbuttonObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
gdjs.s284Code.condition1IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s284Code.condition0IsTrue_0.val ) {
{
gdjs.s284Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s284Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s284Code.GDRbuttonObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
gdjs.s284Code.condition1IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s284Code.condition0IsTrue_0.val ) {
{
gdjs.s284Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s284Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s284Code.GDLbuttonObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
gdjs.s284Code.condition1IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s284Code.condition0IsTrue_0.val ) {
{
gdjs.s284Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s284Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


gdjs.s284Code.condition0IsTrue_0.val = false;
{
{gdjs.s284Code.conditionTrue_1 = gdjs.s284Code.condition0IsTrue_0;
gdjs.s284Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(92917972);
}
}if (gdjs.s284Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "crazychase3.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s284Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects, gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s284Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s284Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s284Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects, gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s284Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s284Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s284Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects, gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s284Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s284Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s284Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects, gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s284Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s284Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s284Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects, gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s284Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s284Code.GDBObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s284Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s284Code.GDAObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s284Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s284Code.GDoffObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s284Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s284Code.GDonObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s284Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s284Code.condition0IsTrue_0.val = false;
gdjs.s284Code.condition1IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s284Code.condition0IsTrue_0.val ) {
{
gdjs.s284Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s284Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s284Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s284Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s284Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s284Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s284Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s284Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.s284Code.GDexitObjects1);

gdjs.s284Code.condition0IsTrue_0.val = false;
{
gdjs.s284Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDbugzObjects1Objects, gdjs.s284Code.mapOfGDgdjs_46s284Code_46GDexitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s284Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s285", false);
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s284Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s284Code.GDbugzObjects1.length !== 0 ? gdjs.s284Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s284Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s284Code.GDcaseObjects1.length = 0;
gdjs.s284Code.GDcaseObjects2.length = 0;
gdjs.s284Code.GDoffObjects1.length = 0;
gdjs.s284Code.GDoffObjects2.length = 0;
gdjs.s284Code.GDonObjects1.length = 0;
gdjs.s284Code.GDonObjects2.length = 0;
gdjs.s284Code.GDstartObjects1.length = 0;
gdjs.s284Code.GDstartObjects2.length = 0;
gdjs.s284Code.GDBObjects1.length = 0;
gdjs.s284Code.GDBObjects2.length = 0;
gdjs.s284Code.GDAObjects1.length = 0;
gdjs.s284Code.GDAObjects2.length = 0;
gdjs.s284Code.GDbugzObjects1.length = 0;
gdjs.s284Code.GDbugzObjects2.length = 0;
gdjs.s284Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s284Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s284Code.GDblackObjects1.length = 0;
gdjs.s284Code.GDblackObjects2.length = 0;
gdjs.s284Code.GDDOWNcolObjects1.length = 0;
gdjs.s284Code.GDDOWNcolObjects2.length = 0;
gdjs.s284Code.GDUPbuttonObjects1.length = 0;
gdjs.s284Code.GDUPbuttonObjects2.length = 0;
gdjs.s284Code.GDUPcolObjects1.length = 0;
gdjs.s284Code.GDUPcolObjects2.length = 0;
gdjs.s284Code.GDLbuttonObjects1.length = 0;
gdjs.s284Code.GDLbuttonObjects2.length = 0;
gdjs.s284Code.GDLcolObjects1.length = 0;
gdjs.s284Code.GDLcolObjects2.length = 0;
gdjs.s284Code.GDRbuttonObjects1.length = 0;
gdjs.s284Code.GDRbuttonObjects2.length = 0;
gdjs.s284Code.GDexitObjects1.length = 0;
gdjs.s284Code.GDexitObjects2.length = 0;
gdjs.s284Code.GDDeathObjects1.length = 0;
gdjs.s284Code.GDDeathObjects2.length = 0;
gdjs.s284Code.GDRcolObjects1.length = 0;
gdjs.s284Code.GDRcolObjects2.length = 0;
gdjs.s284Code.GDchapter4Objects1.length = 0;
gdjs.s284Code.GDchapter4Objects2.length = 0;
gdjs.s284Code.GDchapter3Objects1.length = 0;
gdjs.s284Code.GDchapter3Objects2.length = 0;
gdjs.s284Code.GDchapter2Objects1.length = 0;
gdjs.s284Code.GDchapter2Objects2.length = 0;
gdjs.s284Code.GDchapter1Objects1.length = 0;
gdjs.s284Code.GDchapter1Objects2.length = 0;
gdjs.s284Code.GDBGObjects1.length = 0;
gdjs.s284Code.GDBGObjects2.length = 0;
gdjs.s284Code.GDshadowObjects1.length = 0;
gdjs.s284Code.GDshadowObjects2.length = 0;

gdjs.s284Code.eventsList0(runtimeScene);
return;

}

gdjs['s284Code'] = gdjs.s284Code;
