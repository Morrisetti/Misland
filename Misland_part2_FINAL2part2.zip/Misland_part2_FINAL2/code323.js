gdjs.s288Code = {};
gdjs.s288Code.GDcaseObjects1= [];
gdjs.s288Code.GDcaseObjects2= [];
gdjs.s288Code.GDimageObjects1= [];
gdjs.s288Code.GDimageObjects2= [];
gdjs.s288Code.GDoffObjects1= [];
gdjs.s288Code.GDoffObjects2= [];
gdjs.s288Code.GDonObjects1= [];
gdjs.s288Code.GDonObjects2= [];
gdjs.s288Code.GDstartObjects1= [];
gdjs.s288Code.GDstartObjects2= [];
gdjs.s288Code.GDBObjects1= [];
gdjs.s288Code.GDBObjects2= [];
gdjs.s288Code.GDblackObjects1= [];
gdjs.s288Code.GDblackObjects2= [];
gdjs.s288Code.GDAObjects1= [];
gdjs.s288Code.GDAObjects2= [];

gdjs.s288Code.conditionTrue_0 = {val:false};
gdjs.s288Code.condition0IsTrue_0 = {val:false};
gdjs.s288Code.condition1IsTrue_0 = {val:false};


gdjs.s288Code.mapOfGDgdjs_46s288Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s288Code.GDoffObjects1});gdjs.s288Code.mapOfGDgdjs_46s288Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s288Code.GDonObjects1});gdjs.s288Code.mapOfGDgdjs_46s288Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s288Code.GDBObjects1});gdjs.s288Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s288Code.GDoffObjects1);

gdjs.s288Code.condition0IsTrue_0.val = false;
{
gdjs.s288Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s288Code.mapOfGDgdjs_46s288Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s288Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s288Code.GDonObjects1);

gdjs.s288Code.condition0IsTrue_0.val = false;
{
gdjs.s288Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s288Code.mapOfGDgdjs_46s288Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s288Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s288Code.condition0IsTrue_0.val = false;
{
gdjs.s288Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s288Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s290", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s288Code.GDBObjects1);

gdjs.s288Code.condition0IsTrue_0.val = false;
{
gdjs.s288Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s288Code.mapOfGDgdjs_46s288Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s288Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s290", false);
}}

}


{


{
}

}


};

gdjs.s288Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s288Code.GDcaseObjects1.length = 0;
gdjs.s288Code.GDcaseObjects2.length = 0;
gdjs.s288Code.GDimageObjects1.length = 0;
gdjs.s288Code.GDimageObjects2.length = 0;
gdjs.s288Code.GDoffObjects1.length = 0;
gdjs.s288Code.GDoffObjects2.length = 0;
gdjs.s288Code.GDonObjects1.length = 0;
gdjs.s288Code.GDonObjects2.length = 0;
gdjs.s288Code.GDstartObjects1.length = 0;
gdjs.s288Code.GDstartObjects2.length = 0;
gdjs.s288Code.GDBObjects1.length = 0;
gdjs.s288Code.GDBObjects2.length = 0;
gdjs.s288Code.GDblackObjects1.length = 0;
gdjs.s288Code.GDblackObjects2.length = 0;
gdjs.s288Code.GDAObjects1.length = 0;
gdjs.s288Code.GDAObjects2.length = 0;

gdjs.s288Code.eventsList0(runtimeScene);
return;

}

gdjs['s288Code'] = gdjs.s288Code;
