gdjs.s294Code = {};
gdjs.s294Code.GDcaseObjects1= [];
gdjs.s294Code.GDcaseObjects2= [];
gdjs.s294Code.GDimageObjects1= [];
gdjs.s294Code.GDimageObjects2= [];
gdjs.s294Code.GDoffObjects1= [];
gdjs.s294Code.GDoffObjects2= [];
gdjs.s294Code.GDonObjects1= [];
gdjs.s294Code.GDonObjects2= [];
gdjs.s294Code.GDstartObjects1= [];
gdjs.s294Code.GDstartObjects2= [];
gdjs.s294Code.GDBObjects1= [];
gdjs.s294Code.GDBObjects2= [];
gdjs.s294Code.GDblackObjects1= [];
gdjs.s294Code.GDblackObjects2= [];
gdjs.s294Code.GDAObjects1= [];
gdjs.s294Code.GDAObjects2= [];
gdjs.s294Code.GDbuttonObjects1= [];
gdjs.s294Code.GDbuttonObjects2= [];

gdjs.s294Code.conditionTrue_0 = {val:false};
gdjs.s294Code.condition0IsTrue_0 = {val:false};
gdjs.s294Code.condition1IsTrue_0 = {val:false};


gdjs.s294Code.mapOfGDgdjs_46s294Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s294Code.GDbuttonObjects1});gdjs.s294Code.mapOfGDgdjs_46s294Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s294Code.GDoffObjects1});gdjs.s294Code.mapOfGDgdjs_46s294Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s294Code.GDonObjects1});gdjs.s294Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s294Code.GDcaseObjects1);

gdjs.s294Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s294Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s294Code.GDcaseObjects1[i].timerElapsedTime("", 0.7) ) {
        gdjs.s294Code.condition0IsTrue_0.val = true;
        gdjs.s294Code.GDcaseObjects1[k] = gdjs.s294Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s294Code.GDcaseObjects1.length = k;}if (gdjs.s294Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s289", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s294Code.GDbuttonObjects1);

gdjs.s294Code.condition0IsTrue_0.val = false;
{
gdjs.s294Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s294Code.mapOfGDgdjs_46s294Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s294Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s295", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s294Code.GDoffObjects1);

gdjs.s294Code.condition0IsTrue_0.val = false;
{
gdjs.s294Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s294Code.mapOfGDgdjs_46s294Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s294Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s294Code.GDonObjects1);

gdjs.s294Code.condition0IsTrue_0.val = false;
{
gdjs.s294Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s294Code.mapOfGDgdjs_46s294Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s294Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s294Code.condition0IsTrue_0.val = false;
{
gdjs.s294Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s294Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s295", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s294Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s294Code.GDcaseObjects1.length = 0;
gdjs.s294Code.GDcaseObjects2.length = 0;
gdjs.s294Code.GDimageObjects1.length = 0;
gdjs.s294Code.GDimageObjects2.length = 0;
gdjs.s294Code.GDoffObjects1.length = 0;
gdjs.s294Code.GDoffObjects2.length = 0;
gdjs.s294Code.GDonObjects1.length = 0;
gdjs.s294Code.GDonObjects2.length = 0;
gdjs.s294Code.GDstartObjects1.length = 0;
gdjs.s294Code.GDstartObjects2.length = 0;
gdjs.s294Code.GDBObjects1.length = 0;
gdjs.s294Code.GDBObjects2.length = 0;
gdjs.s294Code.GDblackObjects1.length = 0;
gdjs.s294Code.GDblackObjects2.length = 0;
gdjs.s294Code.GDAObjects1.length = 0;
gdjs.s294Code.GDAObjects2.length = 0;
gdjs.s294Code.GDbuttonObjects1.length = 0;
gdjs.s294Code.GDbuttonObjects2.length = 0;

gdjs.s294Code.eventsList0(runtimeScene);
return;

}

gdjs['s294Code'] = gdjs.s294Code;
