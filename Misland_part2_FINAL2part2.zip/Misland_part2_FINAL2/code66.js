gdjs.s56Code = {};
gdjs.s56Code.GDcaseObjects1= [];
gdjs.s56Code.GDcaseObjects2= [];
gdjs.s56Code.GDimageObjects1= [];
gdjs.s56Code.GDimageObjects2= [];
gdjs.s56Code.GDoffObjects1= [];
gdjs.s56Code.GDoffObjects2= [];
gdjs.s56Code.GDonObjects1= [];
gdjs.s56Code.GDonObjects2= [];
gdjs.s56Code.GDstartObjects1= [];
gdjs.s56Code.GDstartObjects2= [];
gdjs.s56Code.GDBObjects1= [];
gdjs.s56Code.GDBObjects2= [];
gdjs.s56Code.GDblackObjects1= [];
gdjs.s56Code.GDblackObjects2= [];
gdjs.s56Code.GDAObjects1= [];
gdjs.s56Code.GDAObjects2= [];

gdjs.s56Code.conditionTrue_0 = {val:false};
gdjs.s56Code.condition0IsTrue_0 = {val:false};
gdjs.s56Code.condition1IsTrue_0 = {val:false};


gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s56Code.GDstartObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s56Code.GDoffObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s56Code.GDonObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s56Code.GDBObjects1});gdjs.s56Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s56Code.GDstartObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s56Code.GDoffObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s56Code.GDonObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s56Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s56.1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s56Code.GDBObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s56.1", false);
}}

}


{


{
}

}


};

gdjs.s56Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s56Code.GDcaseObjects1.length = 0;
gdjs.s56Code.GDcaseObjects2.length = 0;
gdjs.s56Code.GDimageObjects1.length = 0;
gdjs.s56Code.GDimageObjects2.length = 0;
gdjs.s56Code.GDoffObjects1.length = 0;
gdjs.s56Code.GDoffObjects2.length = 0;
gdjs.s56Code.GDonObjects1.length = 0;
gdjs.s56Code.GDonObjects2.length = 0;
gdjs.s56Code.GDstartObjects1.length = 0;
gdjs.s56Code.GDstartObjects2.length = 0;
gdjs.s56Code.GDBObjects1.length = 0;
gdjs.s56Code.GDBObjects2.length = 0;
gdjs.s56Code.GDblackObjects1.length = 0;
gdjs.s56Code.GDblackObjects2.length = 0;
gdjs.s56Code.GDAObjects1.length = 0;
gdjs.s56Code.GDAObjects2.length = 0;

gdjs.s56Code.eventsList0(runtimeScene);
return;

}

gdjs['s56Code'] = gdjs.s56Code;
