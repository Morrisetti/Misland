gdjs.s270Code = {};
gdjs.s270Code.GDcaseObjects1= [];
gdjs.s270Code.GDcaseObjects2= [];
gdjs.s270Code.GDimageObjects1= [];
gdjs.s270Code.GDimageObjects2= [];
gdjs.s270Code.GDoffObjects1= [];
gdjs.s270Code.GDoffObjects2= [];
gdjs.s270Code.GDonObjects1= [];
gdjs.s270Code.GDonObjects2= [];
gdjs.s270Code.GDstartObjects1= [];
gdjs.s270Code.GDstartObjects2= [];
gdjs.s270Code.GDBObjects1= [];
gdjs.s270Code.GDBObjects2= [];
gdjs.s270Code.GDblackObjects1= [];
gdjs.s270Code.GDblackObjects2= [];
gdjs.s270Code.GDAObjects1= [];
gdjs.s270Code.GDAObjects2= [];

gdjs.s270Code.conditionTrue_0 = {val:false};
gdjs.s270Code.condition0IsTrue_0 = {val:false};
gdjs.s270Code.condition1IsTrue_0 = {val:false};


gdjs.s270Code.mapOfGDgdjs_46s270Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s270Code.GDoffObjects1});gdjs.s270Code.mapOfGDgdjs_46s270Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s270Code.GDonObjects1});gdjs.s270Code.mapOfGDgdjs_46s270Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s270Code.GDAObjects1});gdjs.s270Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s270Code.GDoffObjects1);

gdjs.s270Code.condition0IsTrue_0.val = false;
{
gdjs.s270Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s270Code.mapOfGDgdjs_46s270Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s270Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s270Code.GDonObjects1);

gdjs.s270Code.condition0IsTrue_0.val = false;
{
gdjs.s270Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s270Code.mapOfGDgdjs_46s270Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s270Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s270Code.condition0IsTrue_0.val = false;
{
gdjs.s270Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s270Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s271", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s270Code.GDAObjects1);

gdjs.s270Code.condition0IsTrue_0.val = false;
{
gdjs.s270Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s270Code.mapOfGDgdjs_46s270Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s270Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s271", false);
}}

}


{


{
}

}


};

gdjs.s270Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s270Code.GDcaseObjects1.length = 0;
gdjs.s270Code.GDcaseObjects2.length = 0;
gdjs.s270Code.GDimageObjects1.length = 0;
gdjs.s270Code.GDimageObjects2.length = 0;
gdjs.s270Code.GDoffObjects1.length = 0;
gdjs.s270Code.GDoffObjects2.length = 0;
gdjs.s270Code.GDonObjects1.length = 0;
gdjs.s270Code.GDonObjects2.length = 0;
gdjs.s270Code.GDstartObjects1.length = 0;
gdjs.s270Code.GDstartObjects2.length = 0;
gdjs.s270Code.GDBObjects1.length = 0;
gdjs.s270Code.GDBObjects2.length = 0;
gdjs.s270Code.GDblackObjects1.length = 0;
gdjs.s270Code.GDblackObjects2.length = 0;
gdjs.s270Code.GDAObjects1.length = 0;
gdjs.s270Code.GDAObjects2.length = 0;

gdjs.s270Code.eventsList0(runtimeScene);
return;

}

gdjs['s270Code'] = gdjs.s270Code;
