gdjs.s350Code = {};
gdjs.s350Code.GDcaseObjects1= [];
gdjs.s350Code.GDcaseObjects2= [];
gdjs.s350Code.GDimageObjects1= [];
gdjs.s350Code.GDimageObjects2= [];
gdjs.s350Code.GDoffObjects1= [];
gdjs.s350Code.GDoffObjects2= [];
gdjs.s350Code.GDonObjects1= [];
gdjs.s350Code.GDonObjects2= [];
gdjs.s350Code.GDstartObjects1= [];
gdjs.s350Code.GDstartObjects2= [];
gdjs.s350Code.GDBObjects1= [];
gdjs.s350Code.GDBObjects2= [];
gdjs.s350Code.GDAObjects1= [];
gdjs.s350Code.GDAObjects2= [];
gdjs.s350Code.GDcrosshairsObjects1= [];
gdjs.s350Code.GDcrosshairsObjects2= [];
gdjs.s350Code.GDDOWNbuttonObjects1= [];
gdjs.s350Code.GDDOWNbuttonObjects2= [];
gdjs.s350Code.GDDOWNcolObjects1= [];
gdjs.s350Code.GDDOWNcolObjects2= [];
gdjs.s350Code.GDUPbuttonObjects1= [];
gdjs.s350Code.GDUPbuttonObjects2= [];
gdjs.s350Code.GDUPcolObjects1= [];
gdjs.s350Code.GDUPcolObjects2= [];
gdjs.s350Code.GDLbuttonObjects1= [];
gdjs.s350Code.GDLbuttonObjects2= [];
gdjs.s350Code.GDLcolObjects1= [];
gdjs.s350Code.GDLcolObjects2= [];
gdjs.s350Code.GDRbuttonObjects1= [];
gdjs.s350Code.GDRbuttonObjects2= [];
gdjs.s350Code.GDRcolObjects1= [];
gdjs.s350Code.GDRcolObjects2= [];
gdjs.s350Code.GDchapter4Objects1= [];
gdjs.s350Code.GDchapter4Objects2= [];
gdjs.s350Code.GDchapter3Objects1= [];
gdjs.s350Code.GDchapter3Objects2= [];
gdjs.s350Code.GDchapter2Objects1= [];
gdjs.s350Code.GDchapter2Objects2= [];
gdjs.s350Code.GDblackObjects1= [];
gdjs.s350Code.GDblackObjects2= [];
gdjs.s350Code.GDchapter1Objects1= [];
gdjs.s350Code.GDchapter1Objects2= [];

gdjs.s350Code.conditionTrue_0 = {val:false};
gdjs.s350Code.condition0IsTrue_0 = {val:false};
gdjs.s350Code.condition1IsTrue_0 = {val:false};
gdjs.s350Code.condition2IsTrue_0 = {val:false};


gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s350Code.GDDOWNbuttonObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s350Code.GDUPbuttonObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s350Code.GDRbuttonObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s350Code.GDLbuttonObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s350Code.GDcrosshairsObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s350Code.GDRcolObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s350Code.GDcrosshairsObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s350Code.GDLcolObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s350Code.GDcrosshairsObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s350Code.GDUPcolObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s350Code.GDcrosshairsObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s350Code.GDDOWNcolObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s350Code.GDcrosshairsObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s350Code.GDDOWNcolObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s350Code.GDoffObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s350Code.GDonObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s350Code.GDcrosshairsObjects1});gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s350Code.GDchapter1Objects1});gdjs.s350Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s350Code.GDDOWNbuttonObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
gdjs.s350Code.condition1IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s350Code.condition0IsTrue_0.val ) {
{
gdjs.s350Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s350Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s350Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s350Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s350Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s350Code.GDUPbuttonObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
gdjs.s350Code.condition1IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s350Code.condition0IsTrue_0.val ) {
{
gdjs.s350Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s350Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s350Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s350Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s350Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s350Code.GDRbuttonObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
gdjs.s350Code.condition1IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s350Code.condition0IsTrue_0.val ) {
{
gdjs.s350Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s350Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s350Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s350Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s350Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s350Code.GDLbuttonObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
gdjs.s350Code.condition1IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s350Code.condition0IsTrue_0.val ) {
{
gdjs.s350Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s350Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s350Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s350Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s350Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s350Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s350Code.GDcrosshairsObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects, gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s350Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s350Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s350Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s350Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s350Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s350Code.GDcrosshairsObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects, gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s350Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s350Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s350Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s350Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s350Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s350Code.GDcrosshairsObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects, gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s350Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s350Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s350Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s350Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s350Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s350Code.GDcrosshairsObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects, gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s350Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s350Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s350Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s350Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s350Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s350Code.GDcrosshairsObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects, gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s350Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s350Code.GDoffObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s350Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s350Code.GDonObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s350Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s350Code.GDstartObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s350Code.GDstartObjects1.length;i<l;++i) {
    if ( gdjs.s350Code.GDstartObjects1[i].timerElapsedTime("", 4) ) {
        gdjs.s350Code.condition0IsTrue_0.val = true;
        gdjs.s350Code.GDstartObjects1[k] = gdjs.s350Code.GDstartObjects1[i];
        ++k;
    }
}
gdjs.s350Code.GDstartObjects1.length = k;}if (gdjs.s350Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s343", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s350Code.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s350Code.GDcrosshairsObjects1);

gdjs.s350Code.condition0IsTrue_0.val = false;
gdjs.s350Code.condition1IsTrue_0.val = false;
{
gdjs.s350Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDcrosshairsObjects1Objects, gdjs.s350Code.mapOfGDgdjs_46s350Code_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s350Code.condition0IsTrue_0.val ) {
{
gdjs.s350Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s350Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s351", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s350Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s350Code.GDcaseObjects1.length = 0;
gdjs.s350Code.GDcaseObjects2.length = 0;
gdjs.s350Code.GDimageObjects1.length = 0;
gdjs.s350Code.GDimageObjects2.length = 0;
gdjs.s350Code.GDoffObjects1.length = 0;
gdjs.s350Code.GDoffObjects2.length = 0;
gdjs.s350Code.GDonObjects1.length = 0;
gdjs.s350Code.GDonObjects2.length = 0;
gdjs.s350Code.GDstartObjects1.length = 0;
gdjs.s350Code.GDstartObjects2.length = 0;
gdjs.s350Code.GDBObjects1.length = 0;
gdjs.s350Code.GDBObjects2.length = 0;
gdjs.s350Code.GDAObjects1.length = 0;
gdjs.s350Code.GDAObjects2.length = 0;
gdjs.s350Code.GDcrosshairsObjects1.length = 0;
gdjs.s350Code.GDcrosshairsObjects2.length = 0;
gdjs.s350Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s350Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s350Code.GDDOWNcolObjects1.length = 0;
gdjs.s350Code.GDDOWNcolObjects2.length = 0;
gdjs.s350Code.GDUPbuttonObjects1.length = 0;
gdjs.s350Code.GDUPbuttonObjects2.length = 0;
gdjs.s350Code.GDUPcolObjects1.length = 0;
gdjs.s350Code.GDUPcolObjects2.length = 0;
gdjs.s350Code.GDLbuttonObjects1.length = 0;
gdjs.s350Code.GDLbuttonObjects2.length = 0;
gdjs.s350Code.GDLcolObjects1.length = 0;
gdjs.s350Code.GDLcolObjects2.length = 0;
gdjs.s350Code.GDRbuttonObjects1.length = 0;
gdjs.s350Code.GDRbuttonObjects2.length = 0;
gdjs.s350Code.GDRcolObjects1.length = 0;
gdjs.s350Code.GDRcolObjects2.length = 0;
gdjs.s350Code.GDchapter4Objects1.length = 0;
gdjs.s350Code.GDchapter4Objects2.length = 0;
gdjs.s350Code.GDchapter3Objects1.length = 0;
gdjs.s350Code.GDchapter3Objects2.length = 0;
gdjs.s350Code.GDchapter2Objects1.length = 0;
gdjs.s350Code.GDchapter2Objects2.length = 0;
gdjs.s350Code.GDblackObjects1.length = 0;
gdjs.s350Code.GDblackObjects2.length = 0;
gdjs.s350Code.GDchapter1Objects1.length = 0;
gdjs.s350Code.GDchapter1Objects2.length = 0;

gdjs.s350Code.eventsList0(runtimeScene);
return;

}

gdjs['s350Code'] = gdjs.s350Code;
