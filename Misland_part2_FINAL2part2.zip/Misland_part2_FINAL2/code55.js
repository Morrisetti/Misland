gdjs.s46Code = {};
gdjs.s46Code.GDcaseObjects1= [];
gdjs.s46Code.GDcaseObjects2= [];
gdjs.s46Code.GDimageObjects1= [];
gdjs.s46Code.GDimageObjects2= [];
gdjs.s46Code.GDoffObjects1= [];
gdjs.s46Code.GDoffObjects2= [];
gdjs.s46Code.GDonObjects1= [];
gdjs.s46Code.GDonObjects2= [];
gdjs.s46Code.GDstartObjects1= [];
gdjs.s46Code.GDstartObjects2= [];
gdjs.s46Code.GDBObjects1= [];
gdjs.s46Code.GDBObjects2= [];
gdjs.s46Code.GDblackObjects1= [];
gdjs.s46Code.GDblackObjects2= [];
gdjs.s46Code.GDAObjects1= [];
gdjs.s46Code.GDAObjects2= [];

gdjs.s46Code.conditionTrue_0 = {val:false};
gdjs.s46Code.condition0IsTrue_0 = {val:false};
gdjs.s46Code.condition1IsTrue_0 = {val:false};


gdjs.s46Code.mapOfGDgdjs_46s46Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s46Code.GDstartObjects1});gdjs.s46Code.mapOfGDgdjs_46s46Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s46Code.GDoffObjects1});gdjs.s46Code.mapOfGDgdjs_46s46Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s46Code.GDonObjects1});gdjs.s46Code.mapOfGDgdjs_46s46Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s46Code.GDBObjects1});gdjs.s46Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s46Code.GDstartObjects1);

gdjs.s46Code.condition0IsTrue_0.val = false;
{
gdjs.s46Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s46Code.mapOfGDgdjs_46s46Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s46Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s46Code.GDoffObjects1);

gdjs.s46Code.condition0IsTrue_0.val = false;
{
gdjs.s46Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s46Code.mapOfGDgdjs_46s46Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s46Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s46Code.GDonObjects1);

gdjs.s46Code.condition0IsTrue_0.val = false;
{
gdjs.s46Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s46Code.mapOfGDgdjs_46s46Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s46Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s46Code.condition0IsTrue_0.val = false;
{
gdjs.s46Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s46Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s47", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s46Code.GDBObjects1);

gdjs.s46Code.condition0IsTrue_0.val = false;
{
gdjs.s46Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s46Code.mapOfGDgdjs_46s46Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s46Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s47", false);
}}

}


{


{
}

}


};

gdjs.s46Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s46Code.GDcaseObjects1.length = 0;
gdjs.s46Code.GDcaseObjects2.length = 0;
gdjs.s46Code.GDimageObjects1.length = 0;
gdjs.s46Code.GDimageObjects2.length = 0;
gdjs.s46Code.GDoffObjects1.length = 0;
gdjs.s46Code.GDoffObjects2.length = 0;
gdjs.s46Code.GDonObjects1.length = 0;
gdjs.s46Code.GDonObjects2.length = 0;
gdjs.s46Code.GDstartObjects1.length = 0;
gdjs.s46Code.GDstartObjects2.length = 0;
gdjs.s46Code.GDBObjects1.length = 0;
gdjs.s46Code.GDBObjects2.length = 0;
gdjs.s46Code.GDblackObjects1.length = 0;
gdjs.s46Code.GDblackObjects2.length = 0;
gdjs.s46Code.GDAObjects1.length = 0;
gdjs.s46Code.GDAObjects2.length = 0;

gdjs.s46Code.eventsList0(runtimeScene);
return;

}

gdjs['s46Code'] = gdjs.s46Code;
