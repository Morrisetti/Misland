gdjs.s307Code = {};
gdjs.s307Code.GDcaseObjects1= [];
gdjs.s307Code.GDcaseObjects2= [];
gdjs.s307Code.GDimageObjects1= [];
gdjs.s307Code.GDimageObjects2= [];
gdjs.s307Code.GDoffObjects1= [];
gdjs.s307Code.GDoffObjects2= [];
gdjs.s307Code.GDonObjects1= [];
gdjs.s307Code.GDonObjects2= [];
gdjs.s307Code.GDstartObjects1= [];
gdjs.s307Code.GDstartObjects2= [];
gdjs.s307Code.GDBObjects1= [];
gdjs.s307Code.GDBObjects2= [];
gdjs.s307Code.GDblackObjects1= [];
gdjs.s307Code.GDblackObjects2= [];
gdjs.s307Code.GDAObjects1= [];
gdjs.s307Code.GDAObjects2= [];

gdjs.s307Code.conditionTrue_0 = {val:false};
gdjs.s307Code.condition0IsTrue_0 = {val:false};
gdjs.s307Code.condition1IsTrue_0 = {val:false};


gdjs.s307Code.mapOfGDgdjs_46s307Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s307Code.GDoffObjects1});gdjs.s307Code.mapOfGDgdjs_46s307Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s307Code.GDonObjects1});gdjs.s307Code.mapOfGDgdjs_46s307Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s307Code.GDBObjects1});gdjs.s307Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s307Code.GDoffObjects1);

gdjs.s307Code.condition0IsTrue_0.val = false;
{
gdjs.s307Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s307Code.mapOfGDgdjs_46s307Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s307Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s307Code.GDonObjects1);

gdjs.s307Code.condition0IsTrue_0.val = false;
{
gdjs.s307Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s307Code.mapOfGDgdjs_46s307Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s307Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s307Code.condition0IsTrue_0.val = false;
{
gdjs.s307Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s307Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s308", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s307Code.GDBObjects1);

gdjs.s307Code.condition0IsTrue_0.val = false;
{
gdjs.s307Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s307Code.mapOfGDgdjs_46s307Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s307Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s308", false);
}}

}


{


{
}

}


};

gdjs.s307Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s307Code.GDcaseObjects1.length = 0;
gdjs.s307Code.GDcaseObjects2.length = 0;
gdjs.s307Code.GDimageObjects1.length = 0;
gdjs.s307Code.GDimageObjects2.length = 0;
gdjs.s307Code.GDoffObjects1.length = 0;
gdjs.s307Code.GDoffObjects2.length = 0;
gdjs.s307Code.GDonObjects1.length = 0;
gdjs.s307Code.GDonObjects2.length = 0;
gdjs.s307Code.GDstartObjects1.length = 0;
gdjs.s307Code.GDstartObjects2.length = 0;
gdjs.s307Code.GDBObjects1.length = 0;
gdjs.s307Code.GDBObjects2.length = 0;
gdjs.s307Code.GDblackObjects1.length = 0;
gdjs.s307Code.GDblackObjects2.length = 0;
gdjs.s307Code.GDAObjects1.length = 0;
gdjs.s307Code.GDAObjects2.length = 0;

gdjs.s307Code.eventsList0(runtimeScene);
return;

}

gdjs['s307Code'] = gdjs.s307Code;
