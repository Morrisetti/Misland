gdjs.s370Code = {};
gdjs.s370Code.GDcaseObjects1= [];
gdjs.s370Code.GDcaseObjects2= [];
gdjs.s370Code.GDimageObjects1= [];
gdjs.s370Code.GDimageObjects2= [];
gdjs.s370Code.GDoffObjects1= [];
gdjs.s370Code.GDoffObjects2= [];
gdjs.s370Code.GDonObjects1= [];
gdjs.s370Code.GDonObjects2= [];
gdjs.s370Code.GDstartObjects1= [];
gdjs.s370Code.GDstartObjects2= [];
gdjs.s370Code.GDBObjects1= [];
gdjs.s370Code.GDBObjects2= [];
gdjs.s370Code.GDblackObjects1= [];
gdjs.s370Code.GDblackObjects2= [];
gdjs.s370Code.GDAObjects1= [];
gdjs.s370Code.GDAObjects2= [];

gdjs.s370Code.conditionTrue_0 = {val:false};
gdjs.s370Code.condition0IsTrue_0 = {val:false};
gdjs.s370Code.condition1IsTrue_0 = {val:false};


gdjs.s370Code.mapOfGDgdjs_46s370Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s370Code.GDoffObjects1});gdjs.s370Code.mapOfGDgdjs_46s370Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s370Code.GDonObjects1});gdjs.s370Code.mapOfGDgdjs_46s370Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s370Code.GDBObjects1});gdjs.s370Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s370Code.GDoffObjects1);

gdjs.s370Code.condition0IsTrue_0.val = false;
{
gdjs.s370Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s370Code.mapOfGDgdjs_46s370Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s370Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s370Code.GDonObjects1);

gdjs.s370Code.condition0IsTrue_0.val = false;
{
gdjs.s370Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s370Code.mapOfGDgdjs_46s370Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s370Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s370Code.condition0IsTrue_0.val = false;
{
gdjs.s370Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s370Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s371", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s370Code.GDBObjects1);

gdjs.s370Code.condition0IsTrue_0.val = false;
{
gdjs.s370Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s370Code.mapOfGDgdjs_46s370Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s370Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s371", false);
}}

}


{


{
}

}


};

gdjs.s370Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s370Code.GDcaseObjects1.length = 0;
gdjs.s370Code.GDcaseObjects2.length = 0;
gdjs.s370Code.GDimageObjects1.length = 0;
gdjs.s370Code.GDimageObjects2.length = 0;
gdjs.s370Code.GDoffObjects1.length = 0;
gdjs.s370Code.GDoffObjects2.length = 0;
gdjs.s370Code.GDonObjects1.length = 0;
gdjs.s370Code.GDonObjects2.length = 0;
gdjs.s370Code.GDstartObjects1.length = 0;
gdjs.s370Code.GDstartObjects2.length = 0;
gdjs.s370Code.GDBObjects1.length = 0;
gdjs.s370Code.GDBObjects2.length = 0;
gdjs.s370Code.GDblackObjects1.length = 0;
gdjs.s370Code.GDblackObjects2.length = 0;
gdjs.s370Code.GDAObjects1.length = 0;
gdjs.s370Code.GDAObjects2.length = 0;

gdjs.s370Code.eventsList0(runtimeScene);
return;

}

gdjs['s370Code'] = gdjs.s370Code;
