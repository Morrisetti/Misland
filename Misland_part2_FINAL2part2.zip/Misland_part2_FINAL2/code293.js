gdjs.s257Code = {};
gdjs.s257Code.GDcaseObjects1= [];
gdjs.s257Code.GDcaseObjects2= [];
gdjs.s257Code.GDimageObjects1= [];
gdjs.s257Code.GDimageObjects2= [];
gdjs.s257Code.GDoffObjects1= [];
gdjs.s257Code.GDoffObjects2= [];
gdjs.s257Code.GDonObjects1= [];
gdjs.s257Code.GDonObjects2= [];
gdjs.s257Code.GDstartObjects1= [];
gdjs.s257Code.GDstartObjects2= [];
gdjs.s257Code.GDBObjects1= [];
gdjs.s257Code.GDBObjects2= [];
gdjs.s257Code.GDblackObjects1= [];
gdjs.s257Code.GDblackObjects2= [];
gdjs.s257Code.GDAObjects1= [];
gdjs.s257Code.GDAObjects2= [];

gdjs.s257Code.conditionTrue_0 = {val:false};
gdjs.s257Code.condition0IsTrue_0 = {val:false};
gdjs.s257Code.condition1IsTrue_0 = {val:false};


gdjs.s257Code.mapOfGDgdjs_46s257Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s257Code.GDoffObjects1});gdjs.s257Code.mapOfGDgdjs_46s257Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s257Code.GDonObjects1});gdjs.s257Code.mapOfGDgdjs_46s257Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s257Code.GDBObjects1});gdjs.s257Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s257Code.GDoffObjects1);

gdjs.s257Code.condition0IsTrue_0.val = false;
{
gdjs.s257Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s257Code.mapOfGDgdjs_46s257Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s257Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s257Code.GDonObjects1);

gdjs.s257Code.condition0IsTrue_0.val = false;
{
gdjs.s257Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s257Code.mapOfGDgdjs_46s257Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s257Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s257Code.condition0IsTrue_0.val = false;
{
gdjs.s257Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s257Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s258", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s257Code.GDBObjects1);

gdjs.s257Code.condition0IsTrue_0.val = false;
{
gdjs.s257Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s257Code.mapOfGDgdjs_46s257Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s257Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s258", false);
}}

}


{


{
}

}


};

gdjs.s257Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s257Code.GDcaseObjects1.length = 0;
gdjs.s257Code.GDcaseObjects2.length = 0;
gdjs.s257Code.GDimageObjects1.length = 0;
gdjs.s257Code.GDimageObjects2.length = 0;
gdjs.s257Code.GDoffObjects1.length = 0;
gdjs.s257Code.GDoffObjects2.length = 0;
gdjs.s257Code.GDonObjects1.length = 0;
gdjs.s257Code.GDonObjects2.length = 0;
gdjs.s257Code.GDstartObjects1.length = 0;
gdjs.s257Code.GDstartObjects2.length = 0;
gdjs.s257Code.GDBObjects1.length = 0;
gdjs.s257Code.GDBObjects2.length = 0;
gdjs.s257Code.GDblackObjects1.length = 0;
gdjs.s257Code.GDblackObjects2.length = 0;
gdjs.s257Code.GDAObjects1.length = 0;
gdjs.s257Code.GDAObjects2.length = 0;

gdjs.s257Code.eventsList0(runtimeScene);
return;

}

gdjs['s257Code'] = gdjs.s257Code;
