gdjs.s80Code = {};
gdjs.s80Code.GDcaseObjects1= [];
gdjs.s80Code.GDcaseObjects2= [];
gdjs.s80Code.GDoffObjects1= [];
gdjs.s80Code.GDoffObjects2= [];
gdjs.s80Code.GDonObjects1= [];
gdjs.s80Code.GDonObjects2= [];
gdjs.s80Code.GDstartObjects1= [];
gdjs.s80Code.GDstartObjects2= [];
gdjs.s80Code.GDBObjects1= [];
gdjs.s80Code.GDBObjects2= [];
gdjs.s80Code.GDAObjects1= [];
gdjs.s80Code.GDAObjects2= [];
gdjs.s80Code.GDbugzObjects1= [];
gdjs.s80Code.GDbugzObjects2= [];
gdjs.s80Code.GDDOWNbuttonObjects1= [];
gdjs.s80Code.GDDOWNbuttonObjects2= [];
gdjs.s80Code.GDblackObjects1= [];
gdjs.s80Code.GDblackObjects2= [];
gdjs.s80Code.GDDOWNcolObjects1= [];
gdjs.s80Code.GDDOWNcolObjects2= [];
gdjs.s80Code.GDUPbuttonObjects1= [];
gdjs.s80Code.GDUPbuttonObjects2= [];
gdjs.s80Code.GDUPcolObjects1= [];
gdjs.s80Code.GDUPcolObjects2= [];
gdjs.s80Code.GDLbuttonObjects1= [];
gdjs.s80Code.GDLbuttonObjects2= [];
gdjs.s80Code.GDLcolObjects1= [];
gdjs.s80Code.GDLcolObjects2= [];
gdjs.s80Code.GDRbuttonObjects1= [];
gdjs.s80Code.GDRbuttonObjects2= [];
gdjs.s80Code.GDexitObjects1= [];
gdjs.s80Code.GDexitObjects2= [];
gdjs.s80Code.GDdeathObjects1= [];
gdjs.s80Code.GDdeathObjects2= [];
gdjs.s80Code.GDRcolObjects1= [];
gdjs.s80Code.GDRcolObjects2= [];
gdjs.s80Code.GDchapter4Objects1= [];
gdjs.s80Code.GDchapter4Objects2= [];
gdjs.s80Code.GDchapter3Objects1= [];
gdjs.s80Code.GDchapter3Objects2= [];
gdjs.s80Code.GDchapter2Objects1= [];
gdjs.s80Code.GDchapter2Objects2= [];
gdjs.s80Code.GDchapter1Objects1= [];
gdjs.s80Code.GDchapter1Objects2= [];
gdjs.s80Code.GDBGObjects1= [];
gdjs.s80Code.GDBGObjects2= [];

gdjs.s80Code.conditionTrue_0 = {val:false};
gdjs.s80Code.condition0IsTrue_0 = {val:false};
gdjs.s80Code.condition1IsTrue_0 = {val:false};
gdjs.s80Code.condition2IsTrue_0 = {val:false};
gdjs.s80Code.conditionTrue_1 = {val:false};
gdjs.s80Code.condition0IsTrue_1 = {val:false};
gdjs.s80Code.condition1IsTrue_1 = {val:false};
gdjs.s80Code.condition2IsTrue_1 = {val:false};


gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s80Code.GDDOWNbuttonObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s80Code.GDUPbuttonObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s80Code.GDRbuttonObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s80Code.GDLbuttonObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s80Code.GDbugzObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s80Code.GDRcolObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s80Code.GDbugzObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s80Code.GDLcolObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s80Code.GDbugzObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s80Code.GDUPcolObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s80Code.GDbugzObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s80Code.GDDOWNcolObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s80Code.GDbugzObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s80Code.GDDOWNcolObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s80Code.GDBObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s80Code.GDAObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s80Code.GDoffObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s80Code.GDonObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s80Code.GDbugzObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDdeathObjects1Objects = Hashtable.newFrom({"death": gdjs.s80Code.GDdeathObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s80Code.GDbugzObjects1});gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.s80Code.GDexitObjects1});gdjs.s80Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s80Code.GDDOWNbuttonObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
gdjs.s80Code.condition1IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s80Code.condition0IsTrue_0.val ) {
{
gdjs.s80Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s80Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s80Code.GDUPbuttonObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
gdjs.s80Code.condition1IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s80Code.condition0IsTrue_0.val ) {
{
gdjs.s80Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s80Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s80Code.GDRbuttonObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
gdjs.s80Code.condition1IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s80Code.condition0IsTrue_0.val ) {
{
gdjs.s80Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s80Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


gdjs.s80Code.condition0IsTrue_0.val = false;
{
{gdjs.s80Code.conditionTrue_1 = gdjs.s80Code.condition0IsTrue_0;
gdjs.s80Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(88197148);
}
}if (gdjs.s80Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter6_v1.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s80Code.GDLbuttonObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
gdjs.s80Code.condition1IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s80Code.condition0IsTrue_0.val ) {
{
gdjs.s80Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s80Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s80Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects, gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s80Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s80Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s80Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects, gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s80Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s80Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s80Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects, gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s80Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s80Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s80Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects, gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s80Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s80Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s80Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects, gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s80Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s80Code.GDBObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s80Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s80Code.GDAObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s80Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s80Code.GDoffObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s80Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s80Code.GDonObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s80Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s80Code.condition0IsTrue_0.val = false;
gdjs.s80Code.condition1IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s80Code.condition0IsTrue_0.val ) {
{
gdjs.s80Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s80Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s80Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s80Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s80Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s80Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s80Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s80Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s80Code.GDdeathObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects, gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDdeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s80Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s80.1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.s80Code.GDexitObjects1);

gdjs.s80Code.condition0IsTrue_0.val = false;
{
gdjs.s80Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDbugzObjects1Objects, gdjs.s80Code.mapOfGDgdjs_46s80Code_46GDexitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s80Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s82", false);
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s80Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s80Code.GDbugzObjects1.length !== 0 ? gdjs.s80Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s80Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s80Code.GDcaseObjects1.length = 0;
gdjs.s80Code.GDcaseObjects2.length = 0;
gdjs.s80Code.GDoffObjects1.length = 0;
gdjs.s80Code.GDoffObjects2.length = 0;
gdjs.s80Code.GDonObjects1.length = 0;
gdjs.s80Code.GDonObjects2.length = 0;
gdjs.s80Code.GDstartObjects1.length = 0;
gdjs.s80Code.GDstartObjects2.length = 0;
gdjs.s80Code.GDBObjects1.length = 0;
gdjs.s80Code.GDBObjects2.length = 0;
gdjs.s80Code.GDAObjects1.length = 0;
gdjs.s80Code.GDAObjects2.length = 0;
gdjs.s80Code.GDbugzObjects1.length = 0;
gdjs.s80Code.GDbugzObjects2.length = 0;
gdjs.s80Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s80Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s80Code.GDblackObjects1.length = 0;
gdjs.s80Code.GDblackObjects2.length = 0;
gdjs.s80Code.GDDOWNcolObjects1.length = 0;
gdjs.s80Code.GDDOWNcolObjects2.length = 0;
gdjs.s80Code.GDUPbuttonObjects1.length = 0;
gdjs.s80Code.GDUPbuttonObjects2.length = 0;
gdjs.s80Code.GDUPcolObjects1.length = 0;
gdjs.s80Code.GDUPcolObjects2.length = 0;
gdjs.s80Code.GDLbuttonObjects1.length = 0;
gdjs.s80Code.GDLbuttonObjects2.length = 0;
gdjs.s80Code.GDLcolObjects1.length = 0;
gdjs.s80Code.GDLcolObjects2.length = 0;
gdjs.s80Code.GDRbuttonObjects1.length = 0;
gdjs.s80Code.GDRbuttonObjects2.length = 0;
gdjs.s80Code.GDexitObjects1.length = 0;
gdjs.s80Code.GDexitObjects2.length = 0;
gdjs.s80Code.GDdeathObjects1.length = 0;
gdjs.s80Code.GDdeathObjects2.length = 0;
gdjs.s80Code.GDRcolObjects1.length = 0;
gdjs.s80Code.GDRcolObjects2.length = 0;
gdjs.s80Code.GDchapter4Objects1.length = 0;
gdjs.s80Code.GDchapter4Objects2.length = 0;
gdjs.s80Code.GDchapter3Objects1.length = 0;
gdjs.s80Code.GDchapter3Objects2.length = 0;
gdjs.s80Code.GDchapter2Objects1.length = 0;
gdjs.s80Code.GDchapter2Objects2.length = 0;
gdjs.s80Code.GDchapter1Objects1.length = 0;
gdjs.s80Code.GDchapter1Objects2.length = 0;
gdjs.s80Code.GDBGObjects1.length = 0;
gdjs.s80Code.GDBGObjects2.length = 0;

gdjs.s80Code.eventsList0(runtimeScene);
return;

}

gdjs['s80Code'] = gdjs.s80Code;
