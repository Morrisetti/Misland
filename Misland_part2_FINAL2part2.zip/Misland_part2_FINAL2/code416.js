gdjs.s373Code = {};
gdjs.s373Code.GDcaseObjects1= [];
gdjs.s373Code.GDcaseObjects2= [];
gdjs.s373Code.GDimageObjects1= [];
gdjs.s373Code.GDimageObjects2= [];
gdjs.s373Code.GDoffObjects1= [];
gdjs.s373Code.GDoffObjects2= [];
gdjs.s373Code.GDonObjects1= [];
gdjs.s373Code.GDonObjects2= [];
gdjs.s373Code.GDstartObjects1= [];
gdjs.s373Code.GDstartObjects2= [];
gdjs.s373Code.GDBObjects1= [];
gdjs.s373Code.GDBObjects2= [];
gdjs.s373Code.GDblackObjects1= [];
gdjs.s373Code.GDblackObjects2= [];
gdjs.s373Code.GDAObjects1= [];
gdjs.s373Code.GDAObjects2= [];

gdjs.s373Code.conditionTrue_0 = {val:false};
gdjs.s373Code.condition0IsTrue_0 = {val:false};
gdjs.s373Code.condition1IsTrue_0 = {val:false};


gdjs.s373Code.mapOfGDgdjs_46s373Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s373Code.GDoffObjects1});gdjs.s373Code.mapOfGDgdjs_46s373Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s373Code.GDonObjects1});gdjs.s373Code.mapOfGDgdjs_46s373Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s373Code.GDBObjects1});gdjs.s373Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s373Code.GDoffObjects1);

gdjs.s373Code.condition0IsTrue_0.val = false;
{
gdjs.s373Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s373Code.mapOfGDgdjs_46s373Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s373Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s373Code.GDonObjects1);

gdjs.s373Code.condition0IsTrue_0.val = false;
{
gdjs.s373Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s373Code.mapOfGDgdjs_46s373Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s373Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s373Code.condition0IsTrue_0.val = false;
{
gdjs.s373Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s373Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s374", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s373Code.GDBObjects1);

gdjs.s373Code.condition0IsTrue_0.val = false;
{
gdjs.s373Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s373Code.mapOfGDgdjs_46s373Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s373Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s374", false);
}}

}


{


{
}

}


};

gdjs.s373Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s373Code.GDcaseObjects1.length = 0;
gdjs.s373Code.GDcaseObjects2.length = 0;
gdjs.s373Code.GDimageObjects1.length = 0;
gdjs.s373Code.GDimageObjects2.length = 0;
gdjs.s373Code.GDoffObjects1.length = 0;
gdjs.s373Code.GDoffObjects2.length = 0;
gdjs.s373Code.GDonObjects1.length = 0;
gdjs.s373Code.GDonObjects2.length = 0;
gdjs.s373Code.GDstartObjects1.length = 0;
gdjs.s373Code.GDstartObjects2.length = 0;
gdjs.s373Code.GDBObjects1.length = 0;
gdjs.s373Code.GDBObjects2.length = 0;
gdjs.s373Code.GDblackObjects1.length = 0;
gdjs.s373Code.GDblackObjects2.length = 0;
gdjs.s373Code.GDAObjects1.length = 0;
gdjs.s373Code.GDAObjects2.length = 0;

gdjs.s373Code.eventsList0(runtimeScene);
return;

}

gdjs['s373Code'] = gdjs.s373Code;
