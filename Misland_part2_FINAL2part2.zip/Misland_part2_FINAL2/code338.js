gdjs.s296Code = {};
gdjs.s296Code.GDcaseObjects1= [];
gdjs.s296Code.GDcaseObjects2= [];
gdjs.s296Code.GDimageObjects1= [];
gdjs.s296Code.GDimageObjects2= [];
gdjs.s296Code.GDoffObjects1= [];
gdjs.s296Code.GDoffObjects2= [];
gdjs.s296Code.GDonObjects1= [];
gdjs.s296Code.GDonObjects2= [];
gdjs.s296Code.GDstartObjects1= [];
gdjs.s296Code.GDstartObjects2= [];
gdjs.s296Code.GDBObjects1= [];
gdjs.s296Code.GDBObjects2= [];
gdjs.s296Code.GDblackObjects1= [];
gdjs.s296Code.GDblackObjects2= [];
gdjs.s296Code.GDAObjects1= [];
gdjs.s296Code.GDAObjects2= [];
gdjs.s296Code.GDbuttonObjects1= [];
gdjs.s296Code.GDbuttonObjects2= [];

gdjs.s296Code.conditionTrue_0 = {val:false};
gdjs.s296Code.condition0IsTrue_0 = {val:false};
gdjs.s296Code.condition1IsTrue_0 = {val:false};


gdjs.s296Code.mapOfGDgdjs_46s296Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s296Code.GDbuttonObjects1});gdjs.s296Code.mapOfGDgdjs_46s296Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s296Code.GDoffObjects1});gdjs.s296Code.mapOfGDgdjs_46s296Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s296Code.GDonObjects1});gdjs.s296Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s296Code.GDcaseObjects1);

gdjs.s296Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s296Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s296Code.GDcaseObjects1[i].timerElapsedTime("", 0.7) ) {
        gdjs.s296Code.condition0IsTrue_0.val = true;
        gdjs.s296Code.GDcaseObjects1[k] = gdjs.s296Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s296Code.GDcaseObjects1.length = k;}if (gdjs.s296Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s289", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s296Code.GDbuttonObjects1);

gdjs.s296Code.condition0IsTrue_0.val = false;
{
gdjs.s296Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s296Code.mapOfGDgdjs_46s296Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s296Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s2902", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s296Code.GDoffObjects1);

gdjs.s296Code.condition0IsTrue_0.val = false;
{
gdjs.s296Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s296Code.mapOfGDgdjs_46s296Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s296Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s296Code.GDonObjects1);

gdjs.s296Code.condition0IsTrue_0.val = false;
{
gdjs.s296Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s296Code.mapOfGDgdjs_46s296Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s296Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s296Code.condition0IsTrue_0.val = false;
{
gdjs.s296Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s296Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s2902", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s296Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s296Code.GDcaseObjects1.length = 0;
gdjs.s296Code.GDcaseObjects2.length = 0;
gdjs.s296Code.GDimageObjects1.length = 0;
gdjs.s296Code.GDimageObjects2.length = 0;
gdjs.s296Code.GDoffObjects1.length = 0;
gdjs.s296Code.GDoffObjects2.length = 0;
gdjs.s296Code.GDonObjects1.length = 0;
gdjs.s296Code.GDonObjects2.length = 0;
gdjs.s296Code.GDstartObjects1.length = 0;
gdjs.s296Code.GDstartObjects2.length = 0;
gdjs.s296Code.GDBObjects1.length = 0;
gdjs.s296Code.GDBObjects2.length = 0;
gdjs.s296Code.GDblackObjects1.length = 0;
gdjs.s296Code.GDblackObjects2.length = 0;
gdjs.s296Code.GDAObjects1.length = 0;
gdjs.s296Code.GDAObjects2.length = 0;
gdjs.s296Code.GDbuttonObjects1.length = 0;
gdjs.s296Code.GDbuttonObjects2.length = 0;

gdjs.s296Code.eventsList0(runtimeScene);
return;

}

gdjs['s296Code'] = gdjs.s296Code;
