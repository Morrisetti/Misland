gdjs.s123Code = {};
gdjs.s123Code.GDcaseObjects1= [];
gdjs.s123Code.GDcaseObjects2= [];
gdjs.s123Code.GDimageObjects1= [];
gdjs.s123Code.GDimageObjects2= [];
gdjs.s123Code.GDoffObjects1= [];
gdjs.s123Code.GDoffObjects2= [];
gdjs.s123Code.GDonObjects1= [];
gdjs.s123Code.GDonObjects2= [];
gdjs.s123Code.GDstartObjects1= [];
gdjs.s123Code.GDstartObjects2= [];
gdjs.s123Code.GDBObjects1= [];
gdjs.s123Code.GDBObjects2= [];
gdjs.s123Code.GDblackObjects1= [];
gdjs.s123Code.GDblackObjects2= [];
gdjs.s123Code.GDAObjects1= [];
gdjs.s123Code.GDAObjects2= [];

gdjs.s123Code.conditionTrue_0 = {val:false};
gdjs.s123Code.condition0IsTrue_0 = {val:false};
gdjs.s123Code.condition1IsTrue_0 = {val:false};
gdjs.s123Code.conditionTrue_1 = {val:false};
gdjs.s123Code.condition0IsTrue_1 = {val:false};
gdjs.s123Code.condition1IsTrue_1 = {val:false};


gdjs.s123Code.mapOfGDgdjs_46s123Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s123Code.GDstartObjects1});gdjs.s123Code.mapOfGDgdjs_46s123Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s123Code.GDoffObjects1});gdjs.s123Code.mapOfGDgdjs_46s123Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s123Code.GDonObjects1});gdjs.s123Code.mapOfGDgdjs_46s123Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s123Code.GDBObjects1});gdjs.s123Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s123Code.condition0IsTrue_0.val = false;
{
{gdjs.s123Code.conditionTrue_1 = gdjs.s123Code.condition0IsTrue_0;
gdjs.s123Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(89264748);
}
}if (gdjs.s123Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\dead.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s123Code.GDstartObjects1);

gdjs.s123Code.condition0IsTrue_0.val = false;
{
gdjs.s123Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s123Code.mapOfGDgdjs_46s123Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s123Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s118", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s123Code.GDoffObjects1);

gdjs.s123Code.condition0IsTrue_0.val = false;
{
gdjs.s123Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s123Code.mapOfGDgdjs_46s123Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s123Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s123Code.GDonObjects1);

gdjs.s123Code.condition0IsTrue_0.val = false;
{
gdjs.s123Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s123Code.mapOfGDgdjs_46s123Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s123Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s123Code.condition0IsTrue_0.val = false;
{
gdjs.s123Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.s123Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s125", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s123Code.GDBObjects1);

gdjs.s123Code.condition0IsTrue_0.val = false;
{
gdjs.s123Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s123Code.mapOfGDgdjs_46s123Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s123Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


};

gdjs.s123Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s123Code.GDcaseObjects1.length = 0;
gdjs.s123Code.GDcaseObjects2.length = 0;
gdjs.s123Code.GDimageObjects1.length = 0;
gdjs.s123Code.GDimageObjects2.length = 0;
gdjs.s123Code.GDoffObjects1.length = 0;
gdjs.s123Code.GDoffObjects2.length = 0;
gdjs.s123Code.GDonObjects1.length = 0;
gdjs.s123Code.GDonObjects2.length = 0;
gdjs.s123Code.GDstartObjects1.length = 0;
gdjs.s123Code.GDstartObjects2.length = 0;
gdjs.s123Code.GDBObjects1.length = 0;
gdjs.s123Code.GDBObjects2.length = 0;
gdjs.s123Code.GDblackObjects1.length = 0;
gdjs.s123Code.GDblackObjects2.length = 0;
gdjs.s123Code.GDAObjects1.length = 0;
gdjs.s123Code.GDAObjects2.length = 0;

gdjs.s123Code.eventsList0(runtimeScene);
return;

}

gdjs['s123Code'] = gdjs.s123Code;
