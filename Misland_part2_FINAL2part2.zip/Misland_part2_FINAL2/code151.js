gdjs.s134Code = {};
gdjs.s134Code.GDcaseObjects1= [];
gdjs.s134Code.GDcaseObjects2= [];
gdjs.s134Code.GDoffObjects1= [];
gdjs.s134Code.GDoffObjects2= [];
gdjs.s134Code.GDonObjects1= [];
gdjs.s134Code.GDonObjects2= [];
gdjs.s134Code.GDstartObjects1= [];
gdjs.s134Code.GDstartObjects2= [];
gdjs.s134Code.GDBObjects1= [];
gdjs.s134Code.GDBObjects2= [];
gdjs.s134Code.GDAObjects1= [];
gdjs.s134Code.GDAObjects2= [];
gdjs.s134Code.GDbugzObjects1= [];
gdjs.s134Code.GDbugzObjects2= [];
gdjs.s134Code.GDDOWNbuttonObjects1= [];
gdjs.s134Code.GDDOWNbuttonObjects2= [];
gdjs.s134Code.GDblackObjects1= [];
gdjs.s134Code.GDblackObjects2= [];
gdjs.s134Code.GDDOWNcol2Objects1= [];
gdjs.s134Code.GDDOWNcol2Objects2= [];
gdjs.s134Code.GDDOWNcolObjects1= [];
gdjs.s134Code.GDDOWNcolObjects2= [];
gdjs.s134Code.GDUPbuttonObjects1= [];
gdjs.s134Code.GDUPbuttonObjects2= [];
gdjs.s134Code.GDUPcolObjects1= [];
gdjs.s134Code.GDUPcolObjects2= [];
gdjs.s134Code.GDLbuttonObjects1= [];
gdjs.s134Code.GDLbuttonObjects2= [];
gdjs.s134Code.GDLcolObjects1= [];
gdjs.s134Code.GDLcolObjects2= [];
gdjs.s134Code.GDRbuttonObjects1= [];
gdjs.s134Code.GDRbuttonObjects2= [];
gdjs.s134Code.GDTALK3Objects1= [];
gdjs.s134Code.GDTALK3Objects2= [];
gdjs.s134Code.GDdeathObjects1= [];
gdjs.s134Code.GDdeathObjects2= [];
gdjs.s134Code.GDExitObjects1= [];
gdjs.s134Code.GDExitObjects2= [];
gdjs.s134Code.GDRcolObjects1= [];
gdjs.s134Code.GDRcolObjects2= [];
gdjs.s134Code.GDchapter4Objects1= [];
gdjs.s134Code.GDchapter4Objects2= [];
gdjs.s134Code.GDchapter3Objects1= [];
gdjs.s134Code.GDchapter3Objects2= [];
gdjs.s134Code.GDchapter2Objects1= [];
gdjs.s134Code.GDchapter2Objects2= [];
gdjs.s134Code.GDchapter1Objects1= [];
gdjs.s134Code.GDchapter1Objects2= [];
gdjs.s134Code.GDBGObjects1= [];
gdjs.s134Code.GDBGObjects2= [];

gdjs.s134Code.conditionTrue_0 = {val:false};
gdjs.s134Code.condition0IsTrue_0 = {val:false};
gdjs.s134Code.condition1IsTrue_0 = {val:false};
gdjs.s134Code.condition2IsTrue_0 = {val:false};


gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s134Code.GDDOWNbuttonObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s134Code.GDUPbuttonObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s134Code.GDRbuttonObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s134Code.GDLbuttonObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s134Code.GDbugzObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s134Code.GDRcolObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s134Code.GDbugzObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s134Code.GDLcolObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s134Code.GDbugzObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s134Code.GDUPcolObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s134Code.GDbugzObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s134Code.GDDOWNcolObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s134Code.GDbugzObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s134Code.GDDOWNcolObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s134Code.GDbugzObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDDOWNcol2Objects1Objects = Hashtable.newFrom({"DOWNcol2": gdjs.s134Code.GDDOWNcol2Objects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s134Code.GDBObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s134Code.GDAObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s134Code.GDoffObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s134Code.GDonObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s134Code.GDbugzObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s134Code.GDExitObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s134Code.GDbugzObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDdeathObjects1Objects = Hashtable.newFrom({"death": gdjs.s134Code.GDdeathObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s134Code.GDbugzObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDTALK3Objects1Objects = Hashtable.newFrom({"TALK3": gdjs.s134Code.GDTALK3Objects1});gdjs.s134Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s134Code.GDDOWNbuttonObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
gdjs.s134Code.condition1IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s134Code.condition0IsTrue_0.val ) {
{
gdjs.s134Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s134Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s134Code.GDUPbuttonObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
gdjs.s134Code.condition1IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s134Code.condition0IsTrue_0.val ) {
{
gdjs.s134Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s134Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s134Code.GDRbuttonObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
gdjs.s134Code.condition1IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s134Code.condition0IsTrue_0.val ) {
{
gdjs.s134Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s134Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s134Code.GDLbuttonObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
gdjs.s134Code.condition1IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s134Code.condition0IsTrue_0.val ) {
{
gdjs.s134Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s134Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s134Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s134Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects, gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s134Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s134Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects, gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s134Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s134Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects, gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s134Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s134Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects, gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s134Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s134Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects, gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol2"), gdjs.s134Code.GDDOWNcol2Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects, gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDDOWNcol2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s134Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].setDirectionOrAngle(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s134Code.GDBObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s134Code.GDAObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s134Code.GDoffObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s134Code.GDonObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s134Code.condition0IsTrue_0.val = false;
gdjs.s134Code.condition1IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s134Code.condition0IsTrue_0.val ) {
{
gdjs.s134Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s134Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s134Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s134Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s134Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s134Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s134Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s134Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s134Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects, gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s135", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s134Code.GDdeathObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects, gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDdeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s132", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK3"), gdjs.s134Code.GDTALK3Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDbugzObjects1Objects, gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDTALK3Objects1Objects, false, runtimeScene, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s95", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s134Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s134Code.GDbugzObjects1.length !== 0 ? gdjs.s134Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s134Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s134Code.GDcaseObjects1.length = 0;
gdjs.s134Code.GDcaseObjects2.length = 0;
gdjs.s134Code.GDoffObjects1.length = 0;
gdjs.s134Code.GDoffObjects2.length = 0;
gdjs.s134Code.GDonObjects1.length = 0;
gdjs.s134Code.GDonObjects2.length = 0;
gdjs.s134Code.GDstartObjects1.length = 0;
gdjs.s134Code.GDstartObjects2.length = 0;
gdjs.s134Code.GDBObjects1.length = 0;
gdjs.s134Code.GDBObjects2.length = 0;
gdjs.s134Code.GDAObjects1.length = 0;
gdjs.s134Code.GDAObjects2.length = 0;
gdjs.s134Code.GDbugzObjects1.length = 0;
gdjs.s134Code.GDbugzObjects2.length = 0;
gdjs.s134Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s134Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s134Code.GDblackObjects1.length = 0;
gdjs.s134Code.GDblackObjects2.length = 0;
gdjs.s134Code.GDDOWNcol2Objects1.length = 0;
gdjs.s134Code.GDDOWNcol2Objects2.length = 0;
gdjs.s134Code.GDDOWNcolObjects1.length = 0;
gdjs.s134Code.GDDOWNcolObjects2.length = 0;
gdjs.s134Code.GDUPbuttonObjects1.length = 0;
gdjs.s134Code.GDUPbuttonObjects2.length = 0;
gdjs.s134Code.GDUPcolObjects1.length = 0;
gdjs.s134Code.GDUPcolObjects2.length = 0;
gdjs.s134Code.GDLbuttonObjects1.length = 0;
gdjs.s134Code.GDLbuttonObjects2.length = 0;
gdjs.s134Code.GDLcolObjects1.length = 0;
gdjs.s134Code.GDLcolObjects2.length = 0;
gdjs.s134Code.GDRbuttonObjects1.length = 0;
gdjs.s134Code.GDRbuttonObjects2.length = 0;
gdjs.s134Code.GDTALK3Objects1.length = 0;
gdjs.s134Code.GDTALK3Objects2.length = 0;
gdjs.s134Code.GDdeathObjects1.length = 0;
gdjs.s134Code.GDdeathObjects2.length = 0;
gdjs.s134Code.GDExitObjects1.length = 0;
gdjs.s134Code.GDExitObjects2.length = 0;
gdjs.s134Code.GDRcolObjects1.length = 0;
gdjs.s134Code.GDRcolObjects2.length = 0;
gdjs.s134Code.GDchapter4Objects1.length = 0;
gdjs.s134Code.GDchapter4Objects2.length = 0;
gdjs.s134Code.GDchapter3Objects1.length = 0;
gdjs.s134Code.GDchapter3Objects2.length = 0;
gdjs.s134Code.GDchapter2Objects1.length = 0;
gdjs.s134Code.GDchapter2Objects2.length = 0;
gdjs.s134Code.GDchapter1Objects1.length = 0;
gdjs.s134Code.GDchapter1Objects2.length = 0;
gdjs.s134Code.GDBGObjects1.length = 0;
gdjs.s134Code.GDBGObjects2.length = 0;

gdjs.s134Code.eventsList0(runtimeScene);
return;

}

gdjs['s134Code'] = gdjs.s134Code;
