gdjs.s334Code = {};
gdjs.s334Code.GDcaseObjects1= [];
gdjs.s334Code.GDcaseObjects2= [];
gdjs.s334Code.GDimageObjects1= [];
gdjs.s334Code.GDimageObjects2= [];
gdjs.s334Code.GDoffObjects1= [];
gdjs.s334Code.GDoffObjects2= [];
gdjs.s334Code.GDonObjects1= [];
gdjs.s334Code.GDonObjects2= [];
gdjs.s334Code.GDstartObjects1= [];
gdjs.s334Code.GDstartObjects2= [];
gdjs.s334Code.GDBObjects1= [];
gdjs.s334Code.GDBObjects2= [];
gdjs.s334Code.GDblackObjects1= [];
gdjs.s334Code.GDblackObjects2= [];
gdjs.s334Code.GDAObjects1= [];
gdjs.s334Code.GDAObjects2= [];

gdjs.s334Code.conditionTrue_0 = {val:false};
gdjs.s334Code.condition0IsTrue_0 = {val:false};
gdjs.s334Code.condition1IsTrue_0 = {val:false};


gdjs.s334Code.mapOfGDgdjs_46s334Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s334Code.GDoffObjects1});gdjs.s334Code.mapOfGDgdjs_46s334Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s334Code.GDonObjects1});gdjs.s334Code.mapOfGDgdjs_46s334Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s334Code.GDAObjects1});gdjs.s334Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s334Code.GDoffObjects1);

gdjs.s334Code.condition0IsTrue_0.val = false;
{
gdjs.s334Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s334Code.mapOfGDgdjs_46s334Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s334Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s334Code.GDonObjects1);

gdjs.s334Code.condition0IsTrue_0.val = false;
{
gdjs.s334Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s334Code.mapOfGDgdjs_46s334Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s334Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s334Code.condition0IsTrue_0.val = false;
{
gdjs.s334Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s334Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s335", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s334Code.GDAObjects1);

gdjs.s334Code.condition0IsTrue_0.val = false;
{
gdjs.s334Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s334Code.mapOfGDgdjs_46s334Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s334Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s335", false);
}}

}


{


{
}

}


};

gdjs.s334Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s334Code.GDcaseObjects1.length = 0;
gdjs.s334Code.GDcaseObjects2.length = 0;
gdjs.s334Code.GDimageObjects1.length = 0;
gdjs.s334Code.GDimageObjects2.length = 0;
gdjs.s334Code.GDoffObjects1.length = 0;
gdjs.s334Code.GDoffObjects2.length = 0;
gdjs.s334Code.GDonObjects1.length = 0;
gdjs.s334Code.GDonObjects2.length = 0;
gdjs.s334Code.GDstartObjects1.length = 0;
gdjs.s334Code.GDstartObjects2.length = 0;
gdjs.s334Code.GDBObjects1.length = 0;
gdjs.s334Code.GDBObjects2.length = 0;
gdjs.s334Code.GDblackObjects1.length = 0;
gdjs.s334Code.GDblackObjects2.length = 0;
gdjs.s334Code.GDAObjects1.length = 0;
gdjs.s334Code.GDAObjects2.length = 0;

gdjs.s334Code.eventsList0(runtimeScene);
return;

}

gdjs['s334Code'] = gdjs.s334Code;
