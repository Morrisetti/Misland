gdjs.s371Code = {};
gdjs.s371Code.GDcaseObjects1= [];
gdjs.s371Code.GDcaseObjects2= [];
gdjs.s371Code.GDimageObjects1= [];
gdjs.s371Code.GDimageObjects2= [];
gdjs.s371Code.GDoffObjects1= [];
gdjs.s371Code.GDoffObjects2= [];
gdjs.s371Code.GDonObjects1= [];
gdjs.s371Code.GDonObjects2= [];
gdjs.s371Code.GDstartObjects1= [];
gdjs.s371Code.GDstartObjects2= [];
gdjs.s371Code.GDBObjects1= [];
gdjs.s371Code.GDBObjects2= [];
gdjs.s371Code.GDblackObjects1= [];
gdjs.s371Code.GDblackObjects2= [];
gdjs.s371Code.GDAObjects1= [];
gdjs.s371Code.GDAObjects2= [];

gdjs.s371Code.conditionTrue_0 = {val:false};
gdjs.s371Code.condition0IsTrue_0 = {val:false};
gdjs.s371Code.condition1IsTrue_0 = {val:false};
gdjs.s371Code.conditionTrue_1 = {val:false};
gdjs.s371Code.condition0IsTrue_1 = {val:false};
gdjs.s371Code.condition1IsTrue_1 = {val:false};


gdjs.s371Code.mapOfGDgdjs_46s371Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s371Code.GDoffObjects1});gdjs.s371Code.mapOfGDgdjs_46s371Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s371Code.GDonObjects1});gdjs.s371Code.mapOfGDgdjs_46s371Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s371Code.GDAObjects1});gdjs.s371Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s371Code.condition0IsTrue_0.val = false;
{
{gdjs.s371Code.conditionTrue_1 = gdjs.s371Code.condition0IsTrue_0;
gdjs.s371Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(94861900);
}
}if (gdjs.s371Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Part 2\\NEW ITEMSV3\\chpater9_v2.mp3", true, 100, 1);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s371Code.GDoffObjects1);

gdjs.s371Code.condition0IsTrue_0.val = false;
{
gdjs.s371Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s371Code.mapOfGDgdjs_46s371Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s371Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s371Code.GDonObjects1);

gdjs.s371Code.condition0IsTrue_0.val = false;
{
gdjs.s371Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s371Code.mapOfGDgdjs_46s371Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s371Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s371Code.condition0IsTrue_0.val = false;
{
gdjs.s371Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s371Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s372", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s371Code.GDAObjects1);

gdjs.s371Code.condition0IsTrue_0.val = false;
{
gdjs.s371Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s371Code.mapOfGDgdjs_46s371Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s371Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s372", false);
}}

}


{


{
}

}


};

gdjs.s371Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s371Code.GDcaseObjects1.length = 0;
gdjs.s371Code.GDcaseObjects2.length = 0;
gdjs.s371Code.GDimageObjects1.length = 0;
gdjs.s371Code.GDimageObjects2.length = 0;
gdjs.s371Code.GDoffObjects1.length = 0;
gdjs.s371Code.GDoffObjects2.length = 0;
gdjs.s371Code.GDonObjects1.length = 0;
gdjs.s371Code.GDonObjects2.length = 0;
gdjs.s371Code.GDstartObjects1.length = 0;
gdjs.s371Code.GDstartObjects2.length = 0;
gdjs.s371Code.GDBObjects1.length = 0;
gdjs.s371Code.GDBObjects2.length = 0;
gdjs.s371Code.GDblackObjects1.length = 0;
gdjs.s371Code.GDblackObjects2.length = 0;
gdjs.s371Code.GDAObjects1.length = 0;
gdjs.s371Code.GDAObjects2.length = 0;

gdjs.s371Code.eventsList0(runtimeScene);
return;

}

gdjs['s371Code'] = gdjs.s371Code;
