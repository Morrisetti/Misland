gdjs.s238Code = {};
gdjs.s238Code.GDcaseObjects1= [];
gdjs.s238Code.GDcaseObjects2= [];
gdjs.s238Code.GDoffObjects1= [];
gdjs.s238Code.GDoffObjects2= [];
gdjs.s238Code.GDonObjects1= [];
gdjs.s238Code.GDonObjects2= [];
gdjs.s238Code.GDstartObjects1= [];
gdjs.s238Code.GDstartObjects2= [];
gdjs.s238Code.GDBObjects1= [];
gdjs.s238Code.GDBObjects2= [];
gdjs.s238Code.GDAObjects1= [];
gdjs.s238Code.GDAObjects2= [];
gdjs.s238Code.GDbugzObjects1= [];
gdjs.s238Code.GDbugzObjects2= [];
gdjs.s238Code.GDDOWNbuttonObjects1= [];
gdjs.s238Code.GDDOWNbuttonObjects2= [];
gdjs.s238Code.GDblackObjects1= [];
gdjs.s238Code.GDblackObjects2= [];
gdjs.s238Code.GDDOWNcolObjects1= [];
gdjs.s238Code.GDDOWNcolObjects2= [];
gdjs.s238Code.GDUPbuttonObjects1= [];
gdjs.s238Code.GDUPbuttonObjects2= [];
gdjs.s238Code.GDUPcolObjects1= [];
gdjs.s238Code.GDUPcolObjects2= [];
gdjs.s238Code.GDLbuttonObjects1= [];
gdjs.s238Code.GDLbuttonObjects2= [];
gdjs.s238Code.GDLcolObjects1= [];
gdjs.s238Code.GDLcolObjects2= [];
gdjs.s238Code.GDRbuttonObjects1= [];
gdjs.s238Code.GDRbuttonObjects2= [];
gdjs.s238Code.GDexitObjects1= [];
gdjs.s238Code.GDexitObjects2= [];
gdjs.s238Code.GDTALK2Objects1= [];
gdjs.s238Code.GDTALK2Objects2= [];
gdjs.s238Code.GDTALKObjects1= [];
gdjs.s238Code.GDTALKObjects2= [];
gdjs.s238Code.GDRcolObjects1= [];
gdjs.s238Code.GDRcolObjects2= [];
gdjs.s238Code.GDchapter4Objects1= [];
gdjs.s238Code.GDchapter4Objects2= [];
gdjs.s238Code.GDchapter3Objects1= [];
gdjs.s238Code.GDchapter3Objects2= [];
gdjs.s238Code.GDchapter2Objects1= [];
gdjs.s238Code.GDchapter2Objects2= [];
gdjs.s238Code.GDchapter1Objects1= [];
gdjs.s238Code.GDchapter1Objects2= [];
gdjs.s238Code.GDBGObjects1= [];
gdjs.s238Code.GDBGObjects2= [];

gdjs.s238Code.conditionTrue_0 = {val:false};
gdjs.s238Code.condition0IsTrue_0 = {val:false};
gdjs.s238Code.condition1IsTrue_0 = {val:false};
gdjs.s238Code.condition2IsTrue_0 = {val:false};


gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s238Code.GDDOWNbuttonObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s238Code.GDUPbuttonObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s238Code.GDRbuttonObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s238Code.GDLbuttonObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s238Code.GDbugzObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s238Code.GDRcolObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s238Code.GDbugzObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s238Code.GDLcolObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s238Code.GDbugzObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s238Code.GDUPcolObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s238Code.GDbugzObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s238Code.GDDOWNcolObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s238Code.GDbugzObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s238Code.GDDOWNcolObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s238Code.GDBObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s238Code.GDAObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s238Code.GDoffObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s238Code.GDonObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s238Code.GDbugzObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDTALKObjects1Objects = Hashtable.newFrom({"TALK": gdjs.s238Code.GDTALKObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s238Code.GDbugzObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.s238Code.GDexitObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s238Code.GDbugzObjects1});gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDTALK2Objects1Objects = Hashtable.newFrom({"TALK2": gdjs.s238Code.GDTALK2Objects1});gdjs.s238Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s238Code.GDDOWNbuttonObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
gdjs.s238Code.condition1IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s238Code.condition0IsTrue_0.val ) {
{
gdjs.s238Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s238Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s238Code.GDUPbuttonObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
gdjs.s238Code.condition1IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s238Code.condition0IsTrue_0.val ) {
{
gdjs.s238Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s238Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s238Code.GDRbuttonObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
gdjs.s238Code.condition1IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s238Code.condition0IsTrue_0.val ) {
{
gdjs.s238Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s238Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s238Code.GDLbuttonObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
gdjs.s238Code.condition1IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s238Code.condition0IsTrue_0.val ) {
{
gdjs.s238Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s238Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s238Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects, gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s238Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s238Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects, gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s238Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s238Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects, gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s238Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s238Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects, gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s238Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s238Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects, gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s238Code.GDBObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s238Code.GDAObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s238Code.GDoffObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s238Code.GDonObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s238Code.condition0IsTrue_0.val = false;
gdjs.s238Code.condition1IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s238Code.condition0IsTrue_0.val ) {
{
gdjs.s238Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s238Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s238Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s238Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s238Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s238Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s238Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s238Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK"), gdjs.s238Code.GDTALKObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects, gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDTALKObjects1Objects, false, runtimeScene, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s235", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.s238Code.GDexitObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects, gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDexitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s239", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK2"), gdjs.s238Code.GDTALK2Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);

gdjs.s238Code.condition0IsTrue_0.val = false;
{
gdjs.s238Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDbugzObjects1Objects, gdjs.s238Code.mapOfGDgdjs_46s238Code_46GDTALK2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s238Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s237", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s238Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s238Code.GDbugzObjects1.length !== 0 ? gdjs.s238Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s238Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s238Code.GDcaseObjects1.length = 0;
gdjs.s238Code.GDcaseObjects2.length = 0;
gdjs.s238Code.GDoffObjects1.length = 0;
gdjs.s238Code.GDoffObjects2.length = 0;
gdjs.s238Code.GDonObjects1.length = 0;
gdjs.s238Code.GDonObjects2.length = 0;
gdjs.s238Code.GDstartObjects1.length = 0;
gdjs.s238Code.GDstartObjects2.length = 0;
gdjs.s238Code.GDBObjects1.length = 0;
gdjs.s238Code.GDBObjects2.length = 0;
gdjs.s238Code.GDAObjects1.length = 0;
gdjs.s238Code.GDAObjects2.length = 0;
gdjs.s238Code.GDbugzObjects1.length = 0;
gdjs.s238Code.GDbugzObjects2.length = 0;
gdjs.s238Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s238Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s238Code.GDblackObjects1.length = 0;
gdjs.s238Code.GDblackObjects2.length = 0;
gdjs.s238Code.GDDOWNcolObjects1.length = 0;
gdjs.s238Code.GDDOWNcolObjects2.length = 0;
gdjs.s238Code.GDUPbuttonObjects1.length = 0;
gdjs.s238Code.GDUPbuttonObjects2.length = 0;
gdjs.s238Code.GDUPcolObjects1.length = 0;
gdjs.s238Code.GDUPcolObjects2.length = 0;
gdjs.s238Code.GDLbuttonObjects1.length = 0;
gdjs.s238Code.GDLbuttonObjects2.length = 0;
gdjs.s238Code.GDLcolObjects1.length = 0;
gdjs.s238Code.GDLcolObjects2.length = 0;
gdjs.s238Code.GDRbuttonObjects1.length = 0;
gdjs.s238Code.GDRbuttonObjects2.length = 0;
gdjs.s238Code.GDexitObjects1.length = 0;
gdjs.s238Code.GDexitObjects2.length = 0;
gdjs.s238Code.GDTALK2Objects1.length = 0;
gdjs.s238Code.GDTALK2Objects2.length = 0;
gdjs.s238Code.GDTALKObjects1.length = 0;
gdjs.s238Code.GDTALKObjects2.length = 0;
gdjs.s238Code.GDRcolObjects1.length = 0;
gdjs.s238Code.GDRcolObjects2.length = 0;
gdjs.s238Code.GDchapter4Objects1.length = 0;
gdjs.s238Code.GDchapter4Objects2.length = 0;
gdjs.s238Code.GDchapter3Objects1.length = 0;
gdjs.s238Code.GDchapter3Objects2.length = 0;
gdjs.s238Code.GDchapter2Objects1.length = 0;
gdjs.s238Code.GDchapter2Objects2.length = 0;
gdjs.s238Code.GDchapter1Objects1.length = 0;
gdjs.s238Code.GDchapter1Objects2.length = 0;
gdjs.s238Code.GDBGObjects1.length = 0;
gdjs.s238Code.GDBGObjects2.length = 0;

gdjs.s238Code.eventsList0(runtimeScene);
return;

}

gdjs['s238Code'] = gdjs.s238Code;
