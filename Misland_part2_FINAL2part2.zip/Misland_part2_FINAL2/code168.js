gdjs.s151Code = {};
gdjs.s151Code.GDcaseObjects1= [];
gdjs.s151Code.GDcaseObjects2= [];
gdjs.s151Code.GDimageObjects1= [];
gdjs.s151Code.GDimageObjects2= [];
gdjs.s151Code.GDoffObjects1= [];
gdjs.s151Code.GDoffObjects2= [];
gdjs.s151Code.GDonObjects1= [];
gdjs.s151Code.GDonObjects2= [];
gdjs.s151Code.GDstartObjects1= [];
gdjs.s151Code.GDstartObjects2= [];
gdjs.s151Code.GDBObjects1= [];
gdjs.s151Code.GDBObjects2= [];
gdjs.s151Code.GDblackObjects1= [];
gdjs.s151Code.GDblackObjects2= [];
gdjs.s151Code.GDAObjects1= [];
gdjs.s151Code.GDAObjects2= [];

gdjs.s151Code.conditionTrue_0 = {val:false};
gdjs.s151Code.condition0IsTrue_0 = {val:false};
gdjs.s151Code.condition1IsTrue_0 = {val:false};


gdjs.s151Code.mapOfGDgdjs_46s151Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s151Code.GDstartObjects1});gdjs.s151Code.mapOfGDgdjs_46s151Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s151Code.GDoffObjects1});gdjs.s151Code.mapOfGDgdjs_46s151Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s151Code.GDonObjects1});gdjs.s151Code.mapOfGDgdjs_46s151Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s151Code.GDAObjects1});gdjs.s151Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s151Code.GDstartObjects1);

gdjs.s151Code.condition0IsTrue_0.val = false;
{
gdjs.s151Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s151Code.mapOfGDgdjs_46s151Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s151Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s151Code.GDoffObjects1);

gdjs.s151Code.condition0IsTrue_0.val = false;
{
gdjs.s151Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s151Code.mapOfGDgdjs_46s151Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s151Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s151Code.GDonObjects1);

gdjs.s151Code.condition0IsTrue_0.val = false;
{
gdjs.s151Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s151Code.mapOfGDgdjs_46s151Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s151Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s151Code.condition0IsTrue_0.val = false;
{
gdjs.s151Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s151Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s152", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s151Code.GDAObjects1);

gdjs.s151Code.condition0IsTrue_0.val = false;
{
gdjs.s151Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s151Code.mapOfGDgdjs_46s151Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s151Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s152", false);
}}

}


{


{
}

}


};

gdjs.s151Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s151Code.GDcaseObjects1.length = 0;
gdjs.s151Code.GDcaseObjects2.length = 0;
gdjs.s151Code.GDimageObjects1.length = 0;
gdjs.s151Code.GDimageObjects2.length = 0;
gdjs.s151Code.GDoffObjects1.length = 0;
gdjs.s151Code.GDoffObjects2.length = 0;
gdjs.s151Code.GDonObjects1.length = 0;
gdjs.s151Code.GDonObjects2.length = 0;
gdjs.s151Code.GDstartObjects1.length = 0;
gdjs.s151Code.GDstartObjects2.length = 0;
gdjs.s151Code.GDBObjects1.length = 0;
gdjs.s151Code.GDBObjects2.length = 0;
gdjs.s151Code.GDblackObjects1.length = 0;
gdjs.s151Code.GDblackObjects2.length = 0;
gdjs.s151Code.GDAObjects1.length = 0;
gdjs.s151Code.GDAObjects2.length = 0;

gdjs.s151Code.eventsList0(runtimeScene);
return;

}

gdjs['s151Code'] = gdjs.s151Code;
