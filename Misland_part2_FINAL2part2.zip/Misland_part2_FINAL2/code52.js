gdjs.s43Code = {};
gdjs.s43Code.GDcaseObjects1= [];
gdjs.s43Code.GDcaseObjects2= [];
gdjs.s43Code.GDimageObjects1= [];
gdjs.s43Code.GDimageObjects2= [];
gdjs.s43Code.GDoffObjects1= [];
gdjs.s43Code.GDoffObjects2= [];
gdjs.s43Code.GDonObjects1= [];
gdjs.s43Code.GDonObjects2= [];
gdjs.s43Code.GDstartObjects1= [];
gdjs.s43Code.GDstartObjects2= [];
gdjs.s43Code.GDBObjects1= [];
gdjs.s43Code.GDBObjects2= [];
gdjs.s43Code.GDblackObjects1= [];
gdjs.s43Code.GDblackObjects2= [];
gdjs.s43Code.GDAObjects1= [];
gdjs.s43Code.GDAObjects2= [];

gdjs.s43Code.conditionTrue_0 = {val:false};
gdjs.s43Code.condition0IsTrue_0 = {val:false};
gdjs.s43Code.condition1IsTrue_0 = {val:false};


gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s43Code.GDstartObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s43Code.GDoffObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s43Code.GDonObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s43Code.GDAObjects1});gdjs.s43Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s43Code.GDstartObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s43Code.GDoffObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s43Code.GDonObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s43Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s44", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s43Code.GDAObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s44", false);
}}

}


{


{
}

}


};

gdjs.s43Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s43Code.GDcaseObjects1.length = 0;
gdjs.s43Code.GDcaseObjects2.length = 0;
gdjs.s43Code.GDimageObjects1.length = 0;
gdjs.s43Code.GDimageObjects2.length = 0;
gdjs.s43Code.GDoffObjects1.length = 0;
gdjs.s43Code.GDoffObjects2.length = 0;
gdjs.s43Code.GDonObjects1.length = 0;
gdjs.s43Code.GDonObjects2.length = 0;
gdjs.s43Code.GDstartObjects1.length = 0;
gdjs.s43Code.GDstartObjects2.length = 0;
gdjs.s43Code.GDBObjects1.length = 0;
gdjs.s43Code.GDBObjects2.length = 0;
gdjs.s43Code.GDblackObjects1.length = 0;
gdjs.s43Code.GDblackObjects2.length = 0;
gdjs.s43Code.GDAObjects1.length = 0;
gdjs.s43Code.GDAObjects2.length = 0;

gdjs.s43Code.eventsList0(runtimeScene);
return;

}

gdjs['s43Code'] = gdjs.s43Code;
