gdjs.s141Code = {};
gdjs.s141Code.GDcaseObjects1= [];
gdjs.s141Code.GDcaseObjects2= [];
gdjs.s141Code.GDimageObjects1= [];
gdjs.s141Code.GDimageObjects2= [];
gdjs.s141Code.GDoffObjects1= [];
gdjs.s141Code.GDoffObjects2= [];
gdjs.s141Code.GDonObjects1= [];
gdjs.s141Code.GDonObjects2= [];
gdjs.s141Code.GDstartObjects1= [];
gdjs.s141Code.GDstartObjects2= [];
gdjs.s141Code.GDBObjects1= [];
gdjs.s141Code.GDBObjects2= [];
gdjs.s141Code.GDblackObjects1= [];
gdjs.s141Code.GDblackObjects2= [];
gdjs.s141Code.GDAObjects1= [];
gdjs.s141Code.GDAObjects2= [];

gdjs.s141Code.conditionTrue_0 = {val:false};
gdjs.s141Code.condition0IsTrue_0 = {val:false};
gdjs.s141Code.condition1IsTrue_0 = {val:false};
gdjs.s141Code.conditionTrue_1 = {val:false};
gdjs.s141Code.condition0IsTrue_1 = {val:false};
gdjs.s141Code.condition1IsTrue_1 = {val:false};


gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s141Code.GDstartObjects1});gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s141Code.GDoffObjects1});gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s141Code.GDonObjects1});gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s141Code.GDAObjects1});gdjs.s141Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s141Code.condition0IsTrue_0.val = false;
{
{gdjs.s141Code.conditionTrue_1 = gdjs.s141Code.condition0IsTrue_0;
gdjs.s141Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(89758092);
}
}if (gdjs.s141Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter5_v3.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s141Code.GDstartObjects1);

gdjs.s141Code.condition0IsTrue_0.val = false;
{
gdjs.s141Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s141Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s141Code.GDoffObjects1);

gdjs.s141Code.condition0IsTrue_0.val = false;
{
gdjs.s141Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s141Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s141Code.GDonObjects1);

gdjs.s141Code.condition0IsTrue_0.val = false;
{
gdjs.s141Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s141Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s141Code.condition0IsTrue_0.val = false;
{
gdjs.s141Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s141Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s142", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s141Code.GDAObjects1);

gdjs.s141Code.condition0IsTrue_0.val = false;
{
gdjs.s141Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s141Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s142", false);
}}

}


{


{
}

}


};

gdjs.s141Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s141Code.GDcaseObjects1.length = 0;
gdjs.s141Code.GDcaseObjects2.length = 0;
gdjs.s141Code.GDimageObjects1.length = 0;
gdjs.s141Code.GDimageObjects2.length = 0;
gdjs.s141Code.GDoffObjects1.length = 0;
gdjs.s141Code.GDoffObjects2.length = 0;
gdjs.s141Code.GDonObjects1.length = 0;
gdjs.s141Code.GDonObjects2.length = 0;
gdjs.s141Code.GDstartObjects1.length = 0;
gdjs.s141Code.GDstartObjects2.length = 0;
gdjs.s141Code.GDBObjects1.length = 0;
gdjs.s141Code.GDBObjects2.length = 0;
gdjs.s141Code.GDblackObjects1.length = 0;
gdjs.s141Code.GDblackObjects2.length = 0;
gdjs.s141Code.GDAObjects1.length = 0;
gdjs.s141Code.GDAObjects2.length = 0;

gdjs.s141Code.eventsList0(runtimeScene);
return;

}

gdjs['s141Code'] = gdjs.s141Code;
