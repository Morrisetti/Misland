gdjs.C8Code = {};
gdjs.C8Code.GDcaseObjects1= [];
gdjs.C8Code.GDcaseObjects2= [];
gdjs.C8Code.GDimageObjects1= [];
gdjs.C8Code.GDimageObjects2= [];
gdjs.C8Code.GDoffObjects1= [];
gdjs.C8Code.GDoffObjects2= [];
gdjs.C8Code.GDonObjects1= [];
gdjs.C8Code.GDonObjects2= [];
gdjs.C8Code.GDstartObjects1= [];
gdjs.C8Code.GDstartObjects2= [];
gdjs.C8Code.GDBObjects1= [];
gdjs.C8Code.GDBObjects2= [];
gdjs.C8Code.GDblackObjects1= [];
gdjs.C8Code.GDblackObjects2= [];
gdjs.C8Code.GDAObjects1= [];
gdjs.C8Code.GDAObjects2= [];

gdjs.C8Code.conditionTrue_0 = {val:false};
gdjs.C8Code.condition0IsTrue_0 = {val:false};
gdjs.C8Code.condition1IsTrue_0 = {val:false};
gdjs.C8Code.conditionTrue_1 = {val:false};
gdjs.C8Code.condition0IsTrue_1 = {val:false};
gdjs.C8Code.condition1IsTrue_1 = {val:false};


gdjs.C8Code.mapOfGDgdjs_46C8Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.C8Code.GDstartObjects1});gdjs.C8Code.mapOfGDgdjs_46C8Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.C8Code.GDoffObjects1});gdjs.C8Code.mapOfGDgdjs_46C8Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.C8Code.GDonObjects1});gdjs.C8Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.C8Code.condition0IsTrue_0.val = false;
{
{gdjs.C8Code.conditionTrue_1 = gdjs.C8Code.condition0IsTrue_0;
gdjs.C8Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(92489172);
}
}if (gdjs.C8Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter5_v6.mp3", true, 80, 1);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.C8Code.GDstartObjects1);

gdjs.C8Code.condition0IsTrue_0.val = false;
{
gdjs.C8Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C8Code.mapOfGDgdjs_46C8Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.C8Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s262", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.C8Code.GDoffObjects1);

gdjs.C8Code.condition0IsTrue_0.val = false;
{
gdjs.C8Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C8Code.mapOfGDgdjs_46C8Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.C8Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.C8Code.GDonObjects1);

gdjs.C8Code.condition0IsTrue_0.val = false;
{
gdjs.C8Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C8Code.mapOfGDgdjs_46C8Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.C8Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.C8Code.condition0IsTrue_0.val = false;
{
gdjs.C8Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.C8Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s262", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.C8Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.C8Code.GDcaseObjects1.length = 0;
gdjs.C8Code.GDcaseObjects2.length = 0;
gdjs.C8Code.GDimageObjects1.length = 0;
gdjs.C8Code.GDimageObjects2.length = 0;
gdjs.C8Code.GDoffObjects1.length = 0;
gdjs.C8Code.GDoffObjects2.length = 0;
gdjs.C8Code.GDonObjects1.length = 0;
gdjs.C8Code.GDonObjects2.length = 0;
gdjs.C8Code.GDstartObjects1.length = 0;
gdjs.C8Code.GDstartObjects2.length = 0;
gdjs.C8Code.GDBObjects1.length = 0;
gdjs.C8Code.GDBObjects2.length = 0;
gdjs.C8Code.GDblackObjects1.length = 0;
gdjs.C8Code.GDblackObjects2.length = 0;
gdjs.C8Code.GDAObjects1.length = 0;
gdjs.C8Code.GDAObjects2.length = 0;

gdjs.C8Code.eventsList0(runtimeScene);
return;

}

gdjs['C8Code'] = gdjs.C8Code;
