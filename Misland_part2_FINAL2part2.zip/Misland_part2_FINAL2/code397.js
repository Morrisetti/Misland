gdjs.s354Code = {};
gdjs.s354Code.GDcaseObjects1= [];
gdjs.s354Code.GDcaseObjects2= [];
gdjs.s354Code.GDimageObjects1= [];
gdjs.s354Code.GDimageObjects2= [];
gdjs.s354Code.GDoffObjects1= [];
gdjs.s354Code.GDoffObjects2= [];
gdjs.s354Code.GDonObjects1= [];
gdjs.s354Code.GDonObjects2= [];
gdjs.s354Code.GDstartObjects1= [];
gdjs.s354Code.GDstartObjects2= [];
gdjs.s354Code.GDBObjects1= [];
gdjs.s354Code.GDBObjects2= [];
gdjs.s354Code.GDAObjects1= [];
gdjs.s354Code.GDAObjects2= [];
gdjs.s354Code.GDcrosshairsObjects1= [];
gdjs.s354Code.GDcrosshairsObjects2= [];
gdjs.s354Code.GDDOWNbuttonObjects1= [];
gdjs.s354Code.GDDOWNbuttonObjects2= [];
gdjs.s354Code.GDDOWNcolObjects1= [];
gdjs.s354Code.GDDOWNcolObjects2= [];
gdjs.s354Code.GDUPbuttonObjects1= [];
gdjs.s354Code.GDUPbuttonObjects2= [];
gdjs.s354Code.GDUPcolObjects1= [];
gdjs.s354Code.GDUPcolObjects2= [];
gdjs.s354Code.GDLbuttonObjects1= [];
gdjs.s354Code.GDLbuttonObjects2= [];
gdjs.s354Code.GDLcolObjects1= [];
gdjs.s354Code.GDLcolObjects2= [];
gdjs.s354Code.GDRbuttonObjects1= [];
gdjs.s354Code.GDRbuttonObjects2= [];
gdjs.s354Code.GDRcolObjects1= [];
gdjs.s354Code.GDRcolObjects2= [];
gdjs.s354Code.GDchapter4Objects1= [];
gdjs.s354Code.GDchapter4Objects2= [];
gdjs.s354Code.GDchapter3Objects1= [];
gdjs.s354Code.GDchapter3Objects2= [];
gdjs.s354Code.GDchapter2Objects1= [];
gdjs.s354Code.GDchapter2Objects2= [];
gdjs.s354Code.GDblackObjects1= [];
gdjs.s354Code.GDblackObjects2= [];
gdjs.s354Code.GDchapter1Objects1= [];
gdjs.s354Code.GDchapter1Objects2= [];

gdjs.s354Code.conditionTrue_0 = {val:false};
gdjs.s354Code.condition0IsTrue_0 = {val:false};
gdjs.s354Code.condition1IsTrue_0 = {val:false};
gdjs.s354Code.condition2IsTrue_0 = {val:false};


gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s354Code.GDDOWNbuttonObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s354Code.GDUPbuttonObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s354Code.GDRbuttonObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s354Code.GDLbuttonObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s354Code.GDcrosshairsObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s354Code.GDRcolObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s354Code.GDcrosshairsObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s354Code.GDLcolObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s354Code.GDcrosshairsObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s354Code.GDUPcolObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s354Code.GDcrosshairsObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s354Code.GDDOWNcolObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s354Code.GDcrosshairsObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s354Code.GDDOWNcolObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s354Code.GDoffObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s354Code.GDonObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s354Code.GDcrosshairsObjects1});gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s354Code.GDchapter1Objects1});gdjs.s354Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s354Code.GDDOWNbuttonObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
gdjs.s354Code.condition1IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s354Code.condition0IsTrue_0.val ) {
{
gdjs.s354Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s354Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s354Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s354Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s354Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s354Code.GDUPbuttonObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
gdjs.s354Code.condition1IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s354Code.condition0IsTrue_0.val ) {
{
gdjs.s354Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s354Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s354Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s354Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s354Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s354Code.GDRbuttonObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
gdjs.s354Code.condition1IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s354Code.condition0IsTrue_0.val ) {
{
gdjs.s354Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s354Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s354Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s354Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s354Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s354Code.GDLbuttonObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
gdjs.s354Code.condition1IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s354Code.condition0IsTrue_0.val ) {
{
gdjs.s354Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s354Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s354Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s354Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s354Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s354Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s354Code.GDcrosshairsObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects, gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s354Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s354Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s354Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s354Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s354Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s354Code.GDcrosshairsObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects, gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s354Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s354Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s354Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s354Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s354Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s354Code.GDcrosshairsObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects, gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s354Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s354Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s354Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s354Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s354Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s354Code.GDcrosshairsObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects, gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s354Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s354Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s354Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s354Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s354Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s354Code.GDcrosshairsObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects, gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s354Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s354Code.GDoffObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s354Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s354Code.GDonObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s354Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s354Code.GDstartObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s354Code.GDstartObjects1.length;i<l;++i) {
    if ( gdjs.s354Code.GDstartObjects1[i].timerElapsedTime("", 2) ) {
        gdjs.s354Code.condition0IsTrue_0.val = true;
        gdjs.s354Code.GDstartObjects1[k] = gdjs.s354Code.GDstartObjects1[i];
        ++k;
    }
}
gdjs.s354Code.GDstartObjects1.length = k;}if (gdjs.s354Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s343", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s354Code.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s354Code.GDcrosshairsObjects1);

gdjs.s354Code.condition0IsTrue_0.val = false;
gdjs.s354Code.condition1IsTrue_0.val = false;
{
gdjs.s354Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDcrosshairsObjects1Objects, gdjs.s354Code.mapOfGDgdjs_46s354Code_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s354Code.condition0IsTrue_0.val ) {
{
gdjs.s354Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s354Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s355", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s354Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s354Code.GDcaseObjects1.length = 0;
gdjs.s354Code.GDcaseObjects2.length = 0;
gdjs.s354Code.GDimageObjects1.length = 0;
gdjs.s354Code.GDimageObjects2.length = 0;
gdjs.s354Code.GDoffObjects1.length = 0;
gdjs.s354Code.GDoffObjects2.length = 0;
gdjs.s354Code.GDonObjects1.length = 0;
gdjs.s354Code.GDonObjects2.length = 0;
gdjs.s354Code.GDstartObjects1.length = 0;
gdjs.s354Code.GDstartObjects2.length = 0;
gdjs.s354Code.GDBObjects1.length = 0;
gdjs.s354Code.GDBObjects2.length = 0;
gdjs.s354Code.GDAObjects1.length = 0;
gdjs.s354Code.GDAObjects2.length = 0;
gdjs.s354Code.GDcrosshairsObjects1.length = 0;
gdjs.s354Code.GDcrosshairsObjects2.length = 0;
gdjs.s354Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s354Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s354Code.GDDOWNcolObjects1.length = 0;
gdjs.s354Code.GDDOWNcolObjects2.length = 0;
gdjs.s354Code.GDUPbuttonObjects1.length = 0;
gdjs.s354Code.GDUPbuttonObjects2.length = 0;
gdjs.s354Code.GDUPcolObjects1.length = 0;
gdjs.s354Code.GDUPcolObjects2.length = 0;
gdjs.s354Code.GDLbuttonObjects1.length = 0;
gdjs.s354Code.GDLbuttonObjects2.length = 0;
gdjs.s354Code.GDLcolObjects1.length = 0;
gdjs.s354Code.GDLcolObjects2.length = 0;
gdjs.s354Code.GDRbuttonObjects1.length = 0;
gdjs.s354Code.GDRbuttonObjects2.length = 0;
gdjs.s354Code.GDRcolObjects1.length = 0;
gdjs.s354Code.GDRcolObjects2.length = 0;
gdjs.s354Code.GDchapter4Objects1.length = 0;
gdjs.s354Code.GDchapter4Objects2.length = 0;
gdjs.s354Code.GDchapter3Objects1.length = 0;
gdjs.s354Code.GDchapter3Objects2.length = 0;
gdjs.s354Code.GDchapter2Objects1.length = 0;
gdjs.s354Code.GDchapter2Objects2.length = 0;
gdjs.s354Code.GDblackObjects1.length = 0;
gdjs.s354Code.GDblackObjects2.length = 0;
gdjs.s354Code.GDchapter1Objects1.length = 0;
gdjs.s354Code.GDchapter1Objects2.length = 0;

gdjs.s354Code.eventsList0(runtimeScene);
return;

}

gdjs['s354Code'] = gdjs.s354Code;
