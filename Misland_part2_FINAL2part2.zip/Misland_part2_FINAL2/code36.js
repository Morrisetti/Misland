gdjs.s29Code = {};
gdjs.s29Code.GDcaseObjects1= [];
gdjs.s29Code.GDcaseObjects2= [];
gdjs.s29Code.GDoffObjects1= [];
gdjs.s29Code.GDoffObjects2= [];
gdjs.s29Code.GDonObjects1= [];
gdjs.s29Code.GDonObjects2= [];
gdjs.s29Code.GDstartObjects1= [];
gdjs.s29Code.GDstartObjects2= [];
gdjs.s29Code.GDBObjects1= [];
gdjs.s29Code.GDBObjects2= [];
gdjs.s29Code.GDAObjects1= [];
gdjs.s29Code.GDAObjects2= [];
gdjs.s29Code.GDbugzObjects1= [];
gdjs.s29Code.GDbugzObjects2= [];
gdjs.s29Code.GDDOWNbuttonObjects1= [];
gdjs.s29Code.GDDOWNbuttonObjects2= [];
gdjs.s29Code.GDblackObjects1= [];
gdjs.s29Code.GDblackObjects2= [];
gdjs.s29Code.GDblockObjects1= [];
gdjs.s29Code.GDblockObjects2= [];
gdjs.s29Code.GDdeathObjects1= [];
gdjs.s29Code.GDdeathObjects2= [];
gdjs.s29Code.GDUPbuttonObjects1= [];
gdjs.s29Code.GDUPbuttonObjects2= [];
gdjs.s29Code.GDplatformObjects1= [];
gdjs.s29Code.GDplatformObjects2= [];
gdjs.s29Code.GDLbuttonObjects1= [];
gdjs.s29Code.GDLbuttonObjects2= [];
gdjs.s29Code.GDLcolObjects1= [];
gdjs.s29Code.GDLcolObjects2= [];
gdjs.s29Code.GDRbuttonObjects1= [];
gdjs.s29Code.GDRbuttonObjects2= [];
gdjs.s29Code.GDTALK2Objects1= [];
gdjs.s29Code.GDTALK2Objects2= [];
gdjs.s29Code.GDExitObjects1= [];
gdjs.s29Code.GDExitObjects2= [];
gdjs.s29Code.GDRcolObjects1= [];
gdjs.s29Code.GDRcolObjects2= [];
gdjs.s29Code.GDchapter4Objects1= [];
gdjs.s29Code.GDchapter4Objects2= [];
gdjs.s29Code.GDchapter3Objects1= [];
gdjs.s29Code.GDchapter3Objects2= [];
gdjs.s29Code.GDchapter2Objects1= [];
gdjs.s29Code.GDchapter2Objects2= [];
gdjs.s29Code.GDchapter1Objects1= [];
gdjs.s29Code.GDchapter1Objects2= [];
gdjs.s29Code.GDBGObjects1= [];
gdjs.s29Code.GDBGObjects2= [];

gdjs.s29Code.conditionTrue_0 = {val:false};
gdjs.s29Code.condition0IsTrue_0 = {val:false};
gdjs.s29Code.condition1IsTrue_0 = {val:false};
gdjs.s29Code.condition2IsTrue_0 = {val:false};
gdjs.s29Code.conditionTrue_1 = {val:false};
gdjs.s29Code.condition0IsTrue_1 = {val:false};
gdjs.s29Code.condition1IsTrue_1 = {val:false};
gdjs.s29Code.condition2IsTrue_1 = {val:false};


gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s29Code.GDDOWNbuttonObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s29Code.GDUPbuttonObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s29Code.GDRbuttonObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s29Code.GDLbuttonObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s29Code.GDbugzObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s29Code.GDRcolObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s29Code.GDbugzObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s29Code.GDLcolObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s29Code.GDbugzObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDplatformObjects1Objects = Hashtable.newFrom({"platform": gdjs.s29Code.GDplatformObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s29Code.GDbugzObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDdeathObjects1Objects = Hashtable.newFrom({"death": gdjs.s29Code.GDdeathObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s29Code.GDBObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s29Code.GDAObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s29Code.GDoffObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s29Code.GDonObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s29Code.GDbugzObjects1});gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s29Code.GDExitObjects1});gdjs.s29Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s29Code.GDDOWNbuttonObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
gdjs.s29Code.condition1IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s29Code.condition0IsTrue_0.val ) {
{
gdjs.s29Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s29Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s29Code.GDUPbuttonObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
gdjs.s29Code.condition1IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s29Code.condition0IsTrue_0.val ) {
{
gdjs.s29Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s29Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s29Code.GDRbuttonObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
gdjs.s29Code.condition1IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s29Code.condition0IsTrue_0.val ) {
{
gdjs.s29Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s29Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s29Code.GDLbuttonObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
gdjs.s29Code.condition1IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s29Code.condition0IsTrue_0.val ) {
{
gdjs.s29Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s29Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].flipX(true);
}
}{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}}

}


{


gdjs.s29Code.condition0IsTrue_0.val = false;
{
{gdjs.s29Code.conditionTrue_1 = gdjs.s29Code.condition0IsTrue_0;
gdjs.s29Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(86917468);
}
}if (gdjs.s29Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter8_v2.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s29Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDbugzObjects1Objects, gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s29Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s29Code.GDbugzObjects1 */
{}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s29Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDbugzObjects1Objects, gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s29Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s29Code.GDbugzObjects1 */
{}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("platform"), gdjs.s29Code.GDplatformObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDbugzObjects1Objects, gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDplatformObjects1Objects, false, runtimeScene, false);
}if (gdjs.s29Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s29Code.GDbugzObjects1 */
{}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s29Code.GDdeathObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDbugzObjects1Objects, gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDdeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s29Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s28.1", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s29Code.GDBObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s29Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s29Code.GDAObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
gdjs.s29Code.condition1IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDAObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s29Code.condition0IsTrue_0.val ) {
{
{gdjs.s29Code.conditionTrue_1 = gdjs.s29Code.condition1IsTrue_0;
gdjs.s29Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(86922076);
}
}}
if (gdjs.s29Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s29Code.GDoffObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s29Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s29Code.GDonObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s29Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s29Code.condition0IsTrue_0.val = false;
gdjs.s29Code.condition1IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s29Code.condition0IsTrue_0.val ) {
{
gdjs.s29Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s29Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s29Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s29Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);

gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDbugzObjects1Objects, gdjs.s29Code.mapOfGDgdjs_46s29Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s29Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s29.1", false);
}}

}


{


gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s29Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s29Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s29Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{


{
}

}


{


gdjs.s29Code.condition0IsTrue_0.val = false;
{
gdjs.s29Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s29Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s29Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s29Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s29Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s29Code.GDbugzObjects1.length !== 0 ? gdjs.s29Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s29Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s29Code.GDcaseObjects1.length = 0;
gdjs.s29Code.GDcaseObjects2.length = 0;
gdjs.s29Code.GDoffObjects1.length = 0;
gdjs.s29Code.GDoffObjects2.length = 0;
gdjs.s29Code.GDonObjects1.length = 0;
gdjs.s29Code.GDonObjects2.length = 0;
gdjs.s29Code.GDstartObjects1.length = 0;
gdjs.s29Code.GDstartObjects2.length = 0;
gdjs.s29Code.GDBObjects1.length = 0;
gdjs.s29Code.GDBObjects2.length = 0;
gdjs.s29Code.GDAObjects1.length = 0;
gdjs.s29Code.GDAObjects2.length = 0;
gdjs.s29Code.GDbugzObjects1.length = 0;
gdjs.s29Code.GDbugzObjects2.length = 0;
gdjs.s29Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s29Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s29Code.GDblackObjects1.length = 0;
gdjs.s29Code.GDblackObjects2.length = 0;
gdjs.s29Code.GDblockObjects1.length = 0;
gdjs.s29Code.GDblockObjects2.length = 0;
gdjs.s29Code.GDdeathObjects1.length = 0;
gdjs.s29Code.GDdeathObjects2.length = 0;
gdjs.s29Code.GDUPbuttonObjects1.length = 0;
gdjs.s29Code.GDUPbuttonObjects2.length = 0;
gdjs.s29Code.GDplatformObjects1.length = 0;
gdjs.s29Code.GDplatformObjects2.length = 0;
gdjs.s29Code.GDLbuttonObjects1.length = 0;
gdjs.s29Code.GDLbuttonObjects2.length = 0;
gdjs.s29Code.GDLcolObjects1.length = 0;
gdjs.s29Code.GDLcolObjects2.length = 0;
gdjs.s29Code.GDRbuttonObjects1.length = 0;
gdjs.s29Code.GDRbuttonObjects2.length = 0;
gdjs.s29Code.GDTALK2Objects1.length = 0;
gdjs.s29Code.GDTALK2Objects2.length = 0;
gdjs.s29Code.GDExitObjects1.length = 0;
gdjs.s29Code.GDExitObjects2.length = 0;
gdjs.s29Code.GDRcolObjects1.length = 0;
gdjs.s29Code.GDRcolObjects2.length = 0;
gdjs.s29Code.GDchapter4Objects1.length = 0;
gdjs.s29Code.GDchapter4Objects2.length = 0;
gdjs.s29Code.GDchapter3Objects1.length = 0;
gdjs.s29Code.GDchapter3Objects2.length = 0;
gdjs.s29Code.GDchapter2Objects1.length = 0;
gdjs.s29Code.GDchapter2Objects2.length = 0;
gdjs.s29Code.GDchapter1Objects1.length = 0;
gdjs.s29Code.GDchapter1Objects2.length = 0;
gdjs.s29Code.GDBGObjects1.length = 0;
gdjs.s29Code.GDBGObjects2.length = 0;

gdjs.s29Code.eventsList0(runtimeScene);
return;

}

gdjs['s29Code'] = gdjs.s29Code;
