gdjs.s290Code = {};
gdjs.s290Code.GDcaseObjects1= [];
gdjs.s290Code.GDcaseObjects2= [];
gdjs.s290Code.GDimageObjects1= [];
gdjs.s290Code.GDimageObjects2= [];
gdjs.s290Code.GDoffObjects1= [];
gdjs.s290Code.GDoffObjects2= [];
gdjs.s290Code.GDonObjects1= [];
gdjs.s290Code.GDonObjects2= [];
gdjs.s290Code.GDstartObjects1= [];
gdjs.s290Code.GDstartObjects2= [];
gdjs.s290Code.GDBObjects1= [];
gdjs.s290Code.GDBObjects2= [];
gdjs.s290Code.GDblackObjects1= [];
gdjs.s290Code.GDblackObjects2= [];
gdjs.s290Code.GDAObjects1= [];
gdjs.s290Code.GDAObjects2= [];
gdjs.s290Code.GDbuttonObjects1= [];
gdjs.s290Code.GDbuttonObjects2= [];

gdjs.s290Code.conditionTrue_0 = {val:false};
gdjs.s290Code.condition0IsTrue_0 = {val:false};
gdjs.s290Code.condition1IsTrue_0 = {val:false};
gdjs.s290Code.conditionTrue_1 = {val:false};
gdjs.s290Code.condition0IsTrue_1 = {val:false};
gdjs.s290Code.condition1IsTrue_1 = {val:false};


gdjs.s290Code.mapOfGDgdjs_46s290Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s290Code.GDbuttonObjects1});gdjs.s290Code.mapOfGDgdjs_46s290Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s290Code.GDoffObjects1});gdjs.s290Code.mapOfGDgdjs_46s290Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s290Code.GDonObjects1});gdjs.s290Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s290Code.GDcaseObjects1);

gdjs.s290Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s290Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s290Code.GDcaseObjects1[i].timerElapsedTime("", 0.5) ) {
        gdjs.s290Code.condition0IsTrue_0.val = true;
        gdjs.s290Code.GDcaseObjects1[k] = gdjs.s290Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s290Code.GDcaseObjects1.length = k;}if (gdjs.s290Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s291", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s290Code.GDbuttonObjects1);

gdjs.s290Code.condition0IsTrue_0.val = false;
{
gdjs.s290Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s290Code.mapOfGDgdjs_46s290Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s290Code.condition0IsTrue_0.val) {
}

}


{


gdjs.s290Code.condition0IsTrue_0.val = false;
{
{gdjs.s290Code.conditionTrue_1 = gdjs.s290Code.condition0IsTrue_0;
gdjs.s290Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(93026060);
}
}if (gdjs.s290Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "chapter_8_v3.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s290Code.GDoffObjects1);

gdjs.s290Code.condition0IsTrue_0.val = false;
{
gdjs.s290Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s290Code.mapOfGDgdjs_46s290Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s290Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s290Code.GDonObjects1);

gdjs.s290Code.condition0IsTrue_0.val = false;
{
gdjs.s290Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s290Code.mapOfGDgdjs_46s290Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s290Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s290Code.condition0IsTrue_0.val = false;
{
gdjs.s290Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s290Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


};

gdjs.s290Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s290Code.GDcaseObjects1.length = 0;
gdjs.s290Code.GDcaseObjects2.length = 0;
gdjs.s290Code.GDimageObjects1.length = 0;
gdjs.s290Code.GDimageObjects2.length = 0;
gdjs.s290Code.GDoffObjects1.length = 0;
gdjs.s290Code.GDoffObjects2.length = 0;
gdjs.s290Code.GDonObjects1.length = 0;
gdjs.s290Code.GDonObjects2.length = 0;
gdjs.s290Code.GDstartObjects1.length = 0;
gdjs.s290Code.GDstartObjects2.length = 0;
gdjs.s290Code.GDBObjects1.length = 0;
gdjs.s290Code.GDBObjects2.length = 0;
gdjs.s290Code.GDblackObjects1.length = 0;
gdjs.s290Code.GDblackObjects2.length = 0;
gdjs.s290Code.GDAObjects1.length = 0;
gdjs.s290Code.GDAObjects2.length = 0;
gdjs.s290Code.GDbuttonObjects1.length = 0;
gdjs.s290Code.GDbuttonObjects2.length = 0;

gdjs.s290Code.eventsList0(runtimeScene);
return;

}

gdjs['s290Code'] = gdjs.s290Code;
