gdjs.s372Code = {};
gdjs.s372Code.GDcaseObjects1= [];
gdjs.s372Code.GDcaseObjects2= [];
gdjs.s372Code.GDoffObjects1= [];
gdjs.s372Code.GDoffObjects2= [];
gdjs.s372Code.GDonObjects1= [];
gdjs.s372Code.GDonObjects2= [];
gdjs.s372Code.GDstartObjects1= [];
gdjs.s372Code.GDstartObjects2= [];
gdjs.s372Code.GDBObjects1= [];
gdjs.s372Code.GDBObjects2= [];
gdjs.s372Code.GDAObjects1= [];
gdjs.s372Code.GDAObjects2= [];
gdjs.s372Code.GDcarObjects1= [];
gdjs.s372Code.GDcarObjects2= [];
gdjs.s372Code.GDDOWNbuttonObjects1= [];
gdjs.s372Code.GDDOWNbuttonObjects2= [];
gdjs.s372Code.GDblackObjects1= [];
gdjs.s372Code.GDblackObjects2= [];
gdjs.s372Code.GDDOWNcol2Objects1= [];
gdjs.s372Code.GDDOWNcol2Objects2= [];
gdjs.s372Code.GDDOWNcolObjects1= [];
gdjs.s372Code.GDDOWNcolObjects2= [];
gdjs.s372Code.GDUPbuttonObjects1= [];
gdjs.s372Code.GDUPbuttonObjects2= [];
gdjs.s372Code.GDUPcolObjects1= [];
gdjs.s372Code.GDUPcolObjects2= [];
gdjs.s372Code.GDLbuttonObjects1= [];
gdjs.s372Code.GDLbuttonObjects2= [];
gdjs.s372Code.GDLcolObjects1= [];
gdjs.s372Code.GDLcolObjects2= [];
gdjs.s372Code.GDRbuttonObjects1= [];
gdjs.s372Code.GDRbuttonObjects2= [];
gdjs.s372Code.GDTALK3Objects1= [];
gdjs.s372Code.GDTALK3Objects2= [];
gdjs.s372Code.GDTALK2Objects1= [];
gdjs.s372Code.GDTALK2Objects2= [];
gdjs.s372Code.GDExitObjects1= [];
gdjs.s372Code.GDExitObjects2= [];
gdjs.s372Code.GDRcolObjects1= [];
gdjs.s372Code.GDRcolObjects2= [];
gdjs.s372Code.GDchapter4Objects1= [];
gdjs.s372Code.GDchapter4Objects2= [];
gdjs.s372Code.GDchapter3Objects1= [];
gdjs.s372Code.GDchapter3Objects2= [];
gdjs.s372Code.GDchapter2Objects1= [];
gdjs.s372Code.GDchapter2Objects2= [];
gdjs.s372Code.GDchapter1Objects1= [];
gdjs.s372Code.GDchapter1Objects2= [];
gdjs.s372Code.GDNewObjectObjects1= [];
gdjs.s372Code.GDNewObjectObjects2= [];
gdjs.s372Code.GDob7Objects1= [];
gdjs.s372Code.GDob7Objects2= [];
gdjs.s372Code.GDob6Objects1= [];
gdjs.s372Code.GDob6Objects2= [];
gdjs.s372Code.GDob5Objects1= [];
gdjs.s372Code.GDob5Objects2= [];
gdjs.s372Code.GDob4Objects1= [];
gdjs.s372Code.GDob4Objects2= [];
gdjs.s372Code.GDob3Objects1= [];
gdjs.s372Code.GDob3Objects2= [];
gdjs.s372Code.GDob2Objects1= [];
gdjs.s372Code.GDob2Objects2= [];
gdjs.s372Code.GDob1Objects1= [];
gdjs.s372Code.GDob1Objects2= [];
gdjs.s372Code.GDtargetObjects1= [];
gdjs.s372Code.GDtargetObjects2= [];

gdjs.s372Code.conditionTrue_0 = {val:false};
gdjs.s372Code.condition0IsTrue_0 = {val:false};
gdjs.s372Code.condition1IsTrue_0 = {val:false};
gdjs.s372Code.condition2IsTrue_0 = {val:false};


gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s372Code.GDDOWNbuttonObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s372Code.GDUPbuttonObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s372Code.GDRbuttonObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s372Code.GDLbuttonObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s372Code.GDRcolObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s372Code.GDLcolObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s372Code.GDUPcolObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s372Code.GDDOWNcolObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s372Code.GDDOWNcolObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s372Code.GDBObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s372Code.GDAObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s372Code.GDoffObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s372Code.GDonObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob1Objects1Objects = Hashtable.newFrom({"ob1": gdjs.s372Code.GDob1Objects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob2Objects1Objects = Hashtable.newFrom({"ob2": gdjs.s372Code.GDob2Objects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob3Objects1Objects = Hashtable.newFrom({"ob3": gdjs.s372Code.GDob3Objects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob4Objects1Objects = Hashtable.newFrom({"ob4": gdjs.s372Code.GDob4Objects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob5Objects1Objects = Hashtable.newFrom({"ob5": gdjs.s372Code.GDob5Objects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob6Objects1Objects = Hashtable.newFrom({"ob6": gdjs.s372Code.GDob6Objects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s372Code.GDcarObjects1});gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob7Objects1Objects = Hashtable.newFrom({"ob7": gdjs.s372Code.GDob7Objects1});gdjs.s372Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s372Code.GDDOWNbuttonObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
gdjs.s372Code.condition1IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s372Code.condition0IsTrue_0.val ) {
{
gdjs.s372Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s372Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s372Code.GDUPbuttonObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
gdjs.s372Code.condition1IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s372Code.condition0IsTrue_0.val ) {
{
gdjs.s372Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s372Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s372Code.GDRbuttonObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
gdjs.s372Code.condition1IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s372Code.condition0IsTrue_0.val ) {
{
gdjs.s372Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s372Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s372Code.GDLbuttonObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
gdjs.s372Code.condition1IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s372Code.condition0IsTrue_0.val ) {
{
gdjs.s372Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s372Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s372Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s372Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s372Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s372Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s372Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s372Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s372Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s372Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s372Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s372Code.GDBObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s372Code.GDAObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s372Code.GDoffObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s372Code.GDonObjects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s372Code.condition0IsTrue_0.val = false;
gdjs.s372Code.condition1IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s372Code.condition0IsTrue_0.val ) {
{
gdjs.s372Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s372Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s372Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s372Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].flipX(false);
}
}}

}


{


gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s372Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s372Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s372Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s372Code.GDcarObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob1"), gdjs.s372Code.GDob1Objects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob1Objects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s371", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob2"), gdjs.s372Code.GDob2Objects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s371", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob3"), gdjs.s372Code.GDob3Objects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob3Objects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s371", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob4"), gdjs.s372Code.GDob4Objects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob4Objects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s371", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob5"), gdjs.s372Code.GDob5Objects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob5Objects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s371", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob6"), gdjs.s372Code.GDob6Objects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob6Objects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s371", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s372Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob7"), gdjs.s372Code.GDob7Objects1);

gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDcarObjects1Objects, gdjs.s372Code.mapOfGDgdjs_46s372Code_46GDob7Objects1Objects, false, runtimeScene, false);
}if (gdjs.s372Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s371", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob1"), gdjs.s372Code.GDob1Objects1);
{for(var i = 0, len = gdjs.s372Code.GDob1Objects1.length ;i < len;++i) {
    gdjs.s372Code.GDob1Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob2"), gdjs.s372Code.GDob2Objects1);
{for(var i = 0, len = gdjs.s372Code.GDob2Objects1.length ;i < len;++i) {
    gdjs.s372Code.GDob2Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob3"), gdjs.s372Code.GDob3Objects1);
{for(var i = 0, len = gdjs.s372Code.GDob3Objects1.length ;i < len;++i) {
    gdjs.s372Code.GDob3Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob4"), gdjs.s372Code.GDob4Objects1);
{for(var i = 0, len = gdjs.s372Code.GDob4Objects1.length ;i < len;++i) {
    gdjs.s372Code.GDob4Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob5"), gdjs.s372Code.GDob5Objects1);
{for(var i = 0, len = gdjs.s372Code.GDob5Objects1.length ;i < len;++i) {
    gdjs.s372Code.GDob5Objects1[i].addForceTowardPosition(400, 1000, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob6"), gdjs.s372Code.GDob6Objects1);
{for(var i = 0, len = gdjs.s372Code.GDob6Objects1.length ;i < len;++i) {
    gdjs.s372Code.GDob6Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob7"), gdjs.s372Code.GDob7Objects1);
{for(var i = 0, len = gdjs.s372Code.GDob7Objects1.length ;i < len;++i) {
    gdjs.s372Code.GDob7Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


gdjs.s372Code.condition0IsTrue_0.val = false;
{
gdjs.s372Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 45, "");
}if (gdjs.s372Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s373", false);
}}

}


};

gdjs.s372Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s372Code.GDcaseObjects1.length = 0;
gdjs.s372Code.GDcaseObjects2.length = 0;
gdjs.s372Code.GDoffObjects1.length = 0;
gdjs.s372Code.GDoffObjects2.length = 0;
gdjs.s372Code.GDonObjects1.length = 0;
gdjs.s372Code.GDonObjects2.length = 0;
gdjs.s372Code.GDstartObjects1.length = 0;
gdjs.s372Code.GDstartObjects2.length = 0;
gdjs.s372Code.GDBObjects1.length = 0;
gdjs.s372Code.GDBObjects2.length = 0;
gdjs.s372Code.GDAObjects1.length = 0;
gdjs.s372Code.GDAObjects2.length = 0;
gdjs.s372Code.GDcarObjects1.length = 0;
gdjs.s372Code.GDcarObjects2.length = 0;
gdjs.s372Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s372Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s372Code.GDblackObjects1.length = 0;
gdjs.s372Code.GDblackObjects2.length = 0;
gdjs.s372Code.GDDOWNcol2Objects1.length = 0;
gdjs.s372Code.GDDOWNcol2Objects2.length = 0;
gdjs.s372Code.GDDOWNcolObjects1.length = 0;
gdjs.s372Code.GDDOWNcolObjects2.length = 0;
gdjs.s372Code.GDUPbuttonObjects1.length = 0;
gdjs.s372Code.GDUPbuttonObjects2.length = 0;
gdjs.s372Code.GDUPcolObjects1.length = 0;
gdjs.s372Code.GDUPcolObjects2.length = 0;
gdjs.s372Code.GDLbuttonObjects1.length = 0;
gdjs.s372Code.GDLbuttonObjects2.length = 0;
gdjs.s372Code.GDLcolObjects1.length = 0;
gdjs.s372Code.GDLcolObjects2.length = 0;
gdjs.s372Code.GDRbuttonObjects1.length = 0;
gdjs.s372Code.GDRbuttonObjects2.length = 0;
gdjs.s372Code.GDTALK3Objects1.length = 0;
gdjs.s372Code.GDTALK3Objects2.length = 0;
gdjs.s372Code.GDTALK2Objects1.length = 0;
gdjs.s372Code.GDTALK2Objects2.length = 0;
gdjs.s372Code.GDExitObjects1.length = 0;
gdjs.s372Code.GDExitObjects2.length = 0;
gdjs.s372Code.GDRcolObjects1.length = 0;
gdjs.s372Code.GDRcolObjects2.length = 0;
gdjs.s372Code.GDchapter4Objects1.length = 0;
gdjs.s372Code.GDchapter4Objects2.length = 0;
gdjs.s372Code.GDchapter3Objects1.length = 0;
gdjs.s372Code.GDchapter3Objects2.length = 0;
gdjs.s372Code.GDchapter2Objects1.length = 0;
gdjs.s372Code.GDchapter2Objects2.length = 0;
gdjs.s372Code.GDchapter1Objects1.length = 0;
gdjs.s372Code.GDchapter1Objects2.length = 0;
gdjs.s372Code.GDNewObjectObjects1.length = 0;
gdjs.s372Code.GDNewObjectObjects2.length = 0;
gdjs.s372Code.GDob7Objects1.length = 0;
gdjs.s372Code.GDob7Objects2.length = 0;
gdjs.s372Code.GDob6Objects1.length = 0;
gdjs.s372Code.GDob6Objects2.length = 0;
gdjs.s372Code.GDob5Objects1.length = 0;
gdjs.s372Code.GDob5Objects2.length = 0;
gdjs.s372Code.GDob4Objects1.length = 0;
gdjs.s372Code.GDob4Objects2.length = 0;
gdjs.s372Code.GDob3Objects1.length = 0;
gdjs.s372Code.GDob3Objects2.length = 0;
gdjs.s372Code.GDob2Objects1.length = 0;
gdjs.s372Code.GDob2Objects2.length = 0;
gdjs.s372Code.GDob1Objects1.length = 0;
gdjs.s372Code.GDob1Objects2.length = 0;
gdjs.s372Code.GDtargetObjects1.length = 0;
gdjs.s372Code.GDtargetObjects2.length = 0;

gdjs.s372Code.eventsList0(runtimeScene);
return;

}

gdjs['s372Code'] = gdjs.s372Code;
