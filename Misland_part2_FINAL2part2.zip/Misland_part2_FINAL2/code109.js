gdjs.s92Code = {};
gdjs.s92Code.GDcaseObjects1= [];
gdjs.s92Code.GDcaseObjects2= [];
gdjs.s92Code.GDimageObjects1= [];
gdjs.s92Code.GDimageObjects2= [];
gdjs.s92Code.GDoffObjects1= [];
gdjs.s92Code.GDoffObjects2= [];
gdjs.s92Code.GDonObjects1= [];
gdjs.s92Code.GDonObjects2= [];
gdjs.s92Code.GDstartObjects1= [];
gdjs.s92Code.GDstartObjects2= [];
gdjs.s92Code.GDBObjects1= [];
gdjs.s92Code.GDBObjects2= [];
gdjs.s92Code.GDAObjects1= [];
gdjs.s92Code.GDAObjects2= [];
gdjs.s92Code.GDcrosshairsObjects1= [];
gdjs.s92Code.GDcrosshairsObjects2= [];
gdjs.s92Code.GDDOWNbuttonObjects1= [];
gdjs.s92Code.GDDOWNbuttonObjects2= [];
gdjs.s92Code.GDDOWNcolObjects1= [];
gdjs.s92Code.GDDOWNcolObjects2= [];
gdjs.s92Code.GDUPbuttonObjects1= [];
gdjs.s92Code.GDUPbuttonObjects2= [];
gdjs.s92Code.GDUPcolObjects1= [];
gdjs.s92Code.GDUPcolObjects2= [];
gdjs.s92Code.GDLbuttonObjects1= [];
gdjs.s92Code.GDLbuttonObjects2= [];
gdjs.s92Code.GDLcolObjects1= [];
gdjs.s92Code.GDLcolObjects2= [];
gdjs.s92Code.GDRbuttonObjects1= [];
gdjs.s92Code.GDRbuttonObjects2= [];
gdjs.s92Code.GDRcolObjects1= [];
gdjs.s92Code.GDRcolObjects2= [];
gdjs.s92Code.GDchapter4Objects1= [];
gdjs.s92Code.GDchapter4Objects2= [];
gdjs.s92Code.GDchapter3Objects1= [];
gdjs.s92Code.GDchapter3Objects2= [];
gdjs.s92Code.GDchapter2Objects1= [];
gdjs.s92Code.GDchapter2Objects2= [];
gdjs.s92Code.GDblackObjects1= [];
gdjs.s92Code.GDblackObjects2= [];
gdjs.s92Code.GDchapter1Objects1= [];
gdjs.s92Code.GDchapter1Objects2= [];

gdjs.s92Code.conditionTrue_0 = {val:false};
gdjs.s92Code.condition0IsTrue_0 = {val:false};
gdjs.s92Code.condition1IsTrue_0 = {val:false};
gdjs.s92Code.condition2IsTrue_0 = {val:false};


gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s92Code.GDDOWNbuttonObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s92Code.GDUPbuttonObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s92Code.GDRbuttonObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s92Code.GDLbuttonObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s92Code.GDcrosshairsObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s92Code.GDRcolObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s92Code.GDcrosshairsObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s92Code.GDLcolObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s92Code.GDcrosshairsObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s92Code.GDUPcolObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s92Code.GDcrosshairsObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s92Code.GDDOWNcolObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s92Code.GDcrosshairsObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s92Code.GDDOWNcolObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s92Code.GDoffObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s92Code.GDonObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s92Code.GDcrosshairsObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDchapter2Objects1Objects = Hashtable.newFrom({"chapter2": gdjs.s92Code.GDchapter2Objects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s92Code.GDAObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s92Code.GDcrosshairsObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDchapter2Objects1Objects = Hashtable.newFrom({"chapter2": gdjs.s92Code.GDchapter2Objects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s92Code.GDcrosshairsObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s92Code.GDchapter1Objects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s92Code.GDAObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s92Code.GDcrosshairsObjects1});gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s92Code.GDchapter1Objects1});gdjs.s92Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s92Code.GDDOWNbuttonObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
gdjs.s92Code.condition1IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s92Code.condition0IsTrue_0.val ) {
{
gdjs.s92Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s92Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s92Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s92Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s92Code.GDUPbuttonObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
gdjs.s92Code.condition1IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s92Code.condition0IsTrue_0.val ) {
{
gdjs.s92Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s92Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s92Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s92Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s92Code.GDRbuttonObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
gdjs.s92Code.condition1IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s92Code.condition0IsTrue_0.val ) {
{
gdjs.s92Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s92Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s92Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s92Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s92Code.GDLbuttonObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
gdjs.s92Code.condition1IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s92Code.condition0IsTrue_0.val ) {
{
gdjs.s92Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s92Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s92Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s92Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s92Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects, gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s92Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s92Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s92Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s92Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s92Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects, gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s92Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s92Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s92Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s92Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s92Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects, gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s92Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s92Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s92Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s92Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s92Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects, gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s92Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s92Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s92Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s92Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s92Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects, gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s92Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s92Code.GDoffObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s92Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s92Code.GDonObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s92Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s92Code.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter2"), gdjs.s92Code.GDchapter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
gdjs.s92Code.condition1IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects, gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDchapter2Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s92Code.condition0IsTrue_0.val ) {
{
gdjs.s92Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.s92Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s93", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter2"), gdjs.s92Code.GDchapter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
gdjs.s92Code.condition1IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects, gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDchapter2Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s92Code.condition0IsTrue_0.val ) {
{
gdjs.s92Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s92Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s93", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s92Code.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s92Code.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
gdjs.s92Code.condition1IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects, gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s92Code.condition0IsTrue_0.val ) {
{
gdjs.s92Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.s92Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s88", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s92Code.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s92Code.GDcrosshairsObjects1);

gdjs.s92Code.condition0IsTrue_0.val = false;
gdjs.s92Code.condition1IsTrue_0.val = false;
{
gdjs.s92Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDcrosshairsObjects1Objects, gdjs.s92Code.mapOfGDgdjs_46s92Code_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s92Code.condition0IsTrue_0.val ) {
{
gdjs.s92Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s92Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s89.1", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s92Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s92Code.GDcaseObjects1.length = 0;
gdjs.s92Code.GDcaseObjects2.length = 0;
gdjs.s92Code.GDimageObjects1.length = 0;
gdjs.s92Code.GDimageObjects2.length = 0;
gdjs.s92Code.GDoffObjects1.length = 0;
gdjs.s92Code.GDoffObjects2.length = 0;
gdjs.s92Code.GDonObjects1.length = 0;
gdjs.s92Code.GDonObjects2.length = 0;
gdjs.s92Code.GDstartObjects1.length = 0;
gdjs.s92Code.GDstartObjects2.length = 0;
gdjs.s92Code.GDBObjects1.length = 0;
gdjs.s92Code.GDBObjects2.length = 0;
gdjs.s92Code.GDAObjects1.length = 0;
gdjs.s92Code.GDAObjects2.length = 0;
gdjs.s92Code.GDcrosshairsObjects1.length = 0;
gdjs.s92Code.GDcrosshairsObjects2.length = 0;
gdjs.s92Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s92Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s92Code.GDDOWNcolObjects1.length = 0;
gdjs.s92Code.GDDOWNcolObjects2.length = 0;
gdjs.s92Code.GDUPbuttonObjects1.length = 0;
gdjs.s92Code.GDUPbuttonObjects2.length = 0;
gdjs.s92Code.GDUPcolObjects1.length = 0;
gdjs.s92Code.GDUPcolObjects2.length = 0;
gdjs.s92Code.GDLbuttonObjects1.length = 0;
gdjs.s92Code.GDLbuttonObjects2.length = 0;
gdjs.s92Code.GDLcolObjects1.length = 0;
gdjs.s92Code.GDLcolObjects2.length = 0;
gdjs.s92Code.GDRbuttonObjects1.length = 0;
gdjs.s92Code.GDRbuttonObjects2.length = 0;
gdjs.s92Code.GDRcolObjects1.length = 0;
gdjs.s92Code.GDRcolObjects2.length = 0;
gdjs.s92Code.GDchapter4Objects1.length = 0;
gdjs.s92Code.GDchapter4Objects2.length = 0;
gdjs.s92Code.GDchapter3Objects1.length = 0;
gdjs.s92Code.GDchapter3Objects2.length = 0;
gdjs.s92Code.GDchapter2Objects1.length = 0;
gdjs.s92Code.GDchapter2Objects2.length = 0;
gdjs.s92Code.GDblackObjects1.length = 0;
gdjs.s92Code.GDblackObjects2.length = 0;
gdjs.s92Code.GDchapter1Objects1.length = 0;
gdjs.s92Code.GDchapter1Objects2.length = 0;

gdjs.s92Code.eventsList0(runtimeScene);
return;

}

gdjs['s92Code'] = gdjs.s92Code;
