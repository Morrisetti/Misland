gdjs.C7Code = {};
gdjs.C7Code.GDcaseObjects1= [];
gdjs.C7Code.GDcaseObjects2= [];
gdjs.C7Code.GDimageObjects1= [];
gdjs.C7Code.GDimageObjects2= [];
gdjs.C7Code.GDoffObjects1= [];
gdjs.C7Code.GDoffObjects2= [];
gdjs.C7Code.GDonObjects1= [];
gdjs.C7Code.GDonObjects2= [];
gdjs.C7Code.GDstartObjects1= [];
gdjs.C7Code.GDstartObjects2= [];
gdjs.C7Code.GDBObjects1= [];
gdjs.C7Code.GDBObjects2= [];
gdjs.C7Code.GDblackObjects1= [];
gdjs.C7Code.GDblackObjects2= [];
gdjs.C7Code.GDAObjects1= [];
gdjs.C7Code.GDAObjects2= [];

gdjs.C7Code.conditionTrue_0 = {val:false};
gdjs.C7Code.condition0IsTrue_0 = {val:false};
gdjs.C7Code.condition1IsTrue_0 = {val:false};
gdjs.C7Code.conditionTrue_1 = {val:false};
gdjs.C7Code.condition0IsTrue_1 = {val:false};
gdjs.C7Code.condition1IsTrue_1 = {val:false};


gdjs.C7Code.mapOfGDgdjs_46C7Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.C7Code.GDstartObjects1});gdjs.C7Code.mapOfGDgdjs_46C7Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.C7Code.GDoffObjects1});gdjs.C7Code.mapOfGDgdjs_46C7Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.C7Code.GDonObjects1});gdjs.C7Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.C7Code.condition0IsTrue_0.val = false;
{
{gdjs.C7Code.conditionTrue_1 = gdjs.C7Code.condition0IsTrue_0;
gdjs.C7Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(89954780);
}
}if (gdjs.C7Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter5_v6.mp3", true, 80, 1);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.C7Code.GDstartObjects1);

gdjs.C7Code.condition0IsTrue_0.val = false;
{
gdjs.C7Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C7Code.mapOfGDgdjs_46C7Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.C7Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s155", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.C7Code.GDoffObjects1);

gdjs.C7Code.condition0IsTrue_0.val = false;
{
gdjs.C7Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C7Code.mapOfGDgdjs_46C7Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.C7Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.C7Code.GDonObjects1);

gdjs.C7Code.condition0IsTrue_0.val = false;
{
gdjs.C7Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C7Code.mapOfGDgdjs_46C7Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.C7Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.C7Code.condition0IsTrue_0.val = false;
{
gdjs.C7Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.C7Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s155", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.C7Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.C7Code.GDcaseObjects1.length = 0;
gdjs.C7Code.GDcaseObjects2.length = 0;
gdjs.C7Code.GDimageObjects1.length = 0;
gdjs.C7Code.GDimageObjects2.length = 0;
gdjs.C7Code.GDoffObjects1.length = 0;
gdjs.C7Code.GDoffObjects2.length = 0;
gdjs.C7Code.GDonObjects1.length = 0;
gdjs.C7Code.GDonObjects2.length = 0;
gdjs.C7Code.GDstartObjects1.length = 0;
gdjs.C7Code.GDstartObjects2.length = 0;
gdjs.C7Code.GDBObjects1.length = 0;
gdjs.C7Code.GDBObjects2.length = 0;
gdjs.C7Code.GDblackObjects1.length = 0;
gdjs.C7Code.GDblackObjects2.length = 0;
gdjs.C7Code.GDAObjects1.length = 0;
gdjs.C7Code.GDAObjects2.length = 0;

gdjs.C7Code.eventsList0(runtimeScene);
return;

}

gdjs['C7Code'] = gdjs.C7Code;
