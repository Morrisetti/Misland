gdjs.s73Code = {};
gdjs.s73Code.GDcaseObjects1= [];
gdjs.s73Code.GDcaseObjects2= [];
gdjs.s73Code.GDimageObjects1= [];
gdjs.s73Code.GDimageObjects2= [];
gdjs.s73Code.GDoffObjects1= [];
gdjs.s73Code.GDoffObjects2= [];
gdjs.s73Code.GDonObjects1= [];
gdjs.s73Code.GDonObjects2= [];
gdjs.s73Code.GDstartObjects1= [];
gdjs.s73Code.GDstartObjects2= [];
gdjs.s73Code.GDBObjects1= [];
gdjs.s73Code.GDBObjects2= [];
gdjs.s73Code.GDblackObjects1= [];
gdjs.s73Code.GDblackObjects2= [];
gdjs.s73Code.GDAObjects1= [];
gdjs.s73Code.GDAObjects2= [];

gdjs.s73Code.conditionTrue_0 = {val:false};
gdjs.s73Code.condition0IsTrue_0 = {val:false};
gdjs.s73Code.condition1IsTrue_0 = {val:false};


gdjs.s73Code.mapOfGDgdjs_46s73Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s73Code.GDstartObjects1});gdjs.s73Code.mapOfGDgdjs_46s73Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s73Code.GDoffObjects1});gdjs.s73Code.mapOfGDgdjs_46s73Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s73Code.GDonObjects1});gdjs.s73Code.mapOfGDgdjs_46s73Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s73Code.GDBObjects1});gdjs.s73Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s73Code.GDstartObjects1);

gdjs.s73Code.condition0IsTrue_0.val = false;
{
gdjs.s73Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s73Code.mapOfGDgdjs_46s73Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s73Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s73Code.GDoffObjects1);

gdjs.s73Code.condition0IsTrue_0.val = false;
{
gdjs.s73Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s73Code.mapOfGDgdjs_46s73Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s73Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s73Code.GDonObjects1);

gdjs.s73Code.condition0IsTrue_0.val = false;
{
gdjs.s73Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s73Code.mapOfGDgdjs_46s73Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s73Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s73Code.condition0IsTrue_0.val = false;
{
gdjs.s73Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s73Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s74", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s73Code.GDBObjects1);

gdjs.s73Code.condition0IsTrue_0.val = false;
{
gdjs.s73Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s73Code.mapOfGDgdjs_46s73Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s73Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s74", false);
}}

}


{


{
}

}


};

gdjs.s73Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s73Code.GDcaseObjects1.length = 0;
gdjs.s73Code.GDcaseObjects2.length = 0;
gdjs.s73Code.GDimageObjects1.length = 0;
gdjs.s73Code.GDimageObjects2.length = 0;
gdjs.s73Code.GDoffObjects1.length = 0;
gdjs.s73Code.GDoffObjects2.length = 0;
gdjs.s73Code.GDonObjects1.length = 0;
gdjs.s73Code.GDonObjects2.length = 0;
gdjs.s73Code.GDstartObjects1.length = 0;
gdjs.s73Code.GDstartObjects2.length = 0;
gdjs.s73Code.GDBObjects1.length = 0;
gdjs.s73Code.GDBObjects2.length = 0;
gdjs.s73Code.GDblackObjects1.length = 0;
gdjs.s73Code.GDblackObjects2.length = 0;
gdjs.s73Code.GDAObjects1.length = 0;
gdjs.s73Code.GDAObjects2.length = 0;

gdjs.s73Code.eventsList0(runtimeScene);
return;

}

gdjs['s73Code'] = gdjs.s73Code;
