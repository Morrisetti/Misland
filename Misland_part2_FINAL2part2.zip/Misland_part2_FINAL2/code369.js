gdjs.s327Code = {};
gdjs.s327Code.GDcaseObjects1= [];
gdjs.s327Code.GDcaseObjects2= [];
gdjs.s327Code.GDimageObjects1= [];
gdjs.s327Code.GDimageObjects2= [];
gdjs.s327Code.GDoffObjects1= [];
gdjs.s327Code.GDoffObjects2= [];
gdjs.s327Code.GDonObjects1= [];
gdjs.s327Code.GDonObjects2= [];
gdjs.s327Code.GDstartObjects1= [];
gdjs.s327Code.GDstartObjects2= [];
gdjs.s327Code.GDBObjects1= [];
gdjs.s327Code.GDBObjects2= [];
gdjs.s327Code.GDblackObjects1= [];
gdjs.s327Code.GDblackObjects2= [];
gdjs.s327Code.GDAObjects1= [];
gdjs.s327Code.GDAObjects2= [];

gdjs.s327Code.conditionTrue_0 = {val:false};
gdjs.s327Code.condition0IsTrue_0 = {val:false};
gdjs.s327Code.condition1IsTrue_0 = {val:false};


gdjs.s327Code.mapOfGDgdjs_46s327Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s327Code.GDoffObjects1});gdjs.s327Code.mapOfGDgdjs_46s327Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s327Code.GDonObjects1});gdjs.s327Code.mapOfGDgdjs_46s327Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s327Code.GDBObjects1});gdjs.s327Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s327Code.GDoffObjects1);

gdjs.s327Code.condition0IsTrue_0.val = false;
{
gdjs.s327Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s327Code.mapOfGDgdjs_46s327Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s327Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s327Code.GDonObjects1);

gdjs.s327Code.condition0IsTrue_0.val = false;
{
gdjs.s327Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s327Code.mapOfGDgdjs_46s327Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s327Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s327Code.condition0IsTrue_0.val = false;
{
gdjs.s327Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s327Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s328", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s327Code.GDBObjects1);

gdjs.s327Code.condition0IsTrue_0.val = false;
{
gdjs.s327Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s327Code.mapOfGDgdjs_46s327Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s327Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s328", false);
}}

}


{


{
}

}


};

gdjs.s327Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s327Code.GDcaseObjects1.length = 0;
gdjs.s327Code.GDcaseObjects2.length = 0;
gdjs.s327Code.GDimageObjects1.length = 0;
gdjs.s327Code.GDimageObjects2.length = 0;
gdjs.s327Code.GDoffObjects1.length = 0;
gdjs.s327Code.GDoffObjects2.length = 0;
gdjs.s327Code.GDonObjects1.length = 0;
gdjs.s327Code.GDonObjects2.length = 0;
gdjs.s327Code.GDstartObjects1.length = 0;
gdjs.s327Code.GDstartObjects2.length = 0;
gdjs.s327Code.GDBObjects1.length = 0;
gdjs.s327Code.GDBObjects2.length = 0;
gdjs.s327Code.GDblackObjects1.length = 0;
gdjs.s327Code.GDblackObjects2.length = 0;
gdjs.s327Code.GDAObjects1.length = 0;
gdjs.s327Code.GDAObjects2.length = 0;

gdjs.s327Code.eventsList0(runtimeScene);
return;

}

gdjs['s327Code'] = gdjs.s327Code;
