gdjs.s297Code = {};
gdjs.s297Code.GDcaseObjects1= [];
gdjs.s297Code.GDcaseObjects2= [];
gdjs.s297Code.GDimageObjects1= [];
gdjs.s297Code.GDimageObjects2= [];
gdjs.s297Code.GDoffObjects1= [];
gdjs.s297Code.GDoffObjects2= [];
gdjs.s297Code.GDonObjects1= [];
gdjs.s297Code.GDonObjects2= [];
gdjs.s297Code.GDstartObjects1= [];
gdjs.s297Code.GDstartObjects2= [];
gdjs.s297Code.GDBObjects1= [];
gdjs.s297Code.GDBObjects2= [];
gdjs.s297Code.GDblackObjects1= [];
gdjs.s297Code.GDblackObjects2= [];
gdjs.s297Code.GDAObjects1= [];
gdjs.s297Code.GDAObjects2= [];
gdjs.s297Code.GDbuttonObjects1= [];
gdjs.s297Code.GDbuttonObjects2= [];

gdjs.s297Code.conditionTrue_0 = {val:false};
gdjs.s297Code.condition0IsTrue_0 = {val:false};
gdjs.s297Code.condition1IsTrue_0 = {val:false};
gdjs.s297Code.conditionTrue_1 = {val:false};
gdjs.s297Code.condition0IsTrue_1 = {val:false};
gdjs.s297Code.condition1IsTrue_1 = {val:false};


gdjs.s297Code.mapOfGDgdjs_46s297Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s297Code.GDbuttonObjects1});gdjs.s297Code.mapOfGDgdjs_46s297Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s297Code.GDoffObjects1});gdjs.s297Code.mapOfGDgdjs_46s297Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s297Code.GDonObjects1});gdjs.s297Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s297Code.GDcaseObjects1);

gdjs.s297Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s297Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s297Code.GDcaseObjects1[i].timerElapsedTime("", 0.4) ) {
        gdjs.s297Code.condition0IsTrue_0.val = true;
        gdjs.s297Code.GDcaseObjects1[k] = gdjs.s297Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s297Code.GDcaseObjects1.length = k;}if (gdjs.s297Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s298", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s297Code.GDbuttonObjects1);

gdjs.s297Code.condition0IsTrue_0.val = false;
{
gdjs.s297Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s297Code.mapOfGDgdjs_46s297Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s297Code.condition0IsTrue_0.val) {
}

}


{


gdjs.s297Code.condition0IsTrue_0.val = false;
{
{gdjs.s297Code.conditionTrue_1 = gdjs.s297Code.condition0IsTrue_0;
gdjs.s297Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(93191252);
}
}if (gdjs.s297Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "chapter_8_v3.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s297Code.GDoffObjects1);

gdjs.s297Code.condition0IsTrue_0.val = false;
{
gdjs.s297Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s297Code.mapOfGDgdjs_46s297Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s297Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s297Code.GDonObjects1);

gdjs.s297Code.condition0IsTrue_0.val = false;
{
gdjs.s297Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s297Code.mapOfGDgdjs_46s297Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s297Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s297Code.condition0IsTrue_0.val = false;
{
gdjs.s297Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s297Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


};

gdjs.s297Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s297Code.GDcaseObjects1.length = 0;
gdjs.s297Code.GDcaseObjects2.length = 0;
gdjs.s297Code.GDimageObjects1.length = 0;
gdjs.s297Code.GDimageObjects2.length = 0;
gdjs.s297Code.GDoffObjects1.length = 0;
gdjs.s297Code.GDoffObjects2.length = 0;
gdjs.s297Code.GDonObjects1.length = 0;
gdjs.s297Code.GDonObjects2.length = 0;
gdjs.s297Code.GDstartObjects1.length = 0;
gdjs.s297Code.GDstartObjects2.length = 0;
gdjs.s297Code.GDBObjects1.length = 0;
gdjs.s297Code.GDBObjects2.length = 0;
gdjs.s297Code.GDblackObjects1.length = 0;
gdjs.s297Code.GDblackObjects2.length = 0;
gdjs.s297Code.GDAObjects1.length = 0;
gdjs.s297Code.GDAObjects2.length = 0;
gdjs.s297Code.GDbuttonObjects1.length = 0;
gdjs.s297Code.GDbuttonObjects2.length = 0;

gdjs.s297Code.eventsList0(runtimeScene);
return;

}

gdjs['s297Code'] = gdjs.s297Code;
