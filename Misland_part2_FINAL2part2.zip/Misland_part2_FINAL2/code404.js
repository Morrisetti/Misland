gdjs.s360Code = {};
gdjs.s360Code.GDcaseObjects1= [];
gdjs.s360Code.GDcaseObjects2= [];
gdjs.s360Code.GDimageObjects1= [];
gdjs.s360Code.GDimageObjects2= [];
gdjs.s360Code.GDoffObjects1= [];
gdjs.s360Code.GDoffObjects2= [];
gdjs.s360Code.GDonObjects1= [];
gdjs.s360Code.GDonObjects2= [];
gdjs.s360Code.GDstartObjects1= [];
gdjs.s360Code.GDstartObjects2= [];
gdjs.s360Code.GDBObjects1= [];
gdjs.s360Code.GDBObjects2= [];
gdjs.s360Code.GDAObjects1= [];
gdjs.s360Code.GDAObjects2= [];
gdjs.s360Code.GDcrosshairsObjects1= [];
gdjs.s360Code.GDcrosshairsObjects2= [];
gdjs.s360Code.GDDOWNbuttonObjects1= [];
gdjs.s360Code.GDDOWNbuttonObjects2= [];
gdjs.s360Code.GDDOWNcolObjects1= [];
gdjs.s360Code.GDDOWNcolObjects2= [];
gdjs.s360Code.GDUPbuttonObjects1= [];
gdjs.s360Code.GDUPbuttonObjects2= [];
gdjs.s360Code.GDUPcolObjects1= [];
gdjs.s360Code.GDUPcolObjects2= [];
gdjs.s360Code.GDLbuttonObjects1= [];
gdjs.s360Code.GDLbuttonObjects2= [];
gdjs.s360Code.GDLcolObjects1= [];
gdjs.s360Code.GDLcolObjects2= [];
gdjs.s360Code.GDRbuttonObjects1= [];
gdjs.s360Code.GDRbuttonObjects2= [];
gdjs.s360Code.GDRcolObjects1= [];
gdjs.s360Code.GDRcolObjects2= [];
gdjs.s360Code.GDchapter4Objects1= [];
gdjs.s360Code.GDchapter4Objects2= [];
gdjs.s360Code.GDchapter3Objects1= [];
gdjs.s360Code.GDchapter3Objects2= [];
gdjs.s360Code.GDchapter2Objects1= [];
gdjs.s360Code.GDchapter2Objects2= [];
gdjs.s360Code.GDblackObjects1= [];
gdjs.s360Code.GDblackObjects2= [];
gdjs.s360Code.GDchapter1Objects1= [];
gdjs.s360Code.GDchapter1Objects2= [];

gdjs.s360Code.conditionTrue_0 = {val:false};
gdjs.s360Code.condition0IsTrue_0 = {val:false};
gdjs.s360Code.condition1IsTrue_0 = {val:false};
gdjs.s360Code.condition2IsTrue_0 = {val:false};


gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s360Code.GDDOWNbuttonObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s360Code.GDUPbuttonObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s360Code.GDRbuttonObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s360Code.GDLbuttonObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s360Code.GDcrosshairsObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s360Code.GDRcolObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s360Code.GDcrosshairsObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s360Code.GDLcolObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s360Code.GDcrosshairsObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s360Code.GDUPcolObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s360Code.GDcrosshairsObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s360Code.GDDOWNcolObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s360Code.GDcrosshairsObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s360Code.GDDOWNcolObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s360Code.GDoffObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s360Code.GDonObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s360Code.GDBObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s360Code.GDcrosshairsObjects1});gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s360Code.GDchapter1Objects1});gdjs.s360Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s360Code.GDDOWNbuttonObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
gdjs.s360Code.condition1IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s360Code.condition0IsTrue_0.val ) {
{
gdjs.s360Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s360Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s360Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s360Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s360Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s360Code.GDUPbuttonObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
gdjs.s360Code.condition1IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s360Code.condition0IsTrue_0.val ) {
{
gdjs.s360Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s360Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s360Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s360Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s360Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s360Code.GDRbuttonObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
gdjs.s360Code.condition1IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s360Code.condition0IsTrue_0.val ) {
{
gdjs.s360Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s360Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s360Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s360Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s360Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s360Code.GDLbuttonObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
gdjs.s360Code.condition1IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s360Code.condition0IsTrue_0.val ) {
{
gdjs.s360Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s360Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s360Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s360Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s360Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s360Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s360Code.GDcrosshairsObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects, gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s360Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s360Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s360Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s360Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s360Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s360Code.GDcrosshairsObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects, gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s360Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s360Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s360Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s360Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s360Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s360Code.GDcrosshairsObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects, gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s360Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s360Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s360Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s360Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s360Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s360Code.GDcrosshairsObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects, gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s360Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s360Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s360Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s360Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s360Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s360Code.GDcrosshairsObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects, gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s360Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s360Code.GDoffObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s360Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s360Code.GDonObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s360Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s360Code.GDstartObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s360Code.GDstartObjects1.length;i<l;++i) {
    if ( gdjs.s360Code.GDstartObjects1[i].timerElapsedTime("", 4) ) {
        gdjs.s360Code.condition0IsTrue_0.val = true;
        gdjs.s360Code.GDstartObjects1[k] = gdjs.s360Code.GDstartObjects1[i];
        ++k;
    }
}
gdjs.s360Code.GDstartObjects1.length = k;}if (gdjs.s360Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s359.1", false);
}}

}


{


gdjs.s360Code.condition0IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s360Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s359", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s360Code.GDBObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s360Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s359", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s360Code.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s360Code.GDcrosshairsObjects1);

gdjs.s360Code.condition0IsTrue_0.val = false;
gdjs.s360Code.condition1IsTrue_0.val = false;
{
gdjs.s360Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDcrosshairsObjects1Objects, gdjs.s360Code.mapOfGDgdjs_46s360Code_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s360Code.condition0IsTrue_0.val ) {
{
gdjs.s360Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s360Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s361", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s360Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s360Code.GDcaseObjects1.length = 0;
gdjs.s360Code.GDcaseObjects2.length = 0;
gdjs.s360Code.GDimageObjects1.length = 0;
gdjs.s360Code.GDimageObjects2.length = 0;
gdjs.s360Code.GDoffObjects1.length = 0;
gdjs.s360Code.GDoffObjects2.length = 0;
gdjs.s360Code.GDonObjects1.length = 0;
gdjs.s360Code.GDonObjects2.length = 0;
gdjs.s360Code.GDstartObjects1.length = 0;
gdjs.s360Code.GDstartObjects2.length = 0;
gdjs.s360Code.GDBObjects1.length = 0;
gdjs.s360Code.GDBObjects2.length = 0;
gdjs.s360Code.GDAObjects1.length = 0;
gdjs.s360Code.GDAObjects2.length = 0;
gdjs.s360Code.GDcrosshairsObjects1.length = 0;
gdjs.s360Code.GDcrosshairsObjects2.length = 0;
gdjs.s360Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s360Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s360Code.GDDOWNcolObjects1.length = 0;
gdjs.s360Code.GDDOWNcolObjects2.length = 0;
gdjs.s360Code.GDUPbuttonObjects1.length = 0;
gdjs.s360Code.GDUPbuttonObjects2.length = 0;
gdjs.s360Code.GDUPcolObjects1.length = 0;
gdjs.s360Code.GDUPcolObjects2.length = 0;
gdjs.s360Code.GDLbuttonObjects1.length = 0;
gdjs.s360Code.GDLbuttonObjects2.length = 0;
gdjs.s360Code.GDLcolObjects1.length = 0;
gdjs.s360Code.GDLcolObjects2.length = 0;
gdjs.s360Code.GDRbuttonObjects1.length = 0;
gdjs.s360Code.GDRbuttonObjects2.length = 0;
gdjs.s360Code.GDRcolObjects1.length = 0;
gdjs.s360Code.GDRcolObjects2.length = 0;
gdjs.s360Code.GDchapter4Objects1.length = 0;
gdjs.s360Code.GDchapter4Objects2.length = 0;
gdjs.s360Code.GDchapter3Objects1.length = 0;
gdjs.s360Code.GDchapter3Objects2.length = 0;
gdjs.s360Code.GDchapter2Objects1.length = 0;
gdjs.s360Code.GDchapter2Objects2.length = 0;
gdjs.s360Code.GDblackObjects1.length = 0;
gdjs.s360Code.GDblackObjects2.length = 0;
gdjs.s360Code.GDchapter1Objects1.length = 0;
gdjs.s360Code.GDchapter1Objects2.length = 0;

gdjs.s360Code.eventsList0(runtimeScene);
return;

}

gdjs['s360Code'] = gdjs.s360Code;
