gdjs.s71Code = {};
gdjs.s71Code.GDcaseObjects1= [];
gdjs.s71Code.GDcaseObjects2= [];
gdjs.s71Code.GDimageObjects1= [];
gdjs.s71Code.GDimageObjects2= [];
gdjs.s71Code.GDoffObjects1= [];
gdjs.s71Code.GDoffObjects2= [];
gdjs.s71Code.GDonObjects1= [];
gdjs.s71Code.GDonObjects2= [];
gdjs.s71Code.GDstartObjects1= [];
gdjs.s71Code.GDstartObjects2= [];
gdjs.s71Code.GDBObjects1= [];
gdjs.s71Code.GDBObjects2= [];
gdjs.s71Code.GDblackObjects1= [];
gdjs.s71Code.GDblackObjects2= [];
gdjs.s71Code.GDAObjects1= [];
gdjs.s71Code.GDAObjects2= [];

gdjs.s71Code.conditionTrue_0 = {val:false};
gdjs.s71Code.condition0IsTrue_0 = {val:false};
gdjs.s71Code.condition1IsTrue_0 = {val:false};


gdjs.s71Code.mapOfGDgdjs_46s71Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s71Code.GDstartObjects1});gdjs.s71Code.mapOfGDgdjs_46s71Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s71Code.GDoffObjects1});gdjs.s71Code.mapOfGDgdjs_46s71Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s71Code.GDonObjects1});gdjs.s71Code.mapOfGDgdjs_46s71Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s71Code.GDAObjects1});gdjs.s71Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s71Code.GDstartObjects1);

gdjs.s71Code.condition0IsTrue_0.val = false;
{
gdjs.s71Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s71Code.mapOfGDgdjs_46s71Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s71Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s71Code.GDoffObjects1);

gdjs.s71Code.condition0IsTrue_0.val = false;
{
gdjs.s71Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s71Code.mapOfGDgdjs_46s71Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s71Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s71Code.GDonObjects1);

gdjs.s71Code.condition0IsTrue_0.val = false;
{
gdjs.s71Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s71Code.mapOfGDgdjs_46s71Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s71Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s71Code.condition0IsTrue_0.val = false;
{
gdjs.s71Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s71Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s72.1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s71Code.GDAObjects1);

gdjs.s71Code.condition0IsTrue_0.val = false;
{
gdjs.s71Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s71Code.mapOfGDgdjs_46s71Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s71Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s72.1", false);
}}

}


{


{
}

}


};

gdjs.s71Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s71Code.GDcaseObjects1.length = 0;
gdjs.s71Code.GDcaseObjects2.length = 0;
gdjs.s71Code.GDimageObjects1.length = 0;
gdjs.s71Code.GDimageObjects2.length = 0;
gdjs.s71Code.GDoffObjects1.length = 0;
gdjs.s71Code.GDoffObjects2.length = 0;
gdjs.s71Code.GDonObjects1.length = 0;
gdjs.s71Code.GDonObjects2.length = 0;
gdjs.s71Code.GDstartObjects1.length = 0;
gdjs.s71Code.GDstartObjects2.length = 0;
gdjs.s71Code.GDBObjects1.length = 0;
gdjs.s71Code.GDBObjects2.length = 0;
gdjs.s71Code.GDblackObjects1.length = 0;
gdjs.s71Code.GDblackObjects2.length = 0;
gdjs.s71Code.GDAObjects1.length = 0;
gdjs.s71Code.GDAObjects2.length = 0;

gdjs.s71Code.eventsList0(runtimeScene);
return;

}

gdjs['s71Code'] = gdjs.s71Code;
