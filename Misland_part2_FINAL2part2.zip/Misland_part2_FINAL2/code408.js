gdjs.s364Code = {};
gdjs.s364Code.GDcaseObjects1= [];
gdjs.s364Code.GDcaseObjects2= [];
gdjs.s364Code.GDimageObjects1= [];
gdjs.s364Code.GDimageObjects2= [];
gdjs.s364Code.GDoffObjects1= [];
gdjs.s364Code.GDoffObjects2= [];
gdjs.s364Code.GDonObjects1= [];
gdjs.s364Code.GDonObjects2= [];
gdjs.s364Code.GDstartObjects1= [];
gdjs.s364Code.GDstartObjects2= [];
gdjs.s364Code.GDBObjects1= [];
gdjs.s364Code.GDBObjects2= [];
gdjs.s364Code.GDblackObjects1= [];
gdjs.s364Code.GDblackObjects2= [];
gdjs.s364Code.GDAObjects1= [];
gdjs.s364Code.GDAObjects2= [];

gdjs.s364Code.conditionTrue_0 = {val:false};
gdjs.s364Code.condition0IsTrue_0 = {val:false};
gdjs.s364Code.condition1IsTrue_0 = {val:false};
gdjs.s364Code.conditionTrue_1 = {val:false};
gdjs.s364Code.condition0IsTrue_1 = {val:false};
gdjs.s364Code.condition1IsTrue_1 = {val:false};


gdjs.s364Code.mapOfGDgdjs_46s364Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s364Code.GDoffObjects1});gdjs.s364Code.mapOfGDgdjs_46s364Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s364Code.GDonObjects1});gdjs.s364Code.mapOfGDgdjs_46s364Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s364Code.GDAObjects1});gdjs.s364Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s364Code.condition0IsTrue_0.val = false;
{
{gdjs.s364Code.conditionTrue_1 = gdjs.s364Code.condition0IsTrue_0;
gdjs.s364Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(94790228);
}
}if (gdjs.s364Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "scuba_wreck.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s364Code.GDoffObjects1);

gdjs.s364Code.condition0IsTrue_0.val = false;
{
gdjs.s364Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s364Code.mapOfGDgdjs_46s364Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s364Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s364Code.GDonObjects1);

gdjs.s364Code.condition0IsTrue_0.val = false;
{
gdjs.s364Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s364Code.mapOfGDgdjs_46s364Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s364Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s364Code.condition0IsTrue_0.val = false;
{
gdjs.s364Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s364Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s365", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s364Code.GDAObjects1);

gdjs.s364Code.condition0IsTrue_0.val = false;
{
gdjs.s364Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s364Code.mapOfGDgdjs_46s364Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s364Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s365", false);
}}

}


{


{
}

}


};

gdjs.s364Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s364Code.GDcaseObjects1.length = 0;
gdjs.s364Code.GDcaseObjects2.length = 0;
gdjs.s364Code.GDimageObjects1.length = 0;
gdjs.s364Code.GDimageObjects2.length = 0;
gdjs.s364Code.GDoffObjects1.length = 0;
gdjs.s364Code.GDoffObjects2.length = 0;
gdjs.s364Code.GDonObjects1.length = 0;
gdjs.s364Code.GDonObjects2.length = 0;
gdjs.s364Code.GDstartObjects1.length = 0;
gdjs.s364Code.GDstartObjects2.length = 0;
gdjs.s364Code.GDBObjects1.length = 0;
gdjs.s364Code.GDBObjects2.length = 0;
gdjs.s364Code.GDblackObjects1.length = 0;
gdjs.s364Code.GDblackObjects2.length = 0;
gdjs.s364Code.GDAObjects1.length = 0;
gdjs.s364Code.GDAObjects2.length = 0;

gdjs.s364Code.eventsList0(runtimeScene);
return;

}

gdjs['s364Code'] = gdjs.s364Code;
