gdjs.s326Code = {};
gdjs.s326Code.GDcaseObjects1= [];
gdjs.s326Code.GDcaseObjects2= [];
gdjs.s326Code.GDimageObjects1= [];
gdjs.s326Code.GDimageObjects2= [];
gdjs.s326Code.GDoffObjects1= [];
gdjs.s326Code.GDoffObjects2= [];
gdjs.s326Code.GDonObjects1= [];
gdjs.s326Code.GDonObjects2= [];
gdjs.s326Code.GDstartObjects1= [];
gdjs.s326Code.GDstartObjects2= [];
gdjs.s326Code.GDBObjects1= [];
gdjs.s326Code.GDBObjects2= [];
gdjs.s326Code.GDblackObjects1= [];
gdjs.s326Code.GDblackObjects2= [];
gdjs.s326Code.GDAObjects1= [];
gdjs.s326Code.GDAObjects2= [];

gdjs.s326Code.conditionTrue_0 = {val:false};
gdjs.s326Code.condition0IsTrue_0 = {val:false};
gdjs.s326Code.condition1IsTrue_0 = {val:false};


gdjs.s326Code.mapOfGDgdjs_46s326Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s326Code.GDoffObjects1});gdjs.s326Code.mapOfGDgdjs_46s326Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s326Code.GDonObjects1});gdjs.s326Code.mapOfGDgdjs_46s326Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s326Code.GDAObjects1});gdjs.s326Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s326Code.GDoffObjects1);

gdjs.s326Code.condition0IsTrue_0.val = false;
{
gdjs.s326Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s326Code.mapOfGDgdjs_46s326Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s326Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s326Code.GDonObjects1);

gdjs.s326Code.condition0IsTrue_0.val = false;
{
gdjs.s326Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s326Code.mapOfGDgdjs_46s326Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s326Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s326Code.condition0IsTrue_0.val = false;
{
gdjs.s326Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s326Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s327", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s326Code.GDAObjects1);

gdjs.s326Code.condition0IsTrue_0.val = false;
{
gdjs.s326Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s326Code.mapOfGDgdjs_46s326Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s326Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s327", false);
}}

}


{


{
}

}


};

gdjs.s326Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s326Code.GDcaseObjects1.length = 0;
gdjs.s326Code.GDcaseObjects2.length = 0;
gdjs.s326Code.GDimageObjects1.length = 0;
gdjs.s326Code.GDimageObjects2.length = 0;
gdjs.s326Code.GDoffObjects1.length = 0;
gdjs.s326Code.GDoffObjects2.length = 0;
gdjs.s326Code.GDonObjects1.length = 0;
gdjs.s326Code.GDonObjects2.length = 0;
gdjs.s326Code.GDstartObjects1.length = 0;
gdjs.s326Code.GDstartObjects2.length = 0;
gdjs.s326Code.GDBObjects1.length = 0;
gdjs.s326Code.GDBObjects2.length = 0;
gdjs.s326Code.GDblackObjects1.length = 0;
gdjs.s326Code.GDblackObjects2.length = 0;
gdjs.s326Code.GDAObjects1.length = 0;
gdjs.s326Code.GDAObjects2.length = 0;

gdjs.s326Code.eventsList0(runtimeScene);
return;

}

gdjs['s326Code'] = gdjs.s326Code;
