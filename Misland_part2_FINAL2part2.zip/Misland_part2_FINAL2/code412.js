gdjs.s369Code = {};
gdjs.s369Code.GDcaseObjects1= [];
gdjs.s369Code.GDcaseObjects2= [];
gdjs.s369Code.GDimageObjects1= [];
gdjs.s369Code.GDimageObjects2= [];
gdjs.s369Code.GDoffObjects1= [];
gdjs.s369Code.GDoffObjects2= [];
gdjs.s369Code.GDonObjects1= [];
gdjs.s369Code.GDonObjects2= [];
gdjs.s369Code.GDstartObjects1= [];
gdjs.s369Code.GDstartObjects2= [];
gdjs.s369Code.GDBObjects1= [];
gdjs.s369Code.GDBObjects2= [];
gdjs.s369Code.GDblackObjects1= [];
gdjs.s369Code.GDblackObjects2= [];
gdjs.s369Code.GDAObjects1= [];
gdjs.s369Code.GDAObjects2= [];

gdjs.s369Code.conditionTrue_0 = {val:false};
gdjs.s369Code.condition0IsTrue_0 = {val:false};
gdjs.s369Code.condition1IsTrue_0 = {val:false};


gdjs.s369Code.mapOfGDgdjs_46s369Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s369Code.GDoffObjects1});gdjs.s369Code.mapOfGDgdjs_46s369Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s369Code.GDonObjects1});gdjs.s369Code.mapOfGDgdjs_46s369Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s369Code.GDAObjects1});gdjs.s369Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s369Code.GDoffObjects1);

gdjs.s369Code.condition0IsTrue_0.val = false;
{
gdjs.s369Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s369Code.mapOfGDgdjs_46s369Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s369Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s369Code.GDonObjects1);

gdjs.s369Code.condition0IsTrue_0.val = false;
{
gdjs.s369Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s369Code.mapOfGDgdjs_46s369Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s369Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s369Code.condition0IsTrue_0.val = false;
{
gdjs.s369Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s369Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s370", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s369Code.GDAObjects1);

gdjs.s369Code.condition0IsTrue_0.val = false;
{
gdjs.s369Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s369Code.mapOfGDgdjs_46s369Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s369Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s370", false);
}}

}


{


{
}

}


};

gdjs.s369Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s369Code.GDcaseObjects1.length = 0;
gdjs.s369Code.GDcaseObjects2.length = 0;
gdjs.s369Code.GDimageObjects1.length = 0;
gdjs.s369Code.GDimageObjects2.length = 0;
gdjs.s369Code.GDoffObjects1.length = 0;
gdjs.s369Code.GDoffObjects2.length = 0;
gdjs.s369Code.GDonObjects1.length = 0;
gdjs.s369Code.GDonObjects2.length = 0;
gdjs.s369Code.GDstartObjects1.length = 0;
gdjs.s369Code.GDstartObjects2.length = 0;
gdjs.s369Code.GDBObjects1.length = 0;
gdjs.s369Code.GDBObjects2.length = 0;
gdjs.s369Code.GDblackObjects1.length = 0;
gdjs.s369Code.GDblackObjects2.length = 0;
gdjs.s369Code.GDAObjects1.length = 0;
gdjs.s369Code.GDAObjects2.length = 0;

gdjs.s369Code.eventsList0(runtimeScene);
return;

}

gdjs['s369Code'] = gdjs.s369Code;
