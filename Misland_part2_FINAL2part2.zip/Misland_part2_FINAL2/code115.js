gdjs.s97Code = {};
gdjs.s97Code.GDcaseObjects1= [];
gdjs.s97Code.GDcaseObjects2= [];
gdjs.s97Code.GDimageObjects1= [];
gdjs.s97Code.GDimageObjects2= [];
gdjs.s97Code.GDoffObjects1= [];
gdjs.s97Code.GDoffObjects2= [];
gdjs.s97Code.GDonObjects1= [];
gdjs.s97Code.GDonObjects2= [];
gdjs.s97Code.GDstartObjects1= [];
gdjs.s97Code.GDstartObjects2= [];
gdjs.s97Code.GDBObjects1= [];
gdjs.s97Code.GDBObjects2= [];
gdjs.s97Code.GDAObjects1= [];
gdjs.s97Code.GDAObjects2= [];
gdjs.s97Code.GDcrosshairsObjects1= [];
gdjs.s97Code.GDcrosshairsObjects2= [];
gdjs.s97Code.GDDOWNbuttonObjects1= [];
gdjs.s97Code.GDDOWNbuttonObjects2= [];
gdjs.s97Code.GDDOWNcolObjects1= [];
gdjs.s97Code.GDDOWNcolObjects2= [];
gdjs.s97Code.GDUPbuttonObjects1= [];
gdjs.s97Code.GDUPbuttonObjects2= [];
gdjs.s97Code.GDUPcolObjects1= [];
gdjs.s97Code.GDUPcolObjects2= [];
gdjs.s97Code.GDLbuttonObjects1= [];
gdjs.s97Code.GDLbuttonObjects2= [];
gdjs.s97Code.GDLcolObjects1= [];
gdjs.s97Code.GDLcolObjects2= [];
gdjs.s97Code.GDRbuttonObjects1= [];
gdjs.s97Code.GDRbuttonObjects2= [];
gdjs.s97Code.GDRcolObjects1= [];
gdjs.s97Code.GDRcolObjects2= [];
gdjs.s97Code.GDchapter4Objects1= [];
gdjs.s97Code.GDchapter4Objects2= [];
gdjs.s97Code.GDchapter3Objects1= [];
gdjs.s97Code.GDchapter3Objects2= [];
gdjs.s97Code.GDchapter2Objects1= [];
gdjs.s97Code.GDchapter2Objects2= [];
gdjs.s97Code.GDblackObjects1= [];
gdjs.s97Code.GDblackObjects2= [];
gdjs.s97Code.GDchapter1Objects1= [];
gdjs.s97Code.GDchapter1Objects2= [];

gdjs.s97Code.conditionTrue_0 = {val:false};
gdjs.s97Code.condition0IsTrue_0 = {val:false};
gdjs.s97Code.condition1IsTrue_0 = {val:false};
gdjs.s97Code.condition2IsTrue_0 = {val:false};


gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s97Code.GDDOWNbuttonObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s97Code.GDUPbuttonObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s97Code.GDRbuttonObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s97Code.GDLbuttonObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s97Code.GDcrosshairsObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s97Code.GDRcolObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s97Code.GDcrosshairsObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s97Code.GDLcolObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s97Code.GDcrosshairsObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s97Code.GDUPcolObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s97Code.GDcrosshairsObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s97Code.GDDOWNcolObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s97Code.GDcrosshairsObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s97Code.GDDOWNcolObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s97Code.GDoffObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s97Code.GDonObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s97Code.GDcrosshairsObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDchapter2Objects1Objects = Hashtable.newFrom({"chapter2": gdjs.s97Code.GDchapter2Objects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s97Code.GDAObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s97Code.GDcrosshairsObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDchapter2Objects1Objects = Hashtable.newFrom({"chapter2": gdjs.s97Code.GDchapter2Objects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s97Code.GDcrosshairsObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s97Code.GDchapter1Objects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s97Code.GDAObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s97Code.GDcrosshairsObjects1});gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s97Code.GDchapter1Objects1});gdjs.s97Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s97Code.GDDOWNbuttonObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
gdjs.s97Code.condition1IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s97Code.condition0IsTrue_0.val ) {
{
gdjs.s97Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s97Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s97Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s97Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s97Code.GDUPbuttonObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
gdjs.s97Code.condition1IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s97Code.condition0IsTrue_0.val ) {
{
gdjs.s97Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s97Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s97Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s97Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s97Code.GDRbuttonObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
gdjs.s97Code.condition1IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s97Code.condition0IsTrue_0.val ) {
{
gdjs.s97Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s97Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s97Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s97Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s97Code.GDLbuttonObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
gdjs.s97Code.condition1IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s97Code.condition0IsTrue_0.val ) {
{
gdjs.s97Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s97Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s97Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s97Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s97Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects, gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s97Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s97Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s97Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s97Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s97Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects, gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s97Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s97Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s97Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s97Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s97Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects, gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s97Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s97Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s97Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s97Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s97Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects, gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s97Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s97Code.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s97Code.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s97Code.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s97Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects, gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s97Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s97Code.GDoffObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s97Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s97Code.GDonObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s97Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s97Code.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter2"), gdjs.s97Code.GDchapter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
gdjs.s97Code.condition1IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects, gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDchapter2Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s97Code.condition0IsTrue_0.val ) {
{
gdjs.s97Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.s97Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s95.1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter2"), gdjs.s97Code.GDchapter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
gdjs.s97Code.condition1IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects, gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDchapter2Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s97Code.condition0IsTrue_0.val ) {
{
gdjs.s97Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s97Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s95.1", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s97Code.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s97Code.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
gdjs.s97Code.condition1IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects, gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s97Code.condition0IsTrue_0.val ) {
{
gdjs.s97Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.s97Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s98", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s97Code.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s97Code.GDcrosshairsObjects1);

gdjs.s97Code.condition0IsTrue_0.val = false;
gdjs.s97Code.condition1IsTrue_0.val = false;
{
gdjs.s97Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDcrosshairsObjects1Objects, gdjs.s97Code.mapOfGDgdjs_46s97Code_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s97Code.condition0IsTrue_0.val ) {
{
gdjs.s97Code.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s97Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s98", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s97Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s97Code.GDcaseObjects1.length = 0;
gdjs.s97Code.GDcaseObjects2.length = 0;
gdjs.s97Code.GDimageObjects1.length = 0;
gdjs.s97Code.GDimageObjects2.length = 0;
gdjs.s97Code.GDoffObjects1.length = 0;
gdjs.s97Code.GDoffObjects2.length = 0;
gdjs.s97Code.GDonObjects1.length = 0;
gdjs.s97Code.GDonObjects2.length = 0;
gdjs.s97Code.GDstartObjects1.length = 0;
gdjs.s97Code.GDstartObjects2.length = 0;
gdjs.s97Code.GDBObjects1.length = 0;
gdjs.s97Code.GDBObjects2.length = 0;
gdjs.s97Code.GDAObjects1.length = 0;
gdjs.s97Code.GDAObjects2.length = 0;
gdjs.s97Code.GDcrosshairsObjects1.length = 0;
gdjs.s97Code.GDcrosshairsObjects2.length = 0;
gdjs.s97Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s97Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s97Code.GDDOWNcolObjects1.length = 0;
gdjs.s97Code.GDDOWNcolObjects2.length = 0;
gdjs.s97Code.GDUPbuttonObjects1.length = 0;
gdjs.s97Code.GDUPbuttonObjects2.length = 0;
gdjs.s97Code.GDUPcolObjects1.length = 0;
gdjs.s97Code.GDUPcolObjects2.length = 0;
gdjs.s97Code.GDLbuttonObjects1.length = 0;
gdjs.s97Code.GDLbuttonObjects2.length = 0;
gdjs.s97Code.GDLcolObjects1.length = 0;
gdjs.s97Code.GDLcolObjects2.length = 0;
gdjs.s97Code.GDRbuttonObjects1.length = 0;
gdjs.s97Code.GDRbuttonObjects2.length = 0;
gdjs.s97Code.GDRcolObjects1.length = 0;
gdjs.s97Code.GDRcolObjects2.length = 0;
gdjs.s97Code.GDchapter4Objects1.length = 0;
gdjs.s97Code.GDchapter4Objects2.length = 0;
gdjs.s97Code.GDchapter3Objects1.length = 0;
gdjs.s97Code.GDchapter3Objects2.length = 0;
gdjs.s97Code.GDchapter2Objects1.length = 0;
gdjs.s97Code.GDchapter2Objects2.length = 0;
gdjs.s97Code.GDblackObjects1.length = 0;
gdjs.s97Code.GDblackObjects2.length = 0;
gdjs.s97Code.GDchapter1Objects1.length = 0;
gdjs.s97Code.GDchapter1Objects2.length = 0;

gdjs.s97Code.eventsList0(runtimeScene);
return;

}

gdjs['s97Code'] = gdjs.s97Code;
