gdjs.s298Code = {};
gdjs.s298Code.GDcaseObjects1= [];
gdjs.s298Code.GDcaseObjects2= [];
gdjs.s298Code.GDimageObjects1= [];
gdjs.s298Code.GDimageObjects2= [];
gdjs.s298Code.GDoffObjects1= [];
gdjs.s298Code.GDoffObjects2= [];
gdjs.s298Code.GDonObjects1= [];
gdjs.s298Code.GDonObjects2= [];
gdjs.s298Code.GDstartObjects1= [];
gdjs.s298Code.GDstartObjects2= [];
gdjs.s298Code.GDBObjects1= [];
gdjs.s298Code.GDBObjects2= [];
gdjs.s298Code.GDblackObjects1= [];
gdjs.s298Code.GDblackObjects2= [];
gdjs.s298Code.GDAObjects1= [];
gdjs.s298Code.GDAObjects2= [];

gdjs.s298Code.conditionTrue_0 = {val:false};
gdjs.s298Code.condition0IsTrue_0 = {val:false};
gdjs.s298Code.condition1IsTrue_0 = {val:false};


gdjs.s298Code.mapOfGDgdjs_46s298Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s298Code.GDoffObjects1});gdjs.s298Code.mapOfGDgdjs_46s298Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s298Code.GDonObjects1});gdjs.s298Code.mapOfGDgdjs_46s298Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s298Code.GDBObjects1});gdjs.s298Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s298Code.GDoffObjects1);

gdjs.s298Code.condition0IsTrue_0.val = false;
{
gdjs.s298Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s298Code.mapOfGDgdjs_46s298Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s298Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s298Code.GDonObjects1);

gdjs.s298Code.condition0IsTrue_0.val = false;
{
gdjs.s298Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s298Code.mapOfGDgdjs_46s298Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s298Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s298Code.condition0IsTrue_0.val = false;
{
gdjs.s298Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s298Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s299", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s298Code.GDBObjects1);

gdjs.s298Code.condition0IsTrue_0.val = false;
{
gdjs.s298Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s298Code.mapOfGDgdjs_46s298Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s298Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s299", false);
}}

}


{


{
}

}


};

gdjs.s298Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s298Code.GDcaseObjects1.length = 0;
gdjs.s298Code.GDcaseObjects2.length = 0;
gdjs.s298Code.GDimageObjects1.length = 0;
gdjs.s298Code.GDimageObjects2.length = 0;
gdjs.s298Code.GDoffObjects1.length = 0;
gdjs.s298Code.GDoffObjects2.length = 0;
gdjs.s298Code.GDonObjects1.length = 0;
gdjs.s298Code.GDonObjects2.length = 0;
gdjs.s298Code.GDstartObjects1.length = 0;
gdjs.s298Code.GDstartObjects2.length = 0;
gdjs.s298Code.GDBObjects1.length = 0;
gdjs.s298Code.GDBObjects2.length = 0;
gdjs.s298Code.GDblackObjects1.length = 0;
gdjs.s298Code.GDblackObjects2.length = 0;
gdjs.s298Code.GDAObjects1.length = 0;
gdjs.s298Code.GDAObjects2.length = 0;

gdjs.s298Code.eventsList0(runtimeScene);
return;

}

gdjs['s298Code'] = gdjs.s298Code;
