gdjs.s222Code = {};
gdjs.s222Code.GDcaseObjects1= [];
gdjs.s222Code.GDcaseObjects2= [];
gdjs.s222Code.GDimageObjects1= [];
gdjs.s222Code.GDimageObjects2= [];
gdjs.s222Code.GDoffObjects1= [];
gdjs.s222Code.GDoffObjects2= [];
gdjs.s222Code.GDonObjects1= [];
gdjs.s222Code.GDonObjects2= [];
gdjs.s222Code.GDstartObjects1= [];
gdjs.s222Code.GDstartObjects2= [];
gdjs.s222Code.GDBObjects1= [];
gdjs.s222Code.GDBObjects2= [];
gdjs.s222Code.GDblackObjects1= [];
gdjs.s222Code.GDblackObjects2= [];
gdjs.s222Code.GDAObjects1= [];
gdjs.s222Code.GDAObjects2= [];
gdjs.s222Code.GDbuttonObjects1= [];
gdjs.s222Code.GDbuttonObjects2= [];

gdjs.s222Code.conditionTrue_0 = {val:false};
gdjs.s222Code.condition0IsTrue_0 = {val:false};
gdjs.s222Code.condition1IsTrue_0 = {val:false};


gdjs.s222Code.mapOfGDgdjs_46s222Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s222Code.GDoffObjects1});gdjs.s222Code.mapOfGDgdjs_46s222Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s222Code.GDonObjects1});gdjs.s222Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s222Code.GDcaseObjects1);

gdjs.s222Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s222Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s222Code.GDcaseObjects1[i].timerElapsedTime("", 0.8) ) {
        gdjs.s222Code.condition0IsTrue_0.val = true;
        gdjs.s222Code.GDcaseObjects1[k] = gdjs.s222Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s222Code.GDcaseObjects1.length = k;}if (gdjs.s222Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s223", false);
}}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s222Code.GDoffObjects1);

gdjs.s222Code.condition0IsTrue_0.val = false;
{
gdjs.s222Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s222Code.mapOfGDgdjs_46s222Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s222Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s222Code.GDonObjects1);

gdjs.s222Code.condition0IsTrue_0.val = false;
{
gdjs.s222Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s222Code.mapOfGDgdjs_46s222Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s222Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s222Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s222Code.GDcaseObjects1.length = 0;
gdjs.s222Code.GDcaseObjects2.length = 0;
gdjs.s222Code.GDimageObjects1.length = 0;
gdjs.s222Code.GDimageObjects2.length = 0;
gdjs.s222Code.GDoffObjects1.length = 0;
gdjs.s222Code.GDoffObjects2.length = 0;
gdjs.s222Code.GDonObjects1.length = 0;
gdjs.s222Code.GDonObjects2.length = 0;
gdjs.s222Code.GDstartObjects1.length = 0;
gdjs.s222Code.GDstartObjects2.length = 0;
gdjs.s222Code.GDBObjects1.length = 0;
gdjs.s222Code.GDBObjects2.length = 0;
gdjs.s222Code.GDblackObjects1.length = 0;
gdjs.s222Code.GDblackObjects2.length = 0;
gdjs.s222Code.GDAObjects1.length = 0;
gdjs.s222Code.GDAObjects2.length = 0;
gdjs.s222Code.GDbuttonObjects1.length = 0;
gdjs.s222Code.GDbuttonObjects2.length = 0;

gdjs.s222Code.eventsList0(runtimeScene);
return;

}

gdjs['s222Code'] = gdjs.s222Code;
