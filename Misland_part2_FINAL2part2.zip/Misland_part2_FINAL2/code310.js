gdjs.s273Code = {};
gdjs.s273Code.GDcaseObjects1= [];
gdjs.s273Code.GDcaseObjects2= [];
gdjs.s273Code.GDimageObjects1= [];
gdjs.s273Code.GDimageObjects2= [];
gdjs.s273Code.GDoffObjects1= [];
gdjs.s273Code.GDoffObjects2= [];
gdjs.s273Code.GDonObjects1= [];
gdjs.s273Code.GDonObjects2= [];
gdjs.s273Code.GDstartObjects1= [];
gdjs.s273Code.GDstartObjects2= [];
gdjs.s273Code.GDBObjects1= [];
gdjs.s273Code.GDBObjects2= [];
gdjs.s273Code.GDblackObjects1= [];
gdjs.s273Code.GDblackObjects2= [];
gdjs.s273Code.GDAObjects1= [];
gdjs.s273Code.GDAObjects2= [];

gdjs.s273Code.conditionTrue_0 = {val:false};
gdjs.s273Code.condition0IsTrue_0 = {val:false};
gdjs.s273Code.condition1IsTrue_0 = {val:false};


gdjs.s273Code.mapOfGDgdjs_46s273Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s273Code.GDoffObjects1});gdjs.s273Code.mapOfGDgdjs_46s273Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s273Code.GDonObjects1});gdjs.s273Code.mapOfGDgdjs_46s273Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s273Code.GDBObjects1});gdjs.s273Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s273Code.GDoffObjects1);

gdjs.s273Code.condition0IsTrue_0.val = false;
{
gdjs.s273Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s273Code.mapOfGDgdjs_46s273Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s273Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s273Code.GDonObjects1);

gdjs.s273Code.condition0IsTrue_0.val = false;
{
gdjs.s273Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s273Code.mapOfGDgdjs_46s273Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s273Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s273Code.condition0IsTrue_0.val = false;
{
gdjs.s273Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s273Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s274", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s273Code.GDBObjects1);

gdjs.s273Code.condition0IsTrue_0.val = false;
{
gdjs.s273Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s273Code.mapOfGDgdjs_46s273Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s273Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s274", false);
}}

}


{


{
}

}


};

gdjs.s273Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s273Code.GDcaseObjects1.length = 0;
gdjs.s273Code.GDcaseObjects2.length = 0;
gdjs.s273Code.GDimageObjects1.length = 0;
gdjs.s273Code.GDimageObjects2.length = 0;
gdjs.s273Code.GDoffObjects1.length = 0;
gdjs.s273Code.GDoffObjects2.length = 0;
gdjs.s273Code.GDonObjects1.length = 0;
gdjs.s273Code.GDonObjects2.length = 0;
gdjs.s273Code.GDstartObjects1.length = 0;
gdjs.s273Code.GDstartObjects2.length = 0;
gdjs.s273Code.GDBObjects1.length = 0;
gdjs.s273Code.GDBObjects2.length = 0;
gdjs.s273Code.GDblackObjects1.length = 0;
gdjs.s273Code.GDblackObjects2.length = 0;
gdjs.s273Code.GDAObjects1.length = 0;
gdjs.s273Code.GDAObjects2.length = 0;

gdjs.s273Code.eventsList0(runtimeScene);
return;

}

gdjs['s273Code'] = gdjs.s273Code;
