gdjs.s274Code = {};
gdjs.s274Code.GDcaseObjects1= [];
gdjs.s274Code.GDcaseObjects2= [];
gdjs.s274Code.GDimageObjects1= [];
gdjs.s274Code.GDimageObjects2= [];
gdjs.s274Code.GDoffObjects1= [];
gdjs.s274Code.GDoffObjects2= [];
gdjs.s274Code.GDonObjects1= [];
gdjs.s274Code.GDonObjects2= [];
gdjs.s274Code.GDstartObjects1= [];
gdjs.s274Code.GDstartObjects2= [];
gdjs.s274Code.GDBObjects1= [];
gdjs.s274Code.GDBObjects2= [];
gdjs.s274Code.GDblackObjects1= [];
gdjs.s274Code.GDblackObjects2= [];
gdjs.s274Code.GDAObjects1= [];
gdjs.s274Code.GDAObjects2= [];

gdjs.s274Code.conditionTrue_0 = {val:false};
gdjs.s274Code.condition0IsTrue_0 = {val:false};
gdjs.s274Code.condition1IsTrue_0 = {val:false};


gdjs.s274Code.mapOfGDgdjs_46s274Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s274Code.GDoffObjects1});gdjs.s274Code.mapOfGDgdjs_46s274Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s274Code.GDonObjects1});gdjs.s274Code.mapOfGDgdjs_46s274Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s274Code.GDAObjects1});gdjs.s274Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s274Code.GDoffObjects1);

gdjs.s274Code.condition0IsTrue_0.val = false;
{
gdjs.s274Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s274Code.mapOfGDgdjs_46s274Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s274Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s274Code.GDonObjects1);

gdjs.s274Code.condition0IsTrue_0.val = false;
{
gdjs.s274Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s274Code.mapOfGDgdjs_46s274Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s274Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s274Code.condition0IsTrue_0.val = false;
{
gdjs.s274Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s274Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s275", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s274Code.GDAObjects1);

gdjs.s274Code.condition0IsTrue_0.val = false;
{
gdjs.s274Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s274Code.mapOfGDgdjs_46s274Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s274Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s275", false);
}}

}


{


{
}

}


};

gdjs.s274Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s274Code.GDcaseObjects1.length = 0;
gdjs.s274Code.GDcaseObjects2.length = 0;
gdjs.s274Code.GDimageObjects1.length = 0;
gdjs.s274Code.GDimageObjects2.length = 0;
gdjs.s274Code.GDoffObjects1.length = 0;
gdjs.s274Code.GDoffObjects2.length = 0;
gdjs.s274Code.GDonObjects1.length = 0;
gdjs.s274Code.GDonObjects2.length = 0;
gdjs.s274Code.GDstartObjects1.length = 0;
gdjs.s274Code.GDstartObjects2.length = 0;
gdjs.s274Code.GDBObjects1.length = 0;
gdjs.s274Code.GDBObjects2.length = 0;
gdjs.s274Code.GDblackObjects1.length = 0;
gdjs.s274Code.GDblackObjects2.length = 0;
gdjs.s274Code.GDAObjects1.length = 0;
gdjs.s274Code.GDAObjects2.length = 0;

gdjs.s274Code.eventsList0(runtimeScene);
return;

}

gdjs['s274Code'] = gdjs.s274Code;
