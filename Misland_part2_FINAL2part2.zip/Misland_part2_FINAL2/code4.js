gdjs.C5Code = {};
gdjs.C5Code.GDcaseObjects1= [];
gdjs.C5Code.GDcaseObjects2= [];
gdjs.C5Code.GDimageObjects1= [];
gdjs.C5Code.GDimageObjects2= [];
gdjs.C5Code.GDoffObjects1= [];
gdjs.C5Code.GDoffObjects2= [];
gdjs.C5Code.GDonObjects1= [];
gdjs.C5Code.GDonObjects2= [];
gdjs.C5Code.GDstartObjects1= [];
gdjs.C5Code.GDstartObjects2= [];
gdjs.C5Code.GDBObjects1= [];
gdjs.C5Code.GDBObjects2= [];
gdjs.C5Code.GDblackObjects1= [];
gdjs.C5Code.GDblackObjects2= [];
gdjs.C5Code.GDAObjects1= [];
gdjs.C5Code.GDAObjects2= [];

gdjs.C5Code.conditionTrue_0 = {val:false};
gdjs.C5Code.condition0IsTrue_0 = {val:false};
gdjs.C5Code.condition1IsTrue_0 = {val:false};
gdjs.C5Code.conditionTrue_1 = {val:false};
gdjs.C5Code.condition0IsTrue_1 = {val:false};
gdjs.C5Code.condition1IsTrue_1 = {val:false};


gdjs.C5Code.mapOfGDgdjs_46C5Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.C5Code.GDstartObjects1});gdjs.C5Code.mapOfGDgdjs_46C5Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.C5Code.GDoffObjects1});gdjs.C5Code.mapOfGDgdjs_46C5Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.C5Code.GDonObjects1});gdjs.C5Code.mapOfGDgdjs_46C5Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.C5Code.GDBObjects1});gdjs.C5Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.C5Code.condition0IsTrue_0.val = false;
{
{gdjs.C5Code.conditionTrue_1 = gdjs.C5Code.condition0IsTrue_0;
gdjs.C5Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(86232780);
}
}if (gdjs.C5Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter5_v6.mp3", true, 80, 1);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.C5Code.GDstartObjects1);

gdjs.C5Code.condition0IsTrue_0.val = false;
{
gdjs.C5Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C5Code.mapOfGDgdjs_46C5Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.C5Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.C5Code.GDoffObjects1);

gdjs.C5Code.condition0IsTrue_0.val = false;
{
gdjs.C5Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C5Code.mapOfGDgdjs_46C5Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.C5Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.C5Code.GDonObjects1);

gdjs.C5Code.condition0IsTrue_0.val = false;
{
gdjs.C5Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C5Code.mapOfGDgdjs_46C5Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.C5Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.C5Code.condition0IsTrue_0.val = false;
{
gdjs.C5Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.C5Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.C5Code.GDBObjects1);

gdjs.C5Code.condition0IsTrue_0.val = false;
{
gdjs.C5Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C5Code.mapOfGDgdjs_46C5Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.C5Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s1", false);
}}

}


{


{
}

}


};

gdjs.C5Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.C5Code.GDcaseObjects1.length = 0;
gdjs.C5Code.GDcaseObjects2.length = 0;
gdjs.C5Code.GDimageObjects1.length = 0;
gdjs.C5Code.GDimageObjects2.length = 0;
gdjs.C5Code.GDoffObjects1.length = 0;
gdjs.C5Code.GDoffObjects2.length = 0;
gdjs.C5Code.GDonObjects1.length = 0;
gdjs.C5Code.GDonObjects2.length = 0;
gdjs.C5Code.GDstartObjects1.length = 0;
gdjs.C5Code.GDstartObjects2.length = 0;
gdjs.C5Code.GDBObjects1.length = 0;
gdjs.C5Code.GDBObjects2.length = 0;
gdjs.C5Code.GDblackObjects1.length = 0;
gdjs.C5Code.GDblackObjects2.length = 0;
gdjs.C5Code.GDAObjects1.length = 0;
gdjs.C5Code.GDAObjects2.length = 0;

gdjs.C5Code.eventsList0(runtimeScene);
return;

}

gdjs['C5Code'] = gdjs.C5Code;
