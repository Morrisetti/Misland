gdjs.s332Code = {};
gdjs.s332Code.GDcaseObjects1= [];
gdjs.s332Code.GDcaseObjects2= [];
gdjs.s332Code.GDimageObjects1= [];
gdjs.s332Code.GDimageObjects2= [];
gdjs.s332Code.GDoffObjects1= [];
gdjs.s332Code.GDoffObjects2= [];
gdjs.s332Code.GDonObjects1= [];
gdjs.s332Code.GDonObjects2= [];
gdjs.s332Code.GDstartObjects1= [];
gdjs.s332Code.GDstartObjects2= [];
gdjs.s332Code.GDBObjects1= [];
gdjs.s332Code.GDBObjects2= [];
gdjs.s332Code.GDblackObjects1= [];
gdjs.s332Code.GDblackObjects2= [];
gdjs.s332Code.GDAObjects1= [];
gdjs.s332Code.GDAObjects2= [];

gdjs.s332Code.conditionTrue_0 = {val:false};
gdjs.s332Code.condition0IsTrue_0 = {val:false};
gdjs.s332Code.condition1IsTrue_0 = {val:false};


gdjs.s332Code.mapOfGDgdjs_46s332Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s332Code.GDoffObjects1});gdjs.s332Code.mapOfGDgdjs_46s332Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s332Code.GDonObjects1});gdjs.s332Code.mapOfGDgdjs_46s332Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s332Code.GDAObjects1});gdjs.s332Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s332Code.GDoffObjects1);

gdjs.s332Code.condition0IsTrue_0.val = false;
{
gdjs.s332Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s332Code.mapOfGDgdjs_46s332Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s332Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s332Code.GDonObjects1);

gdjs.s332Code.condition0IsTrue_0.val = false;
{
gdjs.s332Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s332Code.mapOfGDgdjs_46s332Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s332Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s332Code.condition0IsTrue_0.val = false;
{
gdjs.s332Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s332Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "C9", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s332Code.GDAObjects1);

gdjs.s332Code.condition0IsTrue_0.val = false;
{
gdjs.s332Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s332Code.mapOfGDgdjs_46s332Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s332Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "C9", false);
}}

}


{


{
}

}


};

gdjs.s332Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s332Code.GDcaseObjects1.length = 0;
gdjs.s332Code.GDcaseObjects2.length = 0;
gdjs.s332Code.GDimageObjects1.length = 0;
gdjs.s332Code.GDimageObjects2.length = 0;
gdjs.s332Code.GDoffObjects1.length = 0;
gdjs.s332Code.GDoffObjects2.length = 0;
gdjs.s332Code.GDonObjects1.length = 0;
gdjs.s332Code.GDonObjects2.length = 0;
gdjs.s332Code.GDstartObjects1.length = 0;
gdjs.s332Code.GDstartObjects2.length = 0;
gdjs.s332Code.GDBObjects1.length = 0;
gdjs.s332Code.GDBObjects2.length = 0;
gdjs.s332Code.GDblackObjects1.length = 0;
gdjs.s332Code.GDblackObjects2.length = 0;
gdjs.s332Code.GDAObjects1.length = 0;
gdjs.s332Code.GDAObjects2.length = 0;

gdjs.s332Code.eventsList0(runtimeScene);
return;

}

gdjs['s332Code'] = gdjs.s332Code;
