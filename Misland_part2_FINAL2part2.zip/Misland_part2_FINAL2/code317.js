gdjs.s282Code = {};
gdjs.s282Code.GDcaseObjects1= [];
gdjs.s282Code.GDcaseObjects2= [];
gdjs.s282Code.GDoffObjects1= [];
gdjs.s282Code.GDoffObjects2= [];
gdjs.s282Code.GDonObjects1= [];
gdjs.s282Code.GDonObjects2= [];
gdjs.s282Code.GDstartObjects1= [];
gdjs.s282Code.GDstartObjects2= [];
gdjs.s282Code.GDBObjects1= [];
gdjs.s282Code.GDBObjects2= [];
gdjs.s282Code.GDAObjects1= [];
gdjs.s282Code.GDAObjects2= [];
gdjs.s282Code.GDbugzObjects1= [];
gdjs.s282Code.GDbugzObjects2= [];
gdjs.s282Code.GDDOWNbuttonObjects1= [];
gdjs.s282Code.GDDOWNbuttonObjects2= [];
gdjs.s282Code.GDblackObjects1= [];
gdjs.s282Code.GDblackObjects2= [];
gdjs.s282Code.GDDOWNcolObjects1= [];
gdjs.s282Code.GDDOWNcolObjects2= [];
gdjs.s282Code.GDUPbuttonObjects1= [];
gdjs.s282Code.GDUPbuttonObjects2= [];
gdjs.s282Code.GDUPcolObjects1= [];
gdjs.s282Code.GDUPcolObjects2= [];
gdjs.s282Code.GDLbuttonObjects1= [];
gdjs.s282Code.GDLbuttonObjects2= [];
gdjs.s282Code.GDLcolObjects1= [];
gdjs.s282Code.GDLcolObjects2= [];
gdjs.s282Code.GDRbuttonObjects1= [];
gdjs.s282Code.GDRbuttonObjects2= [];
gdjs.s282Code.GDexitObjects1= [];
gdjs.s282Code.GDexitObjects2= [];
gdjs.s282Code.GDDeathObjects1= [];
gdjs.s282Code.GDDeathObjects2= [];
gdjs.s282Code.GDRcolObjects1= [];
gdjs.s282Code.GDRcolObjects2= [];
gdjs.s282Code.GDchapter4Objects1= [];
gdjs.s282Code.GDchapter4Objects2= [];
gdjs.s282Code.GDchapter3Objects1= [];
gdjs.s282Code.GDchapter3Objects2= [];
gdjs.s282Code.GDchapter2Objects1= [];
gdjs.s282Code.GDchapter2Objects2= [];
gdjs.s282Code.GDchapter1Objects1= [];
gdjs.s282Code.GDchapter1Objects2= [];
gdjs.s282Code.GDBGObjects1= [];
gdjs.s282Code.GDBGObjects2= [];
gdjs.s282Code.GDshadowObjects1= [];
gdjs.s282Code.GDshadowObjects2= [];

gdjs.s282Code.conditionTrue_0 = {val:false};
gdjs.s282Code.condition0IsTrue_0 = {val:false};
gdjs.s282Code.condition1IsTrue_0 = {val:false};
gdjs.s282Code.condition2IsTrue_0 = {val:false};


gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s282Code.GDDOWNbuttonObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s282Code.GDUPbuttonObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s282Code.GDRbuttonObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s282Code.GDLbuttonObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s282Code.GDbugzObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s282Code.GDRcolObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s282Code.GDbugzObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s282Code.GDLcolObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s282Code.GDbugzObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s282Code.GDUPcolObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s282Code.GDbugzObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s282Code.GDDOWNcolObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s282Code.GDbugzObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s282Code.GDDOWNcolObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s282Code.GDBObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s282Code.GDAObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s282Code.GDoffObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s282Code.GDonObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s282Code.GDbugzObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDDeathObjects1Objects = Hashtable.newFrom({"Death": gdjs.s282Code.GDDeathObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s282Code.GDbugzObjects1});gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.s282Code.GDexitObjects1});gdjs.s282Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s282Code.GDDOWNbuttonObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
gdjs.s282Code.condition1IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s282Code.condition0IsTrue_0.val ) {
{
gdjs.s282Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s282Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s282Code.GDUPbuttonObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
gdjs.s282Code.condition1IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s282Code.condition0IsTrue_0.val ) {
{
gdjs.s282Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s282Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s282Code.GDRbuttonObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
gdjs.s282Code.condition1IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s282Code.condition0IsTrue_0.val ) {
{
gdjs.s282Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s282Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s282Code.GDLbuttonObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
gdjs.s282Code.condition1IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s282Code.condition0IsTrue_0.val ) {
{
gdjs.s282Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s282Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s282Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects, gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s282Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s282Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s282Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects, gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s282Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s282Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s282Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects, gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s282Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s282Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s282Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects, gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s282Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s282Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s282Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects, gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s282Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s282Code.GDBObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s282Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s282Code.GDAObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s282Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s282Code.GDoffObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s282Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s282Code.GDonObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s282Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s282Code.condition0IsTrue_0.val = false;
gdjs.s282Code.condition1IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s282Code.condition0IsTrue_0.val ) {
{
gdjs.s282Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s282Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s282Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s282Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s282Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s282Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s282Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s282Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Death"), gdjs.s282Code.GDDeathObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects, gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDDeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s282Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s281", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.s282Code.GDexitObjects1);

gdjs.s282Code.condition0IsTrue_0.val = false;
{
gdjs.s282Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDbugzObjects1Objects, gdjs.s282Code.mapOfGDgdjs_46s282Code_46GDexitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s282Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s283", false);
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s282Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s282Code.GDbugzObjects1.length !== 0 ? gdjs.s282Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s282Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s282Code.GDcaseObjects1.length = 0;
gdjs.s282Code.GDcaseObjects2.length = 0;
gdjs.s282Code.GDoffObjects1.length = 0;
gdjs.s282Code.GDoffObjects2.length = 0;
gdjs.s282Code.GDonObjects1.length = 0;
gdjs.s282Code.GDonObjects2.length = 0;
gdjs.s282Code.GDstartObjects1.length = 0;
gdjs.s282Code.GDstartObjects2.length = 0;
gdjs.s282Code.GDBObjects1.length = 0;
gdjs.s282Code.GDBObjects2.length = 0;
gdjs.s282Code.GDAObjects1.length = 0;
gdjs.s282Code.GDAObjects2.length = 0;
gdjs.s282Code.GDbugzObjects1.length = 0;
gdjs.s282Code.GDbugzObjects2.length = 0;
gdjs.s282Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s282Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s282Code.GDblackObjects1.length = 0;
gdjs.s282Code.GDblackObjects2.length = 0;
gdjs.s282Code.GDDOWNcolObjects1.length = 0;
gdjs.s282Code.GDDOWNcolObjects2.length = 0;
gdjs.s282Code.GDUPbuttonObjects1.length = 0;
gdjs.s282Code.GDUPbuttonObjects2.length = 0;
gdjs.s282Code.GDUPcolObjects1.length = 0;
gdjs.s282Code.GDUPcolObjects2.length = 0;
gdjs.s282Code.GDLbuttonObjects1.length = 0;
gdjs.s282Code.GDLbuttonObjects2.length = 0;
gdjs.s282Code.GDLcolObjects1.length = 0;
gdjs.s282Code.GDLcolObjects2.length = 0;
gdjs.s282Code.GDRbuttonObjects1.length = 0;
gdjs.s282Code.GDRbuttonObjects2.length = 0;
gdjs.s282Code.GDexitObjects1.length = 0;
gdjs.s282Code.GDexitObjects2.length = 0;
gdjs.s282Code.GDDeathObjects1.length = 0;
gdjs.s282Code.GDDeathObjects2.length = 0;
gdjs.s282Code.GDRcolObjects1.length = 0;
gdjs.s282Code.GDRcolObjects2.length = 0;
gdjs.s282Code.GDchapter4Objects1.length = 0;
gdjs.s282Code.GDchapter4Objects2.length = 0;
gdjs.s282Code.GDchapter3Objects1.length = 0;
gdjs.s282Code.GDchapter3Objects2.length = 0;
gdjs.s282Code.GDchapter2Objects1.length = 0;
gdjs.s282Code.GDchapter2Objects2.length = 0;
gdjs.s282Code.GDchapter1Objects1.length = 0;
gdjs.s282Code.GDchapter1Objects2.length = 0;
gdjs.s282Code.GDBGObjects1.length = 0;
gdjs.s282Code.GDBGObjects2.length = 0;
gdjs.s282Code.GDshadowObjects1.length = 0;
gdjs.s282Code.GDshadowObjects2.length = 0;

gdjs.s282Code.eventsList0(runtimeScene);
return;

}

gdjs['s282Code'] = gdjs.s282Code;
