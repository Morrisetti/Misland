gdjs.s30Code = {};
gdjs.s30Code.GDcaseObjects1= [];
gdjs.s30Code.GDcaseObjects2= [];
gdjs.s30Code.GDoffObjects1= [];
gdjs.s30Code.GDoffObjects2= [];
gdjs.s30Code.GDonObjects1= [];
gdjs.s30Code.GDonObjects2= [];
gdjs.s30Code.GDstartObjects1= [];
gdjs.s30Code.GDstartObjects2= [];
gdjs.s30Code.GDBObjects1= [];
gdjs.s30Code.GDBObjects2= [];
gdjs.s30Code.GDAObjects1= [];
gdjs.s30Code.GDAObjects2= [];
gdjs.s30Code.GDbugzObjects1= [];
gdjs.s30Code.GDbugzObjects2= [];
gdjs.s30Code.GDDOWNbuttonObjects1= [];
gdjs.s30Code.GDDOWNbuttonObjects2= [];
gdjs.s30Code.GDblockObjects1= [];
gdjs.s30Code.GDblockObjects2= [];
gdjs.s30Code.GDblack2Objects1= [];
gdjs.s30Code.GDblack2Objects2= [];
gdjs.s30Code.GDblackObjects1= [];
gdjs.s30Code.GDblackObjects2= [];
gdjs.s30Code.GDdeathObjects1= [];
gdjs.s30Code.GDdeathObjects2= [];
gdjs.s30Code.GDUPbuttonObjects1= [];
gdjs.s30Code.GDUPbuttonObjects2= [];
gdjs.s30Code.GDplatformObjects1= [];
gdjs.s30Code.GDplatformObjects2= [];
gdjs.s30Code.GDLbuttonObjects1= [];
gdjs.s30Code.GDLbuttonObjects2= [];
gdjs.s30Code.GDLcolObjects1= [];
gdjs.s30Code.GDLcolObjects2= [];
gdjs.s30Code.GDRbuttonObjects1= [];
gdjs.s30Code.GDRbuttonObjects2= [];
gdjs.s30Code.GDTALK2Objects1= [];
gdjs.s30Code.GDTALK2Objects2= [];
gdjs.s30Code.GDExitObjects1= [];
gdjs.s30Code.GDExitObjects2= [];
gdjs.s30Code.GDRcolObjects1= [];
gdjs.s30Code.GDRcolObjects2= [];
gdjs.s30Code.GDchapter4Objects1= [];
gdjs.s30Code.GDchapter4Objects2= [];
gdjs.s30Code.GDchapter3Objects1= [];
gdjs.s30Code.GDchapter3Objects2= [];
gdjs.s30Code.GDchapter2Objects1= [];
gdjs.s30Code.GDchapter2Objects2= [];
gdjs.s30Code.GDchapter1Objects1= [];
gdjs.s30Code.GDchapter1Objects2= [];
gdjs.s30Code.GDBGObjects1= [];
gdjs.s30Code.GDBGObjects2= [];

gdjs.s30Code.conditionTrue_0 = {val:false};
gdjs.s30Code.condition0IsTrue_0 = {val:false};
gdjs.s30Code.condition1IsTrue_0 = {val:false};
gdjs.s30Code.condition2IsTrue_0 = {val:false};
gdjs.s30Code.conditionTrue_1 = {val:false};
gdjs.s30Code.condition0IsTrue_1 = {val:false};
gdjs.s30Code.condition1IsTrue_1 = {val:false};
gdjs.s30Code.condition2IsTrue_1 = {val:false};


gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s30Code.GDDOWNbuttonObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s30Code.GDUPbuttonObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s30Code.GDRbuttonObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s30Code.GDLbuttonObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s30Code.GDbugzObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s30Code.GDRcolObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s30Code.GDbugzObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s30Code.GDLcolObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s30Code.GDbugzObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDplatformObjects1Objects = Hashtable.newFrom({"platform": gdjs.s30Code.GDplatformObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s30Code.GDbugzObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDdeathObjects1Objects = Hashtable.newFrom({"death": gdjs.s30Code.GDdeathObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s30Code.GDBObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s30Code.GDAObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s30Code.GDoffObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s30Code.GDonObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s30Code.GDbugzObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s30Code.GDExitObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s30Code.GDbugzObjects1});gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDdeathObjects1Objects = Hashtable.newFrom({"death": gdjs.s30Code.GDdeathObjects1});gdjs.s30Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s30Code.GDDOWNbuttonObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
gdjs.s30Code.condition1IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s30Code.condition0IsTrue_0.val ) {
{
gdjs.s30Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s30Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s30Code.GDUPbuttonObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
gdjs.s30Code.condition1IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s30Code.condition0IsTrue_0.val ) {
{
gdjs.s30Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s30Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s30Code.GDRbuttonObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
gdjs.s30Code.condition1IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s30Code.condition0IsTrue_0.val ) {
{
gdjs.s30Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s30Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s30Code.GDLbuttonObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
gdjs.s30Code.condition1IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s30Code.condition0IsTrue_0.val ) {
{
gdjs.s30Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s30Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].flipX(true);
}
}{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}}

}


{


gdjs.s30Code.condition0IsTrue_0.val = false;
{
{gdjs.s30Code.conditionTrue_1 = gdjs.s30Code.condition0IsTrue_0;
gdjs.s30Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(86974860);
}
}if (gdjs.s30Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chpater_8_v22.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s30Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects, gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s30Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s30Code.GDbugzObjects1 */
{}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s30Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects, gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s30Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s30Code.GDbugzObjects1 */
{}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("platform"), gdjs.s30Code.GDplatformObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects, gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDplatformObjects1Objects, false, runtimeScene, false);
}if (gdjs.s30Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s30Code.GDbugzObjects1 */
{}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s30Code.GDdeathObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects, gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDdeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s30Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s30Code.GDbugzObjects1 */
{}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s30Code.GDBObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s30Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s30Code.GDAObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
gdjs.s30Code.condition1IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDAObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s30Code.condition0IsTrue_0.val ) {
{
{gdjs.s30Code.conditionTrue_1 = gdjs.s30Code.condition1IsTrue_0;
gdjs.s30Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(86979548);
}
}}
if (gdjs.s30Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s30Code.GDoffObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s30Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s30Code.GDonObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s30Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s30Code.condition0IsTrue_0.val = false;
gdjs.s30Code.condition1IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s30Code.condition0IsTrue_0.val ) {
{
gdjs.s30Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s30Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s30Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s30Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects, gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s30Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s30.1", false);
}}

}


{


gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s30Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s30Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s30Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s30Code.GDdeathObjects1);

gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDbugzObjects1Objects, gdjs.s30Code.mapOfGDgdjs_46s30Code_46GDdeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s30Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s28.1", false);
}}

}


{


gdjs.s30Code.condition0IsTrue_0.val = false;
{
gdjs.s30Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s30Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s30Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s30Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s30Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s30Code.GDbugzObjects1.length !== 0 ? gdjs.s30Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s30Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s30Code.GDcaseObjects1.length = 0;
gdjs.s30Code.GDcaseObjects2.length = 0;
gdjs.s30Code.GDoffObjects1.length = 0;
gdjs.s30Code.GDoffObjects2.length = 0;
gdjs.s30Code.GDonObjects1.length = 0;
gdjs.s30Code.GDonObjects2.length = 0;
gdjs.s30Code.GDstartObjects1.length = 0;
gdjs.s30Code.GDstartObjects2.length = 0;
gdjs.s30Code.GDBObjects1.length = 0;
gdjs.s30Code.GDBObjects2.length = 0;
gdjs.s30Code.GDAObjects1.length = 0;
gdjs.s30Code.GDAObjects2.length = 0;
gdjs.s30Code.GDbugzObjects1.length = 0;
gdjs.s30Code.GDbugzObjects2.length = 0;
gdjs.s30Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s30Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s30Code.GDblockObjects1.length = 0;
gdjs.s30Code.GDblockObjects2.length = 0;
gdjs.s30Code.GDblack2Objects1.length = 0;
gdjs.s30Code.GDblack2Objects2.length = 0;
gdjs.s30Code.GDblackObjects1.length = 0;
gdjs.s30Code.GDblackObjects2.length = 0;
gdjs.s30Code.GDdeathObjects1.length = 0;
gdjs.s30Code.GDdeathObjects2.length = 0;
gdjs.s30Code.GDUPbuttonObjects1.length = 0;
gdjs.s30Code.GDUPbuttonObjects2.length = 0;
gdjs.s30Code.GDplatformObjects1.length = 0;
gdjs.s30Code.GDplatformObjects2.length = 0;
gdjs.s30Code.GDLbuttonObjects1.length = 0;
gdjs.s30Code.GDLbuttonObjects2.length = 0;
gdjs.s30Code.GDLcolObjects1.length = 0;
gdjs.s30Code.GDLcolObjects2.length = 0;
gdjs.s30Code.GDRbuttonObjects1.length = 0;
gdjs.s30Code.GDRbuttonObjects2.length = 0;
gdjs.s30Code.GDTALK2Objects1.length = 0;
gdjs.s30Code.GDTALK2Objects2.length = 0;
gdjs.s30Code.GDExitObjects1.length = 0;
gdjs.s30Code.GDExitObjects2.length = 0;
gdjs.s30Code.GDRcolObjects1.length = 0;
gdjs.s30Code.GDRcolObjects2.length = 0;
gdjs.s30Code.GDchapter4Objects1.length = 0;
gdjs.s30Code.GDchapter4Objects2.length = 0;
gdjs.s30Code.GDchapter3Objects1.length = 0;
gdjs.s30Code.GDchapter3Objects2.length = 0;
gdjs.s30Code.GDchapter2Objects1.length = 0;
gdjs.s30Code.GDchapter2Objects2.length = 0;
gdjs.s30Code.GDchapter1Objects1.length = 0;
gdjs.s30Code.GDchapter1Objects2.length = 0;
gdjs.s30Code.GDBGObjects1.length = 0;
gdjs.s30Code.GDBGObjects2.length = 0;

gdjs.s30Code.eventsList0(runtimeScene);
return;

}

gdjs['s30Code'] = gdjs.s30Code;
