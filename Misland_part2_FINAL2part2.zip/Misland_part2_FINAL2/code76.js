gdjs.C6Code = {};
gdjs.C6Code.GDcaseObjects1= [];
gdjs.C6Code.GDcaseObjects2= [];
gdjs.C6Code.GDimageObjects1= [];
gdjs.C6Code.GDimageObjects2= [];
gdjs.C6Code.GDoffObjects1= [];
gdjs.C6Code.GDoffObjects2= [];
gdjs.C6Code.GDonObjects1= [];
gdjs.C6Code.GDonObjects2= [];
gdjs.C6Code.GDstartObjects1= [];
gdjs.C6Code.GDstartObjects2= [];
gdjs.C6Code.GDBObjects1= [];
gdjs.C6Code.GDBObjects2= [];
gdjs.C6Code.GDblackObjects1= [];
gdjs.C6Code.GDblackObjects2= [];
gdjs.C6Code.GDAObjects1= [];
gdjs.C6Code.GDAObjects2= [];

gdjs.C6Code.conditionTrue_0 = {val:false};
gdjs.C6Code.condition0IsTrue_0 = {val:false};
gdjs.C6Code.condition1IsTrue_0 = {val:false};
gdjs.C6Code.conditionTrue_1 = {val:false};
gdjs.C6Code.condition0IsTrue_1 = {val:false};
gdjs.C6Code.condition1IsTrue_1 = {val:false};


gdjs.C6Code.mapOfGDgdjs_46C6Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.C6Code.GDstartObjects1});gdjs.C6Code.mapOfGDgdjs_46C6Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.C6Code.GDoffObjects1});gdjs.C6Code.mapOfGDgdjs_46C6Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.C6Code.GDonObjects1});gdjs.C6Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.C6Code.condition0IsTrue_0.val = false;
{
{gdjs.C6Code.conditionTrue_1 = gdjs.C6Code.condition0IsTrue_0;
gdjs.C6Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(87786068);
}
}if (gdjs.C6Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter5_v6.mp3", true, 80, 1);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.C6Code.GDstartObjects1);

gdjs.C6Code.condition0IsTrue_0.val = false;
{
gdjs.C6Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C6Code.mapOfGDgdjs_46C6Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.C6Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s64", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.C6Code.GDoffObjects1);

gdjs.C6Code.condition0IsTrue_0.val = false;
{
gdjs.C6Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C6Code.mapOfGDgdjs_46C6Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.C6Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.C6Code.GDonObjects1);

gdjs.C6Code.condition0IsTrue_0.val = false;
{
gdjs.C6Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C6Code.mapOfGDgdjs_46C6Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.C6Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.C6Code.condition0IsTrue_0.val = false;
{
gdjs.C6Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.C6Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s64", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.C6Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.C6Code.GDcaseObjects1.length = 0;
gdjs.C6Code.GDcaseObjects2.length = 0;
gdjs.C6Code.GDimageObjects1.length = 0;
gdjs.C6Code.GDimageObjects2.length = 0;
gdjs.C6Code.GDoffObjects1.length = 0;
gdjs.C6Code.GDoffObjects2.length = 0;
gdjs.C6Code.GDonObjects1.length = 0;
gdjs.C6Code.GDonObjects2.length = 0;
gdjs.C6Code.GDstartObjects1.length = 0;
gdjs.C6Code.GDstartObjects2.length = 0;
gdjs.C6Code.GDBObjects1.length = 0;
gdjs.C6Code.GDBObjects2.length = 0;
gdjs.C6Code.GDblackObjects1.length = 0;
gdjs.C6Code.GDblackObjects2.length = 0;
gdjs.C6Code.GDAObjects1.length = 0;
gdjs.C6Code.GDAObjects2.length = 0;

gdjs.C6Code.eventsList0(runtimeScene);
return;

}

gdjs['C6Code'] = gdjs.C6Code;
