gdjs.s15_462Code = {};
gdjs.s15_462Code.GDcaseObjects1= [];
gdjs.s15_462Code.GDcaseObjects2= [];
gdjs.s15_462Code.GDimageObjects1= [];
gdjs.s15_462Code.GDimageObjects2= [];
gdjs.s15_462Code.GDoffObjects1= [];
gdjs.s15_462Code.GDoffObjects2= [];
gdjs.s15_462Code.GDonObjects1= [];
gdjs.s15_462Code.GDonObjects2= [];
gdjs.s15_462Code.GDstartObjects1= [];
gdjs.s15_462Code.GDstartObjects2= [];
gdjs.s15_462Code.GDBObjects1= [];
gdjs.s15_462Code.GDBObjects2= [];
gdjs.s15_462Code.GDblackObjects1= [];
gdjs.s15_462Code.GDblackObjects2= [];
gdjs.s15_462Code.GDAObjects1= [];
gdjs.s15_462Code.GDAObjects2= [];

gdjs.s15_462Code.conditionTrue_0 = {val:false};
gdjs.s15_462Code.condition0IsTrue_0 = {val:false};
gdjs.s15_462Code.condition1IsTrue_0 = {val:false};
gdjs.s15_462Code.conditionTrue_1 = {val:false};
gdjs.s15_462Code.condition0IsTrue_1 = {val:false};
gdjs.s15_462Code.condition1IsTrue_1 = {val:false};


gdjs.s15_462Code.mapOfGDgdjs_46s15_95462Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s15_462Code.GDstartObjects1});gdjs.s15_462Code.mapOfGDgdjs_46s15_95462Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s15_462Code.GDoffObjects1});gdjs.s15_462Code.mapOfGDgdjs_46s15_95462Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s15_462Code.GDonObjects1});gdjs.s15_462Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s15_462Code.condition0IsTrue_0.val = false;
{
{gdjs.s15_462Code.conditionTrue_1 = gdjs.s15_462Code.condition0IsTrue_0;
gdjs.s15_462Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(86707780);
}
}if (gdjs.s15_462Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\dead.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s15_462Code.GDstartObjects1);

gdjs.s15_462Code.condition0IsTrue_0.val = false;
{
gdjs.s15_462Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s15_462Code.mapOfGDgdjs_46s15_95462Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s15_462Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s15", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s15_462Code.GDoffObjects1);

gdjs.s15_462Code.condition0IsTrue_0.val = false;
{
gdjs.s15_462Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s15_462Code.mapOfGDgdjs_46s15_95462Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s15_462Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s15_462Code.GDonObjects1);

gdjs.s15_462Code.condition0IsTrue_0.val = false;
{
gdjs.s15_462Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s15_462Code.mapOfGDgdjs_46s15_95462Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s15_462Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s15_462Code.condition0IsTrue_0.val = false;
{
gdjs.s15_462Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.s15_462Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s15", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s15_462Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s15_462Code.GDcaseObjects1.length = 0;
gdjs.s15_462Code.GDcaseObjects2.length = 0;
gdjs.s15_462Code.GDimageObjects1.length = 0;
gdjs.s15_462Code.GDimageObjects2.length = 0;
gdjs.s15_462Code.GDoffObjects1.length = 0;
gdjs.s15_462Code.GDoffObjects2.length = 0;
gdjs.s15_462Code.GDonObjects1.length = 0;
gdjs.s15_462Code.GDonObjects2.length = 0;
gdjs.s15_462Code.GDstartObjects1.length = 0;
gdjs.s15_462Code.GDstartObjects2.length = 0;
gdjs.s15_462Code.GDBObjects1.length = 0;
gdjs.s15_462Code.GDBObjects2.length = 0;
gdjs.s15_462Code.GDblackObjects1.length = 0;
gdjs.s15_462Code.GDblackObjects2.length = 0;
gdjs.s15_462Code.GDAObjects1.length = 0;
gdjs.s15_462Code.GDAObjects2.length = 0;

gdjs.s15_462Code.eventsList0(runtimeScene);
return;

}

gdjs['s15_462Code'] = gdjs.s15_462Code;
