gdjs.s329Code = {};
gdjs.s329Code.GDcaseObjects1= [];
gdjs.s329Code.GDcaseObjects2= [];
gdjs.s329Code.GDimageObjects1= [];
gdjs.s329Code.GDimageObjects2= [];
gdjs.s329Code.GDoffObjects1= [];
gdjs.s329Code.GDoffObjects2= [];
gdjs.s329Code.GDonObjects1= [];
gdjs.s329Code.GDonObjects2= [];
gdjs.s329Code.GDstartObjects1= [];
gdjs.s329Code.GDstartObjects2= [];
gdjs.s329Code.GDBObjects1= [];
gdjs.s329Code.GDBObjects2= [];
gdjs.s329Code.GDblackObjects1= [];
gdjs.s329Code.GDblackObjects2= [];
gdjs.s329Code.GDAObjects1= [];
gdjs.s329Code.GDAObjects2= [];

gdjs.s329Code.conditionTrue_0 = {val:false};
gdjs.s329Code.condition0IsTrue_0 = {val:false};
gdjs.s329Code.condition1IsTrue_0 = {val:false};


gdjs.s329Code.mapOfGDgdjs_46s329Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s329Code.GDoffObjects1});gdjs.s329Code.mapOfGDgdjs_46s329Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s329Code.GDonObjects1});gdjs.s329Code.mapOfGDgdjs_46s329Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s329Code.GDBObjects1});gdjs.s329Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s329Code.GDoffObjects1);

gdjs.s329Code.condition0IsTrue_0.val = false;
{
gdjs.s329Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s329Code.mapOfGDgdjs_46s329Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s329Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s329Code.GDonObjects1);

gdjs.s329Code.condition0IsTrue_0.val = false;
{
gdjs.s329Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s329Code.mapOfGDgdjs_46s329Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s329Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s329Code.condition0IsTrue_0.val = false;
{
gdjs.s329Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s329Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s330", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s329Code.GDBObjects1);

gdjs.s329Code.condition0IsTrue_0.val = false;
{
gdjs.s329Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s329Code.mapOfGDgdjs_46s329Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s329Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s330", false);
}}

}


{


{
}

}


};

gdjs.s329Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s329Code.GDcaseObjects1.length = 0;
gdjs.s329Code.GDcaseObjects2.length = 0;
gdjs.s329Code.GDimageObjects1.length = 0;
gdjs.s329Code.GDimageObjects2.length = 0;
gdjs.s329Code.GDoffObjects1.length = 0;
gdjs.s329Code.GDoffObjects2.length = 0;
gdjs.s329Code.GDonObjects1.length = 0;
gdjs.s329Code.GDonObjects2.length = 0;
gdjs.s329Code.GDstartObjects1.length = 0;
gdjs.s329Code.GDstartObjects2.length = 0;
gdjs.s329Code.GDBObjects1.length = 0;
gdjs.s329Code.GDBObjects2.length = 0;
gdjs.s329Code.GDblackObjects1.length = 0;
gdjs.s329Code.GDblackObjects2.length = 0;
gdjs.s329Code.GDAObjects1.length = 0;
gdjs.s329Code.GDAObjects2.length = 0;

gdjs.s329Code.eventsList0(runtimeScene);
return;

}

gdjs['s329Code'] = gdjs.s329Code;
