gdjs.s157Code = {};
gdjs.s157Code.GDcaseObjects1= [];
gdjs.s157Code.GDcaseObjects2= [];
gdjs.s157Code.GDimageObjects1= [];
gdjs.s157Code.GDimageObjects2= [];
gdjs.s157Code.GDoffObjects1= [];
gdjs.s157Code.GDoffObjects2= [];
gdjs.s157Code.GDonObjects1= [];
gdjs.s157Code.GDonObjects2= [];
gdjs.s157Code.GDstartObjects1= [];
gdjs.s157Code.GDstartObjects2= [];
gdjs.s157Code.GDBObjects1= [];
gdjs.s157Code.GDBObjects2= [];
gdjs.s157Code.GDblackObjects1= [];
gdjs.s157Code.GDblackObjects2= [];
gdjs.s157Code.GDAObjects1= [];
gdjs.s157Code.GDAObjects2= [];

gdjs.s157Code.conditionTrue_0 = {val:false};
gdjs.s157Code.condition0IsTrue_0 = {val:false};
gdjs.s157Code.condition1IsTrue_0 = {val:false};


gdjs.s157Code.mapOfGDgdjs_46s157Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s157Code.GDstartObjects1});gdjs.s157Code.mapOfGDgdjs_46s157Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s157Code.GDoffObjects1});gdjs.s157Code.mapOfGDgdjs_46s157Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s157Code.GDonObjects1});gdjs.s157Code.mapOfGDgdjs_46s157Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s157Code.GDBObjects1});gdjs.s157Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s157Code.GDstartObjects1);

gdjs.s157Code.condition0IsTrue_0.val = false;
{
gdjs.s157Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s157Code.mapOfGDgdjs_46s157Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s157Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s157Code.GDoffObjects1);

gdjs.s157Code.condition0IsTrue_0.val = false;
{
gdjs.s157Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s157Code.mapOfGDgdjs_46s157Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s157Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s157Code.GDonObjects1);

gdjs.s157Code.condition0IsTrue_0.val = false;
{
gdjs.s157Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s157Code.mapOfGDgdjs_46s157Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s157Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s157Code.condition0IsTrue_0.val = false;
{
gdjs.s157Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s157Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s158", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s157Code.GDBObjects1);

gdjs.s157Code.condition0IsTrue_0.val = false;
{
gdjs.s157Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s157Code.mapOfGDgdjs_46s157Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s157Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s158", false);
}}

}


{


{
}

}


};

gdjs.s157Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s157Code.GDcaseObjects1.length = 0;
gdjs.s157Code.GDcaseObjects2.length = 0;
gdjs.s157Code.GDimageObjects1.length = 0;
gdjs.s157Code.GDimageObjects2.length = 0;
gdjs.s157Code.GDoffObjects1.length = 0;
gdjs.s157Code.GDoffObjects2.length = 0;
gdjs.s157Code.GDonObjects1.length = 0;
gdjs.s157Code.GDonObjects2.length = 0;
gdjs.s157Code.GDstartObjects1.length = 0;
gdjs.s157Code.GDstartObjects2.length = 0;
gdjs.s157Code.GDBObjects1.length = 0;
gdjs.s157Code.GDBObjects2.length = 0;
gdjs.s157Code.GDblackObjects1.length = 0;
gdjs.s157Code.GDblackObjects2.length = 0;
gdjs.s157Code.GDAObjects1.length = 0;
gdjs.s157Code.GDAObjects2.length = 0;

gdjs.s157Code.eventsList0(runtimeScene);
return;

}

gdjs['s157Code'] = gdjs.s157Code;
