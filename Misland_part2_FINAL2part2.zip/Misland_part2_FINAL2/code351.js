gdjs.s309Code = {};
gdjs.s309Code.GDcaseObjects1= [];
gdjs.s309Code.GDcaseObjects2= [];
gdjs.s309Code.GDimageObjects1= [];
gdjs.s309Code.GDimageObjects2= [];
gdjs.s309Code.GDoffObjects1= [];
gdjs.s309Code.GDoffObjects2= [];
gdjs.s309Code.GDonObjects1= [];
gdjs.s309Code.GDonObjects2= [];
gdjs.s309Code.GDstartObjects1= [];
gdjs.s309Code.GDstartObjects2= [];
gdjs.s309Code.GDBObjects1= [];
gdjs.s309Code.GDBObjects2= [];
gdjs.s309Code.GDblackObjects1= [];
gdjs.s309Code.GDblackObjects2= [];
gdjs.s309Code.GDAObjects1= [];
gdjs.s309Code.GDAObjects2= [];

gdjs.s309Code.conditionTrue_0 = {val:false};
gdjs.s309Code.condition0IsTrue_0 = {val:false};
gdjs.s309Code.condition1IsTrue_0 = {val:false};


gdjs.s309Code.mapOfGDgdjs_46s309Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s309Code.GDoffObjects1});gdjs.s309Code.mapOfGDgdjs_46s309Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s309Code.GDonObjects1});gdjs.s309Code.mapOfGDgdjs_46s309Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s309Code.GDBObjects1});gdjs.s309Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s309Code.GDoffObjects1);

gdjs.s309Code.condition0IsTrue_0.val = false;
{
gdjs.s309Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s309Code.mapOfGDgdjs_46s309Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s309Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s309Code.GDonObjects1);

gdjs.s309Code.condition0IsTrue_0.val = false;
{
gdjs.s309Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s309Code.mapOfGDgdjs_46s309Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s309Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s309Code.condition0IsTrue_0.val = false;
{
gdjs.s309Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s309Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s310", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s309Code.GDBObjects1);

gdjs.s309Code.condition0IsTrue_0.val = false;
{
gdjs.s309Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s309Code.mapOfGDgdjs_46s309Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s309Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s310", false);
}}

}


{


{
}

}


};

gdjs.s309Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s309Code.GDcaseObjects1.length = 0;
gdjs.s309Code.GDcaseObjects2.length = 0;
gdjs.s309Code.GDimageObjects1.length = 0;
gdjs.s309Code.GDimageObjects2.length = 0;
gdjs.s309Code.GDoffObjects1.length = 0;
gdjs.s309Code.GDoffObjects2.length = 0;
gdjs.s309Code.GDonObjects1.length = 0;
gdjs.s309Code.GDonObjects2.length = 0;
gdjs.s309Code.GDstartObjects1.length = 0;
gdjs.s309Code.GDstartObjects2.length = 0;
gdjs.s309Code.GDBObjects1.length = 0;
gdjs.s309Code.GDBObjects2.length = 0;
gdjs.s309Code.GDblackObjects1.length = 0;
gdjs.s309Code.GDblackObjects2.length = 0;
gdjs.s309Code.GDAObjects1.length = 0;
gdjs.s309Code.GDAObjects2.length = 0;

gdjs.s309Code.eventsList0(runtimeScene);
return;

}

gdjs['s309Code'] = gdjs.s309Code;
