gdjs.s255Code = {};
gdjs.s255Code.GDcaseObjects1= [];
gdjs.s255Code.GDcaseObjects2= [];
gdjs.s255Code.GDimageObjects1= [];
gdjs.s255Code.GDimageObjects2= [];
gdjs.s255Code.GDoffObjects1= [];
gdjs.s255Code.GDoffObjects2= [];
gdjs.s255Code.GDonObjects1= [];
gdjs.s255Code.GDonObjects2= [];
gdjs.s255Code.GDstartObjects1= [];
gdjs.s255Code.GDstartObjects2= [];
gdjs.s255Code.GDBObjects1= [];
gdjs.s255Code.GDBObjects2= [];
gdjs.s255Code.GDblackObjects1= [];
gdjs.s255Code.GDblackObjects2= [];
gdjs.s255Code.GDAObjects1= [];
gdjs.s255Code.GDAObjects2= [];

gdjs.s255Code.conditionTrue_0 = {val:false};
gdjs.s255Code.condition0IsTrue_0 = {val:false};
gdjs.s255Code.condition1IsTrue_0 = {val:false};


gdjs.s255Code.mapOfGDgdjs_46s255Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s255Code.GDoffObjects1});gdjs.s255Code.mapOfGDgdjs_46s255Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s255Code.GDonObjects1});gdjs.s255Code.mapOfGDgdjs_46s255Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s255Code.GDBObjects1});gdjs.s255Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s255Code.GDoffObjects1);

gdjs.s255Code.condition0IsTrue_0.val = false;
{
gdjs.s255Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s255Code.mapOfGDgdjs_46s255Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s255Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s255Code.GDonObjects1);

gdjs.s255Code.condition0IsTrue_0.val = false;
{
gdjs.s255Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s255Code.mapOfGDgdjs_46s255Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s255Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s255Code.condition0IsTrue_0.val = false;
{
gdjs.s255Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s255Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s256", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s255Code.GDBObjects1);

gdjs.s255Code.condition0IsTrue_0.val = false;
{
gdjs.s255Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s255Code.mapOfGDgdjs_46s255Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s255Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s256", false);
}}

}


{


{
}

}


};

gdjs.s255Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s255Code.GDcaseObjects1.length = 0;
gdjs.s255Code.GDcaseObjects2.length = 0;
gdjs.s255Code.GDimageObjects1.length = 0;
gdjs.s255Code.GDimageObjects2.length = 0;
gdjs.s255Code.GDoffObjects1.length = 0;
gdjs.s255Code.GDoffObjects2.length = 0;
gdjs.s255Code.GDonObjects1.length = 0;
gdjs.s255Code.GDonObjects2.length = 0;
gdjs.s255Code.GDstartObjects1.length = 0;
gdjs.s255Code.GDstartObjects2.length = 0;
gdjs.s255Code.GDBObjects1.length = 0;
gdjs.s255Code.GDBObjects2.length = 0;
gdjs.s255Code.GDblackObjects1.length = 0;
gdjs.s255Code.GDblackObjects2.length = 0;
gdjs.s255Code.GDAObjects1.length = 0;
gdjs.s255Code.GDAObjects2.length = 0;

gdjs.s255Code.eventsList0(runtimeScene);
return;

}

gdjs['s255Code'] = gdjs.s255Code;
