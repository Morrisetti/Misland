gdjs.s185Code = {};
gdjs.s185Code.GDcaseObjects1= [];
gdjs.s185Code.GDcaseObjects2= [];
gdjs.s185Code.GDoffObjects1= [];
gdjs.s185Code.GDoffObjects2= [];
gdjs.s185Code.GDonObjects1= [];
gdjs.s185Code.GDonObjects2= [];
gdjs.s185Code.GDstartObjects1= [];
gdjs.s185Code.GDstartObjects2= [];
gdjs.s185Code.GDBObjects1= [];
gdjs.s185Code.GDBObjects2= [];
gdjs.s185Code.GDAObjects1= [];
gdjs.s185Code.GDAObjects2= [];
gdjs.s185Code.GDbugzObjects1= [];
gdjs.s185Code.GDbugzObjects2= [];
gdjs.s185Code.GDDOWNbuttonObjects1= [];
gdjs.s185Code.GDDOWNbuttonObjects2= [];
gdjs.s185Code.GDblackObjects1= [];
gdjs.s185Code.GDblackObjects2= [];
gdjs.s185Code.GDDOWNcolObjects1= [];
gdjs.s185Code.GDDOWNcolObjects2= [];
gdjs.s185Code.GDUPbuttonObjects1= [];
gdjs.s185Code.GDUPbuttonObjects2= [];
gdjs.s185Code.GDUPcolObjects1= [];
gdjs.s185Code.GDUPcolObjects2= [];
gdjs.s185Code.GDLbuttonObjects1= [];
gdjs.s185Code.GDLbuttonObjects2= [];
gdjs.s185Code.GDLcolObjects1= [];
gdjs.s185Code.GDLcolObjects2= [];
gdjs.s185Code.GDRbuttonObjects1= [];
gdjs.s185Code.GDRbuttonObjects2= [];
gdjs.s185Code.GDexitObjects1= [];
gdjs.s185Code.GDexitObjects2= [];
gdjs.s185Code.GDTALKObjects1= [];
gdjs.s185Code.GDTALKObjects2= [];
gdjs.s185Code.GDRcolObjects1= [];
gdjs.s185Code.GDRcolObjects2= [];
gdjs.s185Code.GDchapter4Objects1= [];
gdjs.s185Code.GDchapter4Objects2= [];
gdjs.s185Code.GDchapter3Objects1= [];
gdjs.s185Code.GDchapter3Objects2= [];
gdjs.s185Code.GDchapter2Objects1= [];
gdjs.s185Code.GDchapter2Objects2= [];
gdjs.s185Code.GDchapter1Objects1= [];
gdjs.s185Code.GDchapter1Objects2= [];
gdjs.s185Code.GDBGObjects1= [];
gdjs.s185Code.GDBGObjects2= [];
gdjs.s185Code.GDdeathlightObjects1= [];
gdjs.s185Code.GDdeathlightObjects2= [];
gdjs.s185Code.GDdeathglassObjects1= [];
gdjs.s185Code.GDdeathglassObjects2= [];
gdjs.s185Code.GDshadowObjects1= [];
gdjs.s185Code.GDshadowObjects2= [];

gdjs.s185Code.conditionTrue_0 = {val:false};
gdjs.s185Code.condition0IsTrue_0 = {val:false};
gdjs.s185Code.condition1IsTrue_0 = {val:false};
gdjs.s185Code.condition2IsTrue_0 = {val:false};
gdjs.s185Code.conditionTrue_1 = {val:false};
gdjs.s185Code.condition0IsTrue_1 = {val:false};
gdjs.s185Code.condition1IsTrue_1 = {val:false};
gdjs.s185Code.condition2IsTrue_1 = {val:false};


gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s185Code.GDDOWNbuttonObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s185Code.GDUPbuttonObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s185Code.GDRbuttonObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s185Code.GDLbuttonObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s185Code.GDbugzObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s185Code.GDRcolObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s185Code.GDbugzObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s185Code.GDLcolObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s185Code.GDbugzObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s185Code.GDUPcolObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s185Code.GDbugzObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s185Code.GDDOWNcolObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s185Code.GDbugzObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s185Code.GDDOWNcolObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s185Code.GDBObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s185Code.GDAObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s185Code.GDoffObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s185Code.GDonObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s185Code.GDbugzObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDdeathglassObjects1Objects = Hashtable.newFrom({"deathglass": gdjs.s185Code.GDdeathglassObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s185Code.GDbugzObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.s185Code.GDexitObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s185Code.GDbugzObjects1});gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDdeathlightObjects1Objects = Hashtable.newFrom({"deathlight": gdjs.s185Code.GDdeathlightObjects1});gdjs.s185Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s185Code.GDDOWNbuttonObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
gdjs.s185Code.condition1IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s185Code.condition0IsTrue_0.val ) {
{
gdjs.s185Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s185Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s185Code.GDUPbuttonObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
gdjs.s185Code.condition1IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s185Code.condition0IsTrue_0.val ) {
{
gdjs.s185Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s185Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s185Code.GDRbuttonObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
gdjs.s185Code.condition1IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s185Code.condition0IsTrue_0.val ) {
{
gdjs.s185Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s185Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s185Code.GDLbuttonObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
gdjs.s185Code.condition1IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s185Code.condition0IsTrue_0.val ) {
{
gdjs.s185Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s185Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s185Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects, gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s185Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s185Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects, gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s185Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s185Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects, gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s185Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s185Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects, gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s185Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s185Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects, gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s185Code.GDBObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s185Code.GDAObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s185Code.GDoffObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s185Code.GDonObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s185Code.condition0IsTrue_0.val = false;
gdjs.s185Code.condition1IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s185Code.condition0IsTrue_0.val ) {
{
gdjs.s185Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s185Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s185Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s185Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s185Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s185Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s185Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s185Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("deathglass"), gdjs.s185Code.GDdeathglassObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects, gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDdeathglassObjects1Objects, false, runtimeScene, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s173.1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.s185Code.GDexitObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects, gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDexitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s186", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("deathlight"), gdjs.s185Code.GDdeathlightObjects1);

gdjs.s185Code.condition0IsTrue_0.val = false;
{
gdjs.s185Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDbugzObjects1Objects, gdjs.s185Code.mapOfGDgdjs_46s185Code_46GDdeathlightObjects1Objects, false, runtimeScene, false);
}if (gdjs.s185Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s173.1", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s185Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s185Code.GDbugzObjects1.length !== 0 ? gdjs.s185Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


{


gdjs.s185Code.condition0IsTrue_0.val = false;
{
{gdjs.s185Code.conditionTrue_1 = gdjs.s185Code.condition0IsTrue_0;
gdjs.s185Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(90864412);
}
}if (gdjs.s185Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "scuba_wreck.mp3", true, 100, 1);
}}

}


};

gdjs.s185Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s185Code.GDcaseObjects1.length = 0;
gdjs.s185Code.GDcaseObjects2.length = 0;
gdjs.s185Code.GDoffObjects1.length = 0;
gdjs.s185Code.GDoffObjects2.length = 0;
gdjs.s185Code.GDonObjects1.length = 0;
gdjs.s185Code.GDonObjects2.length = 0;
gdjs.s185Code.GDstartObjects1.length = 0;
gdjs.s185Code.GDstartObjects2.length = 0;
gdjs.s185Code.GDBObjects1.length = 0;
gdjs.s185Code.GDBObjects2.length = 0;
gdjs.s185Code.GDAObjects1.length = 0;
gdjs.s185Code.GDAObjects2.length = 0;
gdjs.s185Code.GDbugzObjects1.length = 0;
gdjs.s185Code.GDbugzObjects2.length = 0;
gdjs.s185Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s185Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s185Code.GDblackObjects1.length = 0;
gdjs.s185Code.GDblackObjects2.length = 0;
gdjs.s185Code.GDDOWNcolObjects1.length = 0;
gdjs.s185Code.GDDOWNcolObjects2.length = 0;
gdjs.s185Code.GDUPbuttonObjects1.length = 0;
gdjs.s185Code.GDUPbuttonObjects2.length = 0;
gdjs.s185Code.GDUPcolObjects1.length = 0;
gdjs.s185Code.GDUPcolObjects2.length = 0;
gdjs.s185Code.GDLbuttonObjects1.length = 0;
gdjs.s185Code.GDLbuttonObjects2.length = 0;
gdjs.s185Code.GDLcolObjects1.length = 0;
gdjs.s185Code.GDLcolObjects2.length = 0;
gdjs.s185Code.GDRbuttonObjects1.length = 0;
gdjs.s185Code.GDRbuttonObjects2.length = 0;
gdjs.s185Code.GDexitObjects1.length = 0;
gdjs.s185Code.GDexitObjects2.length = 0;
gdjs.s185Code.GDTALKObjects1.length = 0;
gdjs.s185Code.GDTALKObjects2.length = 0;
gdjs.s185Code.GDRcolObjects1.length = 0;
gdjs.s185Code.GDRcolObjects2.length = 0;
gdjs.s185Code.GDchapter4Objects1.length = 0;
gdjs.s185Code.GDchapter4Objects2.length = 0;
gdjs.s185Code.GDchapter3Objects1.length = 0;
gdjs.s185Code.GDchapter3Objects2.length = 0;
gdjs.s185Code.GDchapter2Objects1.length = 0;
gdjs.s185Code.GDchapter2Objects2.length = 0;
gdjs.s185Code.GDchapter1Objects1.length = 0;
gdjs.s185Code.GDchapter1Objects2.length = 0;
gdjs.s185Code.GDBGObjects1.length = 0;
gdjs.s185Code.GDBGObjects2.length = 0;
gdjs.s185Code.GDdeathlightObjects1.length = 0;
gdjs.s185Code.GDdeathlightObjects2.length = 0;
gdjs.s185Code.GDdeathglassObjects1.length = 0;
gdjs.s185Code.GDdeathglassObjects2.length = 0;
gdjs.s185Code.GDshadowObjects1.length = 0;
gdjs.s185Code.GDshadowObjects2.length = 0;

gdjs.s185Code.eventsList0(runtimeScene);
return;

}

gdjs['s185Code'] = gdjs.s185Code;
