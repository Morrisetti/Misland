gdjs.s325Code = {};
gdjs.s325Code.GDcaseObjects1= [];
gdjs.s325Code.GDcaseObjects2= [];
gdjs.s325Code.GDimageObjects1= [];
gdjs.s325Code.GDimageObjects2= [];
gdjs.s325Code.GDoffObjects1= [];
gdjs.s325Code.GDoffObjects2= [];
gdjs.s325Code.GDonObjects1= [];
gdjs.s325Code.GDonObjects2= [];
gdjs.s325Code.GDstartObjects1= [];
gdjs.s325Code.GDstartObjects2= [];
gdjs.s325Code.GDBObjects1= [];
gdjs.s325Code.GDBObjects2= [];
gdjs.s325Code.GDblackObjects1= [];
gdjs.s325Code.GDblackObjects2= [];
gdjs.s325Code.GDAObjects1= [];
gdjs.s325Code.GDAObjects2= [];

gdjs.s325Code.conditionTrue_0 = {val:false};
gdjs.s325Code.condition0IsTrue_0 = {val:false};
gdjs.s325Code.condition1IsTrue_0 = {val:false};


gdjs.s325Code.mapOfGDgdjs_46s325Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s325Code.GDoffObjects1});gdjs.s325Code.mapOfGDgdjs_46s325Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s325Code.GDonObjects1});gdjs.s325Code.mapOfGDgdjs_46s325Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s325Code.GDBObjects1});gdjs.s325Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s325Code.GDoffObjects1);

gdjs.s325Code.condition0IsTrue_0.val = false;
{
gdjs.s325Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s325Code.mapOfGDgdjs_46s325Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s325Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s325Code.GDonObjects1);

gdjs.s325Code.condition0IsTrue_0.val = false;
{
gdjs.s325Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s325Code.mapOfGDgdjs_46s325Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s325Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s325Code.condition0IsTrue_0.val = false;
{
gdjs.s325Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s325Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s326", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s325Code.GDBObjects1);

gdjs.s325Code.condition0IsTrue_0.val = false;
{
gdjs.s325Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s325Code.mapOfGDgdjs_46s325Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s325Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s326", false);
}}

}


{


{
}

}


};

gdjs.s325Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s325Code.GDcaseObjects1.length = 0;
gdjs.s325Code.GDcaseObjects2.length = 0;
gdjs.s325Code.GDimageObjects1.length = 0;
gdjs.s325Code.GDimageObjects2.length = 0;
gdjs.s325Code.GDoffObjects1.length = 0;
gdjs.s325Code.GDoffObjects2.length = 0;
gdjs.s325Code.GDonObjects1.length = 0;
gdjs.s325Code.GDonObjects2.length = 0;
gdjs.s325Code.GDstartObjects1.length = 0;
gdjs.s325Code.GDstartObjects2.length = 0;
gdjs.s325Code.GDBObjects1.length = 0;
gdjs.s325Code.GDBObjects2.length = 0;
gdjs.s325Code.GDblackObjects1.length = 0;
gdjs.s325Code.GDblackObjects2.length = 0;
gdjs.s325Code.GDAObjects1.length = 0;
gdjs.s325Code.GDAObjects2.length = 0;

gdjs.s325Code.eventsList0(runtimeScene);
return;

}

gdjs['s325Code'] = gdjs.s325Code;
