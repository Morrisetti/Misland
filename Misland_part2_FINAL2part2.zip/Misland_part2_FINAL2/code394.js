gdjs.s351Code = {};
gdjs.s351Code.GDcaseObjects1= [];
gdjs.s351Code.GDcaseObjects2= [];
gdjs.s351Code.GDimageObjects1= [];
gdjs.s351Code.GDimageObjects2= [];
gdjs.s351Code.GDoffObjects1= [];
gdjs.s351Code.GDoffObjects2= [];
gdjs.s351Code.GDonObjects1= [];
gdjs.s351Code.GDonObjects2= [];
gdjs.s351Code.GDstartObjects1= [];
gdjs.s351Code.GDstartObjects2= [];
gdjs.s351Code.GDBObjects1= [];
gdjs.s351Code.GDBObjects2= [];
gdjs.s351Code.GDblackObjects1= [];
gdjs.s351Code.GDblackObjects2= [];
gdjs.s351Code.GDAObjects1= [];
gdjs.s351Code.GDAObjects2= [];

gdjs.s351Code.conditionTrue_0 = {val:false};
gdjs.s351Code.condition0IsTrue_0 = {val:false};
gdjs.s351Code.condition1IsTrue_0 = {val:false};


gdjs.s351Code.mapOfGDgdjs_46s351Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s351Code.GDoffObjects1});gdjs.s351Code.mapOfGDgdjs_46s351Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s351Code.GDonObjects1});gdjs.s351Code.mapOfGDgdjs_46s351Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s351Code.GDBObjects1});gdjs.s351Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s351Code.GDoffObjects1);

gdjs.s351Code.condition0IsTrue_0.val = false;
{
gdjs.s351Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s351Code.mapOfGDgdjs_46s351Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s351Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s351Code.GDonObjects1);

gdjs.s351Code.condition0IsTrue_0.val = false;
{
gdjs.s351Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s351Code.mapOfGDgdjs_46s351Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s351Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s351Code.condition0IsTrue_0.val = false;
{
gdjs.s351Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s351Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s352", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s351Code.GDBObjects1);

gdjs.s351Code.condition0IsTrue_0.val = false;
{
gdjs.s351Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s351Code.mapOfGDgdjs_46s351Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s351Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s352", false);
}}

}


{


{
}

}


};

gdjs.s351Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s351Code.GDcaseObjects1.length = 0;
gdjs.s351Code.GDcaseObjects2.length = 0;
gdjs.s351Code.GDimageObjects1.length = 0;
gdjs.s351Code.GDimageObjects2.length = 0;
gdjs.s351Code.GDoffObjects1.length = 0;
gdjs.s351Code.GDoffObjects2.length = 0;
gdjs.s351Code.GDonObjects1.length = 0;
gdjs.s351Code.GDonObjects2.length = 0;
gdjs.s351Code.GDstartObjects1.length = 0;
gdjs.s351Code.GDstartObjects2.length = 0;
gdjs.s351Code.GDBObjects1.length = 0;
gdjs.s351Code.GDBObjects2.length = 0;
gdjs.s351Code.GDblackObjects1.length = 0;
gdjs.s351Code.GDblackObjects2.length = 0;
gdjs.s351Code.GDAObjects1.length = 0;
gdjs.s351Code.GDAObjects2.length = 0;

gdjs.s351Code.eventsList0(runtimeScene);
return;

}

gdjs['s351Code'] = gdjs.s351Code;
