gdjs.s58Code = {};
gdjs.s58Code.GDcaseObjects1= [];
gdjs.s58Code.GDcaseObjects2= [];
gdjs.s58Code.GDoffObjects1= [];
gdjs.s58Code.GDoffObjects2= [];
gdjs.s58Code.GDonObjects1= [];
gdjs.s58Code.GDonObjects2= [];
gdjs.s58Code.GDstartObjects1= [];
gdjs.s58Code.GDstartObjects2= [];
gdjs.s58Code.GDBObjects1= [];
gdjs.s58Code.GDBObjects2= [];
gdjs.s58Code.GDAObjects1= [];
gdjs.s58Code.GDAObjects2= [];
gdjs.s58Code.GDbugzObjects1= [];
gdjs.s58Code.GDbugzObjects2= [];
gdjs.s58Code.GDDOWNbuttonObjects1= [];
gdjs.s58Code.GDDOWNbuttonObjects2= [];
gdjs.s58Code.GDblackObjects1= [];
gdjs.s58Code.GDblackObjects2= [];
gdjs.s58Code.GDDOWNcolObjects1= [];
gdjs.s58Code.GDDOWNcolObjects2= [];
gdjs.s58Code.GDUPbuttonObjects1= [];
gdjs.s58Code.GDUPbuttonObjects2= [];
gdjs.s58Code.GDUPcolObjects1= [];
gdjs.s58Code.GDUPcolObjects2= [];
gdjs.s58Code.GDLbuttonObjects1= [];
gdjs.s58Code.GDLbuttonObjects2= [];
gdjs.s58Code.GDLcolObjects1= [];
gdjs.s58Code.GDLcolObjects2= [];
gdjs.s58Code.GDRbuttonObjects1= [];
gdjs.s58Code.GDRbuttonObjects2= [];
gdjs.s58Code.GDexitObjects1= [];
gdjs.s58Code.GDexitObjects2= [];
gdjs.s58Code.GDTALKObjects1= [];
gdjs.s58Code.GDTALKObjects2= [];
gdjs.s58Code.GDRcolObjects1= [];
gdjs.s58Code.GDRcolObjects2= [];
gdjs.s58Code.GDchapter4Objects1= [];
gdjs.s58Code.GDchapter4Objects2= [];
gdjs.s58Code.GDchapter3Objects1= [];
gdjs.s58Code.GDchapter3Objects2= [];
gdjs.s58Code.GDchapter2Objects1= [];
gdjs.s58Code.GDchapter2Objects2= [];
gdjs.s58Code.GDchapter1Objects1= [];
gdjs.s58Code.GDchapter1Objects2= [];
gdjs.s58Code.GDBGObjects1= [];
gdjs.s58Code.GDBGObjects2= [];

gdjs.s58Code.conditionTrue_0 = {val:false};
gdjs.s58Code.condition0IsTrue_0 = {val:false};
gdjs.s58Code.condition1IsTrue_0 = {val:false};
gdjs.s58Code.condition2IsTrue_0 = {val:false};


gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s58Code.GDDOWNbuttonObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s58Code.GDUPbuttonObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s58Code.GDRbuttonObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s58Code.GDLbuttonObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s58Code.GDbugzObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s58Code.GDRcolObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s58Code.GDbugzObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s58Code.GDLcolObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s58Code.GDbugzObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s58Code.GDUPcolObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s58Code.GDbugzObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s58Code.GDDOWNcolObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s58Code.GDbugzObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s58Code.GDDOWNcolObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s58Code.GDBObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s58Code.GDAObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s58Code.GDoffObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s58Code.GDonObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s58Code.GDbugzObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDTALKObjects1Objects = Hashtable.newFrom({"TALK": gdjs.s58Code.GDTALKObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s58Code.GDbugzObjects1});gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.s58Code.GDexitObjects1});gdjs.s58Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s58Code.GDDOWNbuttonObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
gdjs.s58Code.condition1IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s58Code.condition0IsTrue_0.val ) {
{
gdjs.s58Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s58Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s58Code.GDUPbuttonObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
gdjs.s58Code.condition1IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s58Code.condition0IsTrue_0.val ) {
{
gdjs.s58Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s58Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s58Code.GDRbuttonObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
gdjs.s58Code.condition1IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s58Code.condition0IsTrue_0.val ) {
{
gdjs.s58Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s58Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s58Code.GDLbuttonObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
gdjs.s58Code.condition1IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s58Code.condition0IsTrue_0.val ) {
{
gdjs.s58Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s58Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s58Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects, gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s58Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s58Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s58Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects, gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s58Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s58Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s58Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects, gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s58Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s58Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s58Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects, gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s58Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s58Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s58Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects, gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s58Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s58Code.GDBObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s58Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s58Code.GDAObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s58Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s58Code.GDoffObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s58Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s58Code.GDonObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s58Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s58Code.condition0IsTrue_0.val = false;
gdjs.s58Code.condition1IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s58Code.condition0IsTrue_0.val ) {
{
gdjs.s58Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s58Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s58Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s58Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s58Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s58Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s58Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s58Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK"), gdjs.s58Code.GDTALKObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects, gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDTALKObjects1Objects, false, runtimeScene, false);
}if (gdjs.s58Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s55", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.s58Code.GDexitObjects1);

gdjs.s58Code.condition0IsTrue_0.val = false;
{
gdjs.s58Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDbugzObjects1Objects, gdjs.s58Code.mapOfGDgdjs_46s58Code_46GDexitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s58Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s59", false);
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s58Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s58Code.GDbugzObjects1.length !== 0 ? gdjs.s58Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s58Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s58Code.GDcaseObjects1.length = 0;
gdjs.s58Code.GDcaseObjects2.length = 0;
gdjs.s58Code.GDoffObjects1.length = 0;
gdjs.s58Code.GDoffObjects2.length = 0;
gdjs.s58Code.GDonObjects1.length = 0;
gdjs.s58Code.GDonObjects2.length = 0;
gdjs.s58Code.GDstartObjects1.length = 0;
gdjs.s58Code.GDstartObjects2.length = 0;
gdjs.s58Code.GDBObjects1.length = 0;
gdjs.s58Code.GDBObjects2.length = 0;
gdjs.s58Code.GDAObjects1.length = 0;
gdjs.s58Code.GDAObjects2.length = 0;
gdjs.s58Code.GDbugzObjects1.length = 0;
gdjs.s58Code.GDbugzObjects2.length = 0;
gdjs.s58Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s58Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s58Code.GDblackObjects1.length = 0;
gdjs.s58Code.GDblackObjects2.length = 0;
gdjs.s58Code.GDDOWNcolObjects1.length = 0;
gdjs.s58Code.GDDOWNcolObjects2.length = 0;
gdjs.s58Code.GDUPbuttonObjects1.length = 0;
gdjs.s58Code.GDUPbuttonObjects2.length = 0;
gdjs.s58Code.GDUPcolObjects1.length = 0;
gdjs.s58Code.GDUPcolObjects2.length = 0;
gdjs.s58Code.GDLbuttonObjects1.length = 0;
gdjs.s58Code.GDLbuttonObjects2.length = 0;
gdjs.s58Code.GDLcolObjects1.length = 0;
gdjs.s58Code.GDLcolObjects2.length = 0;
gdjs.s58Code.GDRbuttonObjects1.length = 0;
gdjs.s58Code.GDRbuttonObjects2.length = 0;
gdjs.s58Code.GDexitObjects1.length = 0;
gdjs.s58Code.GDexitObjects2.length = 0;
gdjs.s58Code.GDTALKObjects1.length = 0;
gdjs.s58Code.GDTALKObjects2.length = 0;
gdjs.s58Code.GDRcolObjects1.length = 0;
gdjs.s58Code.GDRcolObjects2.length = 0;
gdjs.s58Code.GDchapter4Objects1.length = 0;
gdjs.s58Code.GDchapter4Objects2.length = 0;
gdjs.s58Code.GDchapter3Objects1.length = 0;
gdjs.s58Code.GDchapter3Objects2.length = 0;
gdjs.s58Code.GDchapter2Objects1.length = 0;
gdjs.s58Code.GDchapter2Objects2.length = 0;
gdjs.s58Code.GDchapter1Objects1.length = 0;
gdjs.s58Code.GDchapter1Objects2.length = 0;
gdjs.s58Code.GDBGObjects1.length = 0;
gdjs.s58Code.GDBGObjects2.length = 0;

gdjs.s58Code.eventsList0(runtimeScene);
return;

}

gdjs['s58Code'] = gdjs.s58Code;
