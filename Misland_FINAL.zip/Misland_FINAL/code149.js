gdjs.s133CHCode = {};
gdjs.s133CHCode.GDcaseObjects1= [];
gdjs.s133CHCode.GDcaseObjects2= [];
gdjs.s133CHCode.GDimageObjects1= [];
gdjs.s133CHCode.GDimageObjects2= [];
gdjs.s133CHCode.GDoffObjects1= [];
gdjs.s133CHCode.GDoffObjects2= [];
gdjs.s133CHCode.GDonObjects1= [];
gdjs.s133CHCode.GDonObjects2= [];
gdjs.s133CHCode.GDstartObjects1= [];
gdjs.s133CHCode.GDstartObjects2= [];
gdjs.s133CHCode.GDBObjects1= [];
gdjs.s133CHCode.GDBObjects2= [];
gdjs.s133CHCode.GDAObjects1= [];
gdjs.s133CHCode.GDAObjects2= [];
gdjs.s133CHCode.GDcrosshairsObjects1= [];
gdjs.s133CHCode.GDcrosshairsObjects2= [];
gdjs.s133CHCode.GDDOWNbuttonObjects1= [];
gdjs.s133CHCode.GDDOWNbuttonObjects2= [];
gdjs.s133CHCode.GDDOWNcolObjects1= [];
gdjs.s133CHCode.GDDOWNcolObjects2= [];
gdjs.s133CHCode.GDUPbuttonObjects1= [];
gdjs.s133CHCode.GDUPbuttonObjects2= [];
gdjs.s133CHCode.GDUPcolObjects1= [];
gdjs.s133CHCode.GDUPcolObjects2= [];
gdjs.s133CHCode.GDLbuttonObjects1= [];
gdjs.s133CHCode.GDLbuttonObjects2= [];
gdjs.s133CHCode.GDLcolObjects1= [];
gdjs.s133CHCode.GDLcolObjects2= [];
gdjs.s133CHCode.GDRbuttonObjects1= [];
gdjs.s133CHCode.GDRbuttonObjects2= [];
gdjs.s133CHCode.GDRcolObjects1= [];
gdjs.s133CHCode.GDRcolObjects2= [];
gdjs.s133CHCode.GDchapter4Objects1= [];
gdjs.s133CHCode.GDchapter4Objects2= [];
gdjs.s133CHCode.GDchapter3Objects1= [];
gdjs.s133CHCode.GDchapter3Objects2= [];
gdjs.s133CHCode.GDchapter2Objects1= [];
gdjs.s133CHCode.GDchapter2Objects2= [];
gdjs.s133CHCode.GDblackObjects1= [];
gdjs.s133CHCode.GDblackObjects2= [];
gdjs.s133CHCode.GDchapter1Objects1= [];
gdjs.s133CHCode.GDchapter1Objects2= [];

gdjs.s133CHCode.conditionTrue_0 = {val:false};
gdjs.s133CHCode.condition0IsTrue_0 = {val:false};
gdjs.s133CHCode.condition1IsTrue_0 = {val:false};
gdjs.s133CHCode.condition2IsTrue_0 = {val:false};


gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s133CHCode.GDDOWNbuttonObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s133CHCode.GDUPbuttonObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s133CHCode.GDRbuttonObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s133CHCode.GDLbuttonObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s133CHCode.GDcrosshairsObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s133CHCode.GDRcolObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s133CHCode.GDcrosshairsObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s133CHCode.GDLcolObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s133CHCode.GDcrosshairsObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s133CHCode.GDUPcolObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s133CHCode.GDcrosshairsObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s133CHCode.GDDOWNcolObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s133CHCode.GDcrosshairsObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s133CHCode.GDDOWNcolObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s133CHCode.GDoffObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s133CHCode.GDonObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s133CHCode.GDcrosshairsObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s133CHCode.GDchapter1Objects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s133CHCode.GDAObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s133CHCode.GDcrosshairsObjects1});gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s133CHCode.GDchapter1Objects1});gdjs.s133CHCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s133CHCode.GDDOWNbuttonObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
gdjs.s133CHCode.condition1IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s133CHCode.condition0IsTrue_0.val ) {
{
gdjs.s133CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s133CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s133CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s133CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s133CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s133CHCode.GDUPbuttonObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
gdjs.s133CHCode.condition1IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s133CHCode.condition0IsTrue_0.val ) {
{
gdjs.s133CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s133CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s133CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s133CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s133CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s133CHCode.GDRbuttonObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
gdjs.s133CHCode.condition1IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s133CHCode.condition0IsTrue_0.val ) {
{
gdjs.s133CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s133CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s133CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s133CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s133CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s133CHCode.GDLbuttonObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
gdjs.s133CHCode.condition1IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s133CHCode.condition0IsTrue_0.val ) {
{
gdjs.s133CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s133CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s133CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s133CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s133CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s133CHCode.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s133CHCode.GDcrosshairsObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects, gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s133CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s133CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s133CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s133CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s133CHCode.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s133CHCode.GDcrosshairsObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects, gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s133CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s133CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s133CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s133CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s133CHCode.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s133CHCode.GDcrosshairsObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects, gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s133CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s133CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s133CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s133CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s133CHCode.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s133CHCode.GDcrosshairsObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects, gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s133CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s133CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s133CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s133CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s133CHCode.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s133CHCode.GDcrosshairsObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects, gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s133CHCode.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s133CHCode.GDoffObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s133CHCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s133CHCode.GDonObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s133CHCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s133CHCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s133CHCode.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s133CHCode.GDcrosshairsObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
gdjs.s133CHCode.condition1IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects, gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s133CHCode.condition0IsTrue_0.val ) {
{
gdjs.s133CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.s133CHCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s134", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s133CHCode.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s133CHCode.GDcrosshairsObjects1);

gdjs.s133CHCode.condition0IsTrue_0.val = false;
gdjs.s133CHCode.condition1IsTrue_0.val = false;
{
gdjs.s133CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDcrosshairsObjects1Objects, gdjs.s133CHCode.mapOfGDgdjs_46s133CHCode_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s133CHCode.condition0IsTrue_0.val ) {
{
gdjs.s133CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s133CHCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s134", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s133CHCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s133CHCode.GDcaseObjects1.length = 0;
gdjs.s133CHCode.GDcaseObjects2.length = 0;
gdjs.s133CHCode.GDimageObjects1.length = 0;
gdjs.s133CHCode.GDimageObjects2.length = 0;
gdjs.s133CHCode.GDoffObjects1.length = 0;
gdjs.s133CHCode.GDoffObjects2.length = 0;
gdjs.s133CHCode.GDonObjects1.length = 0;
gdjs.s133CHCode.GDonObjects2.length = 0;
gdjs.s133CHCode.GDstartObjects1.length = 0;
gdjs.s133CHCode.GDstartObjects2.length = 0;
gdjs.s133CHCode.GDBObjects1.length = 0;
gdjs.s133CHCode.GDBObjects2.length = 0;
gdjs.s133CHCode.GDAObjects1.length = 0;
gdjs.s133CHCode.GDAObjects2.length = 0;
gdjs.s133CHCode.GDcrosshairsObjects1.length = 0;
gdjs.s133CHCode.GDcrosshairsObjects2.length = 0;
gdjs.s133CHCode.GDDOWNbuttonObjects1.length = 0;
gdjs.s133CHCode.GDDOWNbuttonObjects2.length = 0;
gdjs.s133CHCode.GDDOWNcolObjects1.length = 0;
gdjs.s133CHCode.GDDOWNcolObjects2.length = 0;
gdjs.s133CHCode.GDUPbuttonObjects1.length = 0;
gdjs.s133CHCode.GDUPbuttonObjects2.length = 0;
gdjs.s133CHCode.GDUPcolObjects1.length = 0;
gdjs.s133CHCode.GDUPcolObjects2.length = 0;
gdjs.s133CHCode.GDLbuttonObjects1.length = 0;
gdjs.s133CHCode.GDLbuttonObjects2.length = 0;
gdjs.s133CHCode.GDLcolObjects1.length = 0;
gdjs.s133CHCode.GDLcolObjects2.length = 0;
gdjs.s133CHCode.GDRbuttonObjects1.length = 0;
gdjs.s133CHCode.GDRbuttonObjects2.length = 0;
gdjs.s133CHCode.GDRcolObjects1.length = 0;
gdjs.s133CHCode.GDRcolObjects2.length = 0;
gdjs.s133CHCode.GDchapter4Objects1.length = 0;
gdjs.s133CHCode.GDchapter4Objects2.length = 0;
gdjs.s133CHCode.GDchapter3Objects1.length = 0;
gdjs.s133CHCode.GDchapter3Objects2.length = 0;
gdjs.s133CHCode.GDchapter2Objects1.length = 0;
gdjs.s133CHCode.GDchapter2Objects2.length = 0;
gdjs.s133CHCode.GDblackObjects1.length = 0;
gdjs.s133CHCode.GDblackObjects2.length = 0;
gdjs.s133CHCode.GDchapter1Objects1.length = 0;
gdjs.s133CHCode.GDchapter1Objects2.length = 0;

gdjs.s133CHCode.eventsList0(runtimeScene);
return;

}

gdjs['s133CHCode'] = gdjs.s133CHCode;
