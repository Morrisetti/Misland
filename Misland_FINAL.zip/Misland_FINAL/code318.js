gdjs.s279Code = {};
gdjs.s279Code.GDcaseObjects1= [];
gdjs.s279Code.GDcaseObjects2= [];
gdjs.s279Code.GDimageObjects1= [];
gdjs.s279Code.GDimageObjects2= [];
gdjs.s279Code.GDoffObjects1= [];
gdjs.s279Code.GDoffObjects2= [];
gdjs.s279Code.GDonObjects1= [];
gdjs.s279Code.GDonObjects2= [];
gdjs.s279Code.GDstartObjects1= [];
gdjs.s279Code.GDstartObjects2= [];
gdjs.s279Code.GDBObjects1= [];
gdjs.s279Code.GDBObjects2= [];
gdjs.s279Code.GDblackObjects1= [];
gdjs.s279Code.GDblackObjects2= [];
gdjs.s279Code.GDAObjects1= [];
gdjs.s279Code.GDAObjects2= [];

gdjs.s279Code.conditionTrue_0 = {val:false};
gdjs.s279Code.condition0IsTrue_0 = {val:false};
gdjs.s279Code.condition1IsTrue_0 = {val:false};


gdjs.s279Code.mapOfGDgdjs_46s279Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s279Code.GDstartObjects1});gdjs.s279Code.mapOfGDgdjs_46s279Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s279Code.GDoffObjects1});gdjs.s279Code.mapOfGDgdjs_46s279Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s279Code.GDonObjects1});gdjs.s279Code.mapOfGDgdjs_46s279Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s279Code.GDBObjects1});gdjs.s279Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s279Code.GDstartObjects1);

gdjs.s279Code.condition0IsTrue_0.val = false;
{
gdjs.s279Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s279Code.mapOfGDgdjs_46s279Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s279Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s279Code.GDoffObjects1);

gdjs.s279Code.condition0IsTrue_0.val = false;
{
gdjs.s279Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s279Code.mapOfGDgdjs_46s279Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s279Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s279Code.GDonObjects1);

gdjs.s279Code.condition0IsTrue_0.val = false;
{
gdjs.s279Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s279Code.mapOfGDgdjs_46s279Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s279Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s279Code.condition0IsTrue_0.val = false;
{
gdjs.s279Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s279Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s280", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s279Code.GDBObjects1);

gdjs.s279Code.condition0IsTrue_0.val = false;
{
gdjs.s279Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s279Code.mapOfGDgdjs_46s279Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s279Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s280", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s279Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s279Code.GDcaseObjects1.length = 0;
gdjs.s279Code.GDcaseObjects2.length = 0;
gdjs.s279Code.GDimageObjects1.length = 0;
gdjs.s279Code.GDimageObjects2.length = 0;
gdjs.s279Code.GDoffObjects1.length = 0;
gdjs.s279Code.GDoffObjects2.length = 0;
gdjs.s279Code.GDonObjects1.length = 0;
gdjs.s279Code.GDonObjects2.length = 0;
gdjs.s279Code.GDstartObjects1.length = 0;
gdjs.s279Code.GDstartObjects2.length = 0;
gdjs.s279Code.GDBObjects1.length = 0;
gdjs.s279Code.GDBObjects2.length = 0;
gdjs.s279Code.GDblackObjects1.length = 0;
gdjs.s279Code.GDblackObjects2.length = 0;
gdjs.s279Code.GDAObjects1.length = 0;
gdjs.s279Code.GDAObjects2.length = 0;

gdjs.s279Code.eventsList0(runtimeScene);
return;

}

gdjs['s279Code'] = gdjs.s279Code;
