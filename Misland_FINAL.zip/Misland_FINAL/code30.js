gdjs.s22Code = {};
gdjs.s22Code.GDcaseObjects1= [];
gdjs.s22Code.GDcaseObjects2= [];
gdjs.s22Code.GDimageObjects1= [];
gdjs.s22Code.GDimageObjects2= [];
gdjs.s22Code.GDoffObjects1= [];
gdjs.s22Code.GDoffObjects2= [];
gdjs.s22Code.GDonObjects1= [];
gdjs.s22Code.GDonObjects2= [];
gdjs.s22Code.GDstartObjects1= [];
gdjs.s22Code.GDstartObjects2= [];
gdjs.s22Code.GDBObjects1= [];
gdjs.s22Code.GDBObjects2= [];
gdjs.s22Code.GDblackObjects1= [];
gdjs.s22Code.GDblackObjects2= [];
gdjs.s22Code.GDAObjects1= [];
gdjs.s22Code.GDAObjects2= [];

gdjs.s22Code.conditionTrue_0 = {val:false};
gdjs.s22Code.condition0IsTrue_0 = {val:false};
gdjs.s22Code.condition1IsTrue_0 = {val:false};
gdjs.s22Code.conditionTrue_1 = {val:false};
gdjs.s22Code.condition0IsTrue_1 = {val:false};
gdjs.s22Code.condition1IsTrue_1 = {val:false};


gdjs.s22Code.mapOfGDgdjs_46s22Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s22Code.GDstartObjects1});gdjs.s22Code.mapOfGDgdjs_46s22Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s22Code.GDoffObjects1});gdjs.s22Code.mapOfGDgdjs_46s22Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s22Code.GDonObjects1});gdjs.s22Code.mapOfGDgdjs_46s22Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s22Code.GDAObjects1});gdjs.s22Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s22Code.condition0IsTrue_0.val = false;
{
{gdjs.s22Code.conditionTrue_1 = gdjs.s22Code.condition0IsTrue_0;
gdjs.s22Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(69097924);
}
}if (gdjs.s22Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\oldlib_v2.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s22Code.GDstartObjects1);

gdjs.s22Code.condition0IsTrue_0.val = false;
{
gdjs.s22Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s22Code.mapOfGDgdjs_46s22Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s22Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s22Code.GDoffObjects1);

gdjs.s22Code.condition0IsTrue_0.val = false;
{
gdjs.s22Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s22Code.mapOfGDgdjs_46s22Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s22Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s22Code.GDonObjects1);

gdjs.s22Code.condition0IsTrue_0.val = false;
{
gdjs.s22Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s22Code.mapOfGDgdjs_46s22Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s22Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s22Code.condition0IsTrue_0.val = false;
{
gdjs.s22Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s22Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s23", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s22Code.GDAObjects1);

gdjs.s22Code.condition0IsTrue_0.val = false;
{
gdjs.s22Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s22Code.mapOfGDgdjs_46s22Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s22Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s23", false);
}}

}


{


{
}

}


};

gdjs.s22Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s22Code.GDcaseObjects1.length = 0;
gdjs.s22Code.GDcaseObjects2.length = 0;
gdjs.s22Code.GDimageObjects1.length = 0;
gdjs.s22Code.GDimageObjects2.length = 0;
gdjs.s22Code.GDoffObjects1.length = 0;
gdjs.s22Code.GDoffObjects2.length = 0;
gdjs.s22Code.GDonObjects1.length = 0;
gdjs.s22Code.GDonObjects2.length = 0;
gdjs.s22Code.GDstartObjects1.length = 0;
gdjs.s22Code.GDstartObjects2.length = 0;
gdjs.s22Code.GDBObjects1.length = 0;
gdjs.s22Code.GDBObjects2.length = 0;
gdjs.s22Code.GDblackObjects1.length = 0;
gdjs.s22Code.GDblackObjects2.length = 0;
gdjs.s22Code.GDAObjects1.length = 0;
gdjs.s22Code.GDAObjects2.length = 0;

gdjs.s22Code.eventsList0(runtimeScene);
return;

}

gdjs['s22Code'] = gdjs.s22Code;
