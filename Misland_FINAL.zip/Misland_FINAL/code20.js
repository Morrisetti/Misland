gdjs.s13_461Code = {};
gdjs.s13_461Code.GDcaseObjects1= [];
gdjs.s13_461Code.GDcaseObjects2= [];
gdjs.s13_461Code.GDimageObjects1= [];
gdjs.s13_461Code.GDimageObjects2= [];
gdjs.s13_461Code.GDoffObjects1= [];
gdjs.s13_461Code.GDoffObjects2= [];
gdjs.s13_461Code.GDonObjects1= [];
gdjs.s13_461Code.GDonObjects2= [];
gdjs.s13_461Code.GDstartObjects1= [];
gdjs.s13_461Code.GDstartObjects2= [];
gdjs.s13_461Code.GDBObjects1= [];
gdjs.s13_461Code.GDBObjects2= [];
gdjs.s13_461Code.GDblackObjects1= [];
gdjs.s13_461Code.GDblackObjects2= [];
gdjs.s13_461Code.GDAObjects1= [];
gdjs.s13_461Code.GDAObjects2= [];

gdjs.s13_461Code.conditionTrue_0 = {val:false};
gdjs.s13_461Code.condition0IsTrue_0 = {val:false};
gdjs.s13_461Code.condition1IsTrue_0 = {val:false};


gdjs.s13_461Code.mapOfGDgdjs_46s13_95461Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s13_461Code.GDstartObjects1});gdjs.s13_461Code.mapOfGDgdjs_46s13_95461Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s13_461Code.GDoffObjects1});gdjs.s13_461Code.mapOfGDgdjs_46s13_95461Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s13_461Code.GDonObjects1});gdjs.s13_461Code.mapOfGDgdjs_46s13_95461Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s13_461Code.GDBObjects1});gdjs.s13_461Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s13_461Code.GDstartObjects1);

gdjs.s13_461Code.condition0IsTrue_0.val = false;
{
gdjs.s13_461Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s13_461Code.mapOfGDgdjs_46s13_95461Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s13_461Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s13_461Code.GDoffObjects1);

gdjs.s13_461Code.condition0IsTrue_0.val = false;
{
gdjs.s13_461Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s13_461Code.mapOfGDgdjs_46s13_95461Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s13_461Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s13_461Code.GDonObjects1);

gdjs.s13_461Code.condition0IsTrue_0.val = false;
{
gdjs.s13_461Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s13_461Code.mapOfGDgdjs_46s13_95461Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s13_461Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s13_461Code.condition0IsTrue_0.val = false;
{
gdjs.s13_461Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s13_461Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s15", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s13_461Code.GDBObjects1);

gdjs.s13_461Code.condition0IsTrue_0.val = false;
{
gdjs.s13_461Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s13_461Code.mapOfGDgdjs_46s13_95461Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s13_461Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s15", false);
}}

}


{


{
}

}


};

gdjs.s13_461Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s13_461Code.GDcaseObjects1.length = 0;
gdjs.s13_461Code.GDcaseObjects2.length = 0;
gdjs.s13_461Code.GDimageObjects1.length = 0;
gdjs.s13_461Code.GDimageObjects2.length = 0;
gdjs.s13_461Code.GDoffObjects1.length = 0;
gdjs.s13_461Code.GDoffObjects2.length = 0;
gdjs.s13_461Code.GDonObjects1.length = 0;
gdjs.s13_461Code.GDonObjects2.length = 0;
gdjs.s13_461Code.GDstartObjects1.length = 0;
gdjs.s13_461Code.GDstartObjects2.length = 0;
gdjs.s13_461Code.GDBObjects1.length = 0;
gdjs.s13_461Code.GDBObjects2.length = 0;
gdjs.s13_461Code.GDblackObjects1.length = 0;
gdjs.s13_461Code.GDblackObjects2.length = 0;
gdjs.s13_461Code.GDAObjects1.length = 0;
gdjs.s13_461Code.GDAObjects2.length = 0;

gdjs.s13_461Code.eventsList0(runtimeScene);
return;

}

gdjs['s13_461Code'] = gdjs.s13_461Code;
