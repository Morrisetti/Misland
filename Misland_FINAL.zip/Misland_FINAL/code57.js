gdjs.s43Code = {};
gdjs.s43Code.GDcaseObjects1= [];
gdjs.s43Code.GDcaseObjects2= [];
gdjs.s43Code.GDoffObjects1= [];
gdjs.s43Code.GDoffObjects2= [];
gdjs.s43Code.GDonObjects1= [];
gdjs.s43Code.GDonObjects2= [];
gdjs.s43Code.GDstartObjects1= [];
gdjs.s43Code.GDstartObjects2= [];
gdjs.s43Code.GDBObjects1= [];
gdjs.s43Code.GDBObjects2= [];
gdjs.s43Code.GDAObjects1= [];
gdjs.s43Code.GDAObjects2= [];
gdjs.s43Code.GDbugzObjects1= [];
gdjs.s43Code.GDbugzObjects2= [];
gdjs.s43Code.GDDOWNbuttonObjects1= [];
gdjs.s43Code.GDDOWNbuttonObjects2= [];
gdjs.s43Code.GDblackObjects1= [];
gdjs.s43Code.GDblackObjects2= [];
gdjs.s43Code.GDDOWNcolObjects1= [];
gdjs.s43Code.GDDOWNcolObjects2= [];
gdjs.s43Code.GDUPbuttonObjects1= [];
gdjs.s43Code.GDUPbuttonObjects2= [];
gdjs.s43Code.GDUPcolObjects1= [];
gdjs.s43Code.GDUPcolObjects2= [];
gdjs.s43Code.GDLbuttonObjects1= [];
gdjs.s43Code.GDLbuttonObjects2= [];
gdjs.s43Code.GDLcolObjects1= [];
gdjs.s43Code.GDLcolObjects2= [];
gdjs.s43Code.GDRbuttonObjects1= [];
gdjs.s43Code.GDRbuttonObjects2= [];
gdjs.s43Code.GDTALK2Objects1= [];
gdjs.s43Code.GDTALK2Objects2= [];
gdjs.s43Code.GDExitObjects1= [];
gdjs.s43Code.GDExitObjects2= [];
gdjs.s43Code.GDRcolObjects1= [];
gdjs.s43Code.GDRcolObjects2= [];
gdjs.s43Code.GDchapter4Objects1= [];
gdjs.s43Code.GDchapter4Objects2= [];
gdjs.s43Code.GDchapter3Objects1= [];
gdjs.s43Code.GDchapter3Objects2= [];
gdjs.s43Code.GDchapter2Objects1= [];
gdjs.s43Code.GDchapter2Objects2= [];
gdjs.s43Code.GDchapter1Objects1= [];
gdjs.s43Code.GDchapter1Objects2= [];
gdjs.s43Code.GDBGObjects1= [];
gdjs.s43Code.GDBGObjects2= [];

gdjs.s43Code.conditionTrue_0 = {val:false};
gdjs.s43Code.condition0IsTrue_0 = {val:false};
gdjs.s43Code.condition1IsTrue_0 = {val:false};
gdjs.s43Code.condition2IsTrue_0 = {val:false};
gdjs.s43Code.conditionTrue_1 = {val:false};
gdjs.s43Code.condition0IsTrue_1 = {val:false};
gdjs.s43Code.condition1IsTrue_1 = {val:false};
gdjs.s43Code.condition2IsTrue_1 = {val:false};


gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s43Code.GDDOWNbuttonObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s43Code.GDUPbuttonObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s43Code.GDRbuttonObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s43Code.GDLbuttonObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s43Code.GDbugzObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s43Code.GDRcolObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s43Code.GDbugzObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s43Code.GDLcolObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s43Code.GDbugzObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s43Code.GDUPcolObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s43Code.GDbugzObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s43Code.GDDOWNcolObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s43Code.GDbugzObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s43Code.GDDOWNcolObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s43Code.GDBObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s43Code.GDAObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s43Code.GDoffObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s43Code.GDonObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s43Code.GDbugzObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s43Code.GDExitObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s43Code.GDbugzObjects1});gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDTALK2Objects1Objects = Hashtable.newFrom({"TALK2": gdjs.s43Code.GDTALK2Objects1});gdjs.s43Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s43Code.GDDOWNbuttonObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
gdjs.s43Code.condition1IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s43Code.condition0IsTrue_0.val ) {
{
gdjs.s43Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s43Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s43Code.GDUPbuttonObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
gdjs.s43Code.condition1IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s43Code.condition0IsTrue_0.val ) {
{
gdjs.s43Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s43Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s43Code.GDRbuttonObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
gdjs.s43Code.condition1IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s43Code.condition0IsTrue_0.val ) {
{
gdjs.s43Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s43Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s43Code.GDLbuttonObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
gdjs.s43Code.condition1IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s43Code.condition0IsTrue_0.val ) {
{
gdjs.s43Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s43Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


gdjs.s43Code.condition0IsTrue_0.val = false;
{
{gdjs.s43Code.conditionTrue_1 = gdjs.s43Code.condition0IsTrue_0;
gdjs.s43Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(69618228);
}
}if (gdjs.s43Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter2v4.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s43Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects, gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s43Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s43Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects, gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s43Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s43Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects, gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s43Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s43Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects, gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s43Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s43Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects, gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s43Code.GDBObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s43Code.GDAObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s43Code.GDoffObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s43Code.GDonObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s43Code.condition0IsTrue_0.val = false;
gdjs.s43Code.condition1IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s43Code.condition0IsTrue_0.val ) {
{
gdjs.s43Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s43Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s43Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s43Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s43Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s43Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s43Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s43Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s43Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects, gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s43.1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK2"), gdjs.s43Code.GDTALK2Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);

gdjs.s43Code.condition0IsTrue_0.val = false;
{
gdjs.s43Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDbugzObjects1Objects, gdjs.s43Code.mapOfGDgdjs_46s43Code_46GDTALK2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s43Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s18", false);
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s43Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s43Code.GDbugzObjects1.length !== 0 ? gdjs.s43Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s43Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s43Code.GDcaseObjects1.length = 0;
gdjs.s43Code.GDcaseObjects2.length = 0;
gdjs.s43Code.GDoffObjects1.length = 0;
gdjs.s43Code.GDoffObjects2.length = 0;
gdjs.s43Code.GDonObjects1.length = 0;
gdjs.s43Code.GDonObjects2.length = 0;
gdjs.s43Code.GDstartObjects1.length = 0;
gdjs.s43Code.GDstartObjects2.length = 0;
gdjs.s43Code.GDBObjects1.length = 0;
gdjs.s43Code.GDBObjects2.length = 0;
gdjs.s43Code.GDAObjects1.length = 0;
gdjs.s43Code.GDAObjects2.length = 0;
gdjs.s43Code.GDbugzObjects1.length = 0;
gdjs.s43Code.GDbugzObjects2.length = 0;
gdjs.s43Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s43Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s43Code.GDblackObjects1.length = 0;
gdjs.s43Code.GDblackObjects2.length = 0;
gdjs.s43Code.GDDOWNcolObjects1.length = 0;
gdjs.s43Code.GDDOWNcolObjects2.length = 0;
gdjs.s43Code.GDUPbuttonObjects1.length = 0;
gdjs.s43Code.GDUPbuttonObjects2.length = 0;
gdjs.s43Code.GDUPcolObjects1.length = 0;
gdjs.s43Code.GDUPcolObjects2.length = 0;
gdjs.s43Code.GDLbuttonObjects1.length = 0;
gdjs.s43Code.GDLbuttonObjects2.length = 0;
gdjs.s43Code.GDLcolObjects1.length = 0;
gdjs.s43Code.GDLcolObjects2.length = 0;
gdjs.s43Code.GDRbuttonObjects1.length = 0;
gdjs.s43Code.GDRbuttonObjects2.length = 0;
gdjs.s43Code.GDTALK2Objects1.length = 0;
gdjs.s43Code.GDTALK2Objects2.length = 0;
gdjs.s43Code.GDExitObjects1.length = 0;
gdjs.s43Code.GDExitObjects2.length = 0;
gdjs.s43Code.GDRcolObjects1.length = 0;
gdjs.s43Code.GDRcolObjects2.length = 0;
gdjs.s43Code.GDchapter4Objects1.length = 0;
gdjs.s43Code.GDchapter4Objects2.length = 0;
gdjs.s43Code.GDchapter3Objects1.length = 0;
gdjs.s43Code.GDchapter3Objects2.length = 0;
gdjs.s43Code.GDchapter2Objects1.length = 0;
gdjs.s43Code.GDchapter2Objects2.length = 0;
gdjs.s43Code.GDchapter1Objects1.length = 0;
gdjs.s43Code.GDchapter1Objects2.length = 0;
gdjs.s43Code.GDBGObjects1.length = 0;
gdjs.s43Code.GDBGObjects2.length = 0;

gdjs.s43Code.eventsList0(runtimeScene);
return;

}

gdjs['s43Code'] = gdjs.s43Code;
