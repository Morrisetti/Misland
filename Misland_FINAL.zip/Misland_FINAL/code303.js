gdjs.s264Code = {};
gdjs.s264Code.GDcaseObjects1= [];
gdjs.s264Code.GDcaseObjects2= [];
gdjs.s264Code.GDimageObjects1= [];
gdjs.s264Code.GDimageObjects2= [];
gdjs.s264Code.GDoffObjects1= [];
gdjs.s264Code.GDoffObjects2= [];
gdjs.s264Code.GDonObjects1= [];
gdjs.s264Code.GDonObjects2= [];
gdjs.s264Code.GDstartObjects1= [];
gdjs.s264Code.GDstartObjects2= [];
gdjs.s264Code.GDBObjects1= [];
gdjs.s264Code.GDBObjects2= [];
gdjs.s264Code.GDblackObjects1= [];
gdjs.s264Code.GDblackObjects2= [];
gdjs.s264Code.GDAObjects1= [];
gdjs.s264Code.GDAObjects2= [];

gdjs.s264Code.conditionTrue_0 = {val:false};
gdjs.s264Code.condition0IsTrue_0 = {val:false};
gdjs.s264Code.condition1IsTrue_0 = {val:false};


gdjs.s264Code.mapOfGDgdjs_46s264Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s264Code.GDstartObjects1});gdjs.s264Code.mapOfGDgdjs_46s264Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s264Code.GDoffObjects1});gdjs.s264Code.mapOfGDgdjs_46s264Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s264Code.GDonObjects1});gdjs.s264Code.mapOfGDgdjs_46s264Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s264Code.GDBObjects1});gdjs.s264Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s264Code.GDstartObjects1);

gdjs.s264Code.condition0IsTrue_0.val = false;
{
gdjs.s264Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s264Code.mapOfGDgdjs_46s264Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s264Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s264Code.GDoffObjects1);

gdjs.s264Code.condition0IsTrue_0.val = false;
{
gdjs.s264Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s264Code.mapOfGDgdjs_46s264Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s264Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s264Code.GDonObjects1);

gdjs.s264Code.condition0IsTrue_0.val = false;
{
gdjs.s264Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s264Code.mapOfGDgdjs_46s264Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s264Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s264Code.condition0IsTrue_0.val = false;
{
gdjs.s264Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s264Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s265", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s264Code.GDBObjects1);

gdjs.s264Code.condition0IsTrue_0.val = false;
{
gdjs.s264Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s264Code.mapOfGDgdjs_46s264Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s264Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s265", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s264Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s264Code.GDcaseObjects1.length = 0;
gdjs.s264Code.GDcaseObjects2.length = 0;
gdjs.s264Code.GDimageObjects1.length = 0;
gdjs.s264Code.GDimageObjects2.length = 0;
gdjs.s264Code.GDoffObjects1.length = 0;
gdjs.s264Code.GDoffObjects2.length = 0;
gdjs.s264Code.GDonObjects1.length = 0;
gdjs.s264Code.GDonObjects2.length = 0;
gdjs.s264Code.GDstartObjects1.length = 0;
gdjs.s264Code.GDstartObjects2.length = 0;
gdjs.s264Code.GDBObjects1.length = 0;
gdjs.s264Code.GDBObjects2.length = 0;
gdjs.s264Code.GDblackObjects1.length = 0;
gdjs.s264Code.GDblackObjects2.length = 0;
gdjs.s264Code.GDAObjects1.length = 0;
gdjs.s264Code.GDAObjects2.length = 0;

gdjs.s264Code.eventsList0(runtimeScene);
return;

}

gdjs['s264Code'] = gdjs.s264Code;
