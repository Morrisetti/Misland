gdjs.s200Code = {};
gdjs.s200Code.GDcaseObjects1= [];
gdjs.s200Code.GDcaseObjects2= [];
gdjs.s200Code.GDimageObjects1= [];
gdjs.s200Code.GDimageObjects2= [];
gdjs.s200Code.GDoffObjects1= [];
gdjs.s200Code.GDoffObjects2= [];
gdjs.s200Code.GDonObjects1= [];
gdjs.s200Code.GDonObjects2= [];
gdjs.s200Code.GDstartObjects1= [];
gdjs.s200Code.GDstartObjects2= [];
gdjs.s200Code.GDBObjects1= [];
gdjs.s200Code.GDBObjects2= [];
gdjs.s200Code.GDblackObjects1= [];
gdjs.s200Code.GDblackObjects2= [];
gdjs.s200Code.GDAObjects1= [];
gdjs.s200Code.GDAObjects2= [];

gdjs.s200Code.conditionTrue_0 = {val:false};
gdjs.s200Code.condition0IsTrue_0 = {val:false};
gdjs.s200Code.condition1IsTrue_0 = {val:false};


gdjs.s200Code.mapOfGDgdjs_46s200Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s200Code.GDstartObjects1});gdjs.s200Code.mapOfGDgdjs_46s200Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s200Code.GDoffObjects1});gdjs.s200Code.mapOfGDgdjs_46s200Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s200Code.GDonObjects1});gdjs.s200Code.mapOfGDgdjs_46s200Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s200Code.GDAObjects1});gdjs.s200Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s200Code.GDstartObjects1);

gdjs.s200Code.condition0IsTrue_0.val = false;
{
gdjs.s200Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s200Code.mapOfGDgdjs_46s200Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s200Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s200Code.GDoffObjects1);

gdjs.s200Code.condition0IsTrue_0.val = false;
{
gdjs.s200Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s200Code.mapOfGDgdjs_46s200Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s200Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s200Code.GDonObjects1);

gdjs.s200Code.condition0IsTrue_0.val = false;
{
gdjs.s200Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s200Code.mapOfGDgdjs_46s200Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s200Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s200Code.condition0IsTrue_0.val = false;
{
gdjs.s200Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s200Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s201", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s200Code.GDAObjects1);

gdjs.s200Code.condition0IsTrue_0.val = false;
{
gdjs.s200Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s200Code.mapOfGDgdjs_46s200Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s200Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s201", false);
}}

}


{


{
}

}


};

gdjs.s200Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s200Code.GDcaseObjects1.length = 0;
gdjs.s200Code.GDcaseObjects2.length = 0;
gdjs.s200Code.GDimageObjects1.length = 0;
gdjs.s200Code.GDimageObjects2.length = 0;
gdjs.s200Code.GDoffObjects1.length = 0;
gdjs.s200Code.GDoffObjects2.length = 0;
gdjs.s200Code.GDonObjects1.length = 0;
gdjs.s200Code.GDonObjects2.length = 0;
gdjs.s200Code.GDstartObjects1.length = 0;
gdjs.s200Code.GDstartObjects2.length = 0;
gdjs.s200Code.GDBObjects1.length = 0;
gdjs.s200Code.GDBObjects2.length = 0;
gdjs.s200Code.GDblackObjects1.length = 0;
gdjs.s200Code.GDblackObjects2.length = 0;
gdjs.s200Code.GDAObjects1.length = 0;
gdjs.s200Code.GDAObjects2.length = 0;

gdjs.s200Code.eventsList0(runtimeScene);
return;

}

gdjs['s200Code'] = gdjs.s200Code;
