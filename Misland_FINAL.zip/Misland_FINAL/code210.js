gdjs.s1722Code = {};
gdjs.s1722Code.GDcaseObjects1= [];
gdjs.s1722Code.GDcaseObjects2= [];
gdjs.s1722Code.GDimageObjects1= [];
gdjs.s1722Code.GDimageObjects2= [];
gdjs.s1722Code.GDoffObjects1= [];
gdjs.s1722Code.GDoffObjects2= [];
gdjs.s1722Code.GDonObjects1= [];
gdjs.s1722Code.GDonObjects2= [];
gdjs.s1722Code.GDstartObjects1= [];
gdjs.s1722Code.GDstartObjects2= [];
gdjs.s1722Code.GDBObjects1= [];
gdjs.s1722Code.GDBObjects2= [];
gdjs.s1722Code.GDblackObjects1= [];
gdjs.s1722Code.GDblackObjects2= [];
gdjs.s1722Code.GDAObjects1= [];
gdjs.s1722Code.GDAObjects2= [];
gdjs.s1722Code.GDbuttonObjects1= [];
gdjs.s1722Code.GDbuttonObjects2= [];

gdjs.s1722Code.conditionTrue_0 = {val:false};
gdjs.s1722Code.condition0IsTrue_0 = {val:false};
gdjs.s1722Code.condition1IsTrue_0 = {val:false};


gdjs.s1722Code.mapOfGDgdjs_46s1722Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s1722Code.GDbuttonObjects1});gdjs.s1722Code.mapOfGDgdjs_46s1722Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s1722Code.GDoffObjects1});gdjs.s1722Code.mapOfGDgdjs_46s1722Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s1722Code.GDonObjects1});gdjs.s1722Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s1722Code.GDcaseObjects1);

gdjs.s1722Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s1722Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s1722Code.GDcaseObjects1[i].timerElapsedTime("", 1) ) {
        gdjs.s1722Code.condition0IsTrue_0.val = true;
        gdjs.s1722Code.GDcaseObjects1[k] = gdjs.s1722Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s1722Code.GDcaseObjects1.length = k;}if (gdjs.s1722Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s1632", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s1722Code.GDbuttonObjects1);

gdjs.s1722Code.condition0IsTrue_0.val = false;
{
gdjs.s1722Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s1722Code.mapOfGDgdjs_46s1722Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s1722Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s1732", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s1722Code.GDoffObjects1);

gdjs.s1722Code.condition0IsTrue_0.val = false;
{
gdjs.s1722Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s1722Code.mapOfGDgdjs_46s1722Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s1722Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s1722Code.GDonObjects1);

gdjs.s1722Code.condition0IsTrue_0.val = false;
{
gdjs.s1722Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s1722Code.mapOfGDgdjs_46s1722Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s1722Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s1722Code.condition0IsTrue_0.val = false;
{
gdjs.s1722Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s1722Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s1732", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s1722Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s1722Code.GDcaseObjects1.length = 0;
gdjs.s1722Code.GDcaseObjects2.length = 0;
gdjs.s1722Code.GDimageObjects1.length = 0;
gdjs.s1722Code.GDimageObjects2.length = 0;
gdjs.s1722Code.GDoffObjects1.length = 0;
gdjs.s1722Code.GDoffObjects2.length = 0;
gdjs.s1722Code.GDonObjects1.length = 0;
gdjs.s1722Code.GDonObjects2.length = 0;
gdjs.s1722Code.GDstartObjects1.length = 0;
gdjs.s1722Code.GDstartObjects2.length = 0;
gdjs.s1722Code.GDBObjects1.length = 0;
gdjs.s1722Code.GDBObjects2.length = 0;
gdjs.s1722Code.GDblackObjects1.length = 0;
gdjs.s1722Code.GDblackObjects2.length = 0;
gdjs.s1722Code.GDAObjects1.length = 0;
gdjs.s1722Code.GDAObjects2.length = 0;
gdjs.s1722Code.GDbuttonObjects1.length = 0;
gdjs.s1722Code.GDbuttonObjects2.length = 0;

gdjs.s1722Code.eventsList0(runtimeScene);
return;

}

gdjs['s1722Code'] = gdjs.s1722Code;
