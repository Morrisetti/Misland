gdjs.s201Code = {};
gdjs.s201Code.GDcaseObjects1= [];
gdjs.s201Code.GDcaseObjects2= [];
gdjs.s201Code.GDimageObjects1= [];
gdjs.s201Code.GDimageObjects2= [];
gdjs.s201Code.GDoffObjects1= [];
gdjs.s201Code.GDoffObjects2= [];
gdjs.s201Code.GDonObjects1= [];
gdjs.s201Code.GDonObjects2= [];
gdjs.s201Code.GDstartObjects1= [];
gdjs.s201Code.GDstartObjects2= [];
gdjs.s201Code.GDBObjects1= [];
gdjs.s201Code.GDBObjects2= [];
gdjs.s201Code.GDblackObjects1= [];
gdjs.s201Code.GDblackObjects2= [];
gdjs.s201Code.GDAObjects1= [];
gdjs.s201Code.GDAObjects2= [];

gdjs.s201Code.conditionTrue_0 = {val:false};
gdjs.s201Code.condition0IsTrue_0 = {val:false};
gdjs.s201Code.condition1IsTrue_0 = {val:false};


gdjs.s201Code.mapOfGDgdjs_46s201Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s201Code.GDstartObjects1});gdjs.s201Code.mapOfGDgdjs_46s201Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s201Code.GDoffObjects1});gdjs.s201Code.mapOfGDgdjs_46s201Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s201Code.GDonObjects1});gdjs.s201Code.mapOfGDgdjs_46s201Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s201Code.GDBObjects1});gdjs.s201Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s201Code.GDstartObjects1);

gdjs.s201Code.condition0IsTrue_0.val = false;
{
gdjs.s201Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s201Code.mapOfGDgdjs_46s201Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s201Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s201Code.GDoffObjects1);

gdjs.s201Code.condition0IsTrue_0.val = false;
{
gdjs.s201Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s201Code.mapOfGDgdjs_46s201Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s201Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s201Code.GDonObjects1);

gdjs.s201Code.condition0IsTrue_0.val = false;
{
gdjs.s201Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s201Code.mapOfGDgdjs_46s201Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s201Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s201Code.condition0IsTrue_0.val = false;
{
gdjs.s201Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s201Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s201.1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s201Code.GDBObjects1);

gdjs.s201Code.condition0IsTrue_0.val = false;
{
gdjs.s201Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s201Code.mapOfGDgdjs_46s201Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s201Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s201.1", false);
}}

}


{


{
}

}


};

gdjs.s201Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s201Code.GDcaseObjects1.length = 0;
gdjs.s201Code.GDcaseObjects2.length = 0;
gdjs.s201Code.GDimageObjects1.length = 0;
gdjs.s201Code.GDimageObjects2.length = 0;
gdjs.s201Code.GDoffObjects1.length = 0;
gdjs.s201Code.GDoffObjects2.length = 0;
gdjs.s201Code.GDonObjects1.length = 0;
gdjs.s201Code.GDonObjects2.length = 0;
gdjs.s201Code.GDstartObjects1.length = 0;
gdjs.s201Code.GDstartObjects2.length = 0;
gdjs.s201Code.GDBObjects1.length = 0;
gdjs.s201Code.GDBObjects2.length = 0;
gdjs.s201Code.GDblackObjects1.length = 0;
gdjs.s201Code.GDblackObjects2.length = 0;
gdjs.s201Code.GDAObjects1.length = 0;
gdjs.s201Code.GDAObjects2.length = 0;

gdjs.s201Code.eventsList0(runtimeScene);
return;

}

gdjs['s201Code'] = gdjs.s201Code;
