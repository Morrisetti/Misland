gdjs.s242Code = {};
gdjs.s242Code.GDcaseObjects1= [];
gdjs.s242Code.GDcaseObjects2= [];
gdjs.s242Code.GDimageObjects1= [];
gdjs.s242Code.GDimageObjects2= [];
gdjs.s242Code.GDoffObjects1= [];
gdjs.s242Code.GDoffObjects2= [];
gdjs.s242Code.GDonObjects1= [];
gdjs.s242Code.GDonObjects2= [];
gdjs.s242Code.GDstartObjects1= [];
gdjs.s242Code.GDstartObjects2= [];
gdjs.s242Code.GDBObjects1= [];
gdjs.s242Code.GDBObjects2= [];
gdjs.s242Code.GDblackObjects1= [];
gdjs.s242Code.GDblackObjects2= [];
gdjs.s242Code.GDAObjects1= [];
gdjs.s242Code.GDAObjects2= [];

gdjs.s242Code.conditionTrue_0 = {val:false};
gdjs.s242Code.condition0IsTrue_0 = {val:false};
gdjs.s242Code.condition1IsTrue_0 = {val:false};


gdjs.s242Code.mapOfGDgdjs_46s242Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s242Code.GDstartObjects1});gdjs.s242Code.mapOfGDgdjs_46s242Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s242Code.GDoffObjects1});gdjs.s242Code.mapOfGDgdjs_46s242Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s242Code.GDonObjects1});gdjs.s242Code.mapOfGDgdjs_46s242Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s242Code.GDAObjects1});gdjs.s242Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s242Code.GDstartObjects1);

gdjs.s242Code.condition0IsTrue_0.val = false;
{
gdjs.s242Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s242Code.mapOfGDgdjs_46s242Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s242Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s242Code.GDoffObjects1);

gdjs.s242Code.condition0IsTrue_0.val = false;
{
gdjs.s242Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s242Code.mapOfGDgdjs_46s242Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s242Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s242Code.GDonObjects1);

gdjs.s242Code.condition0IsTrue_0.val = false;
{
gdjs.s242Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s242Code.mapOfGDgdjs_46s242Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s242Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s242Code.condition0IsTrue_0.val = false;
{
gdjs.s242Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s242Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s243", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s242Code.GDAObjects1);

gdjs.s242Code.condition0IsTrue_0.val = false;
{
gdjs.s242Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s242Code.mapOfGDgdjs_46s242Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s242Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s243", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s242Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s242Code.GDcaseObjects1.length = 0;
gdjs.s242Code.GDcaseObjects2.length = 0;
gdjs.s242Code.GDimageObjects1.length = 0;
gdjs.s242Code.GDimageObjects2.length = 0;
gdjs.s242Code.GDoffObjects1.length = 0;
gdjs.s242Code.GDoffObjects2.length = 0;
gdjs.s242Code.GDonObjects1.length = 0;
gdjs.s242Code.GDonObjects2.length = 0;
gdjs.s242Code.GDstartObjects1.length = 0;
gdjs.s242Code.GDstartObjects2.length = 0;
gdjs.s242Code.GDBObjects1.length = 0;
gdjs.s242Code.GDBObjects2.length = 0;
gdjs.s242Code.GDblackObjects1.length = 0;
gdjs.s242Code.GDblackObjects2.length = 0;
gdjs.s242Code.GDAObjects1.length = 0;
gdjs.s242Code.GDAObjects2.length = 0;

gdjs.s242Code.eventsList0(runtimeScene);
return;

}

gdjs['s242Code'] = gdjs.s242Code;
