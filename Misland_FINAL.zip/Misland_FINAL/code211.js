gdjs.s1732Code = {};
gdjs.s1732Code.GDcaseObjects1= [];
gdjs.s1732Code.GDcaseObjects2= [];
gdjs.s1732Code.GDimageObjects1= [];
gdjs.s1732Code.GDimageObjects2= [];
gdjs.s1732Code.GDoffObjects1= [];
gdjs.s1732Code.GDoffObjects2= [];
gdjs.s1732Code.GDonObjects1= [];
gdjs.s1732Code.GDonObjects2= [];
gdjs.s1732Code.GDstartObjects1= [];
gdjs.s1732Code.GDstartObjects2= [];
gdjs.s1732Code.GDBObjects1= [];
gdjs.s1732Code.GDBObjects2= [];
gdjs.s1732Code.GDblackObjects1= [];
gdjs.s1732Code.GDblackObjects2= [];
gdjs.s1732Code.GDAObjects1= [];
gdjs.s1732Code.GDAObjects2= [];
gdjs.s1732Code.GDbuttonObjects1= [];
gdjs.s1732Code.GDbuttonObjects2= [];

gdjs.s1732Code.conditionTrue_0 = {val:false};
gdjs.s1732Code.condition0IsTrue_0 = {val:false};
gdjs.s1732Code.condition1IsTrue_0 = {val:false};


gdjs.s1732Code.mapOfGDgdjs_46s1732Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s1732Code.GDbuttonObjects1});gdjs.s1732Code.mapOfGDgdjs_46s1732Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s1732Code.GDoffObjects1});gdjs.s1732Code.mapOfGDgdjs_46s1732Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s1732Code.GDonObjects1});gdjs.s1732Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s1732Code.GDcaseObjects1);

gdjs.s1732Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s1732Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s1732Code.GDcaseObjects1[i].timerElapsedTime("", 0.5) ) {
        gdjs.s1732Code.condition0IsTrue_0.val = true;
        gdjs.s1732Code.GDcaseObjects1[k] = gdjs.s1732Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s1732Code.GDcaseObjects1.length = k;}if (gdjs.s1732Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s1742", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s1732Code.GDbuttonObjects1);

gdjs.s1732Code.condition0IsTrue_0.val = false;
{
gdjs.s1732Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s1732Code.mapOfGDgdjs_46s1732Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s1732Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s1732Code.GDoffObjects1);

gdjs.s1732Code.condition0IsTrue_0.val = false;
{
gdjs.s1732Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s1732Code.mapOfGDgdjs_46s1732Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s1732Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s1732Code.GDonObjects1);

gdjs.s1732Code.condition0IsTrue_0.val = false;
{
gdjs.s1732Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s1732Code.mapOfGDgdjs_46s1732Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s1732Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s1732Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s1732Code.GDcaseObjects1.length = 0;
gdjs.s1732Code.GDcaseObjects2.length = 0;
gdjs.s1732Code.GDimageObjects1.length = 0;
gdjs.s1732Code.GDimageObjects2.length = 0;
gdjs.s1732Code.GDoffObjects1.length = 0;
gdjs.s1732Code.GDoffObjects2.length = 0;
gdjs.s1732Code.GDonObjects1.length = 0;
gdjs.s1732Code.GDonObjects2.length = 0;
gdjs.s1732Code.GDstartObjects1.length = 0;
gdjs.s1732Code.GDstartObjects2.length = 0;
gdjs.s1732Code.GDBObjects1.length = 0;
gdjs.s1732Code.GDBObjects2.length = 0;
gdjs.s1732Code.GDblackObjects1.length = 0;
gdjs.s1732Code.GDblackObjects2.length = 0;
gdjs.s1732Code.GDAObjects1.length = 0;
gdjs.s1732Code.GDAObjects2.length = 0;
gdjs.s1732Code.GDbuttonObjects1.length = 0;
gdjs.s1732Code.GDbuttonObjects2.length = 0;

gdjs.s1732Code.eventsList0(runtimeScene);
return;

}

gdjs['s1732Code'] = gdjs.s1732Code;
