gdjs.C3Code = {};
gdjs.C3Code.GDcaseObjects1= [];
gdjs.C3Code.GDcaseObjects2= [];
gdjs.C3Code.GDimageObjects1= [];
gdjs.C3Code.GDimageObjects2= [];
gdjs.C3Code.GDoffObjects1= [];
gdjs.C3Code.GDoffObjects2= [];
gdjs.C3Code.GDonObjects1= [];
gdjs.C3Code.GDonObjects2= [];
gdjs.C3Code.GDstartObjects1= [];
gdjs.C3Code.GDstartObjects2= [];
gdjs.C3Code.GDBObjects1= [];
gdjs.C3Code.GDBObjects2= [];
gdjs.C3Code.GDblackObjects1= [];
gdjs.C3Code.GDblackObjects2= [];
gdjs.C3Code.GDAObjects1= [];
gdjs.C3Code.GDAObjects2= [];

gdjs.C3Code.conditionTrue_0 = {val:false};
gdjs.C3Code.condition0IsTrue_0 = {val:false};
gdjs.C3Code.condition1IsTrue_0 = {val:false};
gdjs.C3Code.conditionTrue_1 = {val:false};
gdjs.C3Code.condition0IsTrue_1 = {val:false};
gdjs.C3Code.condition1IsTrue_1 = {val:false};


gdjs.C3Code.mapOfGDgdjs_46C3Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.C3Code.GDstartObjects1});gdjs.C3Code.mapOfGDgdjs_46C3Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.C3Code.GDoffObjects1});gdjs.C3Code.mapOfGDgdjs_46C3Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.C3Code.GDonObjects1});gdjs.C3Code.mapOfGDgdjs_46C3Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.C3Code.GDstartObjects1});gdjs.C3Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.C3Code.condition0IsTrue_0.val = false;
{
{gdjs.C3Code.conditionTrue_1 = gdjs.C3Code.condition0IsTrue_0;
gdjs.C3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(70686404);
}
}if (gdjs.C3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter6_v1.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.C3Code.GDstartObjects1);

gdjs.C3Code.condition0IsTrue_0.val = false;
{
gdjs.C3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C3Code.mapOfGDgdjs_46C3Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.C3Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.C3Code.GDoffObjects1);

gdjs.C3Code.condition0IsTrue_0.val = false;
{
gdjs.C3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C3Code.mapOfGDgdjs_46C3Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.C3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.C3Code.GDonObjects1);

gdjs.C3Code.condition0IsTrue_0.val = false;
{
gdjs.C3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C3Code.mapOfGDgdjs_46C3Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.C3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.C3Code.condition0IsTrue_0.val = false;
{
gdjs.C3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.C3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s84", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.C3Code.GDstartObjects1);

gdjs.C3Code.condition0IsTrue_0.val = false;
{
gdjs.C3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C3Code.mapOfGDgdjs_46C3Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.C3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s84", false);
}}

}


{


{
}

}


};

gdjs.C3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.C3Code.GDcaseObjects1.length = 0;
gdjs.C3Code.GDcaseObjects2.length = 0;
gdjs.C3Code.GDimageObjects1.length = 0;
gdjs.C3Code.GDimageObjects2.length = 0;
gdjs.C3Code.GDoffObjects1.length = 0;
gdjs.C3Code.GDoffObjects2.length = 0;
gdjs.C3Code.GDonObjects1.length = 0;
gdjs.C3Code.GDonObjects2.length = 0;
gdjs.C3Code.GDstartObjects1.length = 0;
gdjs.C3Code.GDstartObjects2.length = 0;
gdjs.C3Code.GDBObjects1.length = 0;
gdjs.C3Code.GDBObjects2.length = 0;
gdjs.C3Code.GDblackObjects1.length = 0;
gdjs.C3Code.GDblackObjects2.length = 0;
gdjs.C3Code.GDAObjects1.length = 0;
gdjs.C3Code.GDAObjects2.length = 0;

gdjs.C3Code.eventsList0(runtimeScene);
return;

}

gdjs['C3Code'] = gdjs.C3Code;
