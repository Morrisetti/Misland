gdjs.chapselectCode = {};
gdjs.chapselectCode.GDcaseObjects1= [];
gdjs.chapselectCode.GDcaseObjects2= [];
gdjs.chapselectCode.GDimageObjects1= [];
gdjs.chapselectCode.GDimageObjects2= [];
gdjs.chapselectCode.GDoffObjects1= [];
gdjs.chapselectCode.GDoffObjects2= [];
gdjs.chapselectCode.GDonObjects1= [];
gdjs.chapselectCode.GDonObjects2= [];
gdjs.chapselectCode.GDstartObjects1= [];
gdjs.chapselectCode.GDstartObjects2= [];
gdjs.chapselectCode.GDBObjects1= [];
gdjs.chapselectCode.GDBObjects2= [];
gdjs.chapselectCode.GDAObjects1= [];
gdjs.chapselectCode.GDAObjects2= [];
gdjs.chapselectCode.GDcrosshairsObjects1= [];
gdjs.chapselectCode.GDcrosshairsObjects2= [];
gdjs.chapselectCode.GDDOWNbuttonObjects1= [];
gdjs.chapselectCode.GDDOWNbuttonObjects2= [];
gdjs.chapselectCode.GDDOWNcolObjects1= [];
gdjs.chapselectCode.GDDOWNcolObjects2= [];
gdjs.chapselectCode.GDUPbuttonObjects1= [];
gdjs.chapselectCode.GDUPbuttonObjects2= [];
gdjs.chapselectCode.GDUPcolObjects1= [];
gdjs.chapselectCode.GDUPcolObjects2= [];
gdjs.chapselectCode.GDLbuttonObjects1= [];
gdjs.chapselectCode.GDLbuttonObjects2= [];
gdjs.chapselectCode.GDLcolObjects1= [];
gdjs.chapselectCode.GDLcolObjects2= [];
gdjs.chapselectCode.GDRbuttonObjects1= [];
gdjs.chapselectCode.GDRbuttonObjects2= [];
gdjs.chapselectCode.GDRcolObjects1= [];
gdjs.chapselectCode.GDRcolObjects2= [];
gdjs.chapselectCode.GDchapter4Objects1= [];
gdjs.chapselectCode.GDchapter4Objects2= [];
gdjs.chapselectCode.GDchapter3Objects1= [];
gdjs.chapselectCode.GDchapter3Objects2= [];
gdjs.chapselectCode.GDchapter2Objects1= [];
gdjs.chapselectCode.GDchapter2Objects2= [];
gdjs.chapselectCode.GDblackObjects1= [];
gdjs.chapselectCode.GDblackObjects2= [];
gdjs.chapselectCode.GDchapter1Objects1= [];
gdjs.chapselectCode.GDchapter1Objects2= [];

gdjs.chapselectCode.conditionTrue_0 = {val:false};
gdjs.chapselectCode.condition0IsTrue_0 = {val:false};
gdjs.chapselectCode.condition1IsTrue_0 = {val:false};
gdjs.chapselectCode.condition2IsTrue_0 = {val:false};


gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.chapselectCode.GDDOWNbuttonObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.chapselectCode.GDUPbuttonObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.chapselectCode.GDRbuttonObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.chapselectCode.GDLbuttonObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.chapselectCode.GDRcolObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.chapselectCode.GDLcolObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.chapselectCode.GDUPcolObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.chapselectCode.GDDOWNcolObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.chapselectCode.GDDOWNcolObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.chapselectCode.GDBObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.chapselectCode.GDAObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.chapselectCode.GDoffObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.chapselectCode.GDonObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.chapselectCode.GDchapter1Objects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter2Objects1Objects = Hashtable.newFrom({"chapter2": gdjs.chapselectCode.GDchapter2Objects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter3Objects1Objects = Hashtable.newFrom({"chapter3": gdjs.chapselectCode.GDchapter3Objects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter4Objects1Objects = Hashtable.newFrom({"chapter4": gdjs.chapselectCode.GDchapter4Objects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.chapselectCode.GDchapter1Objects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.chapselectCode.GDAObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.chapselectCode.GDchapter1Objects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter2Objects1Objects = Hashtable.newFrom({"chapter2": gdjs.chapselectCode.GDchapter2Objects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.chapselectCode.GDAObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter3Objects1Objects = Hashtable.newFrom({"chapter3": gdjs.chapselectCode.GDchapter3Objects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.chapselectCode.GDAObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.chapselectCode.GDcrosshairsObjects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter4Objects1Objects = Hashtable.newFrom({"chapter4": gdjs.chapselectCode.GDchapter4Objects1});gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.chapselectCode.GDAObjects1});gdjs.chapselectCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.chapselectCode.GDDOWNbuttonObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.chapselectCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.chapselectCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.chapselectCode.GDUPbuttonObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.chapselectCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.chapselectCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.chapselectCode.GDRbuttonObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.chapselectCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.chapselectCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.chapselectCode.GDLbuttonObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.chapselectCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.chapselectCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.chapselectCode.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.chapselectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.chapselectCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.chapselectCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.chapselectCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.chapselectCode.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.chapselectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.chapselectCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.chapselectCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.chapselectCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.chapselectCode.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.chapselectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.chapselectCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.chapselectCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.chapselectCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.chapselectCode.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.chapselectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.chapselectCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.chapselectCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.chapselectCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.chapselectCode.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.chapselectCode.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.chapselectCode.GDBObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.chapselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "chapselect", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.chapselectCode.GDAObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.chapselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "intro", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.chapselectCode.GDoffObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.chapselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.chapselectCode.GDonObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.chapselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.chapselectCode.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter1Objects1Objects, false, runtimeScene, false);
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "intro", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter2"), gdjs.chapselectCode.GDchapter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter2Objects1Objects, false, runtimeScene, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "C2", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter3"), gdjs.chapselectCode.GDchapter3Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter3Objects1Objects, false, runtimeScene, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "C3", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter4"), gdjs.chapselectCode.GDchapter4Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter4Objects1Objects, false, runtimeScene, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "C4", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.chapselectCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.chapselectCode.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "intro", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.chapselectCode.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "intro", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.chapselectCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter2"), gdjs.chapselectCode.GDchapter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter2Objects1Objects, false, runtimeScene, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "C2", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.chapselectCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter3"), gdjs.chapselectCode.GDchapter3Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter3Objects1Objects, false, runtimeScene, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "C3", false);
}}

}


{


gdjs.chapselectCode.condition0IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.chapselectCode.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.chapselectCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter4"), gdjs.chapselectCode.GDchapter4Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.chapselectCode.GDcrosshairsObjects1);

gdjs.chapselectCode.condition0IsTrue_0.val = false;
gdjs.chapselectCode.condition1IsTrue_0.val = false;
{
gdjs.chapselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDcrosshairsObjects1Objects, gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDchapter4Objects1Objects, false, runtimeScene, false);
}if ( gdjs.chapselectCode.condition0IsTrue_0.val ) {
{
gdjs.chapselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.chapselectCode.mapOfGDgdjs_46chapselectCode_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.chapselectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "C4", false);
}}

}


{


{
}

}


};

gdjs.chapselectCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.chapselectCode.GDcaseObjects1.length = 0;
gdjs.chapselectCode.GDcaseObjects2.length = 0;
gdjs.chapselectCode.GDimageObjects1.length = 0;
gdjs.chapselectCode.GDimageObjects2.length = 0;
gdjs.chapselectCode.GDoffObjects1.length = 0;
gdjs.chapselectCode.GDoffObjects2.length = 0;
gdjs.chapselectCode.GDonObjects1.length = 0;
gdjs.chapselectCode.GDonObjects2.length = 0;
gdjs.chapselectCode.GDstartObjects1.length = 0;
gdjs.chapselectCode.GDstartObjects2.length = 0;
gdjs.chapselectCode.GDBObjects1.length = 0;
gdjs.chapselectCode.GDBObjects2.length = 0;
gdjs.chapselectCode.GDAObjects1.length = 0;
gdjs.chapselectCode.GDAObjects2.length = 0;
gdjs.chapselectCode.GDcrosshairsObjects1.length = 0;
gdjs.chapselectCode.GDcrosshairsObjects2.length = 0;
gdjs.chapselectCode.GDDOWNbuttonObjects1.length = 0;
gdjs.chapselectCode.GDDOWNbuttonObjects2.length = 0;
gdjs.chapselectCode.GDDOWNcolObjects1.length = 0;
gdjs.chapselectCode.GDDOWNcolObjects2.length = 0;
gdjs.chapselectCode.GDUPbuttonObjects1.length = 0;
gdjs.chapselectCode.GDUPbuttonObjects2.length = 0;
gdjs.chapselectCode.GDUPcolObjects1.length = 0;
gdjs.chapselectCode.GDUPcolObjects2.length = 0;
gdjs.chapselectCode.GDLbuttonObjects1.length = 0;
gdjs.chapselectCode.GDLbuttonObjects2.length = 0;
gdjs.chapselectCode.GDLcolObjects1.length = 0;
gdjs.chapselectCode.GDLcolObjects2.length = 0;
gdjs.chapselectCode.GDRbuttonObjects1.length = 0;
gdjs.chapselectCode.GDRbuttonObjects2.length = 0;
gdjs.chapselectCode.GDRcolObjects1.length = 0;
gdjs.chapselectCode.GDRcolObjects2.length = 0;
gdjs.chapselectCode.GDchapter4Objects1.length = 0;
gdjs.chapselectCode.GDchapter4Objects2.length = 0;
gdjs.chapselectCode.GDchapter3Objects1.length = 0;
gdjs.chapselectCode.GDchapter3Objects2.length = 0;
gdjs.chapselectCode.GDchapter2Objects1.length = 0;
gdjs.chapselectCode.GDchapter2Objects2.length = 0;
gdjs.chapselectCode.GDblackObjects1.length = 0;
gdjs.chapselectCode.GDblackObjects2.length = 0;
gdjs.chapselectCode.GDchapter1Objects1.length = 0;
gdjs.chapselectCode.GDchapter1Objects2.length = 0;

gdjs.chapselectCode.eventsList0(runtimeScene);
return;

}

gdjs['chapselectCode'] = gdjs.chapselectCode;
