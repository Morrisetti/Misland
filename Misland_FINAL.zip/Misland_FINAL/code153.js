gdjs.s137Code = {};
gdjs.s137Code.GDcaseObjects1= [];
gdjs.s137Code.GDcaseObjects2= [];
gdjs.s137Code.GDimageObjects1= [];
gdjs.s137Code.GDimageObjects2= [];
gdjs.s137Code.GDoffObjects1= [];
gdjs.s137Code.GDoffObjects2= [];
gdjs.s137Code.GDonObjects1= [];
gdjs.s137Code.GDonObjects2= [];
gdjs.s137Code.GDstartObjects1= [];
gdjs.s137Code.GDstartObjects2= [];
gdjs.s137Code.GDBObjects1= [];
gdjs.s137Code.GDBObjects2= [];
gdjs.s137Code.GDblackObjects1= [];
gdjs.s137Code.GDblackObjects2= [];
gdjs.s137Code.GDAObjects1= [];
gdjs.s137Code.GDAObjects2= [];
gdjs.s137Code.GDbuttonObjects1= [];
gdjs.s137Code.GDbuttonObjects2= [];

gdjs.s137Code.conditionTrue_0 = {val:false};
gdjs.s137Code.condition0IsTrue_0 = {val:false};
gdjs.s137Code.condition1IsTrue_0 = {val:false};


gdjs.s137Code.mapOfGDgdjs_46s137Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s137Code.GDbuttonObjects1});gdjs.s137Code.mapOfGDgdjs_46s137Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s137Code.GDoffObjects1});gdjs.s137Code.mapOfGDgdjs_46s137Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s137Code.GDonObjects1});gdjs.s137Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s137Code.GDcaseObjects1);

gdjs.s137Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s137Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s137Code.GDcaseObjects1[i].timerElapsedTime("", 1) ) {
        gdjs.s137Code.condition0IsTrue_0.val = true;
        gdjs.s137Code.GDcaseObjects1[k] = gdjs.s137Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s137Code.GDcaseObjects1.length = k;}if (gdjs.s137Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s132", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s137Code.GDbuttonObjects1);

gdjs.s137Code.condition0IsTrue_0.val = false;
{
gdjs.s137Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s137Code.mapOfGDgdjs_46s137Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s137Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s138", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s137Code.GDoffObjects1);

gdjs.s137Code.condition0IsTrue_0.val = false;
{
gdjs.s137Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s137Code.mapOfGDgdjs_46s137Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s137Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s137Code.GDonObjects1);

gdjs.s137Code.condition0IsTrue_0.val = false;
{
gdjs.s137Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s137Code.mapOfGDgdjs_46s137Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s137Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s137Code.condition0IsTrue_0.val = false;
{
gdjs.s137Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s137Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s138", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s137Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s137Code.GDcaseObjects1.length = 0;
gdjs.s137Code.GDcaseObjects2.length = 0;
gdjs.s137Code.GDimageObjects1.length = 0;
gdjs.s137Code.GDimageObjects2.length = 0;
gdjs.s137Code.GDoffObjects1.length = 0;
gdjs.s137Code.GDoffObjects2.length = 0;
gdjs.s137Code.GDonObjects1.length = 0;
gdjs.s137Code.GDonObjects2.length = 0;
gdjs.s137Code.GDstartObjects1.length = 0;
gdjs.s137Code.GDstartObjects2.length = 0;
gdjs.s137Code.GDBObjects1.length = 0;
gdjs.s137Code.GDBObjects2.length = 0;
gdjs.s137Code.GDblackObjects1.length = 0;
gdjs.s137Code.GDblackObjects2.length = 0;
gdjs.s137Code.GDAObjects1.length = 0;
gdjs.s137Code.GDAObjects2.length = 0;
gdjs.s137Code.GDbuttonObjects1.length = 0;
gdjs.s137Code.GDbuttonObjects2.length = 0;

gdjs.s137Code.eventsList0(runtimeScene);
return;

}

gdjs['s137Code'] = gdjs.s137Code;
