gdjs.s60Code = {};
gdjs.s60Code.GDcaseObjects1= [];
gdjs.s60Code.GDcaseObjects2= [];
gdjs.s60Code.GDoffObjects1= [];
gdjs.s60Code.GDoffObjects2= [];
gdjs.s60Code.GDonObjects1= [];
gdjs.s60Code.GDonObjects2= [];
gdjs.s60Code.GDstartObjects1= [];
gdjs.s60Code.GDstartObjects2= [];
gdjs.s60Code.GDBObjects1= [];
gdjs.s60Code.GDBObjects2= [];
gdjs.s60Code.GDAObjects1= [];
gdjs.s60Code.GDAObjects2= [];
gdjs.s60Code.GDbugzObjects1= [];
gdjs.s60Code.GDbugzObjects2= [];
gdjs.s60Code.GDDOWNbuttonObjects1= [];
gdjs.s60Code.GDDOWNbuttonObjects2= [];
gdjs.s60Code.GDblackObjects1= [];
gdjs.s60Code.GDblackObjects2= [];
gdjs.s60Code.GDDOWNcolObjects1= [];
gdjs.s60Code.GDDOWNcolObjects2= [];
gdjs.s60Code.GDUPbuttonObjects1= [];
gdjs.s60Code.GDUPbuttonObjects2= [];
gdjs.s60Code.GDUPcolObjects1= [];
gdjs.s60Code.GDUPcolObjects2= [];
gdjs.s60Code.GDLbuttonObjects1= [];
gdjs.s60Code.GDLbuttonObjects2= [];
gdjs.s60Code.GDLcolObjects1= [];
gdjs.s60Code.GDLcolObjects2= [];
gdjs.s60Code.GDRbuttonObjects1= [];
gdjs.s60Code.GDRbuttonObjects2= [];
gdjs.s60Code.GDTALK2Objects1= [];
gdjs.s60Code.GDTALK2Objects2= [];
gdjs.s60Code.GDdeathObjects1= [];
gdjs.s60Code.GDdeathObjects2= [];
gdjs.s60Code.GDExitObjects1= [];
gdjs.s60Code.GDExitObjects2= [];
gdjs.s60Code.GDRcolObjects1= [];
gdjs.s60Code.GDRcolObjects2= [];
gdjs.s60Code.GDchapter4Objects1= [];
gdjs.s60Code.GDchapter4Objects2= [];
gdjs.s60Code.GDchapter3Objects1= [];
gdjs.s60Code.GDchapter3Objects2= [];
gdjs.s60Code.GDchapter2Objects1= [];
gdjs.s60Code.GDchapter2Objects2= [];
gdjs.s60Code.GDchapter1Objects1= [];
gdjs.s60Code.GDchapter1Objects2= [];
gdjs.s60Code.GDBGObjects1= [];
gdjs.s60Code.GDBGObjects2= [];
gdjs.s60Code.GDNewObject2Objects1= [];
gdjs.s60Code.GDNewObject2Objects2= [];
gdjs.s60Code.GDNewObjectObjects1= [];
gdjs.s60Code.GDNewObjectObjects2= [];

gdjs.s60Code.conditionTrue_0 = {val:false};
gdjs.s60Code.condition0IsTrue_0 = {val:false};
gdjs.s60Code.condition1IsTrue_0 = {val:false};
gdjs.s60Code.condition2IsTrue_0 = {val:false};
gdjs.s60Code.conditionTrue_1 = {val:false};
gdjs.s60Code.condition0IsTrue_1 = {val:false};
gdjs.s60Code.condition1IsTrue_1 = {val:false};
gdjs.s60Code.condition2IsTrue_1 = {val:false};


gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s60Code.GDDOWNbuttonObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s60Code.GDUPbuttonObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s60Code.GDRbuttonObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s60Code.GDLbuttonObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s60Code.GDbugzObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s60Code.GDRcolObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s60Code.GDbugzObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s60Code.GDLcolObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s60Code.GDbugzObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s60Code.GDUPcolObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s60Code.GDbugzObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s60Code.GDDOWNcolObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s60Code.GDbugzObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s60Code.GDDOWNcolObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s60Code.GDBObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s60Code.GDAObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s60Code.GDoffObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s60Code.GDonObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s60Code.GDbugzObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s60Code.GDExitObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s60Code.GDbugzObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDTALK2Objects1Objects = Hashtable.newFrom({"TALK2": gdjs.s60Code.GDTALK2Objects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s60Code.GDbugzObjects1});gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDdeathObjects1Objects = Hashtable.newFrom({"death": gdjs.s60Code.GDdeathObjects1});gdjs.s60Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s60Code.GDDOWNbuttonObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
gdjs.s60Code.condition1IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s60Code.condition0IsTrue_0.val ) {
{
gdjs.s60Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s60Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s60Code.GDUPbuttonObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
gdjs.s60Code.condition1IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s60Code.condition0IsTrue_0.val ) {
{
gdjs.s60Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s60Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s60Code.GDRbuttonObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
gdjs.s60Code.condition1IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s60Code.condition0IsTrue_0.val ) {
{
gdjs.s60Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s60Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s60Code.GDLbuttonObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
gdjs.s60Code.condition1IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s60Code.condition0IsTrue_0.val ) {
{
gdjs.s60Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s60Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


gdjs.s60Code.condition0IsTrue_0.val = false;
{
{gdjs.s60Code.conditionTrue_1 = gdjs.s60Code.condition0IsTrue_0;
gdjs.s60Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(70059340);
}
}if (gdjs.s60Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter2_v3.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s60Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects, gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s60Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s60Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects, gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s60Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s60Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects, gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s60Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s60Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects, gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s60Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s60Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects, gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s60Code.GDBObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s60Code.GDAObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s60Code.GDoffObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s60Code.GDonObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s60Code.condition0IsTrue_0.val = false;
gdjs.s60Code.condition1IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s60Code.condition0IsTrue_0.val ) {
{
gdjs.s60Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s60Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s60Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s60Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s60Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s60Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s60Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s60Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s60Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects, gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s58", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK2"), gdjs.s60Code.GDTALK2Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects, gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDTALK2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s59", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s60Code.GDdeathObjects1);

gdjs.s60Code.condition0IsTrue_0.val = false;
{
gdjs.s60Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDbugzObjects1Objects, gdjs.s60Code.mapOfGDgdjs_46s60Code_46GDdeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s60Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s57", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s60Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s60Code.GDbugzObjects1.length !== 0 ? gdjs.s60Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s60Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s60Code.GDcaseObjects1.length = 0;
gdjs.s60Code.GDcaseObjects2.length = 0;
gdjs.s60Code.GDoffObjects1.length = 0;
gdjs.s60Code.GDoffObjects2.length = 0;
gdjs.s60Code.GDonObjects1.length = 0;
gdjs.s60Code.GDonObjects2.length = 0;
gdjs.s60Code.GDstartObjects1.length = 0;
gdjs.s60Code.GDstartObjects2.length = 0;
gdjs.s60Code.GDBObjects1.length = 0;
gdjs.s60Code.GDBObjects2.length = 0;
gdjs.s60Code.GDAObjects1.length = 0;
gdjs.s60Code.GDAObjects2.length = 0;
gdjs.s60Code.GDbugzObjects1.length = 0;
gdjs.s60Code.GDbugzObjects2.length = 0;
gdjs.s60Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s60Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s60Code.GDblackObjects1.length = 0;
gdjs.s60Code.GDblackObjects2.length = 0;
gdjs.s60Code.GDDOWNcolObjects1.length = 0;
gdjs.s60Code.GDDOWNcolObjects2.length = 0;
gdjs.s60Code.GDUPbuttonObjects1.length = 0;
gdjs.s60Code.GDUPbuttonObjects2.length = 0;
gdjs.s60Code.GDUPcolObjects1.length = 0;
gdjs.s60Code.GDUPcolObjects2.length = 0;
gdjs.s60Code.GDLbuttonObjects1.length = 0;
gdjs.s60Code.GDLbuttonObjects2.length = 0;
gdjs.s60Code.GDLcolObjects1.length = 0;
gdjs.s60Code.GDLcolObjects2.length = 0;
gdjs.s60Code.GDRbuttonObjects1.length = 0;
gdjs.s60Code.GDRbuttonObjects2.length = 0;
gdjs.s60Code.GDTALK2Objects1.length = 0;
gdjs.s60Code.GDTALK2Objects2.length = 0;
gdjs.s60Code.GDdeathObjects1.length = 0;
gdjs.s60Code.GDdeathObjects2.length = 0;
gdjs.s60Code.GDExitObjects1.length = 0;
gdjs.s60Code.GDExitObjects2.length = 0;
gdjs.s60Code.GDRcolObjects1.length = 0;
gdjs.s60Code.GDRcolObjects2.length = 0;
gdjs.s60Code.GDchapter4Objects1.length = 0;
gdjs.s60Code.GDchapter4Objects2.length = 0;
gdjs.s60Code.GDchapter3Objects1.length = 0;
gdjs.s60Code.GDchapter3Objects2.length = 0;
gdjs.s60Code.GDchapter2Objects1.length = 0;
gdjs.s60Code.GDchapter2Objects2.length = 0;
gdjs.s60Code.GDchapter1Objects1.length = 0;
gdjs.s60Code.GDchapter1Objects2.length = 0;
gdjs.s60Code.GDBGObjects1.length = 0;
gdjs.s60Code.GDBGObjects2.length = 0;
gdjs.s60Code.GDNewObject2Objects1.length = 0;
gdjs.s60Code.GDNewObject2Objects2.length = 0;
gdjs.s60Code.GDNewObjectObjects1.length = 0;
gdjs.s60Code.GDNewObjectObjects2.length = 0;

gdjs.s60Code.eventsList0(runtimeScene);
return;

}

gdjs['s60Code'] = gdjs.s60Code;
