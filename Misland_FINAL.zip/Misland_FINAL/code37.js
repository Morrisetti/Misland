gdjs.s27Code = {};
gdjs.s27Code.GDcaseObjects1= [];
gdjs.s27Code.GDcaseObjects2= [];
gdjs.s27Code.GDimageObjects1= [];
gdjs.s27Code.GDimageObjects2= [];
gdjs.s27Code.GDoffObjects1= [];
gdjs.s27Code.GDoffObjects2= [];
gdjs.s27Code.GDonObjects1= [];
gdjs.s27Code.GDonObjects2= [];
gdjs.s27Code.GDstartObjects1= [];
gdjs.s27Code.GDstartObjects2= [];
gdjs.s27Code.GDBObjects1= [];
gdjs.s27Code.GDBObjects2= [];
gdjs.s27Code.GDblackObjects1= [];
gdjs.s27Code.GDblackObjects2= [];
gdjs.s27Code.GDAObjects1= [];
gdjs.s27Code.GDAObjects2= [];

gdjs.s27Code.conditionTrue_0 = {val:false};
gdjs.s27Code.condition0IsTrue_0 = {val:false};
gdjs.s27Code.condition1IsTrue_0 = {val:false};


gdjs.s27Code.mapOfGDgdjs_46s27Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s27Code.GDstartObjects1});gdjs.s27Code.mapOfGDgdjs_46s27Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s27Code.GDoffObjects1});gdjs.s27Code.mapOfGDgdjs_46s27Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s27Code.GDonObjects1});gdjs.s27Code.mapOfGDgdjs_46s27Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s27Code.GDBObjects1});gdjs.s27Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s27Code.GDstartObjects1);

gdjs.s27Code.condition0IsTrue_0.val = false;
{
gdjs.s27Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s27Code.mapOfGDgdjs_46s27Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s27Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s27Code.GDoffObjects1);

gdjs.s27Code.condition0IsTrue_0.val = false;
{
gdjs.s27Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s27Code.mapOfGDgdjs_46s27Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s27Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s27Code.GDonObjects1);

gdjs.s27Code.condition0IsTrue_0.val = false;
{
gdjs.s27Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s27Code.mapOfGDgdjs_46s27Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s27Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s27Code.condition0IsTrue_0.val = false;
{
gdjs.s27Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s27Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s28", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s27Code.GDBObjects1);

gdjs.s27Code.condition0IsTrue_0.val = false;
{
gdjs.s27Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s27Code.mapOfGDgdjs_46s27Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s27Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s28", false);
}}

}


{


{
}

}


};

gdjs.s27Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s27Code.GDcaseObjects1.length = 0;
gdjs.s27Code.GDcaseObjects2.length = 0;
gdjs.s27Code.GDimageObjects1.length = 0;
gdjs.s27Code.GDimageObjects2.length = 0;
gdjs.s27Code.GDoffObjects1.length = 0;
gdjs.s27Code.GDoffObjects2.length = 0;
gdjs.s27Code.GDonObjects1.length = 0;
gdjs.s27Code.GDonObjects2.length = 0;
gdjs.s27Code.GDstartObjects1.length = 0;
gdjs.s27Code.GDstartObjects2.length = 0;
gdjs.s27Code.GDBObjects1.length = 0;
gdjs.s27Code.GDBObjects2.length = 0;
gdjs.s27Code.GDblackObjects1.length = 0;
gdjs.s27Code.GDblackObjects2.length = 0;
gdjs.s27Code.GDAObjects1.length = 0;
gdjs.s27Code.GDAObjects2.length = 0;

gdjs.s27Code.eventsList0(runtimeScene);
return;

}

gdjs['s27Code'] = gdjs.s27Code;
