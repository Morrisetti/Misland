gdjs.s226Code = {};
gdjs.s226Code.GDcaseObjects1= [];
gdjs.s226Code.GDcaseObjects2= [];
gdjs.s226Code.GDoffObjects1= [];
gdjs.s226Code.GDoffObjects2= [];
gdjs.s226Code.GDonObjects1= [];
gdjs.s226Code.GDonObjects2= [];
gdjs.s226Code.GDstartObjects1= [];
gdjs.s226Code.GDstartObjects2= [];
gdjs.s226Code.GDBObjects1= [];
gdjs.s226Code.GDBObjects2= [];
gdjs.s226Code.GDAObjects1= [];
gdjs.s226Code.GDAObjects2= [];
gdjs.s226Code.GDbugzObjects1= [];
gdjs.s226Code.GDbugzObjects2= [];
gdjs.s226Code.GDDOWNbuttonObjects1= [];
gdjs.s226Code.GDDOWNbuttonObjects2= [];
gdjs.s226Code.GDblackObjects1= [];
gdjs.s226Code.GDblackObjects2= [];
gdjs.s226Code.GDdeathObjects1= [];
gdjs.s226Code.GDdeathObjects2= [];
gdjs.s226Code.GDUPbuttonObjects1= [];
gdjs.s226Code.GDUPbuttonObjects2= [];
gdjs.s226Code.GDplatformObjects1= [];
gdjs.s226Code.GDplatformObjects2= [];
gdjs.s226Code.GDLbuttonObjects1= [];
gdjs.s226Code.GDLbuttonObjects2= [];
gdjs.s226Code.GDLcolObjects1= [];
gdjs.s226Code.GDLcolObjects2= [];
gdjs.s226Code.GDRbuttonObjects1= [];
gdjs.s226Code.GDRbuttonObjects2= [];
gdjs.s226Code.GDTALK2Objects1= [];
gdjs.s226Code.GDTALK2Objects2= [];
gdjs.s226Code.GDExitObjects1= [];
gdjs.s226Code.GDExitObjects2= [];
gdjs.s226Code.GDRcolObjects1= [];
gdjs.s226Code.GDRcolObjects2= [];
gdjs.s226Code.GDchapter4Objects1= [];
gdjs.s226Code.GDchapter4Objects2= [];
gdjs.s226Code.GDchapter3Objects1= [];
gdjs.s226Code.GDchapter3Objects2= [];
gdjs.s226Code.GDchapter2Objects1= [];
gdjs.s226Code.GDchapter2Objects2= [];
gdjs.s226Code.GDchapter1Objects1= [];
gdjs.s226Code.GDchapter1Objects2= [];
gdjs.s226Code.GDBGObjects1= [];
gdjs.s226Code.GDBGObjects2= [];

gdjs.s226Code.conditionTrue_0 = {val:false};
gdjs.s226Code.condition0IsTrue_0 = {val:false};
gdjs.s226Code.condition1IsTrue_0 = {val:false};
gdjs.s226Code.condition2IsTrue_0 = {val:false};
gdjs.s226Code.conditionTrue_1 = {val:false};
gdjs.s226Code.condition0IsTrue_1 = {val:false};
gdjs.s226Code.condition1IsTrue_1 = {val:false};
gdjs.s226Code.condition2IsTrue_1 = {val:false};


gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s226Code.GDDOWNbuttonObjects1});gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s226Code.GDUPbuttonObjects1});gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s226Code.GDRbuttonObjects1});gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s226Code.GDLbuttonObjects1});gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s226Code.GDbugzObjects1});gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s226Code.GDExitObjects1});gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s226Code.GDBObjects1});gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s226Code.GDAObjects1});gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s226Code.GDoffObjects1});gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s226Code.GDonObjects1});gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s226Code.GDbugzObjects1});gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDdeathObjects1Objects = Hashtable.newFrom({"death": gdjs.s226Code.GDdeathObjects1});gdjs.s226Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s226Code.GDDOWNbuttonObjects1);

gdjs.s226Code.condition0IsTrue_0.val = false;
gdjs.s226Code.condition1IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s226Code.condition0IsTrue_0.val ) {
{
gdjs.s226Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s226Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


gdjs.s226Code.condition0IsTrue_0.val = false;
{
{gdjs.s226Code.conditionTrue_1 = gdjs.s226Code.condition0IsTrue_0;
gdjs.s226Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(73936652);
}
}if (gdjs.s226Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\threatre_v2.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s226Code.GDUPbuttonObjects1);

gdjs.s226Code.condition0IsTrue_0.val = false;
gdjs.s226Code.condition1IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s226Code.condition0IsTrue_0.val ) {
{
gdjs.s226Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s226Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s226Code.GDRbuttonObjects1);

gdjs.s226Code.condition0IsTrue_0.val = false;
gdjs.s226Code.condition1IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s226Code.condition0IsTrue_0.val ) {
{
gdjs.s226Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s226Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{}{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s226Code.GDLbuttonObjects1);

gdjs.s226Code.condition0IsTrue_0.val = false;
gdjs.s226Code.condition1IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s226Code.condition0IsTrue_0.val ) {
{
gdjs.s226Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s226Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].flipX(true);
}
}{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s226Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);

gdjs.s226Code.condition0IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDbugzObjects1Objects, gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s226Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s227", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s226Code.GDBObjects1);

gdjs.s226Code.condition0IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s226Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s226Code.GDAObjects1);

gdjs.s226Code.condition0IsTrue_0.val = false;
gdjs.s226Code.condition1IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDAObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s226Code.condition0IsTrue_0.val ) {
{
{gdjs.s226Code.conditionTrue_1 = gdjs.s226Code.condition1IsTrue_0;
gdjs.s226Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(73944908);
}
}}
if (gdjs.s226Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s226Code.GDoffObjects1);

gdjs.s226Code.condition0IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s226Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s226Code.GDonObjects1);

gdjs.s226Code.condition0IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s226Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s226Code.condition0IsTrue_0.val = false;
gdjs.s226Code.condition1IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s226Code.condition0IsTrue_0.val ) {
{
gdjs.s226Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s226Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s226Code.condition0IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s226Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s226Code.condition0IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s226Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s226Code.condition0IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s226Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s226Code.condition0IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s226Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s226Code.GDdeathObjects1);

gdjs.s226Code.condition0IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDbugzObjects1Objects, gdjs.s226Code.mapOfGDgdjs_46s226Code_46GDdeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s226Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s14", false);
}}

}


{


gdjs.s226Code.condition0IsTrue_0.val = false;
{
gdjs.s226Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s226Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s226Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s226Code.GDbugzObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s226Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s226Code.GDbugzObjects1.length !== 0 ? gdjs.s226Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s226Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s226Code.GDcaseObjects1.length = 0;
gdjs.s226Code.GDcaseObjects2.length = 0;
gdjs.s226Code.GDoffObjects1.length = 0;
gdjs.s226Code.GDoffObjects2.length = 0;
gdjs.s226Code.GDonObjects1.length = 0;
gdjs.s226Code.GDonObjects2.length = 0;
gdjs.s226Code.GDstartObjects1.length = 0;
gdjs.s226Code.GDstartObjects2.length = 0;
gdjs.s226Code.GDBObjects1.length = 0;
gdjs.s226Code.GDBObjects2.length = 0;
gdjs.s226Code.GDAObjects1.length = 0;
gdjs.s226Code.GDAObjects2.length = 0;
gdjs.s226Code.GDbugzObjects1.length = 0;
gdjs.s226Code.GDbugzObjects2.length = 0;
gdjs.s226Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s226Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s226Code.GDblackObjects1.length = 0;
gdjs.s226Code.GDblackObjects2.length = 0;
gdjs.s226Code.GDdeathObjects1.length = 0;
gdjs.s226Code.GDdeathObjects2.length = 0;
gdjs.s226Code.GDUPbuttonObjects1.length = 0;
gdjs.s226Code.GDUPbuttonObjects2.length = 0;
gdjs.s226Code.GDplatformObjects1.length = 0;
gdjs.s226Code.GDplatformObjects2.length = 0;
gdjs.s226Code.GDLbuttonObjects1.length = 0;
gdjs.s226Code.GDLbuttonObjects2.length = 0;
gdjs.s226Code.GDLcolObjects1.length = 0;
gdjs.s226Code.GDLcolObjects2.length = 0;
gdjs.s226Code.GDRbuttonObjects1.length = 0;
gdjs.s226Code.GDRbuttonObjects2.length = 0;
gdjs.s226Code.GDTALK2Objects1.length = 0;
gdjs.s226Code.GDTALK2Objects2.length = 0;
gdjs.s226Code.GDExitObjects1.length = 0;
gdjs.s226Code.GDExitObjects2.length = 0;
gdjs.s226Code.GDRcolObjects1.length = 0;
gdjs.s226Code.GDRcolObjects2.length = 0;
gdjs.s226Code.GDchapter4Objects1.length = 0;
gdjs.s226Code.GDchapter4Objects2.length = 0;
gdjs.s226Code.GDchapter3Objects1.length = 0;
gdjs.s226Code.GDchapter3Objects2.length = 0;
gdjs.s226Code.GDchapter2Objects1.length = 0;
gdjs.s226Code.GDchapter2Objects2.length = 0;
gdjs.s226Code.GDchapter1Objects1.length = 0;
gdjs.s226Code.GDchapter1Objects2.length = 0;
gdjs.s226Code.GDBGObjects1.length = 0;
gdjs.s226Code.GDBGObjects2.length = 0;

gdjs.s226Code.eventsList0(runtimeScene);
return;

}

gdjs['s226Code'] = gdjs.s226Code;
