gdjs.s190CHCode = {};
gdjs.s190CHCode.GDcaseObjects1= [];
gdjs.s190CHCode.GDcaseObjects2= [];
gdjs.s190CHCode.GDimageObjects1= [];
gdjs.s190CHCode.GDimageObjects2= [];
gdjs.s190CHCode.GDoffObjects1= [];
gdjs.s190CHCode.GDoffObjects2= [];
gdjs.s190CHCode.GDonObjects1= [];
gdjs.s190CHCode.GDonObjects2= [];
gdjs.s190CHCode.GDstartObjects1= [];
gdjs.s190CHCode.GDstartObjects2= [];
gdjs.s190CHCode.GDBObjects1= [];
gdjs.s190CHCode.GDBObjects2= [];
gdjs.s190CHCode.GDAObjects1= [];
gdjs.s190CHCode.GDAObjects2= [];
gdjs.s190CHCode.GDcrosshairsObjects1= [];
gdjs.s190CHCode.GDcrosshairsObjects2= [];
gdjs.s190CHCode.GDDOWNbuttonObjects1= [];
gdjs.s190CHCode.GDDOWNbuttonObjects2= [];
gdjs.s190CHCode.GDDOWNcolObjects1= [];
gdjs.s190CHCode.GDDOWNcolObjects2= [];
gdjs.s190CHCode.GDUPbuttonObjects1= [];
gdjs.s190CHCode.GDUPbuttonObjects2= [];
gdjs.s190CHCode.GDUPcolObjects1= [];
gdjs.s190CHCode.GDUPcolObjects2= [];
gdjs.s190CHCode.GDLbuttonObjects1= [];
gdjs.s190CHCode.GDLbuttonObjects2= [];
gdjs.s190CHCode.GDLcolObjects1= [];
gdjs.s190CHCode.GDLcolObjects2= [];
gdjs.s190CHCode.GDRbuttonObjects1= [];
gdjs.s190CHCode.GDRbuttonObjects2= [];
gdjs.s190CHCode.GDRcolObjects1= [];
gdjs.s190CHCode.GDRcolObjects2= [];
gdjs.s190CHCode.GDchapter4Objects1= [];
gdjs.s190CHCode.GDchapter4Objects2= [];
gdjs.s190CHCode.GDchapter3Objects1= [];
gdjs.s190CHCode.GDchapter3Objects2= [];
gdjs.s190CHCode.GDchapter2Objects1= [];
gdjs.s190CHCode.GDchapter2Objects2= [];
gdjs.s190CHCode.GDblackObjects1= [];
gdjs.s190CHCode.GDblackObjects2= [];
gdjs.s190CHCode.GDchapter1Objects1= [];
gdjs.s190CHCode.GDchapter1Objects2= [];

gdjs.s190CHCode.conditionTrue_0 = {val:false};
gdjs.s190CHCode.condition0IsTrue_0 = {val:false};
gdjs.s190CHCode.condition1IsTrue_0 = {val:false};
gdjs.s190CHCode.condition2IsTrue_0 = {val:false};


gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s190CHCode.GDDOWNbuttonObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s190CHCode.GDUPbuttonObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s190CHCode.GDRbuttonObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s190CHCode.GDLbuttonObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s190CHCode.GDcrosshairsObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s190CHCode.GDRcolObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s190CHCode.GDcrosshairsObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s190CHCode.GDLcolObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s190CHCode.GDcrosshairsObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s190CHCode.GDUPcolObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s190CHCode.GDcrosshairsObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s190CHCode.GDDOWNcolObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s190CHCode.GDcrosshairsObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s190CHCode.GDDOWNcolObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s190CHCode.GDoffObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s190CHCode.GDonObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s190CHCode.GDcrosshairsObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s190CHCode.GDchapter1Objects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s190CHCode.GDAObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s190CHCode.GDcrosshairsObjects1});gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s190CHCode.GDchapter1Objects1});gdjs.s190CHCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s190CHCode.GDDOWNbuttonObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
gdjs.s190CHCode.condition1IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s190CHCode.condition0IsTrue_0.val ) {
{
gdjs.s190CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s190CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s190CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s190CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s190CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s190CHCode.GDUPbuttonObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
gdjs.s190CHCode.condition1IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s190CHCode.condition0IsTrue_0.val ) {
{
gdjs.s190CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s190CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s190CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s190CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s190CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s190CHCode.GDRbuttonObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
gdjs.s190CHCode.condition1IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s190CHCode.condition0IsTrue_0.val ) {
{
gdjs.s190CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s190CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s190CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s190CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s190CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s190CHCode.GDLbuttonObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
gdjs.s190CHCode.condition1IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s190CHCode.condition0IsTrue_0.val ) {
{
gdjs.s190CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s190CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s190CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s190CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s190CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s190CHCode.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s190CHCode.GDcrosshairsObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects, gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s190CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s190CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s190CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s190CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s190CHCode.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s190CHCode.GDcrosshairsObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects, gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s190CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s190CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s190CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s190CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s190CHCode.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s190CHCode.GDcrosshairsObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects, gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s190CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s190CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s190CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s190CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s190CHCode.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s190CHCode.GDcrosshairsObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects, gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s190CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s190CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s190CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s190CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s190CHCode.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s190CHCode.GDcrosshairsObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects, gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s190CHCode.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s190CHCode.GDoffObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s190CHCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s190CHCode.GDonObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s190CHCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s190CHCode.condition0IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.3, "");
}if (gdjs.s190CHCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s191", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s190CHCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s190CHCode.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s190CHCode.GDcrosshairsObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
gdjs.s190CHCode.condition1IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects, gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s190CHCode.condition0IsTrue_0.val ) {
{
gdjs.s190CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.s190CHCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s192", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s190CHCode.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s190CHCode.GDcrosshairsObjects1);

gdjs.s190CHCode.condition0IsTrue_0.val = false;
gdjs.s190CHCode.condition1IsTrue_0.val = false;
{
gdjs.s190CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDcrosshairsObjects1Objects, gdjs.s190CHCode.mapOfGDgdjs_46s190CHCode_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s190CHCode.condition0IsTrue_0.val ) {
{
gdjs.s190CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s190CHCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s192", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s190CHCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s190CHCode.GDcaseObjects1.length = 0;
gdjs.s190CHCode.GDcaseObjects2.length = 0;
gdjs.s190CHCode.GDimageObjects1.length = 0;
gdjs.s190CHCode.GDimageObjects2.length = 0;
gdjs.s190CHCode.GDoffObjects1.length = 0;
gdjs.s190CHCode.GDoffObjects2.length = 0;
gdjs.s190CHCode.GDonObjects1.length = 0;
gdjs.s190CHCode.GDonObjects2.length = 0;
gdjs.s190CHCode.GDstartObjects1.length = 0;
gdjs.s190CHCode.GDstartObjects2.length = 0;
gdjs.s190CHCode.GDBObjects1.length = 0;
gdjs.s190CHCode.GDBObjects2.length = 0;
gdjs.s190CHCode.GDAObjects1.length = 0;
gdjs.s190CHCode.GDAObjects2.length = 0;
gdjs.s190CHCode.GDcrosshairsObjects1.length = 0;
gdjs.s190CHCode.GDcrosshairsObjects2.length = 0;
gdjs.s190CHCode.GDDOWNbuttonObjects1.length = 0;
gdjs.s190CHCode.GDDOWNbuttonObjects2.length = 0;
gdjs.s190CHCode.GDDOWNcolObjects1.length = 0;
gdjs.s190CHCode.GDDOWNcolObjects2.length = 0;
gdjs.s190CHCode.GDUPbuttonObjects1.length = 0;
gdjs.s190CHCode.GDUPbuttonObjects2.length = 0;
gdjs.s190CHCode.GDUPcolObjects1.length = 0;
gdjs.s190CHCode.GDUPcolObjects2.length = 0;
gdjs.s190CHCode.GDLbuttonObjects1.length = 0;
gdjs.s190CHCode.GDLbuttonObjects2.length = 0;
gdjs.s190CHCode.GDLcolObjects1.length = 0;
gdjs.s190CHCode.GDLcolObjects2.length = 0;
gdjs.s190CHCode.GDRbuttonObjects1.length = 0;
gdjs.s190CHCode.GDRbuttonObjects2.length = 0;
gdjs.s190CHCode.GDRcolObjects1.length = 0;
gdjs.s190CHCode.GDRcolObjects2.length = 0;
gdjs.s190CHCode.GDchapter4Objects1.length = 0;
gdjs.s190CHCode.GDchapter4Objects2.length = 0;
gdjs.s190CHCode.GDchapter3Objects1.length = 0;
gdjs.s190CHCode.GDchapter3Objects2.length = 0;
gdjs.s190CHCode.GDchapter2Objects1.length = 0;
gdjs.s190CHCode.GDchapter2Objects2.length = 0;
gdjs.s190CHCode.GDblackObjects1.length = 0;
gdjs.s190CHCode.GDblackObjects2.length = 0;
gdjs.s190CHCode.GDchapter1Objects1.length = 0;
gdjs.s190CHCode.GDchapter1Objects2.length = 0;

gdjs.s190CHCode.eventsList0(runtimeScene);
return;

}

gdjs['s190CHCode'] = gdjs.s190CHCode;
