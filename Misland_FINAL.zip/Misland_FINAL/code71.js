gdjs.s56Code = {};
gdjs.s56Code.GDcaseObjects1= [];
gdjs.s56Code.GDcaseObjects2= [];
gdjs.s56Code.GDoffObjects1= [];
gdjs.s56Code.GDoffObjects2= [];
gdjs.s56Code.GDonObjects1= [];
gdjs.s56Code.GDonObjects2= [];
gdjs.s56Code.GDstartObjects1= [];
gdjs.s56Code.GDstartObjects2= [];
gdjs.s56Code.GDBObjects1= [];
gdjs.s56Code.GDBObjects2= [];
gdjs.s56Code.GDAObjects1= [];
gdjs.s56Code.GDAObjects2= [];
gdjs.s56Code.GDbugzObjects1= [];
gdjs.s56Code.GDbugzObjects2= [];
gdjs.s56Code.GDDOWNbuttonObjects1= [];
gdjs.s56Code.GDDOWNbuttonObjects2= [];
gdjs.s56Code.GDblackObjects1= [];
gdjs.s56Code.GDblackObjects2= [];
gdjs.s56Code.GDDOWNcolObjects1= [];
gdjs.s56Code.GDDOWNcolObjects2= [];
gdjs.s56Code.GDUPbuttonObjects1= [];
gdjs.s56Code.GDUPbuttonObjects2= [];
gdjs.s56Code.GDUPcolObjects1= [];
gdjs.s56Code.GDUPcolObjects2= [];
gdjs.s56Code.GDLbuttonObjects1= [];
gdjs.s56Code.GDLbuttonObjects2= [];
gdjs.s56Code.GDLcolObjects1= [];
gdjs.s56Code.GDLcolObjects2= [];
gdjs.s56Code.GDRbuttonObjects1= [];
gdjs.s56Code.GDRbuttonObjects2= [];
gdjs.s56Code.GDTALK2Objects1= [];
gdjs.s56Code.GDTALK2Objects2= [];
gdjs.s56Code.GDdeathObjects1= [];
gdjs.s56Code.GDdeathObjects2= [];
gdjs.s56Code.GDExitObjects1= [];
gdjs.s56Code.GDExitObjects2= [];
gdjs.s56Code.GDRcolObjects1= [];
gdjs.s56Code.GDRcolObjects2= [];
gdjs.s56Code.GDchapter4Objects1= [];
gdjs.s56Code.GDchapter4Objects2= [];
gdjs.s56Code.GDchapter3Objects1= [];
gdjs.s56Code.GDchapter3Objects2= [];
gdjs.s56Code.GDchapter2Objects1= [];
gdjs.s56Code.GDchapter2Objects2= [];
gdjs.s56Code.GDchapter1Objects1= [];
gdjs.s56Code.GDchapter1Objects2= [];
gdjs.s56Code.GDBGObjects1= [];
gdjs.s56Code.GDBGObjects2= [];
gdjs.s56Code.GDNewObject2Objects1= [];
gdjs.s56Code.GDNewObject2Objects2= [];
gdjs.s56Code.GDNewObjectObjects1= [];
gdjs.s56Code.GDNewObjectObjects2= [];

gdjs.s56Code.conditionTrue_0 = {val:false};
gdjs.s56Code.condition0IsTrue_0 = {val:false};
gdjs.s56Code.condition1IsTrue_0 = {val:false};
gdjs.s56Code.condition2IsTrue_0 = {val:false};
gdjs.s56Code.conditionTrue_1 = {val:false};
gdjs.s56Code.condition0IsTrue_1 = {val:false};
gdjs.s56Code.condition1IsTrue_1 = {val:false};
gdjs.s56Code.condition2IsTrue_1 = {val:false};


gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s56Code.GDDOWNbuttonObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s56Code.GDUPbuttonObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s56Code.GDRbuttonObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s56Code.GDLbuttonObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s56Code.GDbugzObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s56Code.GDRcolObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s56Code.GDbugzObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s56Code.GDLcolObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s56Code.GDbugzObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s56Code.GDUPcolObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s56Code.GDbugzObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s56Code.GDDOWNcolObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s56Code.GDbugzObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s56Code.GDDOWNcolObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s56Code.GDBObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s56Code.GDAObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s56Code.GDoffObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s56Code.GDonObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s56Code.GDbugzObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s56Code.GDExitObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s56Code.GDbugzObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDTALK2Objects1Objects = Hashtable.newFrom({"TALK2": gdjs.s56Code.GDTALK2Objects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s56Code.GDbugzObjects1});gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDdeathObjects1Objects = Hashtable.newFrom({"death": gdjs.s56Code.GDdeathObjects1});gdjs.s56Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s56Code.GDDOWNbuttonObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
gdjs.s56Code.condition1IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s56Code.condition0IsTrue_0.val ) {
{
gdjs.s56Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s56Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s56Code.GDUPbuttonObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
gdjs.s56Code.condition1IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s56Code.condition0IsTrue_0.val ) {
{
gdjs.s56Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s56Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s56Code.GDRbuttonObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
gdjs.s56Code.condition1IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s56Code.condition0IsTrue_0.val ) {
{
gdjs.s56Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s56Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s56Code.GDLbuttonObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
gdjs.s56Code.condition1IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s56Code.condition0IsTrue_0.val ) {
{
gdjs.s56Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s56Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


gdjs.s56Code.condition0IsTrue_0.val = false;
{
{gdjs.s56Code.conditionTrue_1 = gdjs.s56Code.condition0IsTrue_0;
gdjs.s56Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(69978812);
}
}if (gdjs.s56Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter2_v3.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s56Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects, gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s56Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s56Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects, gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s56Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s56Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects, gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s56Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s56Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects, gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s56Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s56Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects, gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s56Code.GDBObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s56Code.GDAObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s56Code.GDoffObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s56Code.GDonObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s56Code.condition0IsTrue_0.val = false;
gdjs.s56Code.condition1IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s56Code.condition0IsTrue_0.val ) {
{
gdjs.s56Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s56Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s56Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s56Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s56Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s56Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s56Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s56Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s56Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects, gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s58", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK2"), gdjs.s56Code.GDTALK2Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects, gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDTALK2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s59", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);
gdjs.copyArray(runtimeScene.getObjects("death"), gdjs.s56Code.GDdeathObjects1);

gdjs.s56Code.condition0IsTrue_0.val = false;
{
gdjs.s56Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDbugzObjects1Objects, gdjs.s56Code.mapOfGDgdjs_46s56Code_46GDdeathObjects1Objects, false, runtimeScene, false);
}if (gdjs.s56Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s57", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s56Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s56Code.GDbugzObjects1.length !== 0 ? gdjs.s56Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s56Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s56Code.GDcaseObjects1.length = 0;
gdjs.s56Code.GDcaseObjects2.length = 0;
gdjs.s56Code.GDoffObjects1.length = 0;
gdjs.s56Code.GDoffObjects2.length = 0;
gdjs.s56Code.GDonObjects1.length = 0;
gdjs.s56Code.GDonObjects2.length = 0;
gdjs.s56Code.GDstartObjects1.length = 0;
gdjs.s56Code.GDstartObjects2.length = 0;
gdjs.s56Code.GDBObjects1.length = 0;
gdjs.s56Code.GDBObjects2.length = 0;
gdjs.s56Code.GDAObjects1.length = 0;
gdjs.s56Code.GDAObjects2.length = 0;
gdjs.s56Code.GDbugzObjects1.length = 0;
gdjs.s56Code.GDbugzObjects2.length = 0;
gdjs.s56Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s56Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s56Code.GDblackObjects1.length = 0;
gdjs.s56Code.GDblackObjects2.length = 0;
gdjs.s56Code.GDDOWNcolObjects1.length = 0;
gdjs.s56Code.GDDOWNcolObjects2.length = 0;
gdjs.s56Code.GDUPbuttonObjects1.length = 0;
gdjs.s56Code.GDUPbuttonObjects2.length = 0;
gdjs.s56Code.GDUPcolObjects1.length = 0;
gdjs.s56Code.GDUPcolObjects2.length = 0;
gdjs.s56Code.GDLbuttonObjects1.length = 0;
gdjs.s56Code.GDLbuttonObjects2.length = 0;
gdjs.s56Code.GDLcolObjects1.length = 0;
gdjs.s56Code.GDLcolObjects2.length = 0;
gdjs.s56Code.GDRbuttonObjects1.length = 0;
gdjs.s56Code.GDRbuttonObjects2.length = 0;
gdjs.s56Code.GDTALK2Objects1.length = 0;
gdjs.s56Code.GDTALK2Objects2.length = 0;
gdjs.s56Code.GDdeathObjects1.length = 0;
gdjs.s56Code.GDdeathObjects2.length = 0;
gdjs.s56Code.GDExitObjects1.length = 0;
gdjs.s56Code.GDExitObjects2.length = 0;
gdjs.s56Code.GDRcolObjects1.length = 0;
gdjs.s56Code.GDRcolObjects2.length = 0;
gdjs.s56Code.GDchapter4Objects1.length = 0;
gdjs.s56Code.GDchapter4Objects2.length = 0;
gdjs.s56Code.GDchapter3Objects1.length = 0;
gdjs.s56Code.GDchapter3Objects2.length = 0;
gdjs.s56Code.GDchapter2Objects1.length = 0;
gdjs.s56Code.GDchapter2Objects2.length = 0;
gdjs.s56Code.GDchapter1Objects1.length = 0;
gdjs.s56Code.GDchapter1Objects2.length = 0;
gdjs.s56Code.GDBGObjects1.length = 0;
gdjs.s56Code.GDBGObjects2.length = 0;
gdjs.s56Code.GDNewObject2Objects1.length = 0;
gdjs.s56Code.GDNewObject2Objects2.length = 0;
gdjs.s56Code.GDNewObjectObjects1.length = 0;
gdjs.s56Code.GDNewObjectObjects2.length = 0;

gdjs.s56Code.eventsList0(runtimeScene);
return;

}

gdjs['s56Code'] = gdjs.s56Code;
