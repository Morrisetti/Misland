gdjs.s49Code = {};
gdjs.s49Code.GDcaseObjects1= [];
gdjs.s49Code.GDcaseObjects2= [];
gdjs.s49Code.GDimageObjects1= [];
gdjs.s49Code.GDimageObjects2= [];
gdjs.s49Code.GDoffObjects1= [];
gdjs.s49Code.GDoffObjects2= [];
gdjs.s49Code.GDonObjects1= [];
gdjs.s49Code.GDonObjects2= [];
gdjs.s49Code.GDstartObjects1= [];
gdjs.s49Code.GDstartObjects2= [];
gdjs.s49Code.GDBObjects1= [];
gdjs.s49Code.GDBObjects2= [];
gdjs.s49Code.GDblackObjects1= [];
gdjs.s49Code.GDblackObjects2= [];
gdjs.s49Code.GDAObjects1= [];
gdjs.s49Code.GDAObjects2= [];

gdjs.s49Code.conditionTrue_0 = {val:false};
gdjs.s49Code.condition0IsTrue_0 = {val:false};
gdjs.s49Code.condition1IsTrue_0 = {val:false};
gdjs.s49Code.conditionTrue_1 = {val:false};
gdjs.s49Code.condition0IsTrue_1 = {val:false};
gdjs.s49Code.condition1IsTrue_1 = {val:false};


gdjs.s49Code.mapOfGDgdjs_46s49Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s49Code.GDstartObjects1});gdjs.s49Code.mapOfGDgdjs_46s49Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s49Code.GDoffObjects1});gdjs.s49Code.mapOfGDgdjs_46s49Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s49Code.GDonObjects1});gdjs.s49Code.mapOfGDgdjs_46s49Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s49Code.GDBObjects1});gdjs.s49Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s49Code.condition0IsTrue_0.val = false;
{
{gdjs.s49Code.conditionTrue_1 = gdjs.s49Code.condition0IsTrue_0;
gdjs.s49Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(69831556);
}
}if (gdjs.s49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\dead.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s49Code.GDstartObjects1);

gdjs.s49Code.condition0IsTrue_0.val = false;
{
gdjs.s49Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s49Code.mapOfGDgdjs_46s49Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s48", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s49Code.GDoffObjects1);

gdjs.s49Code.condition0IsTrue_0.val = false;
{
gdjs.s49Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s49Code.mapOfGDgdjs_46s49Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s49Code.GDonObjects1);

gdjs.s49Code.condition0IsTrue_0.val = false;
{
gdjs.s49Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s49Code.mapOfGDgdjs_46s49Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s49Code.condition0IsTrue_0.val = false;
{
gdjs.s49Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.s49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s47", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s49Code.GDBObjects1);

gdjs.s49Code.condition0IsTrue_0.val = false;
{
gdjs.s49Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s49Code.mapOfGDgdjs_46s49Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s49Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


};

gdjs.s49Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s49Code.GDcaseObjects1.length = 0;
gdjs.s49Code.GDcaseObjects2.length = 0;
gdjs.s49Code.GDimageObjects1.length = 0;
gdjs.s49Code.GDimageObjects2.length = 0;
gdjs.s49Code.GDoffObjects1.length = 0;
gdjs.s49Code.GDoffObjects2.length = 0;
gdjs.s49Code.GDonObjects1.length = 0;
gdjs.s49Code.GDonObjects2.length = 0;
gdjs.s49Code.GDstartObjects1.length = 0;
gdjs.s49Code.GDstartObjects2.length = 0;
gdjs.s49Code.GDBObjects1.length = 0;
gdjs.s49Code.GDBObjects2.length = 0;
gdjs.s49Code.GDblackObjects1.length = 0;
gdjs.s49Code.GDblackObjects2.length = 0;
gdjs.s49Code.GDAObjects1.length = 0;
gdjs.s49Code.GDAObjects2.length = 0;

gdjs.s49Code.eventsList0(runtimeScene);
return;

}

gdjs['s49Code'] = gdjs.s49Code;
