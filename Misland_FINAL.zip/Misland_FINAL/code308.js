gdjs.s269Code = {};
gdjs.s269Code.GDcaseObjects1= [];
gdjs.s269Code.GDcaseObjects2= [];
gdjs.s269Code.GDimageObjects1= [];
gdjs.s269Code.GDimageObjects2= [];
gdjs.s269Code.GDoffObjects1= [];
gdjs.s269Code.GDoffObjects2= [];
gdjs.s269Code.GDonObjects1= [];
gdjs.s269Code.GDonObjects2= [];
gdjs.s269Code.GDstartObjects1= [];
gdjs.s269Code.GDstartObjects2= [];
gdjs.s269Code.GDBObjects1= [];
gdjs.s269Code.GDBObjects2= [];
gdjs.s269Code.GDblackObjects1= [];
gdjs.s269Code.GDblackObjects2= [];
gdjs.s269Code.GDAObjects1= [];
gdjs.s269Code.GDAObjects2= [];

gdjs.s269Code.conditionTrue_0 = {val:false};
gdjs.s269Code.condition0IsTrue_0 = {val:false};
gdjs.s269Code.condition1IsTrue_0 = {val:false};


gdjs.s269Code.mapOfGDgdjs_46s269Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s269Code.GDstartObjects1});gdjs.s269Code.mapOfGDgdjs_46s269Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s269Code.GDoffObjects1});gdjs.s269Code.mapOfGDgdjs_46s269Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s269Code.GDonObjects1});gdjs.s269Code.mapOfGDgdjs_46s269Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s269Code.GDAObjects1});gdjs.s269Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s269Code.GDstartObjects1);

gdjs.s269Code.condition0IsTrue_0.val = false;
{
gdjs.s269Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s269Code.mapOfGDgdjs_46s269Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s269Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s269Code.GDoffObjects1);

gdjs.s269Code.condition0IsTrue_0.val = false;
{
gdjs.s269Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s269Code.mapOfGDgdjs_46s269Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s269Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s269Code.GDonObjects1);

gdjs.s269Code.condition0IsTrue_0.val = false;
{
gdjs.s269Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s269Code.mapOfGDgdjs_46s269Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s269Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s269Code.condition0IsTrue_0.val = false;
{
gdjs.s269Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s269Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s270", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s269Code.GDAObjects1);

gdjs.s269Code.condition0IsTrue_0.val = false;
{
gdjs.s269Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s269Code.mapOfGDgdjs_46s269Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s269Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s270", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s269Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s269Code.GDcaseObjects1.length = 0;
gdjs.s269Code.GDcaseObjects2.length = 0;
gdjs.s269Code.GDimageObjects1.length = 0;
gdjs.s269Code.GDimageObjects2.length = 0;
gdjs.s269Code.GDoffObjects1.length = 0;
gdjs.s269Code.GDoffObjects2.length = 0;
gdjs.s269Code.GDonObjects1.length = 0;
gdjs.s269Code.GDonObjects2.length = 0;
gdjs.s269Code.GDstartObjects1.length = 0;
gdjs.s269Code.GDstartObjects2.length = 0;
gdjs.s269Code.GDBObjects1.length = 0;
gdjs.s269Code.GDBObjects2.length = 0;
gdjs.s269Code.GDblackObjects1.length = 0;
gdjs.s269Code.GDblackObjects2.length = 0;
gdjs.s269Code.GDAObjects1.length = 0;
gdjs.s269Code.GDAObjects2.length = 0;

gdjs.s269Code.eventsList0(runtimeScene);
return;

}

gdjs['s269Code'] = gdjs.s269Code;
