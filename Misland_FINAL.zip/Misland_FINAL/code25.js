gdjs.s18Code = {};
gdjs.s18Code.GDcaseObjects1= [];
gdjs.s18Code.GDcaseObjects2= [];
gdjs.s18Code.GDimageObjects1= [];
gdjs.s18Code.GDimageObjects2= [];
gdjs.s18Code.GDoffObjects1= [];
gdjs.s18Code.GDoffObjects2= [];
gdjs.s18Code.GDonObjects1= [];
gdjs.s18Code.GDonObjects2= [];
gdjs.s18Code.GDstartObjects1= [];
gdjs.s18Code.GDstartObjects2= [];
gdjs.s18Code.GDBObjects1= [];
gdjs.s18Code.GDBObjects2= [];
gdjs.s18Code.GDblackObjects1= [];
gdjs.s18Code.GDblackObjects2= [];
gdjs.s18Code.GDAObjects1= [];
gdjs.s18Code.GDAObjects2= [];

gdjs.s18Code.conditionTrue_0 = {val:false};
gdjs.s18Code.condition0IsTrue_0 = {val:false};
gdjs.s18Code.condition1IsTrue_0 = {val:false};


gdjs.s18Code.mapOfGDgdjs_46s18Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s18Code.GDstartObjects1});gdjs.s18Code.mapOfGDgdjs_46s18Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s18Code.GDoffObjects1});gdjs.s18Code.mapOfGDgdjs_46s18Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s18Code.GDonObjects1});gdjs.s18Code.mapOfGDgdjs_46s18Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s18Code.GDBObjects1});gdjs.s18Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s18Code.GDstartObjects1);

gdjs.s18Code.condition0IsTrue_0.val = false;
{
gdjs.s18Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s18Code.mapOfGDgdjs_46s18Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s18Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s18Code.GDoffObjects1);

gdjs.s18Code.condition0IsTrue_0.val = false;
{
gdjs.s18Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s18Code.mapOfGDgdjs_46s18Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s18Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s18Code.GDonObjects1);

gdjs.s18Code.condition0IsTrue_0.val = false;
{
gdjs.s18Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s18Code.mapOfGDgdjs_46s18Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s18Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s18Code.condition0IsTrue_0.val = false;
{
gdjs.s18Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s18Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s18.1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s18Code.GDBObjects1);

gdjs.s18Code.condition0IsTrue_0.val = false;
{
gdjs.s18Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s18Code.mapOfGDgdjs_46s18Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s18Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s18.1", false);
}}

}


{


{
}

}


};

gdjs.s18Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s18Code.GDcaseObjects1.length = 0;
gdjs.s18Code.GDcaseObjects2.length = 0;
gdjs.s18Code.GDimageObjects1.length = 0;
gdjs.s18Code.GDimageObjects2.length = 0;
gdjs.s18Code.GDoffObjects1.length = 0;
gdjs.s18Code.GDoffObjects2.length = 0;
gdjs.s18Code.GDonObjects1.length = 0;
gdjs.s18Code.GDonObjects2.length = 0;
gdjs.s18Code.GDstartObjects1.length = 0;
gdjs.s18Code.GDstartObjects2.length = 0;
gdjs.s18Code.GDBObjects1.length = 0;
gdjs.s18Code.GDBObjects2.length = 0;
gdjs.s18Code.GDblackObjects1.length = 0;
gdjs.s18Code.GDblackObjects2.length = 0;
gdjs.s18Code.GDAObjects1.length = 0;
gdjs.s18Code.GDAObjects2.length = 0;

gdjs.s18Code.eventsList0(runtimeScene);
return;

}

gdjs['s18Code'] = gdjs.s18Code;
