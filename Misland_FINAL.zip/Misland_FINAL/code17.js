gdjs.s11Code = {};
gdjs.s11Code.GDcaseObjects1= [];
gdjs.s11Code.GDcaseObjects2= [];
gdjs.s11Code.GDimageObjects1= [];
gdjs.s11Code.GDimageObjects2= [];
gdjs.s11Code.GDoffObjects1= [];
gdjs.s11Code.GDoffObjects2= [];
gdjs.s11Code.GDonObjects1= [];
gdjs.s11Code.GDonObjects2= [];
gdjs.s11Code.GDstartObjects1= [];
gdjs.s11Code.GDstartObjects2= [];
gdjs.s11Code.GDBObjects1= [];
gdjs.s11Code.GDBObjects2= [];
gdjs.s11Code.GDblackObjects1= [];
gdjs.s11Code.GDblackObjects2= [];
gdjs.s11Code.GDAObjects1= [];
gdjs.s11Code.GDAObjects2= [];

gdjs.s11Code.conditionTrue_0 = {val:false};
gdjs.s11Code.condition0IsTrue_0 = {val:false};
gdjs.s11Code.condition1IsTrue_0 = {val:false};


gdjs.s11Code.mapOfGDgdjs_46s11Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s11Code.GDstartObjects1});gdjs.s11Code.mapOfGDgdjs_46s11Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s11Code.GDoffObjects1});gdjs.s11Code.mapOfGDgdjs_46s11Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s11Code.GDonObjects1});gdjs.s11Code.mapOfGDgdjs_46s11Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s11Code.GDBObjects1});gdjs.s11Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s11Code.GDstartObjects1);

gdjs.s11Code.condition0IsTrue_0.val = false;
{
gdjs.s11Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s11Code.mapOfGDgdjs_46s11Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s11Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s11Code.GDoffObjects1);

gdjs.s11Code.condition0IsTrue_0.val = false;
{
gdjs.s11Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s11Code.mapOfGDgdjs_46s11Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s11Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s11Code.GDonObjects1);

gdjs.s11Code.condition0IsTrue_0.val = false;
{
gdjs.s11Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s11Code.mapOfGDgdjs_46s11Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s11Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s11Code.condition0IsTrue_0.val = false;
{
gdjs.s11Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s11Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s12", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s11Code.GDBObjects1);

gdjs.s11Code.condition0IsTrue_0.val = false;
{
gdjs.s11Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s11Code.mapOfGDgdjs_46s11Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s11Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s12", false);
}}

}


{


{
}

}


};

gdjs.s11Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s11Code.GDcaseObjects1.length = 0;
gdjs.s11Code.GDcaseObjects2.length = 0;
gdjs.s11Code.GDimageObjects1.length = 0;
gdjs.s11Code.GDimageObjects2.length = 0;
gdjs.s11Code.GDoffObjects1.length = 0;
gdjs.s11Code.GDoffObjects2.length = 0;
gdjs.s11Code.GDonObjects1.length = 0;
gdjs.s11Code.GDonObjects2.length = 0;
gdjs.s11Code.GDstartObjects1.length = 0;
gdjs.s11Code.GDstartObjects2.length = 0;
gdjs.s11Code.GDBObjects1.length = 0;
gdjs.s11Code.GDBObjects2.length = 0;
gdjs.s11Code.GDblackObjects1.length = 0;
gdjs.s11Code.GDblackObjects2.length = 0;
gdjs.s11Code.GDAObjects1.length = 0;
gdjs.s11Code.GDAObjects2.length = 0;

gdjs.s11Code.eventsList0(runtimeScene);
return;

}

gdjs['s11Code'] = gdjs.s11Code;
