gdjs.introCode = {};
gdjs.introCode.GDcaseObjects1= [];
gdjs.introCode.GDcaseObjects2= [];
gdjs.introCode.GDimageObjects1= [];
gdjs.introCode.GDimageObjects2= [];
gdjs.introCode.GDoffObjects1= [];
gdjs.introCode.GDoffObjects2= [];
gdjs.introCode.GDonObjects1= [];
gdjs.introCode.GDonObjects2= [];
gdjs.introCode.GDstartObjects1= [];
gdjs.introCode.GDstartObjects2= [];
gdjs.introCode.GDBObjects1= [];
gdjs.introCode.GDBObjects2= [];
gdjs.introCode.GDblackObjects1= [];
gdjs.introCode.GDblackObjects2= [];
gdjs.introCode.GDAObjects1= [];
gdjs.introCode.GDAObjects2= [];

gdjs.introCode.conditionTrue_0 = {val:false};
gdjs.introCode.condition0IsTrue_0 = {val:false};
gdjs.introCode.condition1IsTrue_0 = {val:false};
gdjs.introCode.conditionTrue_1 = {val:false};
gdjs.introCode.condition0IsTrue_1 = {val:false};
gdjs.introCode.condition1IsTrue_1 = {val:false};


gdjs.introCode.mapOfGDgdjs_46introCode_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.introCode.GDstartObjects1});gdjs.introCode.mapOfGDgdjs_46introCode_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.introCode.GDoffObjects1});gdjs.introCode.mapOfGDgdjs_46introCode_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.introCode.GDonObjects1});gdjs.introCode.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition0IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(68349764);
}
}if (gdjs.introCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "new items\\9fbda4ca-b1e7-4afd-9086-081fff2e19a4.mp3", false, 100, 1);
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition0IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(68349876);
}
}if (gdjs.introCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\oldlib_v1.mp3", true, 80, 1);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.introCode.GDstartObjects1);

gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.introCode.mapOfGDgdjs_46introCode_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.introCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "C1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.introCode.GDoffObjects1);

gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.introCode.mapOfGDgdjs_46introCode_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.introCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.introCode.GDonObjects1);

gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.introCode.mapOfGDgdjs_46introCode_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.introCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.introCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "C1", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.introCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.introCode.GDcaseObjects1.length = 0;
gdjs.introCode.GDcaseObjects2.length = 0;
gdjs.introCode.GDimageObjects1.length = 0;
gdjs.introCode.GDimageObjects2.length = 0;
gdjs.introCode.GDoffObjects1.length = 0;
gdjs.introCode.GDoffObjects2.length = 0;
gdjs.introCode.GDonObjects1.length = 0;
gdjs.introCode.GDonObjects2.length = 0;
gdjs.introCode.GDstartObjects1.length = 0;
gdjs.introCode.GDstartObjects2.length = 0;
gdjs.introCode.GDBObjects1.length = 0;
gdjs.introCode.GDBObjects2.length = 0;
gdjs.introCode.GDblackObjects1.length = 0;
gdjs.introCode.GDblackObjects2.length = 0;
gdjs.introCode.GDAObjects1.length = 0;
gdjs.introCode.GDAObjects2.length = 0;

gdjs.introCode.eventsList0(runtimeScene);
return;

}

gdjs['introCode'] = gdjs.introCode;
