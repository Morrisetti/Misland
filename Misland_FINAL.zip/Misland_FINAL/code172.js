gdjs.s156Code = {};
gdjs.s156Code.GDcaseObjects1= [];
gdjs.s156Code.GDcaseObjects2= [];
gdjs.s156Code.GDimageObjects1= [];
gdjs.s156Code.GDimageObjects2= [];
gdjs.s156Code.GDoffObjects1= [];
gdjs.s156Code.GDoffObjects2= [];
gdjs.s156Code.GDonObjects1= [];
gdjs.s156Code.GDonObjects2= [];
gdjs.s156Code.GDstartObjects1= [];
gdjs.s156Code.GDstartObjects2= [];
gdjs.s156Code.GDBObjects1= [];
gdjs.s156Code.GDBObjects2= [];
gdjs.s156Code.GDblackObjects1= [];
gdjs.s156Code.GDblackObjects2= [];
gdjs.s156Code.GDAObjects1= [];
gdjs.s156Code.GDAObjects2= [];

gdjs.s156Code.conditionTrue_0 = {val:false};
gdjs.s156Code.condition0IsTrue_0 = {val:false};
gdjs.s156Code.condition1IsTrue_0 = {val:false};
gdjs.s156Code.conditionTrue_1 = {val:false};
gdjs.s156Code.condition0IsTrue_1 = {val:false};
gdjs.s156Code.condition1IsTrue_1 = {val:false};


gdjs.s156Code.mapOfGDgdjs_46s156Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s156Code.GDstartObjects1});gdjs.s156Code.mapOfGDgdjs_46s156Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s156Code.GDoffObjects1});gdjs.s156Code.mapOfGDgdjs_46s156Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s156Code.GDonObjects1});gdjs.s156Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s156Code.condition0IsTrue_0.val = false;
{
{gdjs.s156Code.conditionTrue_1 = gdjs.s156Code.condition0IsTrue_0;
gdjs.s156Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(72287124);
}
}if (gdjs.s156Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\dead.mp3", false, 100, 1);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s156Code.GDstartObjects1);

gdjs.s156Code.condition0IsTrue_0.val = false;
{
gdjs.s156Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s156Code.mapOfGDgdjs_46s156Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s156Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s155", false);
}}

}


{


gdjs.s156Code.condition0IsTrue_0.val = false;
{
gdjs.s156Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.s156Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s155", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s156Code.GDoffObjects1);

gdjs.s156Code.condition0IsTrue_0.val = false;
{
gdjs.s156Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s156Code.mapOfGDgdjs_46s156Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s156Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s156Code.GDonObjects1);

gdjs.s156Code.condition0IsTrue_0.val = false;
{
gdjs.s156Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s156Code.mapOfGDgdjs_46s156Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s156Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s156Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s156Code.GDcaseObjects1.length = 0;
gdjs.s156Code.GDcaseObjects2.length = 0;
gdjs.s156Code.GDimageObjects1.length = 0;
gdjs.s156Code.GDimageObjects2.length = 0;
gdjs.s156Code.GDoffObjects1.length = 0;
gdjs.s156Code.GDoffObjects2.length = 0;
gdjs.s156Code.GDonObjects1.length = 0;
gdjs.s156Code.GDonObjects2.length = 0;
gdjs.s156Code.GDstartObjects1.length = 0;
gdjs.s156Code.GDstartObjects2.length = 0;
gdjs.s156Code.GDBObjects1.length = 0;
gdjs.s156Code.GDBObjects2.length = 0;
gdjs.s156Code.GDblackObjects1.length = 0;
gdjs.s156Code.GDblackObjects2.length = 0;
gdjs.s156Code.GDAObjects1.length = 0;
gdjs.s156Code.GDAObjects2.length = 0;

gdjs.s156Code.eventsList0(runtimeScene);
return;

}

gdjs['s156Code'] = gdjs.s156Code;
