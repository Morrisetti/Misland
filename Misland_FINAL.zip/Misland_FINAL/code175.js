gdjs.s159Code = {};
gdjs.s159Code.GDcaseObjects1= [];
gdjs.s159Code.GDcaseObjects2= [];
gdjs.s159Code.GDimageObjects1= [];
gdjs.s159Code.GDimageObjects2= [];
gdjs.s159Code.GDoffObjects1= [];
gdjs.s159Code.GDoffObjects2= [];
gdjs.s159Code.GDonObjects1= [];
gdjs.s159Code.GDonObjects2= [];
gdjs.s159Code.GDstartObjects1= [];
gdjs.s159Code.GDstartObjects2= [];
gdjs.s159Code.GDBObjects1= [];
gdjs.s159Code.GDBObjects2= [];
gdjs.s159Code.GDblackObjects1= [];
gdjs.s159Code.GDblackObjects2= [];
gdjs.s159Code.GDAObjects1= [];
gdjs.s159Code.GDAObjects2= [];

gdjs.s159Code.conditionTrue_0 = {val:false};
gdjs.s159Code.condition0IsTrue_0 = {val:false};
gdjs.s159Code.condition1IsTrue_0 = {val:false};
gdjs.s159Code.conditionTrue_1 = {val:false};
gdjs.s159Code.condition0IsTrue_1 = {val:false};
gdjs.s159Code.condition1IsTrue_1 = {val:false};


gdjs.s159Code.mapOfGDgdjs_46s159Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s159Code.GDAObjects1});gdjs.s159Code.mapOfGDgdjs_46s159Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s159Code.GDoffObjects1});gdjs.s159Code.mapOfGDgdjs_46s159Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s159Code.GDonObjects1});gdjs.s159Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s159Code.condition0IsTrue_0.val = false;
{
{gdjs.s159Code.conditionTrue_1 = gdjs.s159Code.condition0IsTrue_0;
gdjs.s159Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(72382996);
}
}if (gdjs.s159Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter2_v2.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s159Code.GDAObjects1);

gdjs.s159Code.condition0IsTrue_0.val = false;
{
gdjs.s159Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s159Code.mapOfGDgdjs_46s159Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s159Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s160", false);
}}

}


{


gdjs.s159Code.condition0IsTrue_0.val = false;
{
gdjs.s159Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s159Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s160", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s159Code.GDoffObjects1);

gdjs.s159Code.condition0IsTrue_0.val = false;
{
gdjs.s159Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s159Code.mapOfGDgdjs_46s159Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s159Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s159Code.GDonObjects1);

gdjs.s159Code.condition0IsTrue_0.val = false;
{
gdjs.s159Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s159Code.mapOfGDgdjs_46s159Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s159Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s159Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s159Code.GDcaseObjects1.length = 0;
gdjs.s159Code.GDcaseObjects2.length = 0;
gdjs.s159Code.GDimageObjects1.length = 0;
gdjs.s159Code.GDimageObjects2.length = 0;
gdjs.s159Code.GDoffObjects1.length = 0;
gdjs.s159Code.GDoffObjects2.length = 0;
gdjs.s159Code.GDonObjects1.length = 0;
gdjs.s159Code.GDonObjects2.length = 0;
gdjs.s159Code.GDstartObjects1.length = 0;
gdjs.s159Code.GDstartObjects2.length = 0;
gdjs.s159Code.GDBObjects1.length = 0;
gdjs.s159Code.GDBObjects2.length = 0;
gdjs.s159Code.GDblackObjects1.length = 0;
gdjs.s159Code.GDblackObjects2.length = 0;
gdjs.s159Code.GDAObjects1.length = 0;
gdjs.s159Code.GDAObjects2.length = 0;

gdjs.s159Code.eventsList0(runtimeScene);
return;

}

gdjs['s159Code'] = gdjs.s159Code;
