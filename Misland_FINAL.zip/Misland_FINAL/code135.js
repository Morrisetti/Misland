gdjs.s119Code = {};
gdjs.s119Code.GDcaseObjects1= [];
gdjs.s119Code.GDcaseObjects2= [];
gdjs.s119Code.GDoffObjects1= [];
gdjs.s119Code.GDoffObjects2= [];
gdjs.s119Code.GDonObjects1= [];
gdjs.s119Code.GDonObjects2= [];
gdjs.s119Code.GDstartObjects1= [];
gdjs.s119Code.GDstartObjects2= [];
gdjs.s119Code.GDBObjects1= [];
gdjs.s119Code.GDBObjects2= [];
gdjs.s119Code.GDAObjects1= [];
gdjs.s119Code.GDAObjects2= [];
gdjs.s119Code.GDbugzObjects1= [];
gdjs.s119Code.GDbugzObjects2= [];
gdjs.s119Code.GDDOWNbuttonObjects1= [];
gdjs.s119Code.GDDOWNbuttonObjects2= [];
gdjs.s119Code.GDblackObjects1= [];
gdjs.s119Code.GDblackObjects2= [];
gdjs.s119Code.GDDOWNcolObjects1= [];
gdjs.s119Code.GDDOWNcolObjects2= [];
gdjs.s119Code.GDUPbuttonObjects1= [];
gdjs.s119Code.GDUPbuttonObjects2= [];
gdjs.s119Code.GDUPcolObjects1= [];
gdjs.s119Code.GDUPcolObjects2= [];
gdjs.s119Code.GDLbuttonObjects1= [];
gdjs.s119Code.GDLbuttonObjects2= [];
gdjs.s119Code.GDLcolObjects1= [];
gdjs.s119Code.GDLcolObjects2= [];
gdjs.s119Code.GDRbuttonObjects1= [];
gdjs.s119Code.GDRbuttonObjects2= [];
gdjs.s119Code.GDTALK3Objects1= [];
gdjs.s119Code.GDTALK3Objects2= [];
gdjs.s119Code.GDTALK2Objects1= [];
gdjs.s119Code.GDTALK2Objects2= [];
gdjs.s119Code.GDExitObjects1= [];
gdjs.s119Code.GDExitObjects2= [];
gdjs.s119Code.GDRcolObjects1= [];
gdjs.s119Code.GDRcolObjects2= [];
gdjs.s119Code.GDchapter4Objects1= [];
gdjs.s119Code.GDchapter4Objects2= [];
gdjs.s119Code.GDchapter3Objects1= [];
gdjs.s119Code.GDchapter3Objects2= [];
gdjs.s119Code.GDchapter2Objects1= [];
gdjs.s119Code.GDchapter2Objects2= [];
gdjs.s119Code.GDchapter1Objects1= [];
gdjs.s119Code.GDchapter1Objects2= [];
gdjs.s119Code.GDBGObjects1= [];
gdjs.s119Code.GDBGObjects2= [];

gdjs.s119Code.conditionTrue_0 = {val:false};
gdjs.s119Code.condition0IsTrue_0 = {val:false};
gdjs.s119Code.condition1IsTrue_0 = {val:false};
gdjs.s119Code.condition2IsTrue_0 = {val:false};


gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s119Code.GDDOWNbuttonObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s119Code.GDUPbuttonObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s119Code.GDRbuttonObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s119Code.GDLbuttonObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s119Code.GDbugzObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s119Code.GDRcolObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s119Code.GDbugzObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s119Code.GDLcolObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s119Code.GDbugzObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s119Code.GDUPcolObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s119Code.GDbugzObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s119Code.GDDOWNcolObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s119Code.GDbugzObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s119Code.GDDOWNcolObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s119Code.GDBObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s119Code.GDAObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s119Code.GDoffObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s119Code.GDonObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s119Code.GDbugzObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s119Code.GDExitObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s119Code.GDbugzObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDTALK2Objects1Objects = Hashtable.newFrom({"TALK2": gdjs.s119Code.GDTALK2Objects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s119Code.GDbugzObjects1});gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDTALK3Objects1Objects = Hashtable.newFrom({"TALK3": gdjs.s119Code.GDTALK3Objects1});gdjs.s119Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s119Code.GDDOWNbuttonObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
gdjs.s119Code.condition1IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s119Code.condition0IsTrue_0.val ) {
{
gdjs.s119Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s119Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s119Code.GDUPbuttonObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
gdjs.s119Code.condition1IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s119Code.condition0IsTrue_0.val ) {
{
gdjs.s119Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s119Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s119Code.GDRbuttonObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
gdjs.s119Code.condition1IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s119Code.condition0IsTrue_0.val ) {
{
gdjs.s119Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s119Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s119Code.GDLbuttonObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
gdjs.s119Code.condition1IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s119Code.condition0IsTrue_0.val ) {
{
gdjs.s119Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s119Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s119Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects, gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s119Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s119Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects, gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s119Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s119Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects, gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s119Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s119Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects, gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s119Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s119Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects, gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s119Code.GDBObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s119Code.GDAObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s119Code.GDoffObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s119Code.GDonObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s119Code.condition0IsTrue_0.val = false;
gdjs.s119Code.condition1IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s119Code.condition0IsTrue_0.val ) {
{
gdjs.s119Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s119Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s119Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s119Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s119Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s119Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s119Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s119Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s119Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects, gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s122", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK2"), gdjs.s119Code.GDTALK2Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects, gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDTALK2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s115", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK3"), gdjs.s119Code.GDTALK3Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);

gdjs.s119Code.condition0IsTrue_0.val = false;
{
gdjs.s119Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDbugzObjects1Objects, gdjs.s119Code.mapOfGDgdjs_46s119Code_46GDTALK3Objects1Objects, false, runtimeScene, false);
}if (gdjs.s119Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s120", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s119Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s119Code.GDbugzObjects1.length !== 0 ? gdjs.s119Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s119Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s119Code.GDcaseObjects1.length = 0;
gdjs.s119Code.GDcaseObjects2.length = 0;
gdjs.s119Code.GDoffObjects1.length = 0;
gdjs.s119Code.GDoffObjects2.length = 0;
gdjs.s119Code.GDonObjects1.length = 0;
gdjs.s119Code.GDonObjects2.length = 0;
gdjs.s119Code.GDstartObjects1.length = 0;
gdjs.s119Code.GDstartObjects2.length = 0;
gdjs.s119Code.GDBObjects1.length = 0;
gdjs.s119Code.GDBObjects2.length = 0;
gdjs.s119Code.GDAObjects1.length = 0;
gdjs.s119Code.GDAObjects2.length = 0;
gdjs.s119Code.GDbugzObjects1.length = 0;
gdjs.s119Code.GDbugzObjects2.length = 0;
gdjs.s119Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s119Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s119Code.GDblackObjects1.length = 0;
gdjs.s119Code.GDblackObjects2.length = 0;
gdjs.s119Code.GDDOWNcolObjects1.length = 0;
gdjs.s119Code.GDDOWNcolObjects2.length = 0;
gdjs.s119Code.GDUPbuttonObjects1.length = 0;
gdjs.s119Code.GDUPbuttonObjects2.length = 0;
gdjs.s119Code.GDUPcolObjects1.length = 0;
gdjs.s119Code.GDUPcolObjects2.length = 0;
gdjs.s119Code.GDLbuttonObjects1.length = 0;
gdjs.s119Code.GDLbuttonObjects2.length = 0;
gdjs.s119Code.GDLcolObjects1.length = 0;
gdjs.s119Code.GDLcolObjects2.length = 0;
gdjs.s119Code.GDRbuttonObjects1.length = 0;
gdjs.s119Code.GDRbuttonObjects2.length = 0;
gdjs.s119Code.GDTALK3Objects1.length = 0;
gdjs.s119Code.GDTALK3Objects2.length = 0;
gdjs.s119Code.GDTALK2Objects1.length = 0;
gdjs.s119Code.GDTALK2Objects2.length = 0;
gdjs.s119Code.GDExitObjects1.length = 0;
gdjs.s119Code.GDExitObjects2.length = 0;
gdjs.s119Code.GDRcolObjects1.length = 0;
gdjs.s119Code.GDRcolObjects2.length = 0;
gdjs.s119Code.GDchapter4Objects1.length = 0;
gdjs.s119Code.GDchapter4Objects2.length = 0;
gdjs.s119Code.GDchapter3Objects1.length = 0;
gdjs.s119Code.GDchapter3Objects2.length = 0;
gdjs.s119Code.GDchapter2Objects1.length = 0;
gdjs.s119Code.GDchapter2Objects2.length = 0;
gdjs.s119Code.GDchapter1Objects1.length = 0;
gdjs.s119Code.GDchapter1Objects2.length = 0;
gdjs.s119Code.GDBGObjects1.length = 0;
gdjs.s119Code.GDBGObjects2.length = 0;

gdjs.s119Code.eventsList0(runtimeScene);
return;

}

gdjs['s119Code'] = gdjs.s119Code;
