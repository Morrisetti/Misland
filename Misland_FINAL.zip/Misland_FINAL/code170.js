gdjs.s154Code = {};
gdjs.s154Code.GDcaseObjects1= [];
gdjs.s154Code.GDcaseObjects2= [];
gdjs.s154Code.GDimageObjects1= [];
gdjs.s154Code.GDimageObjects2= [];
gdjs.s154Code.GDoffObjects1= [];
gdjs.s154Code.GDoffObjects2= [];
gdjs.s154Code.GDonObjects1= [];
gdjs.s154Code.GDonObjects2= [];
gdjs.s154Code.GDstartObjects1= [];
gdjs.s154Code.GDstartObjects2= [];
gdjs.s154Code.GDBObjects1= [];
gdjs.s154Code.GDBObjects2= [];
gdjs.s154Code.GDblackObjects1= [];
gdjs.s154Code.GDblackObjects2= [];
gdjs.s154Code.GDAObjects1= [];
gdjs.s154Code.GDAObjects2= [];

gdjs.s154Code.conditionTrue_0 = {val:false};
gdjs.s154Code.condition0IsTrue_0 = {val:false};
gdjs.s154Code.condition1IsTrue_0 = {val:false};


gdjs.s154Code.mapOfGDgdjs_46s154Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s154Code.GDBObjects1});gdjs.s154Code.mapOfGDgdjs_46s154Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s154Code.GDoffObjects1});gdjs.s154Code.mapOfGDgdjs_46s154Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s154Code.GDonObjects1});gdjs.s154Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s154Code.GDBObjects1);

gdjs.s154Code.condition0IsTrue_0.val = false;
{
gdjs.s154Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s154Code.mapOfGDgdjs_46s154Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s154Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s155", false);
}}

}


{


gdjs.s154Code.condition0IsTrue_0.val = false;
{
gdjs.s154Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s154Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s155", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s154Code.GDoffObjects1);

gdjs.s154Code.condition0IsTrue_0.val = false;
{
gdjs.s154Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s154Code.mapOfGDgdjs_46s154Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s154Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s154Code.GDonObjects1);

gdjs.s154Code.condition0IsTrue_0.val = false;
{
gdjs.s154Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s154Code.mapOfGDgdjs_46s154Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s154Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s154Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s154Code.GDcaseObjects1.length = 0;
gdjs.s154Code.GDcaseObjects2.length = 0;
gdjs.s154Code.GDimageObjects1.length = 0;
gdjs.s154Code.GDimageObjects2.length = 0;
gdjs.s154Code.GDoffObjects1.length = 0;
gdjs.s154Code.GDoffObjects2.length = 0;
gdjs.s154Code.GDonObjects1.length = 0;
gdjs.s154Code.GDonObjects2.length = 0;
gdjs.s154Code.GDstartObjects1.length = 0;
gdjs.s154Code.GDstartObjects2.length = 0;
gdjs.s154Code.GDBObjects1.length = 0;
gdjs.s154Code.GDBObjects2.length = 0;
gdjs.s154Code.GDblackObjects1.length = 0;
gdjs.s154Code.GDblackObjects2.length = 0;
gdjs.s154Code.GDAObjects1.length = 0;
gdjs.s154Code.GDAObjects2.length = 0;

gdjs.s154Code.eventsList0(runtimeScene);
return;

}

gdjs['s154Code'] = gdjs.s154Code;
