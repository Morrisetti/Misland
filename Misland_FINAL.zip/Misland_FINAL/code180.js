gdjs.s163Code = {};
gdjs.s163Code.GDcaseObjects1= [];
gdjs.s163Code.GDcaseObjects2= [];
gdjs.s163Code.GDimageObjects1= [];
gdjs.s163Code.GDimageObjects2= [];
gdjs.s163Code.GDoffObjects1= [];
gdjs.s163Code.GDoffObjects2= [];
gdjs.s163Code.GDonObjects1= [];
gdjs.s163Code.GDonObjects2= [];
gdjs.s163Code.GDstartObjects1= [];
gdjs.s163Code.GDstartObjects2= [];
gdjs.s163Code.GDBObjects1= [];
gdjs.s163Code.GDBObjects2= [];
gdjs.s163Code.GDblackObjects1= [];
gdjs.s163Code.GDblackObjects2= [];
gdjs.s163Code.GDAObjects1= [];
gdjs.s163Code.GDAObjects2= [];

gdjs.s163Code.conditionTrue_0 = {val:false};
gdjs.s163Code.condition0IsTrue_0 = {val:false};
gdjs.s163Code.condition1IsTrue_0 = {val:false};
gdjs.s163Code.conditionTrue_1 = {val:false};
gdjs.s163Code.condition0IsTrue_1 = {val:false};
gdjs.s163Code.condition1IsTrue_1 = {val:false};


gdjs.s163Code.mapOfGDgdjs_46s163Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s163Code.GDstartObjects1});gdjs.s163Code.mapOfGDgdjs_46s163Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s163Code.GDoffObjects1});gdjs.s163Code.mapOfGDgdjs_46s163Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s163Code.GDonObjects1});gdjs.s163Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s163Code.condition0IsTrue_0.val = false;
{
{gdjs.s163Code.conditionTrue_1 = gdjs.s163Code.condition0IsTrue_0;
gdjs.s163Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(72443452);
}
}if (gdjs.s163Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\dead.mp3", false, 100, 1);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s163Code.GDstartObjects1);

gdjs.s163Code.condition0IsTrue_0.val = false;
{
gdjs.s163Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s163Code.mapOfGDgdjs_46s163Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s163Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s161.1", false);
}}

}


{


gdjs.s163Code.condition0IsTrue_0.val = false;
{
gdjs.s163Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.s163Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s161.1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s163Code.GDoffObjects1);

gdjs.s163Code.condition0IsTrue_0.val = false;
{
gdjs.s163Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s163Code.mapOfGDgdjs_46s163Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s163Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s163Code.GDonObjects1);

gdjs.s163Code.condition0IsTrue_0.val = false;
{
gdjs.s163Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s163Code.mapOfGDgdjs_46s163Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s163Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s163Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s163Code.GDcaseObjects1.length = 0;
gdjs.s163Code.GDcaseObjects2.length = 0;
gdjs.s163Code.GDimageObjects1.length = 0;
gdjs.s163Code.GDimageObjects2.length = 0;
gdjs.s163Code.GDoffObjects1.length = 0;
gdjs.s163Code.GDoffObjects2.length = 0;
gdjs.s163Code.GDonObjects1.length = 0;
gdjs.s163Code.GDonObjects2.length = 0;
gdjs.s163Code.GDstartObjects1.length = 0;
gdjs.s163Code.GDstartObjects2.length = 0;
gdjs.s163Code.GDBObjects1.length = 0;
gdjs.s163Code.GDBObjects2.length = 0;
gdjs.s163Code.GDblackObjects1.length = 0;
gdjs.s163Code.GDblackObjects2.length = 0;
gdjs.s163Code.GDAObjects1.length = 0;
gdjs.s163Code.GDAObjects2.length = 0;

gdjs.s163Code.eventsList0(runtimeScene);
return;

}

gdjs['s163Code'] = gdjs.s163Code;
