gdjs.s62Code = {};
gdjs.s62Code.GDcaseObjects1= [];
gdjs.s62Code.GDcaseObjects2= [];
gdjs.s62Code.GDimageObjects1= [];
gdjs.s62Code.GDimageObjects2= [];
gdjs.s62Code.GDoffObjects1= [];
gdjs.s62Code.GDoffObjects2= [];
gdjs.s62Code.GDonObjects1= [];
gdjs.s62Code.GDonObjects2= [];
gdjs.s62Code.GDstartObjects1= [];
gdjs.s62Code.GDstartObjects2= [];
gdjs.s62Code.GDBObjects1= [];
gdjs.s62Code.GDBObjects2= [];
gdjs.s62Code.GDblackObjects1= [];
gdjs.s62Code.GDblackObjects2= [];
gdjs.s62Code.GDAObjects1= [];
gdjs.s62Code.GDAObjects2= [];

gdjs.s62Code.conditionTrue_0 = {val:false};
gdjs.s62Code.condition0IsTrue_0 = {val:false};
gdjs.s62Code.condition1IsTrue_0 = {val:false};


gdjs.s62Code.mapOfGDgdjs_46s62Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s62Code.GDstartObjects1});gdjs.s62Code.mapOfGDgdjs_46s62Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s62Code.GDoffObjects1});gdjs.s62Code.mapOfGDgdjs_46s62Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s62Code.GDonObjects1});gdjs.s62Code.mapOfGDgdjs_46s62Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s62Code.GDAObjects1});gdjs.s62Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s62Code.GDstartObjects1);

gdjs.s62Code.condition0IsTrue_0.val = false;
{
gdjs.s62Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s62Code.mapOfGDgdjs_46s62Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s62Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s62Code.GDoffObjects1);

gdjs.s62Code.condition0IsTrue_0.val = false;
{
gdjs.s62Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s62Code.mapOfGDgdjs_46s62Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s62Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s62Code.GDonObjects1);

gdjs.s62Code.condition0IsTrue_0.val = false;
{
gdjs.s62Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s62Code.mapOfGDgdjs_46s62Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s62Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s62Code.condition0IsTrue_0.val = false;
{
gdjs.s62Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s62Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s63", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s62Code.GDAObjects1);

gdjs.s62Code.condition0IsTrue_0.val = false;
{
gdjs.s62Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s62Code.mapOfGDgdjs_46s62Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s62Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s63", false);
}}

}


{


{
}

}


};

gdjs.s62Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s62Code.GDcaseObjects1.length = 0;
gdjs.s62Code.GDcaseObjects2.length = 0;
gdjs.s62Code.GDimageObjects1.length = 0;
gdjs.s62Code.GDimageObjects2.length = 0;
gdjs.s62Code.GDoffObjects1.length = 0;
gdjs.s62Code.GDoffObjects2.length = 0;
gdjs.s62Code.GDonObjects1.length = 0;
gdjs.s62Code.GDonObjects2.length = 0;
gdjs.s62Code.GDstartObjects1.length = 0;
gdjs.s62Code.GDstartObjects2.length = 0;
gdjs.s62Code.GDBObjects1.length = 0;
gdjs.s62Code.GDBObjects2.length = 0;
gdjs.s62Code.GDblackObjects1.length = 0;
gdjs.s62Code.GDblackObjects2.length = 0;
gdjs.s62Code.GDAObjects1.length = 0;
gdjs.s62Code.GDAObjects2.length = 0;

gdjs.s62Code.eventsList0(runtimeScene);
return;

}

gdjs['s62Code'] = gdjs.s62Code;
