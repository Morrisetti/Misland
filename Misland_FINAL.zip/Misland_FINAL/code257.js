gdjs.s218Code = {};
gdjs.s218Code.GDcaseObjects1= [];
gdjs.s218Code.GDcaseObjects2= [];
gdjs.s218Code.GDimageObjects1= [];
gdjs.s218Code.GDimageObjects2= [];
gdjs.s218Code.GDoffObjects1= [];
gdjs.s218Code.GDoffObjects2= [];
gdjs.s218Code.GDonObjects1= [];
gdjs.s218Code.GDonObjects2= [];
gdjs.s218Code.GDstartObjects1= [];
gdjs.s218Code.GDstartObjects2= [];
gdjs.s218Code.GDBObjects1= [];
gdjs.s218Code.GDBObjects2= [];
gdjs.s218Code.GDblackObjects1= [];
gdjs.s218Code.GDblackObjects2= [];
gdjs.s218Code.GDAObjects1= [];
gdjs.s218Code.GDAObjects2= [];

gdjs.s218Code.conditionTrue_0 = {val:false};
gdjs.s218Code.condition0IsTrue_0 = {val:false};
gdjs.s218Code.condition1IsTrue_0 = {val:false};


gdjs.s218Code.mapOfGDgdjs_46s218Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s218Code.GDstartObjects1});gdjs.s218Code.mapOfGDgdjs_46s218Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s218Code.GDoffObjects1});gdjs.s218Code.mapOfGDgdjs_46s218Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s218Code.GDonObjects1});gdjs.s218Code.mapOfGDgdjs_46s218Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s218Code.GDBObjects1});gdjs.s218Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s218Code.GDstartObjects1);

gdjs.s218Code.condition0IsTrue_0.val = false;
{
gdjs.s218Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s218Code.mapOfGDgdjs_46s218Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s218Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s218Code.GDoffObjects1);

gdjs.s218Code.condition0IsTrue_0.val = false;
{
gdjs.s218Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s218Code.mapOfGDgdjs_46s218Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s218Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s218Code.GDonObjects1);

gdjs.s218Code.condition0IsTrue_0.val = false;
{
gdjs.s218Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s218Code.mapOfGDgdjs_46s218Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s218Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s218Code.condition0IsTrue_0.val = false;
{
gdjs.s218Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s218Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s219", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s218Code.GDBObjects1);

gdjs.s218Code.condition0IsTrue_0.val = false;
{
gdjs.s218Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s218Code.mapOfGDgdjs_46s218Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s218Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s219", false);
}}

}


{


{
}

}


};

gdjs.s218Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s218Code.GDcaseObjects1.length = 0;
gdjs.s218Code.GDcaseObjects2.length = 0;
gdjs.s218Code.GDimageObjects1.length = 0;
gdjs.s218Code.GDimageObjects2.length = 0;
gdjs.s218Code.GDoffObjects1.length = 0;
gdjs.s218Code.GDoffObjects2.length = 0;
gdjs.s218Code.GDonObjects1.length = 0;
gdjs.s218Code.GDonObjects2.length = 0;
gdjs.s218Code.GDstartObjects1.length = 0;
gdjs.s218Code.GDstartObjects2.length = 0;
gdjs.s218Code.GDBObjects1.length = 0;
gdjs.s218Code.GDBObjects2.length = 0;
gdjs.s218Code.GDblackObjects1.length = 0;
gdjs.s218Code.GDblackObjects2.length = 0;
gdjs.s218Code.GDAObjects1.length = 0;
gdjs.s218Code.GDAObjects2.length = 0;

gdjs.s218Code.eventsList0(runtimeScene);
return;

}

gdjs['s218Code'] = gdjs.s218Code;
