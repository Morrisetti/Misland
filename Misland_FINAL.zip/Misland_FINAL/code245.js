gdjs.s204Code = {};
gdjs.s204Code.GDcaseObjects1= [];
gdjs.s204Code.GDcaseObjects2= [];
gdjs.s204Code.GDoffObjects1= [];
gdjs.s204Code.GDoffObjects2= [];
gdjs.s204Code.GDonObjects1= [];
gdjs.s204Code.GDonObjects2= [];
gdjs.s204Code.GDstartObjects1= [];
gdjs.s204Code.GDstartObjects2= [];
gdjs.s204Code.GDBObjects1= [];
gdjs.s204Code.GDBObjects2= [];
gdjs.s204Code.GDAObjects1= [];
gdjs.s204Code.GDAObjects2= [];
gdjs.s204Code.GDbugzObjects1= [];
gdjs.s204Code.GDbugzObjects2= [];
gdjs.s204Code.GDDOWNbuttonObjects1= [];
gdjs.s204Code.GDDOWNbuttonObjects2= [];
gdjs.s204Code.GDblackObjects1= [];
gdjs.s204Code.GDblackObjects2= [];
gdjs.s204Code.GDDOWNcolObjects1= [];
gdjs.s204Code.GDDOWNcolObjects2= [];
gdjs.s204Code.GDUPbuttonObjects1= [];
gdjs.s204Code.GDUPbuttonObjects2= [];
gdjs.s204Code.GDUPcolObjects1= [];
gdjs.s204Code.GDUPcolObjects2= [];
gdjs.s204Code.GDLbuttonObjects1= [];
gdjs.s204Code.GDLbuttonObjects2= [];
gdjs.s204Code.GDLcolObjects1= [];
gdjs.s204Code.GDLcolObjects2= [];
gdjs.s204Code.GDRbuttonObjects1= [];
gdjs.s204Code.GDRbuttonObjects2= [];
gdjs.s204Code.GDTALK3Objects1= [];
gdjs.s204Code.GDTALK3Objects2= [];
gdjs.s204Code.GDTALK2Objects1= [];
gdjs.s204Code.GDTALK2Objects2= [];
gdjs.s204Code.GDExitObjects1= [];
gdjs.s204Code.GDExitObjects2= [];
gdjs.s204Code.GDRcolObjects1= [];
gdjs.s204Code.GDRcolObjects2= [];
gdjs.s204Code.GDchapter4Objects1= [];
gdjs.s204Code.GDchapter4Objects2= [];
gdjs.s204Code.GDchapter3Objects1= [];
gdjs.s204Code.GDchapter3Objects2= [];
gdjs.s204Code.GDchapter2Objects1= [];
gdjs.s204Code.GDchapter2Objects2= [];
gdjs.s204Code.GDchapter1Objects1= [];
gdjs.s204Code.GDchapter1Objects2= [];
gdjs.s204Code.GDBGObjects1= [];
gdjs.s204Code.GDBGObjects2= [];

gdjs.s204Code.conditionTrue_0 = {val:false};
gdjs.s204Code.condition0IsTrue_0 = {val:false};
gdjs.s204Code.condition1IsTrue_0 = {val:false};
gdjs.s204Code.condition2IsTrue_0 = {val:false};


gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s204Code.GDDOWNbuttonObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s204Code.GDUPbuttonObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s204Code.GDRbuttonObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s204Code.GDLbuttonObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s204Code.GDbugzObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s204Code.GDRcolObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s204Code.GDbugzObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s204Code.GDLcolObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s204Code.GDbugzObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s204Code.GDUPcolObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s204Code.GDbugzObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s204Code.GDDOWNcolObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s204Code.GDbugzObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s204Code.GDDOWNcolObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s204Code.GDBObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s204Code.GDAObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s204Code.GDoffObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s204Code.GDonObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s204Code.GDbugzObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s204Code.GDExitObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s204Code.GDbugzObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDTALK2Objects1Objects = Hashtable.newFrom({"TALK2": gdjs.s204Code.GDTALK2Objects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s204Code.GDbugzObjects1});gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDTALK3Objects1Objects = Hashtable.newFrom({"TALK3": gdjs.s204Code.GDTALK3Objects1});gdjs.s204Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s204Code.GDDOWNbuttonObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
gdjs.s204Code.condition1IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s204Code.condition0IsTrue_0.val ) {
{
gdjs.s204Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s204Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s204Code.GDUPbuttonObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
gdjs.s204Code.condition1IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s204Code.condition0IsTrue_0.val ) {
{
gdjs.s204Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s204Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s204Code.GDRbuttonObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
gdjs.s204Code.condition1IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s204Code.condition0IsTrue_0.val ) {
{
gdjs.s204Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s204Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s204Code.GDLbuttonObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
gdjs.s204Code.condition1IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s204Code.condition0IsTrue_0.val ) {
{
gdjs.s204Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s204Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s204Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects, gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s204Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s204Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects, gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s204Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s204Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects, gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s204Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s204Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects, gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s204Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s204Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects, gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s204Code.GDBObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s204Code.GDAObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s204Code.GDoffObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s204Code.GDonObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s204Code.condition0IsTrue_0.val = false;
gdjs.s204Code.condition1IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s204Code.condition0IsTrue_0.val ) {
{
gdjs.s204Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s204Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s204Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s204Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s204Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s204Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s204Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s204Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s204Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects, gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s207", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK2"), gdjs.s204Code.GDTALK2Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects, gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDTALK2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s205", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK3"), gdjs.s204Code.GDTALK3Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);

gdjs.s204Code.condition0IsTrue_0.val = false;
{
gdjs.s204Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDbugzObjects1Objects, gdjs.s204Code.mapOfGDgdjs_46s204Code_46GDTALK3Objects1Objects, false, runtimeScene, false);
}if (gdjs.s204Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "S198", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s204Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s204Code.GDbugzObjects1.length !== 0 ? gdjs.s204Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s204Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s204Code.GDcaseObjects1.length = 0;
gdjs.s204Code.GDcaseObjects2.length = 0;
gdjs.s204Code.GDoffObjects1.length = 0;
gdjs.s204Code.GDoffObjects2.length = 0;
gdjs.s204Code.GDonObjects1.length = 0;
gdjs.s204Code.GDonObjects2.length = 0;
gdjs.s204Code.GDstartObjects1.length = 0;
gdjs.s204Code.GDstartObjects2.length = 0;
gdjs.s204Code.GDBObjects1.length = 0;
gdjs.s204Code.GDBObjects2.length = 0;
gdjs.s204Code.GDAObjects1.length = 0;
gdjs.s204Code.GDAObjects2.length = 0;
gdjs.s204Code.GDbugzObjects1.length = 0;
gdjs.s204Code.GDbugzObjects2.length = 0;
gdjs.s204Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s204Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s204Code.GDblackObjects1.length = 0;
gdjs.s204Code.GDblackObjects2.length = 0;
gdjs.s204Code.GDDOWNcolObjects1.length = 0;
gdjs.s204Code.GDDOWNcolObjects2.length = 0;
gdjs.s204Code.GDUPbuttonObjects1.length = 0;
gdjs.s204Code.GDUPbuttonObjects2.length = 0;
gdjs.s204Code.GDUPcolObjects1.length = 0;
gdjs.s204Code.GDUPcolObjects2.length = 0;
gdjs.s204Code.GDLbuttonObjects1.length = 0;
gdjs.s204Code.GDLbuttonObjects2.length = 0;
gdjs.s204Code.GDLcolObjects1.length = 0;
gdjs.s204Code.GDLcolObjects2.length = 0;
gdjs.s204Code.GDRbuttonObjects1.length = 0;
gdjs.s204Code.GDRbuttonObjects2.length = 0;
gdjs.s204Code.GDTALK3Objects1.length = 0;
gdjs.s204Code.GDTALK3Objects2.length = 0;
gdjs.s204Code.GDTALK2Objects1.length = 0;
gdjs.s204Code.GDTALK2Objects2.length = 0;
gdjs.s204Code.GDExitObjects1.length = 0;
gdjs.s204Code.GDExitObjects2.length = 0;
gdjs.s204Code.GDRcolObjects1.length = 0;
gdjs.s204Code.GDRcolObjects2.length = 0;
gdjs.s204Code.GDchapter4Objects1.length = 0;
gdjs.s204Code.GDchapter4Objects2.length = 0;
gdjs.s204Code.GDchapter3Objects1.length = 0;
gdjs.s204Code.GDchapter3Objects2.length = 0;
gdjs.s204Code.GDchapter2Objects1.length = 0;
gdjs.s204Code.GDchapter2Objects2.length = 0;
gdjs.s204Code.GDchapter1Objects1.length = 0;
gdjs.s204Code.GDchapter1Objects2.length = 0;
gdjs.s204Code.GDBGObjects1.length = 0;
gdjs.s204Code.GDBGObjects2.length = 0;

gdjs.s204Code.eventsList0(runtimeScene);
return;

}

gdjs['s204Code'] = gdjs.s204Code;
