gdjs.s247Code = {};
gdjs.s247Code.GDcaseObjects1= [];
gdjs.s247Code.GDcaseObjects2= [];
gdjs.s247Code.GDimageObjects1= [];
gdjs.s247Code.GDimageObjects2= [];
gdjs.s247Code.GDoffObjects1= [];
gdjs.s247Code.GDoffObjects2= [];
gdjs.s247Code.GDonObjects1= [];
gdjs.s247Code.GDonObjects2= [];
gdjs.s247Code.GDstartObjects1= [];
gdjs.s247Code.GDstartObjects2= [];
gdjs.s247Code.GDBObjects1= [];
gdjs.s247Code.GDBObjects2= [];
gdjs.s247Code.GDblackObjects1= [];
gdjs.s247Code.GDblackObjects2= [];
gdjs.s247Code.GDAObjects1= [];
gdjs.s247Code.GDAObjects2= [];

gdjs.s247Code.conditionTrue_0 = {val:false};
gdjs.s247Code.condition0IsTrue_0 = {val:false};
gdjs.s247Code.condition1IsTrue_0 = {val:false};


gdjs.s247Code.mapOfGDgdjs_46s247Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s247Code.GDstartObjects1});gdjs.s247Code.mapOfGDgdjs_46s247Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s247Code.GDoffObjects1});gdjs.s247Code.mapOfGDgdjs_46s247Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s247Code.GDonObjects1});gdjs.s247Code.mapOfGDgdjs_46s247Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s247Code.GDAObjects1});gdjs.s247Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s247Code.GDstartObjects1);

gdjs.s247Code.condition0IsTrue_0.val = false;
{
gdjs.s247Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s247Code.mapOfGDgdjs_46s247Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s247Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s247Code.GDoffObjects1);

gdjs.s247Code.condition0IsTrue_0.val = false;
{
gdjs.s247Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s247Code.mapOfGDgdjs_46s247Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s247Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s247Code.GDonObjects1);

gdjs.s247Code.condition0IsTrue_0.val = false;
{
gdjs.s247Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s247Code.mapOfGDgdjs_46s247Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s247Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s247Code.condition0IsTrue_0.val = false;
{
gdjs.s247Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s247Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s248", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s247Code.GDAObjects1);

gdjs.s247Code.condition0IsTrue_0.val = false;
{
gdjs.s247Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s247Code.mapOfGDgdjs_46s247Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s247Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s248", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s247Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s247Code.GDcaseObjects1.length = 0;
gdjs.s247Code.GDcaseObjects2.length = 0;
gdjs.s247Code.GDimageObjects1.length = 0;
gdjs.s247Code.GDimageObjects2.length = 0;
gdjs.s247Code.GDoffObjects1.length = 0;
gdjs.s247Code.GDoffObjects2.length = 0;
gdjs.s247Code.GDonObjects1.length = 0;
gdjs.s247Code.GDonObjects2.length = 0;
gdjs.s247Code.GDstartObjects1.length = 0;
gdjs.s247Code.GDstartObjects2.length = 0;
gdjs.s247Code.GDBObjects1.length = 0;
gdjs.s247Code.GDBObjects2.length = 0;
gdjs.s247Code.GDblackObjects1.length = 0;
gdjs.s247Code.GDblackObjects2.length = 0;
gdjs.s247Code.GDAObjects1.length = 0;
gdjs.s247Code.GDAObjects2.length = 0;

gdjs.s247Code.eventsList0(runtimeScene);
return;

}

gdjs['s247Code'] = gdjs.s247Code;
