gdjs.s140Code = {};
gdjs.s140Code.GDcaseObjects1= [];
gdjs.s140Code.GDcaseObjects2= [];
gdjs.s140Code.GDimageObjects1= [];
gdjs.s140Code.GDimageObjects2= [];
gdjs.s140Code.GDoffObjects1= [];
gdjs.s140Code.GDoffObjects2= [];
gdjs.s140Code.GDonObjects1= [];
gdjs.s140Code.GDonObjects2= [];
gdjs.s140Code.GDstartObjects1= [];
gdjs.s140Code.GDstartObjects2= [];
gdjs.s140Code.GDBObjects1= [];
gdjs.s140Code.GDBObjects2= [];
gdjs.s140Code.GDblackObjects1= [];
gdjs.s140Code.GDblackObjects2= [];
gdjs.s140Code.GDAObjects1= [];
gdjs.s140Code.GDAObjects2= [];

gdjs.s140Code.conditionTrue_0 = {val:false};
gdjs.s140Code.condition0IsTrue_0 = {val:false};
gdjs.s140Code.condition1IsTrue_0 = {val:false};


gdjs.s140Code.mapOfGDgdjs_46s140Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s140Code.GDstartObjects1});gdjs.s140Code.mapOfGDgdjs_46s140Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s140Code.GDoffObjects1});gdjs.s140Code.mapOfGDgdjs_46s140Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s140Code.GDonObjects1});gdjs.s140Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s140Code.GDcaseObjects1);

gdjs.s140Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s140Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s140Code.GDcaseObjects1[i].timerElapsedTime("", 1.5) ) {
        gdjs.s140Code.condition0IsTrue_0.val = true;
        gdjs.s140Code.GDcaseObjects1[k] = gdjs.s140Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s140Code.GDcaseObjects1.length = k;}if (gdjs.s140Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s141", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s140Code.GDstartObjects1);

gdjs.s140Code.condition0IsTrue_0.val = false;
{
gdjs.s140Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s140Code.mapOfGDgdjs_46s140Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s140Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s140Code.GDoffObjects1);

gdjs.s140Code.condition0IsTrue_0.val = false;
{
gdjs.s140Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s140Code.mapOfGDgdjs_46s140Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s140Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s140Code.GDonObjects1);

gdjs.s140Code.condition0IsTrue_0.val = false;
{
gdjs.s140Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s140Code.mapOfGDgdjs_46s140Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s140Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s140Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s140Code.GDcaseObjects1.length = 0;
gdjs.s140Code.GDcaseObjects2.length = 0;
gdjs.s140Code.GDimageObjects1.length = 0;
gdjs.s140Code.GDimageObjects2.length = 0;
gdjs.s140Code.GDoffObjects1.length = 0;
gdjs.s140Code.GDoffObjects2.length = 0;
gdjs.s140Code.GDonObjects1.length = 0;
gdjs.s140Code.GDonObjects2.length = 0;
gdjs.s140Code.GDstartObjects1.length = 0;
gdjs.s140Code.GDstartObjects2.length = 0;
gdjs.s140Code.GDBObjects1.length = 0;
gdjs.s140Code.GDBObjects2.length = 0;
gdjs.s140Code.GDblackObjects1.length = 0;
gdjs.s140Code.GDblackObjects2.length = 0;
gdjs.s140Code.GDAObjects1.length = 0;
gdjs.s140Code.GDAObjects2.length = 0;

gdjs.s140Code.eventsList0(runtimeScene);
return;

}

gdjs['s140Code'] = gdjs.s140Code;
