gdjs.s244Code = {};
gdjs.s244Code.GDcaseObjects1= [];
gdjs.s244Code.GDcaseObjects2= [];
gdjs.s244Code.GDimageObjects1= [];
gdjs.s244Code.GDimageObjects2= [];
gdjs.s244Code.GDoffObjects1= [];
gdjs.s244Code.GDoffObjects2= [];
gdjs.s244Code.GDonObjects1= [];
gdjs.s244Code.GDonObjects2= [];
gdjs.s244Code.GDstartObjects1= [];
gdjs.s244Code.GDstartObjects2= [];
gdjs.s244Code.GDBObjects1= [];
gdjs.s244Code.GDBObjects2= [];
gdjs.s244Code.GDblackObjects1= [];
gdjs.s244Code.GDblackObjects2= [];
gdjs.s244Code.GDAObjects1= [];
gdjs.s244Code.GDAObjects2= [];

gdjs.s244Code.conditionTrue_0 = {val:false};
gdjs.s244Code.condition0IsTrue_0 = {val:false};
gdjs.s244Code.condition1IsTrue_0 = {val:false};


gdjs.s244Code.mapOfGDgdjs_46s244Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s244Code.GDstartObjects1});gdjs.s244Code.mapOfGDgdjs_46s244Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s244Code.GDoffObjects1});gdjs.s244Code.mapOfGDgdjs_46s244Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s244Code.GDonObjects1});gdjs.s244Code.mapOfGDgdjs_46s244Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s244Code.GDBObjects1});gdjs.s244Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s244Code.GDstartObjects1);

gdjs.s244Code.condition0IsTrue_0.val = false;
{
gdjs.s244Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s244Code.mapOfGDgdjs_46s244Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s244Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s244Code.GDoffObjects1);

gdjs.s244Code.condition0IsTrue_0.val = false;
{
gdjs.s244Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s244Code.mapOfGDgdjs_46s244Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s244Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s244Code.GDonObjects1);

gdjs.s244Code.condition0IsTrue_0.val = false;
{
gdjs.s244Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s244Code.mapOfGDgdjs_46s244Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s244Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s244Code.condition0IsTrue_0.val = false;
{
gdjs.s244Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s244Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s245", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s244Code.GDBObjects1);

gdjs.s244Code.condition0IsTrue_0.val = false;
{
gdjs.s244Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s244Code.mapOfGDgdjs_46s244Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s244Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s245", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s244Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s244Code.GDcaseObjects1.length = 0;
gdjs.s244Code.GDcaseObjects2.length = 0;
gdjs.s244Code.GDimageObjects1.length = 0;
gdjs.s244Code.GDimageObjects2.length = 0;
gdjs.s244Code.GDoffObjects1.length = 0;
gdjs.s244Code.GDoffObjects2.length = 0;
gdjs.s244Code.GDonObjects1.length = 0;
gdjs.s244Code.GDonObjects2.length = 0;
gdjs.s244Code.GDstartObjects1.length = 0;
gdjs.s244Code.GDstartObjects2.length = 0;
gdjs.s244Code.GDBObjects1.length = 0;
gdjs.s244Code.GDBObjects2.length = 0;
gdjs.s244Code.GDblackObjects1.length = 0;
gdjs.s244Code.GDblackObjects2.length = 0;
gdjs.s244Code.GDAObjects1.length = 0;
gdjs.s244Code.GDAObjects2.length = 0;

gdjs.s244Code.eventsList0(runtimeScene);
return;

}

gdjs['s244Code'] = gdjs.s244Code;
