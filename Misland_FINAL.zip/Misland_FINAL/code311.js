gdjs.s272Code = {};
gdjs.s272Code.GDcaseObjects1= [];
gdjs.s272Code.GDcaseObjects2= [];
gdjs.s272Code.GDimageObjects1= [];
gdjs.s272Code.GDimageObjects2= [];
gdjs.s272Code.GDoffObjects1= [];
gdjs.s272Code.GDoffObjects2= [];
gdjs.s272Code.GDonObjects1= [];
gdjs.s272Code.GDonObjects2= [];
gdjs.s272Code.GDstartObjects1= [];
gdjs.s272Code.GDstartObjects2= [];
gdjs.s272Code.GDBObjects1= [];
gdjs.s272Code.GDBObjects2= [];
gdjs.s272Code.GDblackObjects1= [];
gdjs.s272Code.GDblackObjects2= [];
gdjs.s272Code.GDAObjects1= [];
gdjs.s272Code.GDAObjects2= [];

gdjs.s272Code.conditionTrue_0 = {val:false};
gdjs.s272Code.condition0IsTrue_0 = {val:false};
gdjs.s272Code.condition1IsTrue_0 = {val:false};


gdjs.s272Code.mapOfGDgdjs_46s272Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s272Code.GDstartObjects1});gdjs.s272Code.mapOfGDgdjs_46s272Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s272Code.GDoffObjects1});gdjs.s272Code.mapOfGDgdjs_46s272Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s272Code.GDonObjects1});gdjs.s272Code.mapOfGDgdjs_46s272Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s272Code.GDBObjects1});gdjs.s272Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s272Code.GDstartObjects1);

gdjs.s272Code.condition0IsTrue_0.val = false;
{
gdjs.s272Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s272Code.mapOfGDgdjs_46s272Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s272Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s272Code.GDoffObjects1);

gdjs.s272Code.condition0IsTrue_0.val = false;
{
gdjs.s272Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s272Code.mapOfGDgdjs_46s272Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s272Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s272Code.GDonObjects1);

gdjs.s272Code.condition0IsTrue_0.val = false;
{
gdjs.s272Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s272Code.mapOfGDgdjs_46s272Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s272Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s272Code.condition0IsTrue_0.val = false;
{
gdjs.s272Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s272Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s273", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s272Code.GDBObjects1);

gdjs.s272Code.condition0IsTrue_0.val = false;
{
gdjs.s272Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s272Code.mapOfGDgdjs_46s272Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s272Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s273", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s272Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s272Code.GDcaseObjects1.length = 0;
gdjs.s272Code.GDcaseObjects2.length = 0;
gdjs.s272Code.GDimageObjects1.length = 0;
gdjs.s272Code.GDimageObjects2.length = 0;
gdjs.s272Code.GDoffObjects1.length = 0;
gdjs.s272Code.GDoffObjects2.length = 0;
gdjs.s272Code.GDonObjects1.length = 0;
gdjs.s272Code.GDonObjects2.length = 0;
gdjs.s272Code.GDstartObjects1.length = 0;
gdjs.s272Code.GDstartObjects2.length = 0;
gdjs.s272Code.GDBObjects1.length = 0;
gdjs.s272Code.GDBObjects2.length = 0;
gdjs.s272Code.GDblackObjects1.length = 0;
gdjs.s272Code.GDblackObjects2.length = 0;
gdjs.s272Code.GDAObjects1.length = 0;
gdjs.s272Code.GDAObjects2.length = 0;

gdjs.s272Code.eventsList0(runtimeScene);
return;

}

gdjs['s272Code'] = gdjs.s272Code;
