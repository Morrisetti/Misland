gdjs.s223Code = {};
gdjs.s223Code.GDcaseObjects1= [];
gdjs.s223Code.GDcaseObjects2= [];
gdjs.s223Code.GDimageObjects1= [];
gdjs.s223Code.GDimageObjects2= [];
gdjs.s223Code.GDoffObjects1= [];
gdjs.s223Code.GDoffObjects2= [];
gdjs.s223Code.GDonObjects1= [];
gdjs.s223Code.GDonObjects2= [];
gdjs.s223Code.GDstartObjects1= [];
gdjs.s223Code.GDstartObjects2= [];
gdjs.s223Code.GDBObjects1= [];
gdjs.s223Code.GDBObjects2= [];
gdjs.s223Code.GDblackObjects1= [];
gdjs.s223Code.GDblackObjects2= [];
gdjs.s223Code.GDAObjects1= [];
gdjs.s223Code.GDAObjects2= [];

gdjs.s223Code.conditionTrue_0 = {val:false};
gdjs.s223Code.condition0IsTrue_0 = {val:false};
gdjs.s223Code.condition1IsTrue_0 = {val:false};


gdjs.s223Code.mapOfGDgdjs_46s223Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s223Code.GDstartObjects1});gdjs.s223Code.mapOfGDgdjs_46s223Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s223Code.GDoffObjects1});gdjs.s223Code.mapOfGDgdjs_46s223Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s223Code.GDonObjects1});gdjs.s223Code.mapOfGDgdjs_46s223Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s223Code.GDBObjects1});gdjs.s223Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s223Code.GDstartObjects1);

gdjs.s223Code.condition0IsTrue_0.val = false;
{
gdjs.s223Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s223Code.mapOfGDgdjs_46s223Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s223Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s223Code.GDoffObjects1);

gdjs.s223Code.condition0IsTrue_0.val = false;
{
gdjs.s223Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s223Code.mapOfGDgdjs_46s223Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s223Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s223Code.GDonObjects1);

gdjs.s223Code.condition0IsTrue_0.val = false;
{
gdjs.s223Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s223Code.mapOfGDgdjs_46s223Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s223Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s223Code.condition0IsTrue_0.val = false;
{
gdjs.s223Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s223Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s224", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s223Code.GDBObjects1);

gdjs.s223Code.condition0IsTrue_0.val = false;
{
gdjs.s223Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s223Code.mapOfGDgdjs_46s223Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s223Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s224", false);
}}

}


{


{
}

}


};

gdjs.s223Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s223Code.GDcaseObjects1.length = 0;
gdjs.s223Code.GDcaseObjects2.length = 0;
gdjs.s223Code.GDimageObjects1.length = 0;
gdjs.s223Code.GDimageObjects2.length = 0;
gdjs.s223Code.GDoffObjects1.length = 0;
gdjs.s223Code.GDoffObjects2.length = 0;
gdjs.s223Code.GDonObjects1.length = 0;
gdjs.s223Code.GDonObjects2.length = 0;
gdjs.s223Code.GDstartObjects1.length = 0;
gdjs.s223Code.GDstartObjects2.length = 0;
gdjs.s223Code.GDBObjects1.length = 0;
gdjs.s223Code.GDBObjects2.length = 0;
gdjs.s223Code.GDblackObjects1.length = 0;
gdjs.s223Code.GDblackObjects2.length = 0;
gdjs.s223Code.GDAObjects1.length = 0;
gdjs.s223Code.GDAObjects2.length = 0;

gdjs.s223Code.eventsList0(runtimeScene);
return;

}

gdjs['s223Code'] = gdjs.s223Code;
