gdjs.C4Code = {};
gdjs.C4Code.GDcaseObjects1= [];
gdjs.C4Code.GDcaseObjects2= [];
gdjs.C4Code.GDimageObjects1= [];
gdjs.C4Code.GDimageObjects2= [];
gdjs.C4Code.GDoffObjects1= [];
gdjs.C4Code.GDoffObjects2= [];
gdjs.C4Code.GDonObjects1= [];
gdjs.C4Code.GDonObjects2= [];
gdjs.C4Code.GDstartObjects1= [];
gdjs.C4Code.GDstartObjects2= [];
gdjs.C4Code.GDBObjects1= [];
gdjs.C4Code.GDBObjects2= [];
gdjs.C4Code.GDblackObjects1= [];
gdjs.C4Code.GDblackObjects2= [];
gdjs.C4Code.GDAObjects1= [];
gdjs.C4Code.GDAObjects2= [];

gdjs.C4Code.conditionTrue_0 = {val:false};
gdjs.C4Code.condition0IsTrue_0 = {val:false};
gdjs.C4Code.condition1IsTrue_0 = {val:false};
gdjs.C4Code.conditionTrue_1 = {val:false};
gdjs.C4Code.condition0IsTrue_1 = {val:false};
gdjs.C4Code.condition1IsTrue_1 = {val:false};


gdjs.C4Code.mapOfGDgdjs_46C4Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.C4Code.GDstartObjects1});gdjs.C4Code.mapOfGDgdjs_46C4Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.C4Code.GDoffObjects1});gdjs.C4Code.mapOfGDgdjs_46C4Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.C4Code.GDonObjects1});gdjs.C4Code.mapOfGDgdjs_46C4Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.C4Code.GDstartObjects1});gdjs.C4Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.C4Code.condition0IsTrue_0.val = false;
{
{gdjs.C4Code.conditionTrue_1 = gdjs.C4Code.condition0IsTrue_0;
gdjs.C4Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(73196268);
}
}if (gdjs.C4Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter5_v3.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.C4Code.GDstartObjects1);

gdjs.C4Code.condition0IsTrue_0.val = false;
{
gdjs.C4Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C4Code.mapOfGDgdjs_46C4Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.C4Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.C4Code.GDoffObjects1);

gdjs.C4Code.condition0IsTrue_0.val = false;
{
gdjs.C4Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C4Code.mapOfGDgdjs_46C4Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.C4Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.C4Code.GDonObjects1);

gdjs.C4Code.condition0IsTrue_0.val = false;
{
gdjs.C4Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C4Code.mapOfGDgdjs_46C4Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.C4Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.C4Code.condition0IsTrue_0.val = false;
{
gdjs.C4Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.C4Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s196", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.C4Code.GDstartObjects1);

gdjs.C4Code.condition0IsTrue_0.val = false;
{
gdjs.C4Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.C4Code.mapOfGDgdjs_46C4Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.C4Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s196", false);
}}

}


{


{
}

}


};

gdjs.C4Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.C4Code.GDcaseObjects1.length = 0;
gdjs.C4Code.GDcaseObjects2.length = 0;
gdjs.C4Code.GDimageObjects1.length = 0;
gdjs.C4Code.GDimageObjects2.length = 0;
gdjs.C4Code.GDoffObjects1.length = 0;
gdjs.C4Code.GDoffObjects2.length = 0;
gdjs.C4Code.GDonObjects1.length = 0;
gdjs.C4Code.GDonObjects2.length = 0;
gdjs.C4Code.GDstartObjects1.length = 0;
gdjs.C4Code.GDstartObjects2.length = 0;
gdjs.C4Code.GDBObjects1.length = 0;
gdjs.C4Code.GDBObjects2.length = 0;
gdjs.C4Code.GDblackObjects1.length = 0;
gdjs.C4Code.GDblackObjects2.length = 0;
gdjs.C4Code.GDAObjects1.length = 0;
gdjs.C4Code.GDAObjects2.length = 0;

gdjs.C4Code.eventsList0(runtimeScene);
return;

}

gdjs['C4Code'] = gdjs.C4Code;
