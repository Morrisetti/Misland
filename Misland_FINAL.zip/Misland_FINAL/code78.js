gdjs.s63Code = {};
gdjs.s63Code.GDcaseObjects1= [];
gdjs.s63Code.GDcaseObjects2= [];
gdjs.s63Code.GDimageObjects1= [];
gdjs.s63Code.GDimageObjects2= [];
gdjs.s63Code.GDoffObjects1= [];
gdjs.s63Code.GDoffObjects2= [];
gdjs.s63Code.GDonObjects1= [];
gdjs.s63Code.GDonObjects2= [];
gdjs.s63Code.GDstartObjects1= [];
gdjs.s63Code.GDstartObjects2= [];
gdjs.s63Code.GDBObjects1= [];
gdjs.s63Code.GDBObjects2= [];
gdjs.s63Code.GDblackObjects1= [];
gdjs.s63Code.GDblackObjects2= [];
gdjs.s63Code.GDAObjects1= [];
gdjs.s63Code.GDAObjects2= [];

gdjs.s63Code.conditionTrue_0 = {val:false};
gdjs.s63Code.condition0IsTrue_0 = {val:false};
gdjs.s63Code.condition1IsTrue_0 = {val:false};


gdjs.s63Code.mapOfGDgdjs_46s63Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s63Code.GDstartObjects1});gdjs.s63Code.mapOfGDgdjs_46s63Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s63Code.GDoffObjects1});gdjs.s63Code.mapOfGDgdjs_46s63Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s63Code.GDonObjects1});gdjs.s63Code.mapOfGDgdjs_46s63Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s63Code.GDBObjects1});gdjs.s63Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s63Code.GDstartObjects1);

gdjs.s63Code.condition0IsTrue_0.val = false;
{
gdjs.s63Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s63Code.mapOfGDgdjs_46s63Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s63Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s63Code.GDoffObjects1);

gdjs.s63Code.condition0IsTrue_0.val = false;
{
gdjs.s63Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s63Code.mapOfGDgdjs_46s63Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s63Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s63Code.GDonObjects1);

gdjs.s63Code.condition0IsTrue_0.val = false;
{
gdjs.s63Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s63Code.mapOfGDgdjs_46s63Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s63Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s63Code.condition0IsTrue_0.val = false;
{
gdjs.s63Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s63Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s64", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s63Code.GDBObjects1);

gdjs.s63Code.condition0IsTrue_0.val = false;
{
gdjs.s63Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s63Code.mapOfGDgdjs_46s63Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s63Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s64", false);
}}

}


{


{
}

}


};

gdjs.s63Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s63Code.GDcaseObjects1.length = 0;
gdjs.s63Code.GDcaseObjects2.length = 0;
gdjs.s63Code.GDimageObjects1.length = 0;
gdjs.s63Code.GDimageObjects2.length = 0;
gdjs.s63Code.GDoffObjects1.length = 0;
gdjs.s63Code.GDoffObjects2.length = 0;
gdjs.s63Code.GDonObjects1.length = 0;
gdjs.s63Code.GDonObjects2.length = 0;
gdjs.s63Code.GDstartObjects1.length = 0;
gdjs.s63Code.GDstartObjects2.length = 0;
gdjs.s63Code.GDBObjects1.length = 0;
gdjs.s63Code.GDBObjects2.length = 0;
gdjs.s63Code.GDblackObjects1.length = 0;
gdjs.s63Code.GDblackObjects2.length = 0;
gdjs.s63Code.GDAObjects1.length = 0;
gdjs.s63Code.GDAObjects2.length = 0;

gdjs.s63Code.eventsList0(runtimeScene);
return;

}

gdjs['s63Code'] = gdjs.s63Code;
