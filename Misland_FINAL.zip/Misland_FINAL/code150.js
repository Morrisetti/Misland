gdjs.s134Code = {};
gdjs.s134Code.GDcaseObjects1= [];
gdjs.s134Code.GDcaseObjects2= [];
gdjs.s134Code.GDimageObjects1= [];
gdjs.s134Code.GDimageObjects2= [];
gdjs.s134Code.GDoffObjects1= [];
gdjs.s134Code.GDoffObjects2= [];
gdjs.s134Code.GDonObjects1= [];
gdjs.s134Code.GDonObjects2= [];
gdjs.s134Code.GDstartObjects1= [];
gdjs.s134Code.GDstartObjects2= [];
gdjs.s134Code.GDBObjects1= [];
gdjs.s134Code.GDBObjects2= [];
gdjs.s134Code.GDblackObjects1= [];
gdjs.s134Code.GDblackObjects2= [];
gdjs.s134Code.GDAObjects1= [];
gdjs.s134Code.GDAObjects2= [];

gdjs.s134Code.conditionTrue_0 = {val:false};
gdjs.s134Code.condition0IsTrue_0 = {val:false};
gdjs.s134Code.condition1IsTrue_0 = {val:false};


gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s134Code.GDstartObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s134Code.GDoffObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s134Code.GDonObjects1});gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s134Code.GDBObjects1});gdjs.s134Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s134Code.GDstartObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s134Code.GDoffObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s134Code.GDonObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s134Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s135", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s134Code.GDBObjects1);

gdjs.s134Code.condition0IsTrue_0.val = false;
{
gdjs.s134Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s134Code.mapOfGDgdjs_46s134Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s134Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s135", false);
}}

}


{


{
}

}


};

gdjs.s134Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s134Code.GDcaseObjects1.length = 0;
gdjs.s134Code.GDcaseObjects2.length = 0;
gdjs.s134Code.GDimageObjects1.length = 0;
gdjs.s134Code.GDimageObjects2.length = 0;
gdjs.s134Code.GDoffObjects1.length = 0;
gdjs.s134Code.GDoffObjects2.length = 0;
gdjs.s134Code.GDonObjects1.length = 0;
gdjs.s134Code.GDonObjects2.length = 0;
gdjs.s134Code.GDstartObjects1.length = 0;
gdjs.s134Code.GDstartObjects2.length = 0;
gdjs.s134Code.GDBObjects1.length = 0;
gdjs.s134Code.GDBObjects2.length = 0;
gdjs.s134Code.GDblackObjects1.length = 0;
gdjs.s134Code.GDblackObjects2.length = 0;
gdjs.s134Code.GDAObjects1.length = 0;
gdjs.s134Code.GDAObjects2.length = 0;

gdjs.s134Code.eventsList0(runtimeScene);
return;

}

gdjs['s134Code'] = gdjs.s134Code;
