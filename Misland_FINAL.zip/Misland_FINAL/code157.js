gdjs.s141Code = {};
gdjs.s141Code.GDcaseObjects1= [];
gdjs.s141Code.GDcaseObjects2= [];
gdjs.s141Code.GDimageObjects1= [];
gdjs.s141Code.GDimageObjects2= [];
gdjs.s141Code.GDoffObjects1= [];
gdjs.s141Code.GDoffObjects2= [];
gdjs.s141Code.GDonObjects1= [];
gdjs.s141Code.GDonObjects2= [];
gdjs.s141Code.GDstartObjects1= [];
gdjs.s141Code.GDstartObjects2= [];
gdjs.s141Code.GDBObjects1= [];
gdjs.s141Code.GDBObjects2= [];
gdjs.s141Code.GDblackObjects1= [];
gdjs.s141Code.GDblackObjects2= [];
gdjs.s141Code.GDAObjects1= [];
gdjs.s141Code.GDAObjects2= [];
gdjs.s141Code.GDbuttonObjects1= [];
gdjs.s141Code.GDbuttonObjects2= [];

gdjs.s141Code.conditionTrue_0 = {val:false};
gdjs.s141Code.condition0IsTrue_0 = {val:false};
gdjs.s141Code.condition1IsTrue_0 = {val:false};


gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s141Code.GDbuttonObjects1});gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s141Code.GDoffObjects1});gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s141Code.GDonObjects1});gdjs.s141Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s141Code.GDcaseObjects1);

gdjs.s141Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s141Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s141Code.GDcaseObjects1[i].timerElapsedTime("", 1) ) {
        gdjs.s141Code.condition0IsTrue_0.val = true;
        gdjs.s141Code.GDcaseObjects1[k] = gdjs.s141Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s141Code.GDcaseObjects1.length = k;}if (gdjs.s141Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s132", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s141Code.GDbuttonObjects1);

gdjs.s141Code.condition0IsTrue_0.val = false;
{
gdjs.s141Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s141Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s142", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s141Code.GDoffObjects1);

gdjs.s141Code.condition0IsTrue_0.val = false;
{
gdjs.s141Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s141Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s141Code.GDonObjects1);

gdjs.s141Code.condition0IsTrue_0.val = false;
{
gdjs.s141Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s141Code.mapOfGDgdjs_46s141Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s141Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s141Code.condition0IsTrue_0.val = false;
{
gdjs.s141Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s141Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s142", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s141Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s141Code.GDcaseObjects1.length = 0;
gdjs.s141Code.GDcaseObjects2.length = 0;
gdjs.s141Code.GDimageObjects1.length = 0;
gdjs.s141Code.GDimageObjects2.length = 0;
gdjs.s141Code.GDoffObjects1.length = 0;
gdjs.s141Code.GDoffObjects2.length = 0;
gdjs.s141Code.GDonObjects1.length = 0;
gdjs.s141Code.GDonObjects2.length = 0;
gdjs.s141Code.GDstartObjects1.length = 0;
gdjs.s141Code.GDstartObjects2.length = 0;
gdjs.s141Code.GDBObjects1.length = 0;
gdjs.s141Code.GDBObjects2.length = 0;
gdjs.s141Code.GDblackObjects1.length = 0;
gdjs.s141Code.GDblackObjects2.length = 0;
gdjs.s141Code.GDAObjects1.length = 0;
gdjs.s141Code.GDAObjects2.length = 0;
gdjs.s141Code.GDbuttonObjects1.length = 0;
gdjs.s141Code.GDbuttonObjects2.length = 0;

gdjs.s141Code.eventsList0(runtimeScene);
return;

}

gdjs['s141Code'] = gdjs.s141Code;
