gdjs.s188Code = {};
gdjs.s188Code.GDcaseObjects1= [];
gdjs.s188Code.GDcaseObjects2= [];
gdjs.s188Code.GDimageObjects1= [];
gdjs.s188Code.GDimageObjects2= [];
gdjs.s188Code.GDoffObjects1= [];
gdjs.s188Code.GDoffObjects2= [];
gdjs.s188Code.GDonObjects1= [];
gdjs.s188Code.GDonObjects2= [];
gdjs.s188Code.GDstartObjects1= [];
gdjs.s188Code.GDstartObjects2= [];
gdjs.s188Code.GDBObjects1= [];
gdjs.s188Code.GDBObjects2= [];
gdjs.s188Code.GDblackObjects1= [];
gdjs.s188Code.GDblackObjects2= [];
gdjs.s188Code.GDAObjects1= [];
gdjs.s188Code.GDAObjects2= [];
gdjs.s188Code.GDbuttonObjects1= [];
gdjs.s188Code.GDbuttonObjects2= [];

gdjs.s188Code.conditionTrue_0 = {val:false};
gdjs.s188Code.condition0IsTrue_0 = {val:false};
gdjs.s188Code.condition1IsTrue_0 = {val:false};
gdjs.s188Code.conditionTrue_1 = {val:false};
gdjs.s188Code.condition0IsTrue_1 = {val:false};
gdjs.s188Code.condition1IsTrue_1 = {val:false};


gdjs.s188Code.mapOfGDgdjs_46s188Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s188Code.GDbuttonObjects1});gdjs.s188Code.mapOfGDgdjs_46s188Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s188Code.GDoffObjects1});gdjs.s188Code.mapOfGDgdjs_46s188Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s188Code.GDonObjects1});gdjs.s188Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s188Code.condition0IsTrue_0.val = false;
{
{gdjs.s188Code.conditionTrue_1 = gdjs.s188Code.condition0IsTrue_0;
gdjs.s188Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(73033204);
}
}if (gdjs.s188Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\oldlib_v2.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s188Code.GDbuttonObjects1);

gdjs.s188Code.condition0IsTrue_0.val = false;
{
gdjs.s188Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s188Code.mapOfGDgdjs_46s188Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s188Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s189", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s188Code.GDoffObjects1);

gdjs.s188Code.condition0IsTrue_0.val = false;
{
gdjs.s188Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s188Code.mapOfGDgdjs_46s188Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s188Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s188Code.GDonObjects1);

gdjs.s188Code.condition0IsTrue_0.val = false;
{
gdjs.s188Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s188Code.mapOfGDgdjs_46s188Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s188Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s188Code.condition0IsTrue_0.val = false;
{
gdjs.s188Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.s188Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s189", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s188Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s188Code.GDcaseObjects1.length = 0;
gdjs.s188Code.GDcaseObjects2.length = 0;
gdjs.s188Code.GDimageObjects1.length = 0;
gdjs.s188Code.GDimageObjects2.length = 0;
gdjs.s188Code.GDoffObjects1.length = 0;
gdjs.s188Code.GDoffObjects2.length = 0;
gdjs.s188Code.GDonObjects1.length = 0;
gdjs.s188Code.GDonObjects2.length = 0;
gdjs.s188Code.GDstartObjects1.length = 0;
gdjs.s188Code.GDstartObjects2.length = 0;
gdjs.s188Code.GDBObjects1.length = 0;
gdjs.s188Code.GDBObjects2.length = 0;
gdjs.s188Code.GDblackObjects1.length = 0;
gdjs.s188Code.GDblackObjects2.length = 0;
gdjs.s188Code.GDAObjects1.length = 0;
gdjs.s188Code.GDAObjects2.length = 0;
gdjs.s188Code.GDbuttonObjects1.length = 0;
gdjs.s188Code.GDbuttonObjects2.length = 0;

gdjs.s188Code.eventsList0(runtimeScene);
return;

}

gdjs['s188Code'] = gdjs.s188Code;
