gdjs.s239Code = {};
gdjs.s239Code.GDcaseObjects1= [];
gdjs.s239Code.GDcaseObjects2= [];
gdjs.s239Code.GDoffObjects1= [];
gdjs.s239Code.GDoffObjects2= [];
gdjs.s239Code.GDonObjects1= [];
gdjs.s239Code.GDonObjects2= [];
gdjs.s239Code.GDstartObjects1= [];
gdjs.s239Code.GDstartObjects2= [];
gdjs.s239Code.GDBObjects1= [];
gdjs.s239Code.GDBObjects2= [];
gdjs.s239Code.GDAObjects1= [];
gdjs.s239Code.GDAObjects2= [];
gdjs.s239Code.GDcarObjects1= [];
gdjs.s239Code.GDcarObjects2= [];
gdjs.s239Code.GDDOWNbuttonObjects1= [];
gdjs.s239Code.GDDOWNbuttonObjects2= [];
gdjs.s239Code.GDblackObjects1= [];
gdjs.s239Code.GDblackObjects2= [];
gdjs.s239Code.GDDOWNcol2Objects1= [];
gdjs.s239Code.GDDOWNcol2Objects2= [];
gdjs.s239Code.GDDOWNcolObjects1= [];
gdjs.s239Code.GDDOWNcolObjects2= [];
gdjs.s239Code.GDUPbuttonObjects1= [];
gdjs.s239Code.GDUPbuttonObjects2= [];
gdjs.s239Code.GDUPcolObjects1= [];
gdjs.s239Code.GDUPcolObjects2= [];
gdjs.s239Code.GDLbuttonObjects1= [];
gdjs.s239Code.GDLbuttonObjects2= [];
gdjs.s239Code.GDLcolObjects1= [];
gdjs.s239Code.GDLcolObjects2= [];
gdjs.s239Code.GDRbuttonObjects1= [];
gdjs.s239Code.GDRbuttonObjects2= [];
gdjs.s239Code.GDTALK3Objects1= [];
gdjs.s239Code.GDTALK3Objects2= [];
gdjs.s239Code.GDTALK2Objects1= [];
gdjs.s239Code.GDTALK2Objects2= [];
gdjs.s239Code.GDExitObjects1= [];
gdjs.s239Code.GDExitObjects2= [];
gdjs.s239Code.GDRcolObjects1= [];
gdjs.s239Code.GDRcolObjects2= [];
gdjs.s239Code.GDchapter4Objects1= [];
gdjs.s239Code.GDchapter4Objects2= [];
gdjs.s239Code.GDchapter3Objects1= [];
gdjs.s239Code.GDchapter3Objects2= [];
gdjs.s239Code.GDchapter2Objects1= [];
gdjs.s239Code.GDchapter2Objects2= [];
gdjs.s239Code.GDchapter1Objects1= [];
gdjs.s239Code.GDchapter1Objects2= [];
gdjs.s239Code.GDNewObjectObjects1= [];
gdjs.s239Code.GDNewObjectObjects2= [];
gdjs.s239Code.GDob7Objects1= [];
gdjs.s239Code.GDob7Objects2= [];
gdjs.s239Code.GDob6Objects1= [];
gdjs.s239Code.GDob6Objects2= [];
gdjs.s239Code.GDob5Objects1= [];
gdjs.s239Code.GDob5Objects2= [];
gdjs.s239Code.GDob4Objects1= [];
gdjs.s239Code.GDob4Objects2= [];
gdjs.s239Code.GDob3Objects1= [];
gdjs.s239Code.GDob3Objects2= [];
gdjs.s239Code.GDob2Objects1= [];
gdjs.s239Code.GDob2Objects2= [];
gdjs.s239Code.GDob1Objects1= [];
gdjs.s239Code.GDob1Objects2= [];
gdjs.s239Code.GDtargetObjects1= [];
gdjs.s239Code.GDtargetObjects2= [];

gdjs.s239Code.conditionTrue_0 = {val:false};
gdjs.s239Code.condition0IsTrue_0 = {val:false};
gdjs.s239Code.condition1IsTrue_0 = {val:false};
gdjs.s239Code.condition2IsTrue_0 = {val:false};
gdjs.s239Code.conditionTrue_1 = {val:false};
gdjs.s239Code.condition0IsTrue_1 = {val:false};
gdjs.s239Code.condition1IsTrue_1 = {val:false};
gdjs.s239Code.condition2IsTrue_1 = {val:false};


gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s239Code.GDDOWNbuttonObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s239Code.GDUPbuttonObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s239Code.GDRbuttonObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s239Code.GDLbuttonObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s239Code.GDRcolObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s239Code.GDLcolObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s239Code.GDUPcolObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s239Code.GDDOWNcolObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s239Code.GDDOWNcolObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s239Code.GDBObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s239Code.GDAObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s239Code.GDoffObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s239Code.GDonObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob1Objects1Objects = Hashtable.newFrom({"ob1": gdjs.s239Code.GDob1Objects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob2Objects1Objects = Hashtable.newFrom({"ob2": gdjs.s239Code.GDob2Objects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob3Objects1Objects = Hashtable.newFrom({"ob3": gdjs.s239Code.GDob3Objects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob4Objects1Objects = Hashtable.newFrom({"ob4": gdjs.s239Code.GDob4Objects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob5Objects1Objects = Hashtable.newFrom({"ob5": gdjs.s239Code.GDob5Objects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob6Objects1Objects = Hashtable.newFrom({"ob6": gdjs.s239Code.GDob6Objects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects = Hashtable.newFrom({"car": gdjs.s239Code.GDcarObjects1});gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob7Objects1Objects = Hashtable.newFrom({"ob7": gdjs.s239Code.GDob7Objects1});gdjs.s239Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s239Code.GDDOWNbuttonObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
gdjs.s239Code.condition1IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s239Code.condition0IsTrue_0.val ) {
{
gdjs.s239Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s239Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s239Code.GDUPbuttonObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
gdjs.s239Code.condition1IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s239Code.condition0IsTrue_0.val ) {
{
gdjs.s239Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s239Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s239Code.GDRbuttonObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
gdjs.s239Code.condition1IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s239Code.condition0IsTrue_0.val ) {
{
gdjs.s239Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s239Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s239Code.GDLbuttonObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
gdjs.s239Code.condition1IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s239Code.condition0IsTrue_0.val ) {
{
gdjs.s239Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s239Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s239Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s239Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s239Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s239Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s239Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s239Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s239Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s239Code.GDcarObjects1 */
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s239Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s239Code.GDBObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s239Code.GDAObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s239Code.GDoffObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s239Code.GDonObjects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s239Code.condition0IsTrue_0.val = false;
{
{gdjs.s239Code.conditionTrue_1 = gdjs.s239Code.condition0IsTrue_0;
gdjs.s239Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(74224572);
}
}if (gdjs.s239Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter8_v1.mp3", true, 100, 1);
}}

}


{


gdjs.s239Code.condition0IsTrue_0.val = false;
gdjs.s239Code.condition1IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s239Code.condition0IsTrue_0.val ) {
{
gdjs.s239Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s239Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s239Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s239Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].flipX(false);
}
}}

}


{


gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s239Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s239Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
{for(var i = 0, len = gdjs.s239Code.GDcarObjects1.length ;i < len;++i) {
    gdjs.s239Code.GDcarObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob1"), gdjs.s239Code.GDob1Objects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob1Objects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s238", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob2"), gdjs.s239Code.GDob2Objects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s239", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob3"), gdjs.s239Code.GDob3Objects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob3Objects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s238", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob4"), gdjs.s239Code.GDob4Objects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob4Objects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s238", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob5"), gdjs.s239Code.GDob5Objects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob5Objects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s238", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob6"), gdjs.s239Code.GDob6Objects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob6Objects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s238", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("car"), gdjs.s239Code.GDcarObjects1);
gdjs.copyArray(runtimeScene.getObjects("ob7"), gdjs.s239Code.GDob7Objects1);

gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDcarObjects1Objects, gdjs.s239Code.mapOfGDgdjs_46s239Code_46GDob7Objects1Objects, false, runtimeScene, false);
}if (gdjs.s239Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s238", false);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob1"), gdjs.s239Code.GDob1Objects1);
{for(var i = 0, len = gdjs.s239Code.GDob1Objects1.length ;i < len;++i) {
    gdjs.s239Code.GDob1Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob2"), gdjs.s239Code.GDob2Objects1);
{for(var i = 0, len = gdjs.s239Code.GDob2Objects1.length ;i < len;++i) {
    gdjs.s239Code.GDob2Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob3"), gdjs.s239Code.GDob3Objects1);
{for(var i = 0, len = gdjs.s239Code.GDob3Objects1.length ;i < len;++i) {
    gdjs.s239Code.GDob3Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob4"), gdjs.s239Code.GDob4Objects1);
{for(var i = 0, len = gdjs.s239Code.GDob4Objects1.length ;i < len;++i) {
    gdjs.s239Code.GDob4Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob5"), gdjs.s239Code.GDob5Objects1);
{for(var i = 0, len = gdjs.s239Code.GDob5Objects1.length ;i < len;++i) {
    gdjs.s239Code.GDob5Objects1[i].addForceTowardPosition(400, 1000, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob6"), gdjs.s239Code.GDob6Objects1);
{for(var i = 0, len = gdjs.s239Code.GDob6Objects1.length ;i < len;++i) {
    gdjs.s239Code.GDob6Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ob7"), gdjs.s239Code.GDob7Objects1);
{for(var i = 0, len = gdjs.s239Code.GDob7Objects1.length ;i < len;++i) {
    gdjs.s239Code.GDob7Objects1[i].addForceTowardPosition(400, 1100, 170, 0);
}
}}

}


{


gdjs.s239Code.condition0IsTrue_0.val = false;
{
gdjs.s239Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 45, "");
}if (gdjs.s239Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s240", false);
}}

}


};

gdjs.s239Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s239Code.GDcaseObjects1.length = 0;
gdjs.s239Code.GDcaseObjects2.length = 0;
gdjs.s239Code.GDoffObjects1.length = 0;
gdjs.s239Code.GDoffObjects2.length = 0;
gdjs.s239Code.GDonObjects1.length = 0;
gdjs.s239Code.GDonObjects2.length = 0;
gdjs.s239Code.GDstartObjects1.length = 0;
gdjs.s239Code.GDstartObjects2.length = 0;
gdjs.s239Code.GDBObjects1.length = 0;
gdjs.s239Code.GDBObjects2.length = 0;
gdjs.s239Code.GDAObjects1.length = 0;
gdjs.s239Code.GDAObjects2.length = 0;
gdjs.s239Code.GDcarObjects1.length = 0;
gdjs.s239Code.GDcarObjects2.length = 0;
gdjs.s239Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s239Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s239Code.GDblackObjects1.length = 0;
gdjs.s239Code.GDblackObjects2.length = 0;
gdjs.s239Code.GDDOWNcol2Objects1.length = 0;
gdjs.s239Code.GDDOWNcol2Objects2.length = 0;
gdjs.s239Code.GDDOWNcolObjects1.length = 0;
gdjs.s239Code.GDDOWNcolObjects2.length = 0;
gdjs.s239Code.GDUPbuttonObjects1.length = 0;
gdjs.s239Code.GDUPbuttonObjects2.length = 0;
gdjs.s239Code.GDUPcolObjects1.length = 0;
gdjs.s239Code.GDUPcolObjects2.length = 0;
gdjs.s239Code.GDLbuttonObjects1.length = 0;
gdjs.s239Code.GDLbuttonObjects2.length = 0;
gdjs.s239Code.GDLcolObjects1.length = 0;
gdjs.s239Code.GDLcolObjects2.length = 0;
gdjs.s239Code.GDRbuttonObjects1.length = 0;
gdjs.s239Code.GDRbuttonObjects2.length = 0;
gdjs.s239Code.GDTALK3Objects1.length = 0;
gdjs.s239Code.GDTALK3Objects2.length = 0;
gdjs.s239Code.GDTALK2Objects1.length = 0;
gdjs.s239Code.GDTALK2Objects2.length = 0;
gdjs.s239Code.GDExitObjects1.length = 0;
gdjs.s239Code.GDExitObjects2.length = 0;
gdjs.s239Code.GDRcolObjects1.length = 0;
gdjs.s239Code.GDRcolObjects2.length = 0;
gdjs.s239Code.GDchapter4Objects1.length = 0;
gdjs.s239Code.GDchapter4Objects2.length = 0;
gdjs.s239Code.GDchapter3Objects1.length = 0;
gdjs.s239Code.GDchapter3Objects2.length = 0;
gdjs.s239Code.GDchapter2Objects1.length = 0;
gdjs.s239Code.GDchapter2Objects2.length = 0;
gdjs.s239Code.GDchapter1Objects1.length = 0;
gdjs.s239Code.GDchapter1Objects2.length = 0;
gdjs.s239Code.GDNewObjectObjects1.length = 0;
gdjs.s239Code.GDNewObjectObjects2.length = 0;
gdjs.s239Code.GDob7Objects1.length = 0;
gdjs.s239Code.GDob7Objects2.length = 0;
gdjs.s239Code.GDob6Objects1.length = 0;
gdjs.s239Code.GDob6Objects2.length = 0;
gdjs.s239Code.GDob5Objects1.length = 0;
gdjs.s239Code.GDob5Objects2.length = 0;
gdjs.s239Code.GDob4Objects1.length = 0;
gdjs.s239Code.GDob4Objects2.length = 0;
gdjs.s239Code.GDob3Objects1.length = 0;
gdjs.s239Code.GDob3Objects2.length = 0;
gdjs.s239Code.GDob2Objects1.length = 0;
gdjs.s239Code.GDob2Objects2.length = 0;
gdjs.s239Code.GDob1Objects1.length = 0;
gdjs.s239Code.GDob1Objects2.length = 0;
gdjs.s239Code.GDtargetObjects1.length = 0;
gdjs.s239Code.GDtargetObjects2.length = 0;

gdjs.s239Code.eventsList0(runtimeScene);
return;

}

gdjs['s239Code'] = gdjs.s239Code;
