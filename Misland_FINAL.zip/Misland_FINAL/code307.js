gdjs.s268Code = {};
gdjs.s268Code.GDcaseObjects1= [];
gdjs.s268Code.GDcaseObjects2= [];
gdjs.s268Code.GDimageObjects1= [];
gdjs.s268Code.GDimageObjects2= [];
gdjs.s268Code.GDoffObjects1= [];
gdjs.s268Code.GDoffObjects2= [];
gdjs.s268Code.GDonObjects1= [];
gdjs.s268Code.GDonObjects2= [];
gdjs.s268Code.GDstartObjects1= [];
gdjs.s268Code.GDstartObjects2= [];
gdjs.s268Code.GDBObjects1= [];
gdjs.s268Code.GDBObjects2= [];
gdjs.s268Code.GDblackObjects1= [];
gdjs.s268Code.GDblackObjects2= [];
gdjs.s268Code.GDAObjects1= [];
gdjs.s268Code.GDAObjects2= [];

gdjs.s268Code.conditionTrue_0 = {val:false};
gdjs.s268Code.condition0IsTrue_0 = {val:false};
gdjs.s268Code.condition1IsTrue_0 = {val:false};


gdjs.s268Code.mapOfGDgdjs_46s268Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s268Code.GDstartObjects1});gdjs.s268Code.mapOfGDgdjs_46s268Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s268Code.GDoffObjects1});gdjs.s268Code.mapOfGDgdjs_46s268Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s268Code.GDonObjects1});gdjs.s268Code.mapOfGDgdjs_46s268Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s268Code.GDBObjects1});gdjs.s268Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s268Code.GDstartObjects1);

gdjs.s268Code.condition0IsTrue_0.val = false;
{
gdjs.s268Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s268Code.mapOfGDgdjs_46s268Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s268Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s268Code.GDoffObjects1);

gdjs.s268Code.condition0IsTrue_0.val = false;
{
gdjs.s268Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s268Code.mapOfGDgdjs_46s268Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s268Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s268Code.GDonObjects1);

gdjs.s268Code.condition0IsTrue_0.val = false;
{
gdjs.s268Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s268Code.mapOfGDgdjs_46s268Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s268Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s268Code.condition0IsTrue_0.val = false;
{
gdjs.s268Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s268Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s269", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s268Code.GDBObjects1);

gdjs.s268Code.condition0IsTrue_0.val = false;
{
gdjs.s268Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s268Code.mapOfGDgdjs_46s268Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s268Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s269", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s268Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s268Code.GDcaseObjects1.length = 0;
gdjs.s268Code.GDcaseObjects2.length = 0;
gdjs.s268Code.GDimageObjects1.length = 0;
gdjs.s268Code.GDimageObjects2.length = 0;
gdjs.s268Code.GDoffObjects1.length = 0;
gdjs.s268Code.GDoffObjects2.length = 0;
gdjs.s268Code.GDonObjects1.length = 0;
gdjs.s268Code.GDonObjects2.length = 0;
gdjs.s268Code.GDstartObjects1.length = 0;
gdjs.s268Code.GDstartObjects2.length = 0;
gdjs.s268Code.GDBObjects1.length = 0;
gdjs.s268Code.GDBObjects2.length = 0;
gdjs.s268Code.GDblackObjects1.length = 0;
gdjs.s268Code.GDblackObjects2.length = 0;
gdjs.s268Code.GDAObjects1.length = 0;
gdjs.s268Code.GDAObjects2.length = 0;

gdjs.s268Code.eventsList0(runtimeScene);
return;

}

gdjs['s268Code'] = gdjs.s268Code;
