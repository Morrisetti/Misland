gdjs.s153CHCode = {};
gdjs.s153CHCode.GDcaseObjects1= [];
gdjs.s153CHCode.GDcaseObjects2= [];
gdjs.s153CHCode.GDimageObjects1= [];
gdjs.s153CHCode.GDimageObjects2= [];
gdjs.s153CHCode.GDoffObjects1= [];
gdjs.s153CHCode.GDoffObjects2= [];
gdjs.s153CHCode.GDonObjects1= [];
gdjs.s153CHCode.GDonObjects2= [];
gdjs.s153CHCode.GDstartObjects1= [];
gdjs.s153CHCode.GDstartObjects2= [];
gdjs.s153CHCode.GDBObjects1= [];
gdjs.s153CHCode.GDBObjects2= [];
gdjs.s153CHCode.GDAObjects1= [];
gdjs.s153CHCode.GDAObjects2= [];
gdjs.s153CHCode.GDcrosshairsObjects1= [];
gdjs.s153CHCode.GDcrosshairsObjects2= [];
gdjs.s153CHCode.GDDOWNbuttonObjects1= [];
gdjs.s153CHCode.GDDOWNbuttonObjects2= [];
gdjs.s153CHCode.GDDOWNcolObjects1= [];
gdjs.s153CHCode.GDDOWNcolObjects2= [];
gdjs.s153CHCode.GDUPbuttonObjects1= [];
gdjs.s153CHCode.GDUPbuttonObjects2= [];
gdjs.s153CHCode.GDUPcolObjects1= [];
gdjs.s153CHCode.GDUPcolObjects2= [];
gdjs.s153CHCode.GDLbuttonObjects1= [];
gdjs.s153CHCode.GDLbuttonObjects2= [];
gdjs.s153CHCode.GDLcolObjects1= [];
gdjs.s153CHCode.GDLcolObjects2= [];
gdjs.s153CHCode.GDRbuttonObjects1= [];
gdjs.s153CHCode.GDRbuttonObjects2= [];
gdjs.s153CHCode.GDRcolObjects1= [];
gdjs.s153CHCode.GDRcolObjects2= [];
gdjs.s153CHCode.GDchapter4Objects1= [];
gdjs.s153CHCode.GDchapter4Objects2= [];
gdjs.s153CHCode.GDchapter3Objects1= [];
gdjs.s153CHCode.GDchapter3Objects2= [];
gdjs.s153CHCode.GDchapter2Objects1= [];
gdjs.s153CHCode.GDchapter2Objects2= [];
gdjs.s153CHCode.GDblackObjects1= [];
gdjs.s153CHCode.GDblackObjects2= [];
gdjs.s153CHCode.GDchapter1Objects1= [];
gdjs.s153CHCode.GDchapter1Objects2= [];

gdjs.s153CHCode.conditionTrue_0 = {val:false};
gdjs.s153CHCode.condition0IsTrue_0 = {val:false};
gdjs.s153CHCode.condition1IsTrue_0 = {val:false};
gdjs.s153CHCode.condition2IsTrue_0 = {val:false};


gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s153CHCode.GDDOWNbuttonObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s153CHCode.GDUPbuttonObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s153CHCode.GDRbuttonObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s153CHCode.GDLbuttonObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s153CHCode.GDcrosshairsObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s153CHCode.GDRcolObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s153CHCode.GDcrosshairsObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s153CHCode.GDLcolObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s153CHCode.GDcrosshairsObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s153CHCode.GDUPcolObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s153CHCode.GDcrosshairsObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s153CHCode.GDDOWNcolObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s153CHCode.GDcrosshairsObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s153CHCode.GDDOWNcolObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s153CHCode.GDoffObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s153CHCode.GDonObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s153CHCode.GDcrosshairsObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s153CHCode.GDchapter1Objects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s153CHCode.GDAObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects = Hashtable.newFrom({"crosshairs": gdjs.s153CHCode.GDcrosshairsObjects1});gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDchapter1Objects1Objects = Hashtable.newFrom({"chapter1": gdjs.s153CHCode.GDchapter1Objects1});gdjs.s153CHCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s153CHCode.GDDOWNbuttonObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
gdjs.s153CHCode.condition1IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s153CHCode.condition0IsTrue_0.val ) {
{
gdjs.s153CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s153CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s153CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s153CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s153CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s153CHCode.GDUPbuttonObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
gdjs.s153CHCode.condition1IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s153CHCode.condition0IsTrue_0.val ) {
{
gdjs.s153CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s153CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s153CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s153CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s153CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s153CHCode.GDRbuttonObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
gdjs.s153CHCode.condition1IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s153CHCode.condition0IsTrue_0.val ) {
{
gdjs.s153CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s153CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s153CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s153CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s153CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s153CHCode.GDLbuttonObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
gdjs.s153CHCode.condition1IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s153CHCode.condition0IsTrue_0.val ) {
{
gdjs.s153CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s153CHCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s153CHCode.GDcrosshairsObjects1);
{for(var i = 0, len = gdjs.s153CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s153CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s153CHCode.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s153CHCode.GDcrosshairsObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects, gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s153CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s153CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s153CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s153CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s153CHCode.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s153CHCode.GDcrosshairsObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects, gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s153CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s153CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s153CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s153CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s153CHCode.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s153CHCode.GDcrosshairsObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects, gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s153CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s153CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s153CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s153CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s153CHCode.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s153CHCode.GDcrosshairsObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects, gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s153CHCode.condition0IsTrue_0.val) {
/* Reuse gdjs.s153CHCode.GDcrosshairsObjects1 */
{for(var i = 0, len = gdjs.s153CHCode.GDcrosshairsObjects1.length ;i < len;++i) {
    gdjs.s153CHCode.GDcrosshairsObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s153CHCode.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s153CHCode.GDcrosshairsObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects, gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s153CHCode.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s153CHCode.GDoffObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s153CHCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s153CHCode.GDonObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s153CHCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s153CHCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s153CHCode.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s153CHCode.GDcrosshairsObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
gdjs.s153CHCode.condition1IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects, gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s153CHCode.condition0IsTrue_0.val ) {
{
gdjs.s153CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDAObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.s153CHCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s154", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("chapter1"), gdjs.s153CHCode.GDchapter1Objects1);
gdjs.copyArray(runtimeScene.getObjects("crosshairs"), gdjs.s153CHCode.GDcrosshairsObjects1);

gdjs.s153CHCode.condition0IsTrue_0.val = false;
gdjs.s153CHCode.condition1IsTrue_0.val = false;
{
gdjs.s153CHCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDcrosshairsObjects1Objects, gdjs.s153CHCode.mapOfGDgdjs_46s153CHCode_46GDchapter1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.s153CHCode.condition0IsTrue_0.val ) {
{
gdjs.s153CHCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}}
if (gdjs.s153CHCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s154", false);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s153CHCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s153CHCode.GDcaseObjects1.length = 0;
gdjs.s153CHCode.GDcaseObjects2.length = 0;
gdjs.s153CHCode.GDimageObjects1.length = 0;
gdjs.s153CHCode.GDimageObjects2.length = 0;
gdjs.s153CHCode.GDoffObjects1.length = 0;
gdjs.s153CHCode.GDoffObjects2.length = 0;
gdjs.s153CHCode.GDonObjects1.length = 0;
gdjs.s153CHCode.GDonObjects2.length = 0;
gdjs.s153CHCode.GDstartObjects1.length = 0;
gdjs.s153CHCode.GDstartObjects2.length = 0;
gdjs.s153CHCode.GDBObjects1.length = 0;
gdjs.s153CHCode.GDBObjects2.length = 0;
gdjs.s153CHCode.GDAObjects1.length = 0;
gdjs.s153CHCode.GDAObjects2.length = 0;
gdjs.s153CHCode.GDcrosshairsObjects1.length = 0;
gdjs.s153CHCode.GDcrosshairsObjects2.length = 0;
gdjs.s153CHCode.GDDOWNbuttonObjects1.length = 0;
gdjs.s153CHCode.GDDOWNbuttonObjects2.length = 0;
gdjs.s153CHCode.GDDOWNcolObjects1.length = 0;
gdjs.s153CHCode.GDDOWNcolObjects2.length = 0;
gdjs.s153CHCode.GDUPbuttonObjects1.length = 0;
gdjs.s153CHCode.GDUPbuttonObjects2.length = 0;
gdjs.s153CHCode.GDUPcolObjects1.length = 0;
gdjs.s153CHCode.GDUPcolObjects2.length = 0;
gdjs.s153CHCode.GDLbuttonObjects1.length = 0;
gdjs.s153CHCode.GDLbuttonObjects2.length = 0;
gdjs.s153CHCode.GDLcolObjects1.length = 0;
gdjs.s153CHCode.GDLcolObjects2.length = 0;
gdjs.s153CHCode.GDRbuttonObjects1.length = 0;
gdjs.s153CHCode.GDRbuttonObjects2.length = 0;
gdjs.s153CHCode.GDRcolObjects1.length = 0;
gdjs.s153CHCode.GDRcolObjects2.length = 0;
gdjs.s153CHCode.GDchapter4Objects1.length = 0;
gdjs.s153CHCode.GDchapter4Objects2.length = 0;
gdjs.s153CHCode.GDchapter3Objects1.length = 0;
gdjs.s153CHCode.GDchapter3Objects2.length = 0;
gdjs.s153CHCode.GDchapter2Objects1.length = 0;
gdjs.s153CHCode.GDchapter2Objects2.length = 0;
gdjs.s153CHCode.GDblackObjects1.length = 0;
gdjs.s153CHCode.GDblackObjects2.length = 0;
gdjs.s153CHCode.GDchapter1Objects1.length = 0;
gdjs.s153CHCode.GDchapter1Objects2.length = 0;

gdjs.s153CHCode.eventsList0(runtimeScene);
return;

}

gdjs['s153CHCode'] = gdjs.s153CHCode;
