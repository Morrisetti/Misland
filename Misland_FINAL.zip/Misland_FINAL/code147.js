gdjs.s131Code = {};
gdjs.s131Code.GDcaseObjects1= [];
gdjs.s131Code.GDcaseObjects2= [];
gdjs.s131Code.GDimageObjects1= [];
gdjs.s131Code.GDimageObjects2= [];
gdjs.s131Code.GDoffObjects1= [];
gdjs.s131Code.GDoffObjects2= [];
gdjs.s131Code.GDonObjects1= [];
gdjs.s131Code.GDonObjects2= [];
gdjs.s131Code.GDstartObjects1= [];
gdjs.s131Code.GDstartObjects2= [];
gdjs.s131Code.GDBObjects1= [];
gdjs.s131Code.GDBObjects2= [];
gdjs.s131Code.GDblackObjects1= [];
gdjs.s131Code.GDblackObjects2= [];
gdjs.s131Code.GDAObjects1= [];
gdjs.s131Code.GDAObjects2= [];

gdjs.s131Code.conditionTrue_0 = {val:false};
gdjs.s131Code.condition0IsTrue_0 = {val:false};
gdjs.s131Code.condition1IsTrue_0 = {val:false};
gdjs.s131Code.conditionTrue_1 = {val:false};
gdjs.s131Code.condition0IsTrue_1 = {val:false};
gdjs.s131Code.condition1IsTrue_1 = {val:false};


gdjs.s131Code.mapOfGDgdjs_46s131Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s131Code.GDstartObjects1});gdjs.s131Code.mapOfGDgdjs_46s131Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s131Code.GDoffObjects1});gdjs.s131Code.mapOfGDgdjs_46s131Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s131Code.GDonObjects1});gdjs.s131Code.mapOfGDgdjs_46s131Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s131Code.GDBObjects1});gdjs.s131Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s131Code.condition0IsTrue_0.val = false;
{
{gdjs.s131Code.conditionTrue_1 = gdjs.s131Code.condition0IsTrue_0;
gdjs.s131Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(71823188);
}
}if (gdjs.s131Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\oldlib_v1.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s131Code.GDstartObjects1);

gdjs.s131Code.condition0IsTrue_0.val = false;
{
gdjs.s131Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s131Code.mapOfGDgdjs_46s131Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s131Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s131Code.GDoffObjects1);

gdjs.s131Code.condition0IsTrue_0.val = false;
{
gdjs.s131Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s131Code.mapOfGDgdjs_46s131Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s131Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s131Code.GDonObjects1);

gdjs.s131Code.condition0IsTrue_0.val = false;
{
gdjs.s131Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s131Code.mapOfGDgdjs_46s131Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s131Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s131Code.condition0IsTrue_0.val = false;
{
gdjs.s131Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s131Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s133CH", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s131Code.GDBObjects1);

gdjs.s131Code.condition0IsTrue_0.val = false;
{
gdjs.s131Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s131Code.mapOfGDgdjs_46s131Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s131Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s133CH", false);
}}

}


{


{
}

}


};

gdjs.s131Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s131Code.GDcaseObjects1.length = 0;
gdjs.s131Code.GDcaseObjects2.length = 0;
gdjs.s131Code.GDimageObjects1.length = 0;
gdjs.s131Code.GDimageObjects2.length = 0;
gdjs.s131Code.GDoffObjects1.length = 0;
gdjs.s131Code.GDoffObjects2.length = 0;
gdjs.s131Code.GDonObjects1.length = 0;
gdjs.s131Code.GDonObjects2.length = 0;
gdjs.s131Code.GDstartObjects1.length = 0;
gdjs.s131Code.GDstartObjects2.length = 0;
gdjs.s131Code.GDBObjects1.length = 0;
gdjs.s131Code.GDBObjects2.length = 0;
gdjs.s131Code.GDblackObjects1.length = 0;
gdjs.s131Code.GDblackObjects2.length = 0;
gdjs.s131Code.GDAObjects1.length = 0;
gdjs.s131Code.GDAObjects2.length = 0;

gdjs.s131Code.eventsList0(runtimeScene);
return;

}

gdjs['s131Code'] = gdjs.s131Code;
