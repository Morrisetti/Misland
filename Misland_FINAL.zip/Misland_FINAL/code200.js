gdjs.s183Code = {};
gdjs.s183Code.GDcaseObjects1= [];
gdjs.s183Code.GDcaseObjects2= [];
gdjs.s183Code.GDimageObjects1= [];
gdjs.s183Code.GDimageObjects2= [];
gdjs.s183Code.GDoffObjects1= [];
gdjs.s183Code.GDoffObjects2= [];
gdjs.s183Code.GDonObjects1= [];
gdjs.s183Code.GDonObjects2= [];
gdjs.s183Code.GDstartObjects1= [];
gdjs.s183Code.GDstartObjects2= [];
gdjs.s183Code.GDBObjects1= [];
gdjs.s183Code.GDBObjects2= [];
gdjs.s183Code.GDblackObjects1= [];
gdjs.s183Code.GDblackObjects2= [];
gdjs.s183Code.GDAObjects1= [];
gdjs.s183Code.GDAObjects2= [];
gdjs.s183Code.GDbuttonObjects1= [];
gdjs.s183Code.GDbuttonObjects2= [];

gdjs.s183Code.conditionTrue_0 = {val:false};
gdjs.s183Code.condition0IsTrue_0 = {val:false};
gdjs.s183Code.condition1IsTrue_0 = {val:false};


gdjs.s183Code.mapOfGDgdjs_46s183Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s183Code.GDbuttonObjects1});gdjs.s183Code.mapOfGDgdjs_46s183Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s183Code.GDoffObjects1});gdjs.s183Code.mapOfGDgdjs_46s183Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s183Code.GDonObjects1});gdjs.s183Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s183Code.GDcaseObjects1);

gdjs.s183Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s183Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s183Code.GDcaseObjects1[i].timerElapsedTime("", 1.2) ) {
        gdjs.s183Code.condition0IsTrue_0.val = true;
        gdjs.s183Code.GDcaseObjects1[k] = gdjs.s183Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s183Code.GDcaseObjects1.length = k;}if (gdjs.s183Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s183.1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s183Code.GDbuttonObjects1);

gdjs.s183Code.condition0IsTrue_0.val = false;
{
gdjs.s183Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s183Code.mapOfGDgdjs_46s183Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s183Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s183Code.GDoffObjects1);

gdjs.s183Code.condition0IsTrue_0.val = false;
{
gdjs.s183Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s183Code.mapOfGDgdjs_46s183Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s183Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s183Code.GDonObjects1);

gdjs.s183Code.condition0IsTrue_0.val = false;
{
gdjs.s183Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s183Code.mapOfGDgdjs_46s183Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s183Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s183Code.condition0IsTrue_0.val = false;
{
gdjs.s183Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s183Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


};

gdjs.s183Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s183Code.GDcaseObjects1.length = 0;
gdjs.s183Code.GDcaseObjects2.length = 0;
gdjs.s183Code.GDimageObjects1.length = 0;
gdjs.s183Code.GDimageObjects2.length = 0;
gdjs.s183Code.GDoffObjects1.length = 0;
gdjs.s183Code.GDoffObjects2.length = 0;
gdjs.s183Code.GDonObjects1.length = 0;
gdjs.s183Code.GDonObjects2.length = 0;
gdjs.s183Code.GDstartObjects1.length = 0;
gdjs.s183Code.GDstartObjects2.length = 0;
gdjs.s183Code.GDBObjects1.length = 0;
gdjs.s183Code.GDBObjects2.length = 0;
gdjs.s183Code.GDblackObjects1.length = 0;
gdjs.s183Code.GDblackObjects2.length = 0;
gdjs.s183Code.GDAObjects1.length = 0;
gdjs.s183Code.GDAObjects2.length = 0;
gdjs.s183Code.GDbuttonObjects1.length = 0;
gdjs.s183Code.GDbuttonObjects2.length = 0;

gdjs.s183Code.eventsList0(runtimeScene);
return;

}

gdjs['s183Code'] = gdjs.s183Code;
