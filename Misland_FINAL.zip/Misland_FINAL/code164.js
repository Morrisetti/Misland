gdjs.s148_461Code = {};
gdjs.s148_461Code.GDcaseObjects1= [];
gdjs.s148_461Code.GDcaseObjects2= [];
gdjs.s148_461Code.GDimageObjects1= [];
gdjs.s148_461Code.GDimageObjects2= [];
gdjs.s148_461Code.GDoffObjects1= [];
gdjs.s148_461Code.GDoffObjects2= [];
gdjs.s148_461Code.GDonObjects1= [];
gdjs.s148_461Code.GDonObjects2= [];
gdjs.s148_461Code.GDstartObjects1= [];
gdjs.s148_461Code.GDstartObjects2= [];
gdjs.s148_461Code.GDBObjects1= [];
gdjs.s148_461Code.GDBObjects2= [];
gdjs.s148_461Code.GDblackObjects1= [];
gdjs.s148_461Code.GDblackObjects2= [];
gdjs.s148_461Code.GDAObjects1= [];
gdjs.s148_461Code.GDAObjects2= [];

gdjs.s148_461Code.conditionTrue_0 = {val:false};
gdjs.s148_461Code.condition0IsTrue_0 = {val:false};
gdjs.s148_461Code.condition1IsTrue_0 = {val:false};


gdjs.s148_461Code.mapOfGDgdjs_46s148_95461Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s148_461Code.GDAObjects1});gdjs.s148_461Code.mapOfGDgdjs_46s148_95461Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s148_461Code.GDoffObjects1});gdjs.s148_461Code.mapOfGDgdjs_46s148_95461Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s148_461Code.GDonObjects1});gdjs.s148_461Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s148_461Code.GDAObjects1);

gdjs.s148_461Code.condition0IsTrue_0.val = false;
{
gdjs.s148_461Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s148_461Code.mapOfGDgdjs_46s148_95461Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s148_461Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s149", false);
}}

}


{


gdjs.s148_461Code.condition0IsTrue_0.val = false;
{
gdjs.s148_461Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.s148_461Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s149", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s148_461Code.GDoffObjects1);

gdjs.s148_461Code.condition0IsTrue_0.val = false;
{
gdjs.s148_461Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s148_461Code.mapOfGDgdjs_46s148_95461Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s148_461Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s148_461Code.GDonObjects1);

gdjs.s148_461Code.condition0IsTrue_0.val = false;
{
gdjs.s148_461Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s148_461Code.mapOfGDgdjs_46s148_95461Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s148_461Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s148_461Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s148_461Code.GDcaseObjects1.length = 0;
gdjs.s148_461Code.GDcaseObjects2.length = 0;
gdjs.s148_461Code.GDimageObjects1.length = 0;
gdjs.s148_461Code.GDimageObjects2.length = 0;
gdjs.s148_461Code.GDoffObjects1.length = 0;
gdjs.s148_461Code.GDoffObjects2.length = 0;
gdjs.s148_461Code.GDonObjects1.length = 0;
gdjs.s148_461Code.GDonObjects2.length = 0;
gdjs.s148_461Code.GDstartObjects1.length = 0;
gdjs.s148_461Code.GDstartObjects2.length = 0;
gdjs.s148_461Code.GDBObjects1.length = 0;
gdjs.s148_461Code.GDBObjects2.length = 0;
gdjs.s148_461Code.GDblackObjects1.length = 0;
gdjs.s148_461Code.GDblackObjects2.length = 0;
gdjs.s148_461Code.GDAObjects1.length = 0;
gdjs.s148_461Code.GDAObjects2.length = 0;

gdjs.s148_461Code.eventsList0(runtimeScene);
return;

}

gdjs['s148_461Code'] = gdjs.s148_461Code;
