gdjs.s12Code = {};
gdjs.s12Code.GDcaseObjects1= [];
gdjs.s12Code.GDcaseObjects2= [];
gdjs.s12Code.GDoffObjects1= [];
gdjs.s12Code.GDoffObjects2= [];
gdjs.s12Code.GDonObjects1= [];
gdjs.s12Code.GDonObjects2= [];
gdjs.s12Code.GDstartObjects1= [];
gdjs.s12Code.GDstartObjects2= [];
gdjs.s12Code.GDBObjects1= [];
gdjs.s12Code.GDBObjects2= [];
gdjs.s12Code.GDAObjects1= [];
gdjs.s12Code.GDAObjects2= [];
gdjs.s12Code.GDbugzObjects1= [];
gdjs.s12Code.GDbugzObjects2= [];
gdjs.s12Code.GDDOWNbuttonObjects1= [];
gdjs.s12Code.GDDOWNbuttonObjects2= [];
gdjs.s12Code.GDblackObjects1= [];
gdjs.s12Code.GDblackObjects2= [];
gdjs.s12Code.GDDOWNcolObjects1= [];
gdjs.s12Code.GDDOWNcolObjects2= [];
gdjs.s12Code.GDUPbuttonObjects1= [];
gdjs.s12Code.GDUPbuttonObjects2= [];
gdjs.s12Code.GDUPcolObjects1= [];
gdjs.s12Code.GDUPcolObjects2= [];
gdjs.s12Code.GDLbuttonObjects1= [];
gdjs.s12Code.GDLbuttonObjects2= [];
gdjs.s12Code.GDLcolObjects1= [];
gdjs.s12Code.GDLcolObjects2= [];
gdjs.s12Code.GDRbuttonObjects1= [];
gdjs.s12Code.GDRbuttonObjects2= [];
gdjs.s12Code.GDTALK2Objects1= [];
gdjs.s12Code.GDTALK2Objects2= [];
gdjs.s12Code.GDExitObjects1= [];
gdjs.s12Code.GDExitObjects2= [];
gdjs.s12Code.GDRcolObjects1= [];
gdjs.s12Code.GDRcolObjects2= [];
gdjs.s12Code.GDchapter4Objects1= [];
gdjs.s12Code.GDchapter4Objects2= [];
gdjs.s12Code.GDchapter3Objects1= [];
gdjs.s12Code.GDchapter3Objects2= [];
gdjs.s12Code.GDchapter2Objects1= [];
gdjs.s12Code.GDchapter2Objects2= [];
gdjs.s12Code.GDchapter1Objects1= [];
gdjs.s12Code.GDchapter1Objects2= [];
gdjs.s12Code.GDBGObjects1= [];
gdjs.s12Code.GDBGObjects2= [];

gdjs.s12Code.conditionTrue_0 = {val:false};
gdjs.s12Code.condition0IsTrue_0 = {val:false};
gdjs.s12Code.condition1IsTrue_0 = {val:false};
gdjs.s12Code.condition2IsTrue_0 = {val:false};


gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDDOWNbuttonObjects1Objects = Hashtable.newFrom({"DOWNbutton": gdjs.s12Code.GDDOWNbuttonObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDUPbuttonObjects1Objects = Hashtable.newFrom({"UPbutton": gdjs.s12Code.GDUPbuttonObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDRbuttonObjects1Objects = Hashtable.newFrom({"Rbutton": gdjs.s12Code.GDRbuttonObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDLbuttonObjects1Objects = Hashtable.newFrom({"Lbutton": gdjs.s12Code.GDLbuttonObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s12Code.GDbugzObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDRcolObjects1Objects = Hashtable.newFrom({"Rcol": gdjs.s12Code.GDRcolObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s12Code.GDbugzObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDLcolObjects1Objects = Hashtable.newFrom({"Lcol": gdjs.s12Code.GDLcolObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s12Code.GDbugzObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDUPcolObjects1Objects = Hashtable.newFrom({"UPcol": gdjs.s12Code.GDUPcolObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s12Code.GDbugzObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s12Code.GDDOWNcolObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s12Code.GDbugzObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDDOWNcolObjects1Objects = Hashtable.newFrom({"DOWNcol": gdjs.s12Code.GDDOWNcolObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDBObjects1Objects = Hashtable.newFrom({"B": gdjs.s12Code.GDBObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDAObjects1Objects = Hashtable.newFrom({"A": gdjs.s12Code.GDAObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s12Code.GDoffObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s12Code.GDonObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s12Code.GDbugzObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.s12Code.GDExitObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects = Hashtable.newFrom({"bugz": gdjs.s12Code.GDbugzObjects1});gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDTALK2Objects1Objects = Hashtable.newFrom({"TALK2": gdjs.s12Code.GDTALK2Objects1});gdjs.s12Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DOWNbutton"), gdjs.s12Code.GDDOWNbuttonObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
gdjs.s12Code.condition1IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDDOWNbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s12Code.condition0IsTrue_0.val ) {
{
gdjs.s12Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s12Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPbutton"), gdjs.s12Code.GDUPbuttonObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
gdjs.s12Code.condition1IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDUPbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s12Code.condition0IsTrue_0.val ) {
{
gdjs.s12Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s12Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rbutton"), gdjs.s12Code.GDRbuttonObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
gdjs.s12Code.condition1IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDRbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s12Code.condition0IsTrue_0.val ) {
{
gdjs.s12Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s12Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].flipX(false);
}
}{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].setAnimation(3);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lbutton"), gdjs.s12Code.GDLbuttonObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
gdjs.s12Code.condition1IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDLbuttonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.s12Code.condition0IsTrue_0.val ) {
{
gdjs.s12Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.s12Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rcol"), gdjs.s12Code.GDRcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects, gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDRcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s12Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s12Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lcol"), gdjs.s12Code.GDLcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects, gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDLcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s12Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s12Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UPcol"), gdjs.s12Code.GDUPcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects, gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDUPcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s12Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s12Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s12Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects, gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s12Code.condition0IsTrue_0.val) {
/* Reuse gdjs.s12Code.GDbugzObjects1 */
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DOWNcol"), gdjs.s12Code.GDDOWNcolObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects, gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDDOWNcolObjects1Objects, false, runtimeScene, false);
}if (gdjs.s12Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("B"), gdjs.s12Code.GDBObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDBObjects1Objects, runtimeScene, true, false);
}if (gdjs.s12Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.s12Code.GDAObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDAObjects1Objects, runtimeScene, true, false);
}if (gdjs.s12Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s12Code.GDoffObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s12Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s12Code.GDonObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s12Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


gdjs.s12Code.condition0IsTrue_0.val = false;
gdjs.s12Code.condition1IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if ( gdjs.s12Code.condition0IsTrue_0.val ) {
{
gdjs.s12Code.condition1IsTrue_0.val = !(gdjs.evtTools.input.anyKeyPressed(runtimeScene));
}}
if (gdjs.s12Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s12Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].flipX(true);
}
}}

}


{


{
}

}


{


gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.s12Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].flipX(false);
}
}}

}


{


gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.s12Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].setAnimation(2);
}
}}

}


{


gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.s12Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);
{for(var i = 0, len = gdjs.s12Code.GDbugzObjects1.length ;i < len;++i) {
    gdjs.s12Code.GDbugzObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.s12Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects, gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.s12Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s13", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TALK2"), gdjs.s12Code.GDTALK2Objects1);
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);

gdjs.s12Code.condition0IsTrue_0.val = false;
{
gdjs.s12Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDbugzObjects1Objects, gdjs.s12Code.mapOfGDgdjs_46s12Code_46GDTALK2Objects1Objects, false, runtimeScene, false);
}if (gdjs.s12Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s4", false);
}}

}


{


{
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bugz"), gdjs.s12Code.GDbugzObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.s12Code.GDbugzObjects1.length !== 0 ? gdjs.s12Code.GDbugzObjects1[0] : null), true, "", 0);
}}

}


};

gdjs.s12Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s12Code.GDcaseObjects1.length = 0;
gdjs.s12Code.GDcaseObjects2.length = 0;
gdjs.s12Code.GDoffObjects1.length = 0;
gdjs.s12Code.GDoffObjects2.length = 0;
gdjs.s12Code.GDonObjects1.length = 0;
gdjs.s12Code.GDonObjects2.length = 0;
gdjs.s12Code.GDstartObjects1.length = 0;
gdjs.s12Code.GDstartObjects2.length = 0;
gdjs.s12Code.GDBObjects1.length = 0;
gdjs.s12Code.GDBObjects2.length = 0;
gdjs.s12Code.GDAObjects1.length = 0;
gdjs.s12Code.GDAObjects2.length = 0;
gdjs.s12Code.GDbugzObjects1.length = 0;
gdjs.s12Code.GDbugzObjects2.length = 0;
gdjs.s12Code.GDDOWNbuttonObjects1.length = 0;
gdjs.s12Code.GDDOWNbuttonObjects2.length = 0;
gdjs.s12Code.GDblackObjects1.length = 0;
gdjs.s12Code.GDblackObjects2.length = 0;
gdjs.s12Code.GDDOWNcolObjects1.length = 0;
gdjs.s12Code.GDDOWNcolObjects2.length = 0;
gdjs.s12Code.GDUPbuttonObjects1.length = 0;
gdjs.s12Code.GDUPbuttonObjects2.length = 0;
gdjs.s12Code.GDUPcolObjects1.length = 0;
gdjs.s12Code.GDUPcolObjects2.length = 0;
gdjs.s12Code.GDLbuttonObjects1.length = 0;
gdjs.s12Code.GDLbuttonObjects2.length = 0;
gdjs.s12Code.GDLcolObjects1.length = 0;
gdjs.s12Code.GDLcolObjects2.length = 0;
gdjs.s12Code.GDRbuttonObjects1.length = 0;
gdjs.s12Code.GDRbuttonObjects2.length = 0;
gdjs.s12Code.GDTALK2Objects1.length = 0;
gdjs.s12Code.GDTALK2Objects2.length = 0;
gdjs.s12Code.GDExitObjects1.length = 0;
gdjs.s12Code.GDExitObjects2.length = 0;
gdjs.s12Code.GDRcolObjects1.length = 0;
gdjs.s12Code.GDRcolObjects2.length = 0;
gdjs.s12Code.GDchapter4Objects1.length = 0;
gdjs.s12Code.GDchapter4Objects2.length = 0;
gdjs.s12Code.GDchapter3Objects1.length = 0;
gdjs.s12Code.GDchapter3Objects2.length = 0;
gdjs.s12Code.GDchapter2Objects1.length = 0;
gdjs.s12Code.GDchapter2Objects2.length = 0;
gdjs.s12Code.GDchapter1Objects1.length = 0;
gdjs.s12Code.GDchapter1Objects2.length = 0;
gdjs.s12Code.GDBGObjects1.length = 0;
gdjs.s12Code.GDBGObjects2.length = 0;

gdjs.s12Code.eventsList0(runtimeScene);
return;

}

gdjs['s12Code'] = gdjs.s12Code;
