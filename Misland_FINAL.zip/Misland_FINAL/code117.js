gdjs.s101Code = {};
gdjs.s101Code.GDcaseObjects1= [];
gdjs.s101Code.GDcaseObjects2= [];
gdjs.s101Code.GDimageObjects1= [];
gdjs.s101Code.GDimageObjects2= [];
gdjs.s101Code.GDoffObjects1= [];
gdjs.s101Code.GDoffObjects2= [];
gdjs.s101Code.GDonObjects1= [];
gdjs.s101Code.GDonObjects2= [];
gdjs.s101Code.GDstartObjects1= [];
gdjs.s101Code.GDstartObjects2= [];
gdjs.s101Code.GDBObjects1= [];
gdjs.s101Code.GDBObjects2= [];
gdjs.s101Code.GDblackObjects1= [];
gdjs.s101Code.GDblackObjects2= [];
gdjs.s101Code.GDAObjects1= [];
gdjs.s101Code.GDAObjects2= [];

gdjs.s101Code.conditionTrue_0 = {val:false};
gdjs.s101Code.condition0IsTrue_0 = {val:false};
gdjs.s101Code.condition1IsTrue_0 = {val:false};


gdjs.s101Code.mapOfGDgdjs_46s101Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s101Code.GDstartObjects1});gdjs.s101Code.mapOfGDgdjs_46s101Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s101Code.GDoffObjects1});gdjs.s101Code.mapOfGDgdjs_46s101Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s101Code.GDonObjects1});gdjs.s101Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s101Code.GDcaseObjects1);

gdjs.s101Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s101Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s101Code.GDcaseObjects1[i].timerElapsedTime("", 1.2) ) {
        gdjs.s101Code.condition0IsTrue_0.val = true;
        gdjs.s101Code.GDcaseObjects1[k] = gdjs.s101Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s101Code.GDcaseObjects1.length = k;}if (gdjs.s101Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s102", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s101Code.GDstartObjects1);

gdjs.s101Code.condition0IsTrue_0.val = false;
{
gdjs.s101Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s101Code.mapOfGDgdjs_46s101Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s101Code.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s101Code.GDoffObjects1);

gdjs.s101Code.condition0IsTrue_0.val = false;
{
gdjs.s101Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s101Code.mapOfGDgdjs_46s101Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s101Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s101Code.GDonObjects1);

gdjs.s101Code.condition0IsTrue_0.val = false;
{
gdjs.s101Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s101Code.mapOfGDgdjs_46s101Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s101Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


};

gdjs.s101Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s101Code.GDcaseObjects1.length = 0;
gdjs.s101Code.GDcaseObjects2.length = 0;
gdjs.s101Code.GDimageObjects1.length = 0;
gdjs.s101Code.GDimageObjects2.length = 0;
gdjs.s101Code.GDoffObjects1.length = 0;
gdjs.s101Code.GDoffObjects2.length = 0;
gdjs.s101Code.GDonObjects1.length = 0;
gdjs.s101Code.GDonObjects2.length = 0;
gdjs.s101Code.GDstartObjects1.length = 0;
gdjs.s101Code.GDstartObjects2.length = 0;
gdjs.s101Code.GDBObjects1.length = 0;
gdjs.s101Code.GDBObjects2.length = 0;
gdjs.s101Code.GDblackObjects1.length = 0;
gdjs.s101Code.GDblackObjects2.length = 0;
gdjs.s101Code.GDAObjects1.length = 0;
gdjs.s101Code.GDAObjects2.length = 0;

gdjs.s101Code.eventsList0(runtimeScene);
return;

}

gdjs['s101Code'] = gdjs.s101Code;
