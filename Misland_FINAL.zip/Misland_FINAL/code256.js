gdjs.s216Code = {};
gdjs.s216Code.GDcaseObjects1= [];
gdjs.s216Code.GDcaseObjects2= [];
gdjs.s216Code.GDimageObjects1= [];
gdjs.s216Code.GDimageObjects2= [];
gdjs.s216Code.GDoffObjects1= [];
gdjs.s216Code.GDoffObjects2= [];
gdjs.s216Code.GDonObjects1= [];
gdjs.s216Code.GDonObjects2= [];
gdjs.s216Code.GDstartObjects1= [];
gdjs.s216Code.GDstartObjects2= [];
gdjs.s216Code.GDBObjects1= [];
gdjs.s216Code.GDBObjects2= [];
gdjs.s216Code.GDblackObjects1= [];
gdjs.s216Code.GDblackObjects2= [];
gdjs.s216Code.GDAObjects1= [];
gdjs.s216Code.GDAObjects2= [];

gdjs.s216Code.conditionTrue_0 = {val:false};
gdjs.s216Code.condition0IsTrue_0 = {val:false};
gdjs.s216Code.condition1IsTrue_0 = {val:false};
gdjs.s216Code.conditionTrue_1 = {val:false};
gdjs.s216Code.condition0IsTrue_1 = {val:false};
gdjs.s216Code.condition1IsTrue_1 = {val:false};


gdjs.s216Code.mapOfGDgdjs_46s216Code_46GDstartObjects1Objects = Hashtable.newFrom({"start": gdjs.s216Code.GDstartObjects1});gdjs.s216Code.mapOfGDgdjs_46s216Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s216Code.GDoffObjects1});gdjs.s216Code.mapOfGDgdjs_46s216Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s216Code.GDonObjects1});gdjs.s216Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s216Code.condition0IsTrue_0.val = false;
{
{gdjs.s216Code.conditionTrue_1 = gdjs.s216Code.condition0IsTrue_0;
gdjs.s216Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(73742140);
}
}if (gdjs.s216Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\dead.mp3", false, 100, 1);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.s216Code.GDstartObjects1);

gdjs.s216Code.condition0IsTrue_0.val = false;
{
gdjs.s216Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s216Code.mapOfGDgdjs_46s216Code_46GDstartObjects1Objects, runtimeScene, true, false);
}if (gdjs.s216Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s215", false);
}}

}


{


gdjs.s216Code.condition0IsTrue_0.val = false;
{
gdjs.s216Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.s216Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s215", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s216Code.GDoffObjects1);

gdjs.s216Code.condition0IsTrue_0.val = false;
{
gdjs.s216Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s216Code.mapOfGDgdjs_46s216Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s216Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s216Code.GDonObjects1);

gdjs.s216Code.condition0IsTrue_0.val = false;
{
gdjs.s216Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s216Code.mapOfGDgdjs_46s216Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s216Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s216Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s216Code.GDcaseObjects1.length = 0;
gdjs.s216Code.GDcaseObjects2.length = 0;
gdjs.s216Code.GDimageObjects1.length = 0;
gdjs.s216Code.GDimageObjects2.length = 0;
gdjs.s216Code.GDoffObjects1.length = 0;
gdjs.s216Code.GDoffObjects2.length = 0;
gdjs.s216Code.GDonObjects1.length = 0;
gdjs.s216Code.GDonObjects2.length = 0;
gdjs.s216Code.GDstartObjects1.length = 0;
gdjs.s216Code.GDstartObjects2.length = 0;
gdjs.s216Code.GDBObjects1.length = 0;
gdjs.s216Code.GDBObjects2.length = 0;
gdjs.s216Code.GDblackObjects1.length = 0;
gdjs.s216Code.GDblackObjects2.length = 0;
gdjs.s216Code.GDAObjects1.length = 0;
gdjs.s216Code.GDAObjects2.length = 0;

gdjs.s216Code.eventsList0(runtimeScene);
return;

}

gdjs['s216Code'] = gdjs.s216Code;
