gdjs.s194Code = {};
gdjs.s194Code.GDcaseObjects1= [];
gdjs.s194Code.GDcaseObjects2= [];
gdjs.s194Code.GDimageObjects1= [];
gdjs.s194Code.GDimageObjects2= [];
gdjs.s194Code.GDoffObjects1= [];
gdjs.s194Code.GDoffObjects2= [];
gdjs.s194Code.GDonObjects1= [];
gdjs.s194Code.GDonObjects2= [];
gdjs.s194Code.GDstartObjects1= [];
gdjs.s194Code.GDstartObjects2= [];
gdjs.s194Code.GDBObjects1= [];
gdjs.s194Code.GDBObjects2= [];
gdjs.s194Code.GDblackObjects1= [];
gdjs.s194Code.GDblackObjects2= [];
gdjs.s194Code.GDAObjects1= [];
gdjs.s194Code.GDAObjects2= [];
gdjs.s194Code.GDbuttonObjects1= [];
gdjs.s194Code.GDbuttonObjects2= [];

gdjs.s194Code.conditionTrue_0 = {val:false};
gdjs.s194Code.condition0IsTrue_0 = {val:false};
gdjs.s194Code.condition1IsTrue_0 = {val:false};
gdjs.s194Code.conditionTrue_1 = {val:false};
gdjs.s194Code.condition0IsTrue_1 = {val:false};
gdjs.s194Code.condition1IsTrue_1 = {val:false};


gdjs.s194Code.mapOfGDgdjs_46s194Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s194Code.GDbuttonObjects1});gdjs.s194Code.mapOfGDgdjs_46s194Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s194Code.GDoffObjects1});gdjs.s194Code.mapOfGDgdjs_46s194Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s194Code.GDonObjects1});gdjs.s194Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs.s194Code.condition0IsTrue_0.val = false;
{
{gdjs.s194Code.conditionTrue_1 = gdjs.s194Code.condition0IsTrue_0;
gdjs.s194Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(73167292);
}
}if (gdjs.s194Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "music\\MP3s\\chapter5_v3.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s194Code.GDbuttonObjects1);

gdjs.s194Code.condition0IsTrue_0.val = false;
{
gdjs.s194Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s194Code.mapOfGDgdjs_46s194Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s194Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s195", false);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s194Code.GDoffObjects1);

gdjs.s194Code.condition0IsTrue_0.val = false;
{
gdjs.s194Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s194Code.mapOfGDgdjs_46s194Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s194Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s194Code.GDonObjects1);

gdjs.s194Code.condition0IsTrue_0.val = false;
{
gdjs.s194Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s194Code.mapOfGDgdjs_46s194Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s194Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s194Code.condition0IsTrue_0.val = false;
{
gdjs.s194Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
}if (gdjs.s194Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s195", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.s194Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s194Code.GDcaseObjects1.length = 0;
gdjs.s194Code.GDcaseObjects2.length = 0;
gdjs.s194Code.GDimageObjects1.length = 0;
gdjs.s194Code.GDimageObjects2.length = 0;
gdjs.s194Code.GDoffObjects1.length = 0;
gdjs.s194Code.GDoffObjects2.length = 0;
gdjs.s194Code.GDonObjects1.length = 0;
gdjs.s194Code.GDonObjects2.length = 0;
gdjs.s194Code.GDstartObjects1.length = 0;
gdjs.s194Code.GDstartObjects2.length = 0;
gdjs.s194Code.GDBObjects1.length = 0;
gdjs.s194Code.GDBObjects2.length = 0;
gdjs.s194Code.GDblackObjects1.length = 0;
gdjs.s194Code.GDblackObjects2.length = 0;
gdjs.s194Code.GDAObjects1.length = 0;
gdjs.s194Code.GDAObjects2.length = 0;
gdjs.s194Code.GDbuttonObjects1.length = 0;
gdjs.s194Code.GDbuttonObjects2.length = 0;

gdjs.s194Code.eventsList0(runtimeScene);
return;

}

gdjs['s194Code'] = gdjs.s194Code;
