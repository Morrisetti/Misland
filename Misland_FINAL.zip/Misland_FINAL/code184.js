gdjs.s167Code = {};
gdjs.s167Code.GDcaseObjects1= [];
gdjs.s167Code.GDcaseObjects2= [];
gdjs.s167Code.GDimageObjects1= [];
gdjs.s167Code.GDimageObjects2= [];
gdjs.s167Code.GDoffObjects1= [];
gdjs.s167Code.GDoffObjects2= [];
gdjs.s167Code.GDonObjects1= [];
gdjs.s167Code.GDonObjects2= [];
gdjs.s167Code.GDstartObjects1= [];
gdjs.s167Code.GDstartObjects2= [];
gdjs.s167Code.GDBObjects1= [];
gdjs.s167Code.GDBObjects2= [];
gdjs.s167Code.GDblackObjects1= [];
gdjs.s167Code.GDblackObjects2= [];
gdjs.s167Code.GDAObjects1= [];
gdjs.s167Code.GDAObjects2= [];
gdjs.s167Code.GDbuttonObjects1= [];
gdjs.s167Code.GDbuttonObjects2= [];

gdjs.s167Code.conditionTrue_0 = {val:false};
gdjs.s167Code.condition0IsTrue_0 = {val:false};
gdjs.s167Code.condition1IsTrue_0 = {val:false};


gdjs.s167Code.mapOfGDgdjs_46s167Code_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.s167Code.GDbuttonObjects1});gdjs.s167Code.mapOfGDgdjs_46s167Code_46GDoffObjects1Objects = Hashtable.newFrom({"off": gdjs.s167Code.GDoffObjects1});gdjs.s167Code.mapOfGDgdjs_46s167Code_46GDonObjects1Objects = Hashtable.newFrom({"on": gdjs.s167Code.GDonObjects1});gdjs.s167Code.eventsList0 = function(runtimeScene) {

{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("case"), gdjs.s167Code.GDcaseObjects1);

gdjs.s167Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.s167Code.GDcaseObjects1.length;i<l;++i) {
    if ( gdjs.s167Code.GDcaseObjects1[i].timerElapsedTime("", 0.5) ) {
        gdjs.s167Code.condition0IsTrue_0.val = true;
        gdjs.s167Code.GDcaseObjects1[k] = gdjs.s167Code.GDcaseObjects1[i];
        ++k;
    }
}
gdjs.s167Code.GDcaseObjects1.length = k;}if (gdjs.s167Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "s168", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.s167Code.GDbuttonObjects1);

gdjs.s167Code.condition0IsTrue_0.val = false;
{
gdjs.s167Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s167Code.mapOfGDgdjs_46s167Code_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s167Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("off"), gdjs.s167Code.GDoffObjects1);

gdjs.s167Code.condition0IsTrue_0.val = false;
{
gdjs.s167Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s167Code.mapOfGDgdjs_46s167Code_46GDoffObjects1Objects, runtimeScene, true, false);
}if (gdjs.s167Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("on"), gdjs.s167Code.GDonObjects1);

gdjs.s167Code.condition0IsTrue_0.val = false;
{
gdjs.s167Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.s167Code.mapOfGDgdjs_46s167Code_46GDonObjects1Objects, runtimeScene, true, false);
}if (gdjs.s167Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{


gdjs.s167Code.condition0IsTrue_0.val = false;
{
gdjs.s167Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.s167Code.condition0IsTrue_0.val) {
}

}


{


{
}

}


{


{
}

}


};

gdjs.s167Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.s167Code.GDcaseObjects1.length = 0;
gdjs.s167Code.GDcaseObjects2.length = 0;
gdjs.s167Code.GDimageObjects1.length = 0;
gdjs.s167Code.GDimageObjects2.length = 0;
gdjs.s167Code.GDoffObjects1.length = 0;
gdjs.s167Code.GDoffObjects2.length = 0;
gdjs.s167Code.GDonObjects1.length = 0;
gdjs.s167Code.GDonObjects2.length = 0;
gdjs.s167Code.GDstartObjects1.length = 0;
gdjs.s167Code.GDstartObjects2.length = 0;
gdjs.s167Code.GDBObjects1.length = 0;
gdjs.s167Code.GDBObjects2.length = 0;
gdjs.s167Code.GDblackObjects1.length = 0;
gdjs.s167Code.GDblackObjects2.length = 0;
gdjs.s167Code.GDAObjects1.length = 0;
gdjs.s167Code.GDAObjects2.length = 0;
gdjs.s167Code.GDbuttonObjects1.length = 0;
gdjs.s167Code.GDbuttonObjects2.length = 0;

gdjs.s167Code.eventsList0(runtimeScene);
return;

}

gdjs['s167Code'] = gdjs.s167Code;
